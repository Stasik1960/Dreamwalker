package dev.dreamwalker.bloodbornedw;
import dev.dreamwalker.bloodbornedw.block.DwBlocks;
import dev.dreamwalker.bloodbornedw.block.DwBlocks.Entry;
import dev.dreamwalker.bloodbornedw.visual.VisualService;
import dev.dreamwalker.bloodbornedw.command.VisualCommands;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1747;
import net.minecraft.class_1765;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2323;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
public final class BloodborneDw implements ModInitializer {
 public static final String ID="bloodborne_dw";
 @Override public void onInitialize() {
  DwBlocks.initialize();
  for(var entry:DwBlocks.entries()) {
   class_1792 item=entry.block() instanceof class_2323?new class_1765(entry.block(),new class_1792.class_1793()):new class_1747(entry.block(),new class_1792.class_1793());
   class_2378.method_10230(class_7923.field_41178,entry.identifier(),item);
  }
  VisualService.initialize(); VisualCommands.register();
  class_2378.method_10230(class_7923.field_44687,new class_2960(ID,"complete"),FabricItemGroup.builder()
   .method_47321(class_2561.method_43470("bloodborne-dw"))
   .method_47320(()->new class_1799(DwBlocks.entries().iterator().next().block()))
   .method_47317((context,entries)->{for(var e:DwBlocks.entries())entries.method_45421(e.block());}).method_47324());
 }
}
