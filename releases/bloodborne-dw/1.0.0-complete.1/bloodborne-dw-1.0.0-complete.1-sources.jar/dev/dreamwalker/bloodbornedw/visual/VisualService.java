package dev.dreamwalker.bloodbornedw.visual;

import dev.dreamwalker.bloodbornedw.block.DwBlocks;
import dev.dreamwalker.bloodbornedw.block.Visual;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2540;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.LinkedHashSet;

/** World-local, ordered cosmetic overrides.  Rules intentionally never mutate blocks. */
public final class VisualService {
    private static final String STATE_ID = "bloodborne_dw_visual_rules";
    private static final int MAX_RULES = 4096;
    public static final class_2960 SNAPSHOT_PACKET = new class_2960("bloodborne_dw", "visual_rules");
    private static final int MAX_SNAPSHOT_BYTES = 1024 * 1024;
    private static boolean initialized;

    private VisualService() { }

    public static void initialize() {
        if (initialized) return;
        initialized = true;
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sendSnapshot(handler.field_14140));
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> sendSnapshot(player));
    }
    public static boolean initialized() { return initialized; }

    public static Visual effective(class_3218 world, class_2338 pos, class_2680 state) {
        Visual result = state.method_28498(DwBlocks.VISUAL) ? state.method_11654(DwBlocks.VISUAL) : Visual.BASE;
        String id = id(state);
        if (id == null) return result;
        return state(world).compiled.effective(pos, id, result);
    }

    /** Safe, bounded copy suitable for a client packet or test persistence round-trip. */
    public static class_2487 snapshot(class_3218 world) { return writeRules(state(world).rules); }

    public static Visual effective(class_2487 snapshot, class_2338 pos, String id, Visual stored) {
        return compile(snapshot).effective(pos, id, stored);
    }

    /** Decode untrusted snapshot data once, before it reaches the block-render hot path. */
    public static RuleSet compile(class_2487 snapshot) {
        if (snapshot == null) return RuleSet.EMPTY;
        ArrayList<Rule> parsed = new ArrayList<>(); class_2499 list = snapshot.method_10554("rules", 10);
        for (int i = 0; i < list.size() && parsed.size() < MAX_RULES; i++) Rule.read(list.method_10602(i)).ifPresent(parsed::add);
        return new RuleSet(parsed);
    }

    public static void setPoint(class_3218 world, class_2338 pos, String id, Visual visual) {
        add(world, Rule.point(pos, id, visual));
    }

    public static void addAreaRule(class_3218 world, class_2338 first, class_2338 second, Collection<String> ids, Visual visual) {
        add(world, Rule.area(first, second, ids, visual));
    }

    public static void addAllRule(class_3218 world, Collection<String> ids, Visual visual) {
        add(world, Rule.all(ids, visual));
    }

    /** Replaces every prior rule; existing native state remains intact. */
    public static void reset(class_3218 world, Collection<String> ids, Visual visual) {
        RuleState state = state(world);
        List<Rule> proposed = List.of(Rule.all(ids, visual));
        validate(proposed);
        state.rules.clear();
        state.rules.addAll(proposed); state.rebuild();
        state.method_80();
        broadcast(world);
    }

    public static List<String> describe(class_3218 world, class_2338 pos, class_2680 blockState) {
        ArrayList<String> result = new ArrayList<>();
        result.add("stored=" + (blockState.method_28498(DwBlocks.VISUAL) ? blockState.method_11654(DwBlocks.VISUAL).method_15434() : "base"));
        result.add("effective=" + effective(world, pos, blockState).method_15434());
        result.add("rules=" + state(world).rules.size());
        return result;
    }

    public static String id(class_2680 state) {
        DwBlocks.Entry entry = DwBlocks.byBlock(state.method_26204()); return entry == null ? null : entry.id();
    }

    private static void add(class_3218 world, Rule rule) {
        RuleState state = state(world);
        if (state.rules.size() >= MAX_RULES) throw new IllegalStateException("Too many visual rules in this world");
        ArrayList<Rule> proposed = new ArrayList<>(state.rules); proposed.add(rule); validate(proposed);
        state.rules.add(rule); state.rebuild();
        state.method_80();
        broadcast(world);
    }

    private static RuleState state(class_3218 world) {
        return world.method_17983().method_17924(RuleState::fromNbt, RuleState::new, STATE_ID);
    }

    private static class_2487 writeRules(List<Rule> rules) {
        class_2487 nbt = new class_2487(); class_2499 list = new class_2499();
        for (Rule rule : rules) list.add(rule.write());
        nbt.method_10566("rules", list); return nbt;
    }
    private static void validate(List<Rule> rules) {
        if (rules.size() > MAX_RULES) throw new IllegalArgumentException("Too many visual rules");
        for (Rule rule : rules) for (String id : rule.ids) if (!id.matches("\\d{5}") || DwBlocks.byId(id) == null) throw new IllegalArgumentException("Unknown DW id");
        class_2540 buffer = new class_2540(Unpooled.buffer()); buffer.method_10794(writeRules(rules));
        if (buffer.writerIndex() > MAX_SNAPSHOT_BYTES - 256) throw new IllegalArgumentException("Visual rule snapshot exceeds 1 MiB");
    }
    private static void sendSnapshot(net.minecraft.class_3222 player) {
        class_2487 nbt = snapshot(player.method_51469()); class_2540 buffer = new class_2540(Unpooled.buffer());
        buffer.method_10788(player.method_51469().method_27983().method_29177().toString(), 128); buffer.method_10794(nbt);
        if (buffer.writerIndex() <= MAX_SNAPSHOT_BYTES) ServerPlayNetworking.send(player, SNAPSHOT_PACKET, buffer);
    }
    private static void broadcast(class_3218 world) { for (net.minecraft.class_3222 player : world.method_18456()) sendSnapshot(player); }

    private static final class RuleState extends class_18 {
        final List<Rule> rules = new ArrayList<>();
        volatile RuleSet compiled = RuleSet.EMPTY;
        static RuleState fromNbt(class_2487 nbt) {
            RuleState value = new RuleState();
            class_2499 list = nbt.method_10554("rules", 10);
            for (int i = 0; i < list.size() && value.rules.size() < MAX_RULES; i++) Rule.read(list.method_10602(i)).filter(rule -> rule.valid()).ifPresent(value.rules::add);
            value.rebuild(); return value;
        }
        @Override public class_2487 method_75(class_2487 nbt) {
            return writeRules(rules);
        }
        void rebuild() { compiled = new RuleSet(rules); }
    }

    private enum Kind { ALL, POINT, AREA }
    public static final class RuleSet {
        static final RuleSet EMPTY = new RuleSet(List.of());
        private final Rule[] newestFirst;
        private RuleSet(Collection<Rule> rules) { Rule[] ordered=rules.toArray(Rule[]::new); newestFirst=new Rule[ordered.length]; for(int i=0;i<ordered.length;i++) newestFirst[i]=ordered[ordered.length-1-i]; }
        public Visual effective(class_2338 pos, String id, Visual stored) { for(Rule rule:newestFirst) if(rule.matches(pos,id)) return rule.visual; return stored; }
        public int size() { return newestFirst.length; }
    }
    private static final class Rule {
        final Kind kind; final int x1, y1, z1, x2, y2, z2; final Set<String> ids; final Visual visual;
        private Rule(Kind kind, class_2338 first, class_2338 second, Collection<String> ids, Visual visual) {
            this.kind = kind; x1 = Math.min(first.method_10263(), second.method_10263()); y1 = Math.min(first.method_10264(), second.method_10264()); z1 = Math.min(first.method_10260(), second.method_10260());
            x2 = Math.max(first.method_10263(), second.method_10263()); y2 = Math.max(first.method_10264(), second.method_10264()); z2 = Math.max(first.method_10260(), second.method_10260());
            this.ids = Set.copyOf(new LinkedHashSet<>(ids)); this.visual = visual;
        }
        static Rule all(Collection<String> ids, Visual visual) { return new Rule(Kind.ALL, class_2338.field_10980, class_2338.field_10980, ids, visual); }
        static Rule point(class_2338 pos, String id, Visual visual) { return new Rule(Kind.POINT, pos, pos, List.of(id), visual); }
        static Rule area(class_2338 a, class_2338 b, Collection<String> ids, Visual visual) { return new Rule(Kind.AREA, a, b, ids, visual); }
        boolean matches(class_2338 pos, String id) {
            if (!ids.isEmpty() && !ids.contains(id)) return false;
            return kind == Kind.ALL || (pos.method_10263() >= x1 && pos.method_10263() <= x2 && pos.method_10264() >= y1 && pos.method_10264() <= y2 && pos.method_10260() >= z1 && pos.method_10260() <= z2);
        }
        boolean valid() { return ids.stream().allMatch(id -> id.matches("\\d{5}") && DwBlocks.byId(id) != null); }
        class_2487 write() { class_2487 n = new class_2487(); n.method_10582("kind", kind.name()); n.method_10569("x1",x1); n.method_10569("y1",y1); n.method_10569("z1",z1); n.method_10569("x2",x2); n.method_10569("y2",y2); n.method_10569("z2",z2); n.method_10582("visual",visual.method_15434()); n.method_10582("ids",String.join(",",ids)); return n; }
        static java.util.Optional<Rule> read(class_2487 n) { try { Kind k=Kind.valueOf(n.method_10558("kind")); Visual v="alt".equals(n.method_10558("visual"))?Visual.ALT:Visual.BASE; List<String> ids=n.method_10558("ids").isEmpty()?List.of():List.of(n.method_10558("ids").split(",")); return java.util.Optional.of(new Rule(k,new class_2338(n.method_10550("x1"),n.method_10550("y1"),n.method_10550("z1")),new class_2338(n.method_10550("x2"),n.method_10550("y2"),n.method_10550("z2")),ids,v)); } catch (RuntimeException ignored) { return java.util.Optional.empty(); } }
    }
}
