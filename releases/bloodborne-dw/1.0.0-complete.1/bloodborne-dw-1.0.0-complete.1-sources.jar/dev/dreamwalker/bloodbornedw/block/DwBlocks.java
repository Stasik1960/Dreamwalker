package dev.dreamwalker.bloodbornedw.block;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1959;
import net.minecraft.class_2217;
import net.minecraft.class_2221;
import net.minecraft.class_2222;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2292;
import net.minecraft.class_2309;
import net.minecraft.class_2313;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2346;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2356;
import net.minecraft.class_2362;
import net.minecraft.class_2366;
import net.minecraft.class_2368;
import net.minecraft.class_2369;
import net.minecraft.class_2372;
import net.minecraft.class_2373;
import net.minecraft.class_2378;
import net.minecraft.class_2380;
import net.minecraft.class_2381;
import net.minecraft.class_2384;
import net.minecraft.class_2386;
import net.minecraft.class_2389;
import net.minecraft.class_2397;
import net.minecraft.class_2418;
import net.minecraft.class_2431;
import net.minecraft.class_2440;
import net.minecraft.class_2442;
import net.minecraft.class_2443;
import net.minecraft.class_2449;
import net.minecraft.class_2465;
import net.minecraft.class_2468;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2488;
import net.minecraft.class_2502;
import net.minecraft.class_2504;
import net.minecraft.class_2506;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2557;
import net.minecraft.class_2563;
import net.minecraft.class_2565;
import net.minecraft.class_2647;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2682;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3715;
import net.minecraft.class_3726;
import net.minecraft.class_3749;
import net.minecraft.class_4481;
import net.minecraft.class_4719;
import net.minecraft.class_4773;
import net.minecraft.class_4970;
import net.minecraft.class_5172;
import net.minecraft.class_5542;
import net.minecraft.class_5544;
import net.minecraft.class_5555;
import net.minecraft.class_5620;
import net.minecraft.class_5635;
import net.minecraft.class_5812;
import net.minecraft.class_5814;
import net.minecraft.class_5815;
import net.minecraft.class_5954;
import net.minecraft.class_5955;
import net.minecraft.class_6017;
import net.minecraft.class_6348;
import net.minecraft.class_6377;
import net.minecraft.class_7923;
import net.minecraft.class_8177;
import dev.dreamwalker.bloodbornedw.mixin.AbstractBlockSettingsAccessor;
import dev.dreamwalker.bloodbornedw.mixin.AbstractBlockAccessor;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/** Registers one native vanilla-family carrier for every catalog block. */
public final class DwBlocks {
    public static final class_2754<Visual> VISUAL = class_2754.method_11850("visual", Visual.class);
    private static final Map<class_2960, Entry> BY_SOURCE = new LinkedHashMap<>();
    private static final Map<String, Entry> BY_ID = new LinkedHashMap<>();
    private static final Map<class_2248, Entry> BY_BLOCK = new LinkedHashMap<>();
    private static final Map<class_2248, Entry> BY_BLOCK_IDENTITY = new IdentityHashMap<>();
    private static boolean initialized;

    private DwBlocks() {}

    public static synchronized void initialize() {
        if (initialized) return;
        Catalog catalog = readCatalog();
        if (catalog.schema_version != 1 || catalog.blocks == null) throw new IllegalStateException("Unsupported DW block catalog");
        List<PendingEntry> pending = new ArrayList<>();
        List<String> unsupported = new ArrayList<>();
        for (CatalogBlock specification : catalog.blocks) {
            try { pending.add(prepare(specification)); }
            catch (IllegalStateException exception) { unsupported.add(exception.getMessage()); }
        }
        if (!unsupported.isEmpty()) throw new IllegalStateException("DW catalog preflight failed:\n" + String.join("\n", unsupported));
        for (PendingEntry entry : pending) register(entry);
        validateShapes();
        initialized = true;
    }

    public static Entry bySource(class_2960 source) { initialize(); return BY_SOURCE.get(source); }
    public static Entry byId(String id) { initialize(); return BY_ID.get(id); }
    public static Collection<Entry> entries() { initialize(); return Collections.unmodifiableCollection(BY_ID.values()); }
    public static boolean isDw(class_2248 block) {
        return BY_BLOCK_IDENTITY.containsKey(block);
    }
    public static Entry byBlock(class_2248 block) { initialize(); return BY_BLOCK_IDENTITY.get(block); }
    public static boolean isCarrierOf(class_2248 carrier, class_2248 source) {
        Entry entry = BY_BLOCK.get(carrier);
        return entry != null && entry.sourceBlock == source;
    }

    /** Converts a DW carrier state back to its original vanilla state, excluding {@link #VISUAL}. */
    public static class_2680 sourceState(class_2680 state) {
        initialize();
        Entry entry = BY_BLOCK.get(state.method_26204());
        if (entry == null) return state;
        class_2680 result = entry.sourceBlock.method_9564();
        for (class_2769<?> property : state.method_28501()) result = copy(result, state, property);
        return result;
    }

    /** Converts a vanilla source state to this catalog's carrier state with the base visual. */
    public static class_2680 carrierState(class_2680 state) {
        Entry entry = bySource(class_7923.field_41175.method_10221(state.method_26204()));
        if (entry == null) return state;
        class_2680 result = entry.block.method_9564();
        for (class_2769<?> property : state.method_28501()) result = copy(result, state, property);
        return result.method_11657(VISUAL, Visual.BASE);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static class_2680 copy(class_2680 result, class_2680 source, class_2769 property) {
        return result.method_28498(property) ? result.method_11657(property, source.method_11654(property)) : result;
    }

    private static PendingEntry prepare(CatalogBlock specification) {
        if (specification.id == null || !specification.id.matches("\\d{5}")) throw new IllegalStateException("Invalid DW block id: " + specification.id);
        class_2960 sourceId = class_2960.method_12829(specification.source);
        if (sourceId == null || !"minecraft".equals(sourceId.method_12836())) throw new IllegalStateException("Invalid vanilla source for " + specification.id);
        if (BY_ID.containsKey(specification.id) || BY_SOURCE.containsKey(sourceId)) throw new IllegalStateException("Duplicate DW block catalog entry: " + specification.id);
        class_2248 source = class_7923.field_41175.method_17966(sourceId).orElseThrow(() -> new IllegalStateException("Unknown vanilla source " + sourceId));
        class_2248 carrier = createCarrier(source, sourceId, specification);
        class_2680 nativeDefault = carrier.method_9564();
        for (class_2769<?> property : source.method_9564().method_28501()) nativeDefault = copy(nativeDefault, source.method_9564(), property);
        ((dev.dreamwalker.bloodbornedw.mixin.BlockDefaultStateAccessor) carrier).bloodborneDw$setDefaultState(nativeDefault.method_11657(VISUAL, Visual.BASE));
        return new PendingEntry(specification, sourceId, source, carrier);
    }

    private static void register(PendingEntry pending) {
        CatalogBlock specification = pending.specification;
        class_2960 sourceId = pending.sourceId;
        class_2248 source = pending.source;
        class_2248 carrier = pending.carrier;
        class_2960 id = new class_2960("bloodborne_dw", specification.id);
        class_2378.method_10230(class_7923.field_41175, id, carrier);
        Entry entry = new Entry(specification.id, id, sourceId, source, carrier, specification.frequency, specification.name_ru, specification.name_en);
        BY_ID.put(entry.id, entry);
        BY_SOURCE.put(sourceId, entry);
        BY_BLOCK.put(carrier, entry);
        BY_BLOCK_IDENTITY.put(carrier, entry);
    }

    private static class_2248 createCarrier(class_2248 source, class_2960 sourceId, CatalogBlock specification) {
        class_4970.class_2251 settings = class_4970.class_2251.method_9630(source);
        AbstractBlockSettingsAccessor original = (AbstractBlockSettingsAccessor) (Object) ((AbstractBlockAccessor) source).bloodborneDw$getSettings();
        AbstractBlockSettingsAccessor target = (AbstractBlockSettingsAccessor) (Object) settings;
        target.bloodborneDw$setAllowsSpawningPredicate(original.bloodborneDw$allowsSpawningPredicate());
        target.bloodborneDw$setSolidBlockPredicate(original.bloodborneDw$solidBlockPredicate());
        target.bloodborneDw$setSuffocationPredicate(original.bloodborneDw$suffocationPredicate());
        target.bloodborneDw$setBlockVisionPredicate(original.bloodborneDw$blockVisionPredicate());
        target.bloodborneDw$setPostProcessPredicate(original.bloodborneDw$postProcessPredicate());
        settings.method_23352(source.method_23350());
        ((AbstractBlockSettingsAccessor) (Object) settings).bloodborneDw$setLootTableId(new class_2960("bloodborne_dw", "blocks/" + specification.id));
        if (specification.has_alpha || "translucent".equals(specification.render_layer)) settings.method_22488();
        return DwCarrierState.create(() -> {
            if (source instanceof class_5814 oxidizableStairs) return new DwOxidizableStairsBlock(oxidizableStairs.method_33634(), stairsBaseState(source), settings);
            if (source instanceof class_2510) return new DwStairsBlock(stairsBaseState(source), settings);
            if (source instanceof class_2354) return new class_2354(settings);
            if (source instanceof class_2544) return new DwWallBlock(settings);
            if (source instanceof class_2323 door) return new DwDoorBlock(settings, door.method_51169());
            if (source instanceof class_2269) return new DwButtonBlock(settings, blockSetType(sourceId), wooden(sourceId) ? 30 : 20, wooden(sourceId));
            if (source instanceof class_2557) return new DwWeightedPressurePlateBlock(sourceId, settings, blockSetType(sourceId));
            if (source instanceof class_2440) return new DwPressurePlateBlock(wooden(sourceId) ? class_2440.class_2441.field_11361 : class_2440.class_2441.field_11362, settings, blockSetType(sourceId));
            if (source instanceof class_2482) return new class_2482(settings);
            if (source instanceof class_2349) return new class_2349(settings, woodType(sourceId));
            if (source instanceof class_2533) return new DwTrapdoorBlock(settings, blockSetType(sourceId));
            if (source instanceof class_3749) return new class_3749(settings);
            if (source instanceof class_2362 pot) return new DwFlowerPotBlock(pot.method_16231(), settings);
            if (source instanceof class_2563 flower) return new class_2563(flower.method_10188(), settings);
            if (source instanceof class_2356 flower) return new class_2356(flower.method_10188(), flowerDurationSeconds(flower), settings);
            if (source instanceof class_6348 infested) return new class_6348(infested.method_10271(), settings);
            if (source instanceof class_2384 infested) return new class_2384(infested.method_10271(), settings);
            if (source instanceof class_5815) return new class_5815(dyeColor(sourceId), settings);
            if (source instanceof class_2473 sapling) return new DwSaplingBlock(typedField(sapling, class_2473.class, class_2647.class), settings);
            if (source instanceof class_2449) return new class_2449(settings);
            if (source instanceof class_2292) return new DwConcretePowderBlock(hardenedConcrete(sourceId), settings);
            if (source.getClass() == class_2431.class) return new class_2431(settings, typedField(source, class_2431.class, class_6017.class));
            if (source instanceof class_5812 oxidizable) return new DwOxidizableBlock(oxidizable.method_33632(), settings);
            if (source instanceof class_2366) return new class_2366(settings);
            if (source instanceof class_2381) return new class_2381(settings);
            if (source instanceof class_4773) return new DwNetherrackBlock(settings);
            if (source instanceof class_2565) return new DwWetSpongeBlock(settings);
            if (source instanceof class_2502) return new DwSpongeBlock(settings);
            if (source instanceof class_2468) return new class_2468(sourceId.method_12832().startsWith("red_") ? 11098145 : 14406560, settings);
            if (source instanceof class_5954) return new class_5954(settings);
            if (source.getClass() == class_2346.class) return new class_2346(settings);
            if (source instanceof class_2380) return new class_2380(settings);
            if (source instanceof class_5172) return new DwChainBlock(settings);
            if (source.getClass() == class_2465.class) return new class_2465(settings);
            if (source instanceof class_2397) return new DwLeavesBlock(settings);
            if (source instanceof class_2386) return new DwIceBlock(settings);
            if (source instanceof class_5555) return new class_5555(settings);
            if (source instanceof class_2506) return new class_2506(dyeColor(sourceId), settings);
            if (source instanceof class_2368) return new class_2368(settings);
            if (source.getClass() == class_2373.class) return new DwTransparentBlock(settings);
            if (source instanceof class_2372) return new DwGrassBlock(settings);
            if (source instanceof class_2418) return new DwMyceliumBlock(settings);
            if (source instanceof class_2369) return new DwDirtPathBlock(settings);
            if (source instanceof class_2344) return new DwFarmlandBlock(settings);
            if (source instanceof class_2488) return new DwSnowBlock(settings);
            if (source instanceof class_5635) return new class_5635(settings);
            if (source instanceof class_6377) return new class_6377(settings, precipitation -> precipitation == class_1959.class_1963.field_9383, class_5620.field_28011);
            if (source instanceof class_2504 pane) return new class_2504(pane.method_10622(), settings);
            if (source instanceof class_2389) return new DwPaneBlock(settings);
            if (source instanceof class_2313) return new class_2313(settings);
            if (source instanceof class_2442) return new DwPoweredRailBlock(settings);
            if (source instanceof class_2443) return new DwRailBlock(settings);
            if (source instanceof class_4481) return new class_4481(settings);
            if (source instanceof class_3715) return new DwLecternBlock(settings);
            if (source instanceof class_2309) return new class_2309(settings);
            if (source instanceof class_2217) return new DwDeadCoralBlock(settings);
            if (source instanceof class_2222) return new DwDeadCoralWallFanBlock(settings);
            if (source instanceof class_2221) return new DwDeadCoralFanBlock(settings);
            if (source instanceof class_5544) return new class_5544(settings);
            if (source instanceof class_5542) return new DwAmethystClusterBlock(sourceId, settings);
            if (source.getClass() == class_2248.class) return new class_2248(settings);
            return sameClassSettingsCarrier(source, sourceId, settings);
        });
    }

    private static class_2248 sameClassSettingsCarrier(class_2248 source, class_2960 sourceId, class_4970.class_2251 settings) {
        try {
            Constructor<? extends class_2248> constructor = source.getClass().asSubclass(class_2248.class).getDeclaredConstructor(class_4970.class_2251.class);
            constructor.setAccessible(true);
            return constructor.newInstance(settings);
        } catch (ReflectiveOperationException | SecurityException exception) {
            throw new IllegalStateException("DW catalog source needs a native carrier factory: " + sourceId + " (" + source.getClass().getSimpleName() + ")", exception);
        }
    }

    private static void validateShapes() {
        for (Entry entry : BY_ID.values()) {
            for (class_2680 state : entry.block.method_9595().method_11662()) {
                try {
                    if (state.method_26194(class_2682.field_12294, class_2338.field_10980, class_3726.method_16194()) == null
                            || state.method_26172(class_2682.field_12294, class_2338.field_10980, class_3726.method_16194()) == null) {
                        throw new IllegalStateException("null shape");
                    }
                } catch (RuntimeException exception) {
                    throw new IllegalStateException("Invalid native carrier shape for " + entry.identifier, exception);
                }
            }
        }
    }

    private static class_2680 stairsBaseState(class_2248 source) {
        return typedField(source, class_2510.class, class_2680.class);
    }

    /** Production mappings rename fields, so select the sole constructor value by type. */
    private static <T> T typedField(Object source, Class<?> owner, Class<T> type) {
        try {
            java.lang.reflect.Field match = null;
            for (var field : owner.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(field.getModifiers()) || !type.isAssignableFrom(field.getType())) continue;
                if (match != null) throw new IllegalStateException("Ambiguous " + type.getSimpleName() + " field on " + owner.getSimpleName());
                match = field;
            }
            if (match == null) throw new IllegalStateException("Missing " + type.getSimpleName() + " field on " + owner.getSimpleName());
            match.setAccessible(true);
            return type.cast(match.get(source));
        } catch (IllegalAccessException | SecurityException exception) {
            throw new IllegalStateException("Cannot read native constructor field from " + owner.getSimpleName(), exception);
        }
    }

    private static class_4719 woodType(class_2960 id) {
        String path = id.method_12832();
        if (path.startsWith("spruce_")) return class_4719.field_21677;
        if (path.startsWith("birch_")) return class_4719.field_21678;
        if (path.startsWith("acacia_")) return class_4719.field_21679;
        if (path.startsWith("cherry_")) return class_4719.field_42837;
        if (path.startsWith("jungle_")) return class_4719.field_21680;
        if (path.startsWith("dark_oak_")) return class_4719.field_21681;
        if (path.startsWith("crimson_")) return class_4719.field_22183;
        if (path.startsWith("warped_")) return class_4719.field_22184;
        if (path.startsWith("mangrove_")) return class_4719.field_37657;
        if (path.startsWith("bamboo_")) return class_4719.field_40350;
        return class_4719.field_21676;
    }

    private static class_8177 blockSetType(class_2960 id) {
        String path = id.method_12832();
        if (path.startsWith("iron_")) return class_8177.field_42819;
        if (path.startsWith("gold_")) return class_8177.field_42820;
        if (path.startsWith("stone_")) return class_8177.field_42821;
        if (path.startsWith("polished_blackstone_")) return class_8177.field_42822;
        return woodType(id).comp_1300();
    }

    private static boolean wooden(class_2960 id) {
        String path = id.method_12832();
        return !(path.startsWith("stone_") || path.startsWith("polished_blackstone_") || path.startsWith("iron_") || path.startsWith("gold_"));
    }

    private static class_1767 dyeColor(class_2960 id) {
        String path = id.method_12832();
        for (class_1767 color : class_1767.values()) if (path.startsWith(color.method_7792() + "_")) return color;
        throw new IllegalStateException("Missing dye color in source id " + id);
    }

    private static class_2248 hardenedConcrete(class_2960 id) {
        String path = id.method_12832();
        class_2960 concrete = new class_2960("minecraft", path.substring(0, path.length() - "_powder".length()));
        return class_7923.field_41175.method_17966(concrete).orElseThrow(() -> new IllegalStateException("Missing hardened concrete for " + id));
    }

    /** FlowerBlock stores non-instant stew durations internally in ticks. */
    private static int flowerDurationSeconds(class_2356 flower) {
        int duration = flower.method_10187();
        return flower.method_10188().method_5561() ? duration : duration / 20;
    }

    private static Catalog readCatalog() {
        var input = DwBlocks.class.getResourceAsStream("/assets/bloodborne_dw/catalog.json");
        if (input == null) throw new IllegalStateException("Missing DW block catalog");
        try (var reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
            return new Gson().fromJson(reader, Catalog.class);
        } catch (JsonParseException | java.io.IOException exception) {
            throw new IllegalStateException("Invalid DW block catalog", exception);
        }
    }

    public static final class Entry {
        private final String id;
        private final class_2960 identifier;
        private final class_2960 source;
        private final class_2248 sourceBlock;
        private final class_2248 block;
        private final int frequency;
        private final String nameRu;
        private final String nameEn;

        private Entry(String id, class_2960 identifier, class_2960 source, class_2248 sourceBlock, class_2248 block, int frequency, String nameRu, String nameEn) {
            this.id = id; this.identifier = identifier; this.source = source; this.sourceBlock = sourceBlock; this.block = block;
            this.frequency = frequency; this.nameRu = nameRu; this.nameEn = nameEn;
        }
        public String id() { return id; }
        public class_2960 identifier() { return identifier; }
        public class_2960 source() { return source; }
        public class_2248 sourceBlock() { return sourceBlock; }
        public class_2248 block() { return block; }
        public int frequency() { return frequency; }
        public String nameRu() { return nameRu; }
        public String nameEn() { return nameEn; }
    }

    private static final class Catalog { int schema_version; List<CatalogBlock> blocks = new ArrayList<>(); }
    private static final class CatalogBlock { String id; String source; int frequency; String name_ru; String name_en; boolean has_alpha; String render_layer; }
    private record PendingEntry(CatalogBlock specification, class_2960 sourceId, class_2248 source, class_2248 carrier) {}

    private static final class DwStairsBlock extends class_2510 {
        private DwStairsBlock(class_2680 base, class_4970.class_2251 settings) { super(base, settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwWallBlock extends class_2544 {
        private DwWallBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) { return super.method_9530(base(state), world, pos, context); }
        @Override public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) { return super.method_9549(base(state), world, pos, context); }
        @Override public class_265 method_9571(class_2680 state, class_1922 world, class_2338 pos) { return super.method_9571(base(state), world, pos); }
        private class_2680 base(class_2680 state) { return state.method_11657(VISUAL, Visual.BASE); }
    }
    private static final class DwOxidizableStairsBlock extends class_5814 {
        private DwOxidizableStairsBlock(class_5955.class_5811 level, class_2680 base, class_4970.class_2251 settings) { super(level, base, settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwOxidizableBlock extends class_5812 {
        private DwOxidizableBlock(class_5955.class_5811 level, class_4970.class_2251 settings) { super(level, settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwDoorBlock extends class_2323 {
        private DwDoorBlock(class_4970.class_2251 settings, class_8177 type) { super(settings, type); }
    }
    private static final class DwFlowerPotBlock extends class_2362 {
        private DwFlowerPotBlock(class_2248 content, class_4970.class_2251 settings) { super(content, settings); }
        @Override public net.minecraft.class_1269 method_9534(class_2680 state, net.minecraft.class_1937 world, class_2338 pos, net.minecraft.class_1657 player, net.minecraft.class_1268 hand, net.minecraft.class_3965 hit) {
            var stack = player.method_5998(hand);
            class_2248 plant = stack.method_7909() instanceof net.minecraft.class_1747 item ? item.method_7711() : class_2246.field_10124;
            Entry plantEntry = byBlock(plant);
            if (plantEntry != null) plant = plantEntry.sourceBlock();
            Entry potted = null;
            for (Entry entry : entries()) if (entry.sourceBlock() instanceof class_2362 pot && pot.method_16231() == plant && plant != class_2246.field_10124) { potted = entry; break; }
            if (potted != null) {
                if (method_16231() != class_2246.field_10124) return net.minecraft.class_1269.field_21466;
                world.method_8652(pos, potted.block().method_9564().method_11657(VISUAL, state.method_11654(VISUAL)), class_2248.field_31036);
                player.method_7281(net.minecraft.class_3468.field_15412);
                if (!player.method_31549().field_7477) stack.method_7934(1);
                world.method_33596(player, net.minecraft.class_5712.field_28733, pos);
                return net.minecraft.class_1269.method_29236(world.field_9236);
            }
            // Native fallback retains compatibility with plants supplied by other mods.
            var result = super.method_9534(state, world, pos, player, hand, hit);
            class_2680 after = world.method_8320(pos);
            class_2680 carrier = carrierState(after);
            if (carrier != after && carrier.method_28498(VISUAL)) world.method_8652(pos, carrier.method_11657(VISUAL, state.method_11654(VISUAL)), class_2248.field_31036);
            return result;
        }
    }
    private static final class DwNetherrackBlock extends class_4773 {
        private DwNetherrackBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public boolean method_9651(net.minecraft.class_4538 world, class_2338 pos, class_2680 state, boolean isClient) { return false; }
    }
    private static final class DwButtonBlock extends class_2269 {
        private DwButtonBlock(class_4970.class_2251 settings, class_8177 type, int ticks, boolean wooden) { super(settings, type, ticks, wooden); }
    }
    private static final class DwPressurePlateBlock extends class_2440 {
        private DwPressurePlateBlock(class_2441 rule, class_4970.class_2251 settings, class_8177 type) { super(rule, settings, type); }
    }
    private static final class DwWeightedPressurePlateBlock extends class_2557 {
        private DwWeightedPressurePlateBlock(class_2960 id, class_4970.class_2251 settings, class_8177 type) { super(id.method_12832().startsWith("heavy_") ? 150 : 15, settings, type); }
    }
    private static final class DwTrapdoorBlock extends class_2533 {
        private DwTrapdoorBlock(class_4970.class_2251 settings, class_8177 type) { super(settings, type); }
    }
    private static final class DwSnowBlock extends class_2488 {
        private DwSnowBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwDirtPathBlock extends class_2369 {
        private DwDirtPathBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public class_2680 method_9605(net.minecraft.class_1750 context) { return method_9564(); }
        @Override public void method_9588(class_2680 state, net.minecraft.class_3218 world, class_2338 pos, net.minecraft.class_5819 random) { }
    }
    /** Keep architectural artwork stable; retain the native collision and fall damage. */
    private static final class DwFarmlandBlock extends class_2344 {
        private DwFarmlandBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public class_2680 method_9605(net.minecraft.class_1750 context) { return method_9564(); }
        @Override public boolean method_9542(class_2680 state) { return false; }
        @Override public void method_9514(class_2680 state, net.minecraft.class_3218 world, class_2338 pos, net.minecraft.class_5819 random) { }
        @Override public void method_9588(class_2680 state, net.minecraft.class_3218 world, class_2338 pos, net.minecraft.class_5819 random) { }
        @Override public void method_9554(net.minecraft.class_1937 world, class_2680 state, class_2338 pos, net.minecraft.class_1297 entity, float distance) {
            entity.method_5747(distance, 1.0F, entity.method_48923().method_48827());
        }
    }
    private static final class DwConcretePowderBlock extends class_2292 {
        private DwConcretePowderBlock(class_2248 hardened, class_4970.class_2251 settings) { super(hardened, settings); }
        @Override public class_2680 method_9605(net.minecraft.class_1750 context) { return method_9564(); }
        @Override public class_2680 method_9559(class_2680 state, net.minecraft.class_2350 direction, class_2680 neighbor, net.minecraft.class_1936 world, class_2338 pos, class_2338 neighborPos) {
            world.method_39279(pos, this, method_26154());
            return state;
        }
        @Override public void method_10127(net.minecraft.class_1937 world, class_2338 pos, class_2680 state, class_2680 replaced, net.minecraft.class_1540 entity) { }
    }
    private static final class DwWetSpongeBlock extends class_2565 {
        private DwWetSpongeBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public void method_9615(class_2680 state, net.minecraft.class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) { }
    }
    private static final class DwSpongeBlock extends class_2502 {
        private DwSpongeBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public void method_9615(class_2680 state, net.minecraft.class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) { }
        @Override public void method_9612(class_2680 state, net.minecraft.class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) { }
    }
    private static final class DwSaplingBlock extends class_2473 {
        private DwSaplingBlock(class_2647 generator, class_4970.class_2251 settings) { super(generator, settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwLeavesBlock extends class_2397 {
        private DwLeavesBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwGrassBlock extends class_2372 {
        private DwGrassBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwMyceliumBlock extends class_2418 {
        private DwMyceliumBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwIceBlock extends class_2386 {
        private DwIceBlock(class_4970.class_2251 settings) { super(settings); }
        @Override public boolean method_9542(class_2680 state) { return false; }
    }
    private static final class DwPaneBlock extends class_2389 {
        private DwPaneBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwLecternBlock extends class_3715 {
        private DwLecternBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwDeadCoralBlock extends class_2217 {
        private DwDeadCoralBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwDeadCoralFanBlock extends class_2221 {
        private DwDeadCoralFanBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwDeadCoralWallFanBlock extends class_2222 {
        private DwDeadCoralWallFanBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwTransparentBlock extends class_2373 {
        private DwTransparentBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwRailBlock extends class_2443 {
        private DwRailBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwPoweredRailBlock extends class_2442 {
        private DwPoweredRailBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwChainBlock extends class_5172 {
        private DwChainBlock(class_4970.class_2251 settings) { super(settings); }
    }
    private static final class DwAmethystClusterBlock extends class_5542 {
        private DwAmethystClusterBlock(class_2960 id, class_4970.class_2251 settings) { super(amethystHeight(id), amethystOffset(id), settings); }
        private static int amethystHeight(class_2960 id) { return id.method_12832().equals("small_amethyst_bud") ? 3 : id.method_12832().equals("medium_amethyst_bud") ? 4 : id.method_12832().equals("large_amethyst_bud") ? 5 : 7; }
        private static int amethystOffset(class_2960 id) { return id.method_12832().equals("small_amethyst_bud") ? 4 : id.method_12832().equals("medium_amethyst_bud") ? 3 : id.method_12832().equals("large_amethyst_bud") ? 3 : 3; }
    }
}
