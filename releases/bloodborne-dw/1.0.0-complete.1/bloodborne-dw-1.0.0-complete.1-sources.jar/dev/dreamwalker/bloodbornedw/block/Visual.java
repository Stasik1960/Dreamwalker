package dev.dreamwalker.bloodbornedw.block;

import net.minecraft.class_3542;

/** Texture slot stored independently from the vanilla carrier state. */
public enum Visual implements class_3542 {
    BASE("base"), ALT("alt");

    private final String id;

    Visual(String id) { this.id = id; }

    @Override public String method_15434() { return id; }
}
