package dev.dreamwalker.bloodbornedw.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import dev.dreamwalker.bloodbornedw.block.DwBlocks;
import dev.dreamwalker.bloodbornedw.block.Visual;
import dev.dreamwalker.bloodbornedw.visual.VisualService;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.lang.reflect.Method;

/** OP-only server commands. Client input is not involved. */
public final class VisualCommands {
    private VisualCommands() { }
    public static void register() { CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> { dispatcher.register(root("bloodborne")); dispatcher.register(root("bb")); }); }
    private static LiteralArgumentBuilder<class_2168> root(String name) {
        return class_2170.method_9247(name)
            .then(class_2170.method_9247("debug").executes(context -> debug(context.getSource())))
            .then(class_2170.method_9247("visual").requires(source -> source.method_9259(2)).then(mode("base", Visual.BASE)).then(mode("alt", Visual.ALT)));
    }
    private static LiteralArgumentBuilder<class_2168> mode(String name, Visual visual) {
        return class_2170.method_9247(name)
            .then(class_2170.method_9247("look").executes(c -> look(c.getSource(), visual, List.of())).then(class_2170.method_9244("ids", StringArgumentType.greedyString()).executes(c -> look(c.getSource(), visual, ids(c)))))
            .then(class_2170.method_9247("all").executes(c -> all(c.getSource(), visual, List.of(), false)).then(class_2170.method_9244("ids", StringArgumentType.greedyString()).executes(c -> all(c.getSource(), visual, ids(c), false))))
            .then(class_2170.method_9247("reset").executes(c -> all(c.getSource(), visual, List.of(), true)).then(class_2170.method_9244("ids", StringArgumentType.greedyString()).executes(c -> all(c.getSource(), visual, ids(c), true))))
            .then(class_2170.method_9247("selection").executes(c -> selection(c.getSource(), visual, List.of())).then(class_2170.method_9244("ids", StringArgumentType.greedyString()).executes(c -> selection(c.getSource(), visual, ids(c)))))
            .then(class_2170.method_9247("area").then(class_2170.method_9244("from", class_2262.method_9698()).then(class_2170.method_9244("to", class_2262.method_9698()).executes(c -> area(c.getSource(), visual, class_2262.method_9696(c,"from"), class_2262.method_9696(c,"to"), List.of())).then(class_2170.method_9244("ids", StringArgumentType.greedyString()).executes(c -> area(c.getSource(),visual,class_2262.method_9696(c,"from"),class_2262.method_9696(c,"to"),ids(c)))))));
    }
    private static int look(class_2168 source, Visual visual, Collection<String> ignored) throws CommandSyntaxException {
        class_3222 player = source.method_9207(); class_239 ray = player.method_5745(8.0, 0.0F, false); if (!(ray instanceof class_3965 hit) || hit.method_17783() != class_239.class_240.field_1332) throw new IllegalArgumentException("Look at a Bloodborne DW block"); class_2338 pos=hit.method_17777(); class_2680 state=player.method_51469().method_8320(pos); String id=VisualService.id(state); if(id==null || (!ignored.isEmpty() && !ignored.contains(id))) throw new IllegalArgumentException("Look at a matching Bloodborne DW block");
        VisualService.setPoint(player.method_51469(),pos,id,visual); player.method_51469().method_8652(pos,state.method_11657(DwBlocks.VISUAL,visual),2); source.method_9226(()->class_2561.method_43470("Visual " + visual.method_15434() + " set at " + pos.method_23854()),true); return 1;
    }
    private static int all(class_2168 source, Visual visual, Collection<String> ids, boolean reset) { class_3218 world=source.method_9225(); if(reset)VisualService.reset(world,ids,visual); else VisualService.addAllRule(world,ids,visual); source.method_9226(()->class_2561.method_43470("Visual rule saved"),true); return 1; }
    private static int area(class_2168 source, Visual visual, class_2338 first, class_2338 second, Collection<String> ids) { VisualService.addAreaRule(source.method_9225(),first,second,ids,visual); source.method_9226(()->class_2561.method_43470("Visual area rule saved"),true); return 1; }
    private static int selection(class_2168 source, Visual visual, Collection<String> ids) throws CommandSyntaxException {
        class_3222 player = source.method_9207(); class_2338[] cuboid = worldEditCuboid(player);
        VisualService.addAreaRule(player.method_51469(), cuboid[0], cuboid[1], ids, visual);
        source.method_9226(() -> class_2561.method_43470("Visual WorldEdit cuboid rule saved"), true); return 1;
    }
    /** All WorldEdit symbols are loaded only after confirming its optional Fabric mod is present. */
    private static class_2338[] worldEditCuboid(class_3222 player) throws CommandSyntaxException {
        if (!FabricLoader.getInstance().isModLoaded("worldedit")) fail("WorldEdit is not installed");
        try {
            Class<?> adapter = Class.forName("com.sk89q.worldedit.fabric.FabricAdapter");
            Object wePlayer = adapter.getMethod("adaptPlayer", class_3222.class).invoke(null, player);
            Class<?> worldEdit = Class.forName("com.sk89q.worldedit.WorldEdit"); Object instance = worldEdit.getMethod("getInstance").invoke(null);
            Object sessions = worldEdit.getMethod("getSessionManager").invoke(instance);
            Method get = find(sessions.getClass(), "get", 1); Object session = get.invoke(sessions, wePlayer);
            Object weWorld = find(wePlayer.getClass(), "getWorld", 0).invoke(wePlayer);
            Object region = find(session.getClass(), "getSelection", 1).invoke(session, weWorld);
            Class<?> cuboid = Class.forName("com.sk89q.worldedit.regions.CuboidRegion");
            if (!cuboid.isInstance(region)) fail("WorldEdit selection must be cuboid; use //sel cuboid");
            Object min = find(region.getClass(), "getMinimumPoint", 0).invoke(region); Object max = find(region.getClass(), "getMaximumPoint", 0).invoke(region);
            class_2338 first = vector(min), second = vector(max);
            if (first.method_10264() < player.method_51469().method_31607() || second.method_10264() >= player.method_51469().method_31600()) fail("WorldEdit selection is outside this dimension's build height");
            return new class_2338[]{first, second};
        } catch (CommandSyntaxException exception) { throw exception; }
        catch (ReflectiveOperationException | RuntimeException exception) { fail("WorldEdit selection is unavailable; make a cuboid selection in this world"); return null; }
    }
    private static Method find(Class<?> type, String name, int arguments) throws NoSuchMethodException { for (Method method : type.getMethods()) if (method.getName().equals(name) && method.getParameterCount() == arguments) return method; throw new NoSuchMethodException(name); }
    private static class_2338 vector(Object vector) throws ReflectiveOperationException { return new class_2338(((Number)find(vector.getClass(),"getBlockX",0).invoke(vector)).intValue(), ((Number)find(vector.getClass(),"getBlockY",0).invoke(vector)).intValue(), ((Number)find(vector.getClass(),"getBlockZ",0).invoke(vector)).intValue()); }
    private static void fail(String message) throws CommandSyntaxException { throw new SimpleCommandExceptionType(class_2561.method_43470(message)).create(); }
    private static int debug(class_2168 source) throws CommandSyntaxException { class_3222 player=source.method_9207(); class_239 ray=player.method_5745(8.0,0.0F,false); if(!(ray instanceof class_3965 hit))throw new IllegalArgumentException("Look at a block"); class_2338 pos=hit.method_17777(); class_2680 state=player.method_51469().method_8320(pos); String id=VisualService.id(state); source.method_9226(()->class_2561.method_43470("id="+(id==null?"none":id)+" source="+(id==null?"none":DwBlocks.byId(id).source())+" pos="+pos.method_23854()+" properties="+state.method_11656()+" collision="+!state.method_26220(player.method_51469(),pos).method_1110()+" light="+state.method_26213()+" "+String.join(" ",VisualService.describe(player.method_51469(),pos,state))),false); return 1; }
    private static List<String> ids(com.mojang.brigadier.context.CommandContext<class_2168> context) { String raw=StringArgumentType.getString(context,"ids"); ArrayList<String> result=new ArrayList<>(); for(String token:raw.trim().split("\\s+")){String id=token.startsWith("bloodborne_dw:")?token.substring("bloodborne_dw:".length()):token; if(!id.matches("\\d{5}")||DwBlocks.byId(id)==null)throw new IllegalArgumentException("Expected known bloodborne_dw:##### id"); result.add(id);} return result; }
}
