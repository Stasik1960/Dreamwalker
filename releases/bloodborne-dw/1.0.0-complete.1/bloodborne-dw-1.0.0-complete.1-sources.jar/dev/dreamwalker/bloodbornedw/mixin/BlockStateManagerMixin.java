package dev.dreamwalker.bloodbornedw.mixin;

import dev.dreamwalker.bloodbornedw.block.DwBlocks;
import dev.dreamwalker.bloodbornedw.block.DwCarrierState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.function.Function;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;

@Mixin(class_2248.class)
abstract class BlockStateManagerMixin {
    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/state/StateManager$Builder;build(Ljava/util/function/Function;Lnet/minecraft/state/StateManager$Factory;)Lnet/minecraft/state/StateManager;"))
    private class_2689<class_2248, class_2680> bloodborneDw$addVisual(class_2689.class_2690<class_2248, class_2680> builder, Function<class_2248, class_2680> owner, class_2689.class_2691<class_2248, class_2680> factory) {
        if (DwCarrierState.isBuilding()) builder.method_11667(DwBlocks.VISUAL);
        return builder.method_11668(owner, factory);
    }
}
