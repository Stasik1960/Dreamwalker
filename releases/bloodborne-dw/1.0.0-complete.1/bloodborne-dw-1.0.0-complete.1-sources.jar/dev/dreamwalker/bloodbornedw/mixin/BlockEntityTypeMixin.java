package dev.dreamwalker.bloodbornedw.mixin;

import dev.dreamwalker.bloodbornedw.block.DwBlocks;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Block-entity support sets contain vanilla source blocks, never their DW carriers. */
@Mixin(class_2591.class)
abstract class BlockEntityTypeMixin {
    @ModifyVariable(method = "supports", at = @At("HEAD"), argsOnly = true)
    private class_2680 bloodborneDw$sourceCarrierState(class_2680 state) {
        return DwBlocks.sourceState(state);
    }
}
