package dev.dreamwalker.bloodbornedw.mixin;

import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4970.class_2251.class)
public interface AbstractBlockSettingsAccessor {
    @Accessor("lootTableId") @Mutable void bloodborneDw$setLootTableId(class_2960 id);
    @Accessor("allowsSpawningPredicate") class_4970.class_4972<class_1299<?>> bloodborneDw$allowsSpawningPredicate();
    @Accessor("solidBlockPredicate") class_4970.class_4973 bloodborneDw$solidBlockPredicate();
    @Accessor("suffocationPredicate") class_4970.class_4973 bloodborneDw$suffocationPredicate();
    @Accessor("blockVisionPredicate") class_4970.class_4973 bloodborneDw$blockVisionPredicate();
    @Accessor("postProcessPredicate") class_4970.class_4973 bloodborneDw$postProcessPredicate();
    @Accessor("allowsSpawningPredicate") @Mutable void bloodborneDw$setAllowsSpawningPredicate(class_4970.class_4972<class_1299<?>> value);
    @Accessor("solidBlockPredicate") @Mutable void bloodborneDw$setSolidBlockPredicate(class_4970.class_4973 value);
    @Accessor("suffocationPredicate") @Mutable void bloodborneDw$setSuffocationPredicate(class_4970.class_4973 value);
    @Accessor("blockVisionPredicate") @Mutable void bloodborneDw$setBlockVisionPredicate(class_4970.class_4973 value);
    @Accessor("postProcessPredicate") @Mutable void bloodborneDw$setPostProcessPredicate(class_4970.class_4973 value);
}
