package dev.dreamwalker.bloodbornedw.mixin;

import dev.dreamwalker.bloodbornedw.block.DwCarrierState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Map;
import net.minecraft.class_2362;

/** A carrier pot must not replace vanilla's content-to-potted lookup entry. */
@Mixin(class_2362.class)
abstract class FlowerPotBlockMixin {
    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/util/Map;put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"))
    private Object bloodborneDw$keepVanillaPotLookup(Map<Object, Object> map, Object key, Object value) {
        return DwCarrierState.isBuilding() ? null : map.put(key, value);
    }
}
