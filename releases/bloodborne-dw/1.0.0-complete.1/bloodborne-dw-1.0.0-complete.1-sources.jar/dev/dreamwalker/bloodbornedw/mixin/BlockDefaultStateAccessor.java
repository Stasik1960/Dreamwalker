package dev.dreamwalker.bloodbornedw.mixin;

import net.minecraft.class_2248;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2248.class)
public interface BlockDefaultStateAccessor {
    @Invoker("setDefaultState") void bloodborneDw$setDefaultState(class_2680 state);
}
