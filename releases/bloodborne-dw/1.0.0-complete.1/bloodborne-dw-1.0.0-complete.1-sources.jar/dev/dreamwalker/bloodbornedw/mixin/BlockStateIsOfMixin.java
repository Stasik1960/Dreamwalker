package dev.dreamwalker.bloodbornedw.mixin;

import dev.dreamwalker.bloodbornedw.block.DwBlocks;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets vanilla neighbor and block-entity checks recognize an equivalent DW carrier. */
@Mixin(class_4970.class_4971.class)
abstract class BlockStateIsOfMixin {
    @Inject(method = "isOf", at = @At("HEAD"), cancellable = true)
    private void bloodborneDw$matchesSource(class_2248 expected, CallbackInfoReturnable<Boolean> callback) {
        class_2248 actual = ((class_2680) (Object) this).method_26204();
        if (DwBlocks.isCarrierOf(actual, expected)) callback.setReturnValue(true);
    }
}
