package dev.dreamwalker.bloodbornedw.mixin;

import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4970.class)
public interface AbstractBlockAccessor {
    @Accessor("settings") class_4970.class_2251 bloodborneDw$getSettings();
}
