package dev.dreamwalker.bloodbornedw.client;

import dev.dreamwalker.bloodbornedw.block.DwBlocks;
import dev.dreamwalker.bloodbornedw.block.Visual;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import java.util.List;
import java.util.function.Supplier;

/** Client-only block-render-time selector.  The guard lets paired wrapped models delegate safely. */
final class VisualBakedModel implements class_1087, FabricBakedModel {
    private static final ThreadLocal<Boolean> SELECTING = ThreadLocal.withInitial(() -> false);
    private final class_1087 delegate;

    VisualBakedModel(class_1087 delegate) { this.delegate = delegate; }

    @Override public boolean isVanillaAdapter() { return false; }
    @Override public void emitBlockQuads(class_1920 view, class_2680 state, class_2338 pos, Supplier<class_5819> random, RenderContext context) {
        if (SELECTING.get() || !state.method_28498(DwBlocks.VISUAL)) { emit(delegate, view, state, pos, random, context); return; }
        String id = BloodborneDwClient.id(state);
        if (id == null) { emit(delegate, view, state, pos, random, context); return; }
        Visual visual = BloodborneDwClient.effective(pos, id, state.method_11654(DwBlocks.VISUAL));
        class_2680 desired = state.method_11657(DwBlocks.VISUAL, visual);
        class_1087 paired = class_310.method_1551().method_1541().method_3349(desired);
        SELECTING.set(true);
        try { emit(paired, view, desired, pos, random, context); }
        finally { SELECTING.remove(); }
    }
    private static void emit(class_1087 model, class_1920 view, class_2680 state, class_2338 pos, Supplier<class_5819> random, RenderContext context) {
        ((FabricBakedModel) model).emitBlockQuads(view, state, pos, random, context);
    }
    @Override public void emitItemQuads(class_1799 stack, Supplier<class_5819> random, RenderContext context) { ((FabricBakedModel) delegate).emitItemQuads(stack, random, context); }
    @Override public List<class_777> method_4707(class_2680 state, class_2350 face, class_5819 random) { return delegate.method_4707(state, face, random); }
    @Override public boolean method_4708() { return delegate.method_4708(); }
    @Override public boolean method_4712() { return delegate.method_4712(); }
    @Override public boolean method_24304() { return delegate.method_24304(); }
    @Override public boolean method_4713() { return delegate.method_4713(); }
    @Override public class_1058 method_4711() { return delegate.method_4711(); }
    @Override public class_809 method_4709() { return delegate.method_4709(); }
    @Override public class_806 method_4710() { return delegate.method_4710(); }
}
