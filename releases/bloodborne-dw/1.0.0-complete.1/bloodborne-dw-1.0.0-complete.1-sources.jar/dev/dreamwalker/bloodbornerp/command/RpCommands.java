package dev.dreamwalker.bloodbornerp.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.dreamwalker.bloodbornerp.lamp.LampService;
import dev.dreamwalker.bloodbornerp.object.ObjectRegistry;
import dev.dreamwalker.bloodbornerp.object.RpObjectEntity;
import java.util.UUID;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** OP-only world-edit endpoints. Targeting is constrained to a loaded nearby RP object. */
public final class RpCommands {
 private static boolean registered; private RpCommands(){}
 public static void register(){if(registered)return;registered=true;CommandRegistrationCallback.EVENT.register((dispatcher,access,environment)->{
  var root=method_9247("bbrp").requires(source->source.method_9259(2));
  root.then(method_9247("object").then(method_9247("rotate").executes(c->object(c.getSource(),"rotate",null))).then(method_9247("delete").executes(c->object(c.getSource(),"delete",null))).then(method_9247("lock").executes(c->object(c.getSource(),"lock",null))).then(method_9247("unlock").executes(c->object(c.getSource(),"unlock",null))).then(method_9247("list").executes(c->object(c.getSource(),"list",null))).then(method_9247("link").then(method_9244("target",StringArgumentType.word()).executes(c->object(c.getSource(),"link",StringArgumentType.getString(c,"target"))))).then(method_9247("unlink").then(method_9244("target",StringArgumentType.word()).executes(c->object(c.getSource(),"unlink",StringArgumentType.getString(c,"target"))))));
  var lamp=method_9247("lamp");
  lamp.then(method_9247("register").then(method_9244("name",StringArgumentType.greedyString()).executes(c->lampRegister(c.getSource(),StringArgumentType.getString(c,"name")))));
  lamp.then(method_9247("rename").then(method_9244("id",StringArgumentType.word()).then(method_9244("name",StringArgumentType.greedyString()).executes(c->lampRename(c.getSource(),StringArgumentType.getString(c,"id"),StringArgumentType.getString(c,"name"))))));
  lamp.then(method_9247("remove").then(method_9244("id",StringArgumentType.word()).executes(c->lampRemove(c.getSource(),StringArgumentType.getString(c,"id")))));
  lamp.then(method_9247("list").executes(c->lampList(c.getSource())));
  lamp.then(routeCommand("link",true)).then(routeCommand("unlink",false));
  var route=method_9247("route");route.then(routeCommand("open",true)).then(routeCommand("close",false));lamp.then(route);root.then(lamp);dispatcher.register(root);
 });}
 private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> routeCommand(String name,boolean open){return method_9247(name).then(method_9244("from",StringArgumentType.word()).then(method_9244("to",StringArgumentType.word()).executes(c->lampRoute(c.getSource(),StringArgumentType.getString(c,"from"),StringArgumentType.getString(c,"to"),open))));}
 private static int object(class_2168 source,String operation,String target){if(!(source.method_9228() instanceof class_3222 player)){source.method_9213(class_2561.method_43471("command.bloodborne_rp.player_required"));return 0;}RpObjectEntity object=ObjectRegistry.objectAt(player);if(object==null){source.method_9213(class_2561.method_43471("command.bloodborne_rp.object_required"));return 0;}if(operation.equals("rotate")){object.method_36456(object.method_36454()+90);object.refreshCollider();source.method_9226(()->class_2561.method_43471("command.bloodborne_rp.done"),false);return 1;}if(operation.equals("delete")){LampService.removeByEntity(source.method_9211(),object.method_5667());object.method_31472();return 1;}if(operation.equals("lock")){object.setLocked(true);return 1;}if(operation.equals("unlock")){object.setLocked(false);return 1;}if(operation.equals("list")){source.method_9226(()->class_2561.method_43470(object.links().toString()),false);return 1;}try{UUID id=UUID.fromString(target);if(operation.equals("unlink")&&object.removeLink(id))return 1;var entity=player.method_51469().method_14190(id);if(entity instanceof RpObjectEntity destination&&object.addLink(destination))return 1;}catch(IllegalArgumentException ignored){}source.method_9213(class_2561.method_43471("command.bloodborne_rp.link_rejected"));return 0;}
 private static int lampRegister(class_2168 source,String name){if(!(source.method_9228() instanceof class_3222 player)||name.isBlank()||name.length()>64||!LampService.register(player,name)){source.method_9213(class_2561.method_43471("command.bloodborne_rp.lamp_rejected"));return 0;}return 1;}
 private static int lampRename(class_2168 source,String raw,String name){try{if(LampService.rename(source.method_9211(),UUID.fromString(raw),name))return 1;}catch(IllegalArgumentException ignored){}source.method_9213(class_2561.method_43471("command.bloodborne_rp.lamp_rejected"));return 0;}
 private static int lampRemove(class_2168 source,String raw){try{if(LampService.remove(source.method_9211(),UUID.fromString(raw)))return 1;}catch(IllegalArgumentException ignored){}source.method_9213(class_2561.method_43471("command.bloodborne_rp.lamp_rejected"));return 0;}
 private static int lampRoute(class_2168 source,String from,String to,boolean open){try{if(LampService.route(source.method_9211(),UUID.fromString(from),UUID.fromString(to),open))return 1;}catch(IllegalArgumentException ignored){}source.method_9213(class_2561.method_43471("command.bloodborne_rp.lamp_rejected"));return 0;}
 private static int lampList(class_2168 source){for(LampService.LampInfo lamp:LampService.list(source.method_9211()))source.method_9226(()->class_2561.method_43470(lamp.id()+" "+lamp.name()),false);return 1;}
}
