package dev.dreamwalker.bloodbornerp.content;

import com.google.gson.Gson;
import dev.dreamwalker.bloodbornerp.BloodborneRp;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class RpSounds {
 private static final Map<String,class_3414> EVENTS=new HashMap<>();
 private RpSounds(){}
 public static void register(){
  try(var reader=new InputStreamReader(RpSounds.class.getResourceAsStream("/assets/bloodborne_rp/sound-catalog.json"),StandardCharsets.UTF_8)){
   for(String name:new Gson().fromJson(reader,String[].class)){
    var id=BloodborneRp.id(name); EVENTS.put(name,class_2378.method_10230(class_7923.field_41172,id,class_3414.method_47908(id)));
   }
  }catch(Exception e){throw new IllegalStateException("Invalid sound catalog",e);}
 }
 public static class_3414 mob(String id,String event,class_3414 fallback){
  String family=id.startsWith("huntsman_")?"huntsman":id.equals("small_rat")?"giant_rat":id;
  return EVENTS.getOrDefault("entity."+family+"_"+event,fallback);
 }
}
