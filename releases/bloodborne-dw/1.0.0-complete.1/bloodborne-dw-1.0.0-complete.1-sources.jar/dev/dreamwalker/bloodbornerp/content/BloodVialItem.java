package dev.dreamwalker.bloodbornerp.content;

import dev.dreamwalker.bloodbornerp.RpConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;

/** Optional ordinary Minecraft healing; no alternate health system. */
public final class BloodVialItem extends class_1792 {
 public BloodVialItem(){super(new class_1793().method_7889(16));}
 @Override public class_1271<class_1799> method_7836(class_1937 world,class_1657 player,class_1268 hand){
  class_1799 stack=player.method_5998(hand);
  if(!RpConfig.INSTANCE.bloodVialsEnabled||!player.method_5805()||player.method_7325()
      ||player.method_6032()>=player.method_6063()||player.method_7357().method_7904(this))
   return class_1271.method_22431(stack);
  if(!world.field_9236){
   player.method_6025(RpConfig.INSTANCE.bloodVialHealing);
   player.method_7357().method_7906(this,40);
   if(!player.method_31549().field_7477)stack.method_7934(1);
   player.method_5783(class_3417.field_20613,1,1);
  }
  return class_1271.method_29237(stack,world.field_9236);
 }
}
