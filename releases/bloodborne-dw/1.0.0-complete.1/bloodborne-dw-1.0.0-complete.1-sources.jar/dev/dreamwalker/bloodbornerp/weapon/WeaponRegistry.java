package dev.dreamwalker.bloodbornerp.weapon;

import dev.dreamwalker.bloodbornerp.BloodborneRp;
import dev.dreamwalker.bloodbornerp.RpConfig;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/** Server-authoritative registration and transformation endpoint for trick weapons. */
public final class WeaponRegistry {
  public static final class_2960 TRANSFORM_PACKET=BloodborneRp.id("transform_weapon");
  public static final TrickWeaponItem SAW_CLEAVER=new TrickWeaponItem("sawcleaver",new WeaponProfile(4.0,-2.6),new WeaponProfile(5.5,-2.9),false);
  public static final TrickWeaponItem SAW_SPEAR=new TrickWeaponItem("sawspear",new WeaponProfile(4.0,-2.5),new WeaponProfile(5.0,-2.7),false);
  public static final TrickWeaponItem BOOM_HAMMER=new TrickWeaponItem("boomhammer",new WeaponProfile(5.5,-3.1),new WeaponProfile(7.5,-3.3),true);
  private static boolean registered;
  private static final java.util.Set<java.util.UUID> PENDING=java.util.concurrent.ConcurrentHashMap.newKeySet();
  private WeaponRegistry() {}

  public static void register() {
    if(registered) return;
    registered=true;
    class_2378.method_10230(class_7923.field_41178,BloodborneRp.id("saw_cleaver"),SAW_CLEAVER);
    class_2378.method_10230(class_7923.field_41178,BloodborneRp.id("saw_spear"),SAW_SPEAR);
    class_2378.method_10230(class_7923.field_41178,BloodborneRp.id("boom_hammer"),BOOM_HAMMER);
    ServerPlayNetworking.registerGlobalReceiver(TRANSFORM_PACKET,(server,player,handler,buf,responseSender)-> {
      if(buf.readableBytes()!=1) return;
      byte handId=buf.readByte();
      if(handId!=0 && handId!=1) return;
      class_1268 hand=handId==0 ? class_1268.field_5808 : class_1268.field_5810;
      if(!PENDING.add(player.method_5667()))return;
      server.execute(()->{try{if(server.method_3760().method_14602(player.method_5667())==player)transform(player,hand);}finally{PENDING.remove(player.method_5667());}});
    });
    net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->PENDING.remove(handler.field_14140.method_5667()));
    net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPING.register(server->PENDING.clear());
  }

  public static boolean transform(class_3222 player, class_1268 hand) {
    if(!player.method_5805() || player.method_7325()) return false;
    if(!(player.method_5998(hand).method_7909() instanceof TrickWeaponItem weapon)) return false;
    if(player.method_7357().method_7904(weapon)) return false;
    TrickWeaponItem.setForm(player.method_5998(hand),TrickWeaponItem.form(player.method_5998(hand)).other());
    player.method_7357().method_7906(weapon,RpConfig.INSTANCE.weaponTransformCooldownTicks);
    return true;
  }
}
