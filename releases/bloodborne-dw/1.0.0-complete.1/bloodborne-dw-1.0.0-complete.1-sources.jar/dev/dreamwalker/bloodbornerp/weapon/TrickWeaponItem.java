package dev.dreamwalker.bloodbornerp.weapon;

import dev.dreamwalker.bloodbornerp.RpConfig;
import dev.dreamwalker.bloodbornerp.content.AssetBacked;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_3222;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.SingletonGeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

/** One durable, enchantable stack per weapon family; only its form is stored in NBT. */
public final class TrickWeaponItem extends class_1792 implements GeoItem, AssetBacked {
  public static final String FORM_KEY="BloodborneRpForm";
  private static final String PROFILE_KEY="BloodborneRpWeaponProfile";
  private static final String MODIFIERS_KEY="AttributeModifiers";
  private static final String DAMAGE_NAME="bloodborne_rp_weapon_damage";
  private static final String SPEED_NAME="bloodborne_rp_weapon_speed";
  private final String familyId;
  private final WeaponProfile folded;
  private final WeaponProfile extended;
  private final boolean ignitesWhenExtended;
  private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);
  private final java.util.function.Supplier<Object> renderProvider=GeoItem.makeRenderer(this);
  /** Set exclusively by the client entrypoint, keeping common code loadable on dedicated servers. */
  public static Consumer<Consumer<Object>> clientRendererConsumer;

  public TrickWeaponItem(String familyId, WeaponProfile folded, WeaponProfile extended, boolean ignitesWhenExtended) {
    super(new class_1793().method_7889(1).method_7895(650));
    this.familyId=familyId;
    this.folded=folded;
    this.extended=extended;
    this.ignitesWhenExtended=ignitesWhenExtended;
    SingletonGeoAnimatable.registerSyncedAnimatable(this);
  }

  @Override public java.util.function.Supplier<Object> getRenderProvider() { return renderProvider; }
  @Override public void createRenderer(Consumer<Object> consumer) {
    if(clientRendererConsumer!=null) clientRendererConsumer.accept(consumer);
  }
  @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {}
  @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
  @Override public String assetId() { return familyId+"_false"; }
  public String formId(class_1799 stack) { return familyId+"_"+form(stack).nbtValue(); }
  public String familyId() { return familyId; }
  public WeaponProfile profile(class_1799 stack) { return form(stack)==WeaponForm.FOLDED ? folded : extended; }
  public boolean ignitesWhenExtended() { return ignitesWhenExtended; }

  public static WeaponForm form(class_1799 stack) {
    return WeaponForm.fromNbt(stack.method_7985() && stack.method_7969().method_10577(FORM_KEY));
  }

  public static void setForm(class_1799 stack, WeaponForm form) {
    stack.method_7948().method_10556(FORM_KEY,form.nbtValue());
    if(stack.method_7909() instanceof TrickWeaponItem weapon) weapon.applyProfile(stack);
  }

  @Override public class_1799 method_7854() {
    class_1799 stack=super.method_7854();
    setForm(stack,WeaponForm.FOLDED);
    return stack;
  }

  @Override public void method_7888(class_1799 stack, class_1937 world, net.minecraft.class_1297 entity, int slot, boolean selected) {
    if(!world.field_9236 && !hasCurrentProfile(stack)) applyProfile(stack);
  }

  @Override public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
    class_1799 stack=user.method_5998(hand);
    if(!world.field_9236 && user instanceof class_3222 player) WeaponRegistry.transform(player,hand);
    return class_1271.method_29237(stack,world.field_9236);
  }

  @Override public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
    WeaponForm current=form(stack);
    if(ignitesWhenExtended && current==WeaponForm.EXTENDED && !target.method_37908().field_9236) {
      target.method_5639(4);
      setForm(stack,WeaponForm.FOLDED);
      if(attacker instanceof class_1657 player) player.method_7357().method_7906(this,RpConfig.INSTANCE.weaponTransformCooldownTicks);
    }
    class_1304 breakSlot=attacker.method_6047()==stack ? class_1304.field_6173 : class_1304.field_6171;
    stack.method_7956(1,attacker,entity -> entity.method_20235(breakSlot));
    return true;
  }

  private boolean hasCurrentProfile(class_1799 stack) {
    class_2487 tag=stack.method_7969();
    return tag!=null && tag.method_10558(PROFILE_KEY).equals(formId(stack));
  }

  private void applyProfile(class_1799 stack) {
    class_2487 tag=stack.method_7948();
    class_2499 modifiers=tag.method_10554(MODIFIERS_KEY,class_2520.field_33260);
    class_2499 retained=new class_2499();
    for(int i=0;i<modifiers.size();i++) {
      class_2487 modifier=modifiers.method_10602(i);
      if(!DAMAGE_NAME.equals(modifier.method_10558("Name")) && !SPEED_NAME.equals(modifier.method_10558("Name"))) retained.add(modifier.method_10553());
    }
    WeaponProfile profile=profile(stack);
    retained.add(attributeModifier("generic.attack_damage",DAMAGE_NAME,profile.attackDamage(),damageUuid()));
    retained.add(attributeModifier("generic.attack_speed",SPEED_NAME,profile.attackSpeed(),speedUuid()));
    tag.method_10566(MODIFIERS_KEY,retained);
    tag.method_10582(PROFILE_KEY,formId(stack));
  }

  private class_2487 attributeModifier(String attribute, String name, double amount, UUID uuid) {
    class_2487 modifier=new class_2487();
    modifier.method_10582("AttributeName",attribute);
    modifier.method_10582("Name",name);
    modifier.method_10549("Amount",amount);
    modifier.method_10569("Operation",0);
    modifier.method_10566("UUID",class_2512.method_25929(uuid));
    modifier.method_10582("Slot","mainhand");
    return modifier;
  }

  private UUID damageUuid() { return UUID.nameUUIDFromBytes((familyId+":damage").getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
  private UUID speedUuid() { return UUID.nameUUIDFromBytes((familyId+":speed").getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
}
