package dev.dreamwalker.bloodbornerp.mob;

import dev.dreamwalker.bloodbornerp.BloodborneRp;
import dev.dreamwalker.bloodbornerp.content.AssetCatalog;
import dev.dreamwalker.bloodbornerp.content.AssetSpec;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

/** Explicitly registered encounter mobs. No biome spawn rules are installed here. */
public final class MobRegistry {
 public static final Map<String, class_1299<RpMobEntity>> TYPES = new LinkedHashMap<>();
 private static boolean registered;
 private static final List<String> IDS = List.of(
  "cleric_beast", "vicar_amelia", "blood_starved_beast", "scourge_beast", "executioner",
  "huntsman_a", "huntsman_b", "huntsman_c", "huntsman_d", "huntsman_wheelchair",
  "large_huntsman", "carrion_crow", "giant_rat", "small_rat", "rabid_dog", "maneater_boar",
  "brick_troll", "rotted_corpse");

 private MobRegistry() {}

 public static void register() {
  if (registered) return;
  registered = true;
  for (String id : IDS) registerMob(id);
 }

 private static void registerMob(String id) {
  AssetSpec asset = AssetCatalog.get(id);
  class_1299<RpMobEntity> type = class_2378.method_10230(class_7923.field_41177, BloodborneRp.id(id),
   FabricEntityTypeBuilder.<RpMobEntity>create(class_1311.field_6302,
    (entityType, world) -> new RpMobEntity(entityType, world, id))
    .dimensions(class_4048.method_18385(asset.width(), asset.height())).trackRangeChunks(8).build());
  TYPES.put(id, type);
  FabricDefaultAttributeRegistry.register(type, RpMobEntity.createAttributes(id));
  class_2378.method_10230(class_7923.field_41178, BloodborneRp.id(id + "_spawn_egg"),
   new class_1826(type, eggPrimary(id), eggSecondary(id), new class_1792.class_1793()));
 }

 private static int eggPrimary(String id) {
  return switch (id) {
   case "cleric_beast", "vicar_amelia", "blood_starved_beast" -> 0x6E4A3A;
   case "huntsman_wheelchair", "executioner", "brick_troll" -> 0x51463F;
   default -> 0x7A6556;
  };
 }

 private static int eggSecondary(String id) {
  return switch (id) {
   case "blood_starved_beast", "rabid_dog" -> 0x9B3124;
   case "carrion_crow", "rotted_corpse" -> 0x27201B;
   default -> 0xC9B69B;
  };
 }
}
