package dev.dreamwalker.bloodbornerp.mob;

import dev.dreamwalker.bloodbornerp.RpConfig;
import dev.dreamwalker.bloodbornerp.content.AssetBacked;
import dev.dreamwalker.bloodbornerp.content.AssetCatalog;
import dev.dreamwalker.bloodbornerp.content.AssetSpec;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1259;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3213;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Shared hostile implementation for catalog-backed Bloodborne encounters. */
public final class RpMobEntity extends class_1588 implements GeoEntity, AssetBacked {
 private static final String FROZEN_NBT = "bloodborne_rp_frozen";
 private static final class_2940<Integer> ATTACK_VARIANT = class_2945.method_12791(RpMobEntity.class, class_2943.field_13327);
 private static final Map<String, MobProfile> PROFILES = Map.ofEntries(
  Map.entry("cleric_beast", new MobProfile(80.0D, 0.20D, 8.0D)),
  Map.entry("vicar_amelia", new MobProfile(70.0D, 0.20D, 7.0D)),
  Map.entry("blood_starved_beast", new MobProfile(60.0D, 0.30D, 6.0D)),
  Map.entry("scourge_beast", new MobProfile(30.0D, 0.27D, 5.0D)),
  Map.entry("executioner", new MobProfile(40.0D, 0.21D, 6.0D)),
  Map.entry("huntsman_a", new MobProfile(20.0D, 0.27D, 4.0D)),
  Map.entry("huntsman_b", new MobProfile(20.0D, 0.27D, 4.0D)),
  Map.entry("huntsman_c", new MobProfile(20.0D, 0.27D, 4.0D)),
  Map.entry("huntsman_d", new MobProfile(18.0D, 0.25D, 4.0D)),
  Map.entry("huntsman_wheelchair", new MobProfile(16.0D, 0.16D, 4.0D)),
  Map.entry("large_huntsman", new MobProfile(35.0D, 0.22D, 6.0D)),
  Map.entry("carrion_crow", new MobProfile(10.0D, 0.32D, 3.0D)),
  Map.entry("giant_rat", new MobProfile(12.0D, 0.29D, 3.0D)),
  Map.entry("small_rat", new MobProfile(6.0D, 0.31D, 2.0D)),
  Map.entry("rabid_dog", new MobProfile(12.0D, 0.33D, 3.0D)),
  Map.entry("maneater_boar", new MobProfile(30.0D, 0.24D, 6.0D)),
  Map.entry("brick_troll", new MobProfile(50.0D, 0.18D, 7.0D)),
  Map.entry("rotted_corpse", new MobProfile(16.0D, 0.22D, 3.0D)));
 private final String assetId;
 private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);
 @Nullable private final class_3213 bossBar;
 private boolean frozen;
 private int animationTicks;

 public RpMobEntity(class_1299<? extends RpMobEntity> type, class_1937 world, String assetId) {
  super(type, world);
  this.assetId = assetId;
  this.bossBar = isBoss(assetId) ? new class_3213(asset().displayName() == null
   ? net.minecraft.class_2561.method_43470(assetId) : net.minecraft.class_2561.method_43470(asset().displayName()), class_1259.class_1260.field_5784, class_1259.class_1261.field_5795) : null;
 }

 @Override public String assetId() { return assetId; }
 public AssetSpec asset() { return AssetCatalog.get(assetId); }
 public boolean getFrozen() { return frozen; }
 public boolean method_32314() { return frozen; }
 public void setFrozen(boolean frozen) {
  this.frozen = frozen;
  if (frozen) {
   method_5942().method_6340();
   method_18799(class_243.field_1353);
   method_5980(null);
  }
 }

 public static class_5132.class_5133 createAttributes(String id) {
  MobProfile profile = profile(id);
  return class_1588.method_26918()
   .method_26868(class_5134.field_23716, profile.health())
   .method_26868(class_5134.field_23719, profile.speed())
   .method_26868(class_5134.field_23721, profile.damage())
   .method_26868(class_5134.field_23717, 32.0D);
 }

 public static double maxHealthFor(String id) { return profile(id).health(); }
 private static MobProfile profile(String id) {
  MobProfile profile = PROFILES.get(id);
  if (profile == null) throw new IllegalArgumentException("Unknown RP mob profile: " + id);
  return profile;
 }
 private record MobProfile(double health, double speed, double damage) {}

 private static boolean isBoss(String id) {
  return id.equals("cleric_beast") || id.equals("vicar_amelia") || id.equals("blood_starved_beast");
 }
 public boolean usesRangedAttack() { return assetId.equals("huntsman_d") || assetId.equals("huntsman_wheelchair"); }

 @Override protected void method_5959() {
  field_6201.method_6277(0, new class_1347(this));
  field_6201.method_6277(2, new TelegraphedAttackGoal(this));
  field_6201.method_6277(8, new class_1361(this, class_1657.class, 8.0F));
  field_6185.method_6277(2, new class_1400<>(this, class_1657.class, 10, true, false,
   player -> RpConfig.INSTANCE.monstersAttackPlayers && !frozen));
 }

 @Override protected void method_5693() {
  super.method_5693();
  method_5841().method_12784(ATTACK_VARIANT, 0);
 }

 @Override public void method_5773() {
  super.method_5773();
  if (animationTicks > 0 && --animationTicks == 0) method_5841().method_12778(ATTACK_VARIANT, 0);
  if (frozen) {
   method_5942().method_6340();
   method_18799(class_243.field_1353);
  }
  if (!method_37908().field_9236 && bossBar != null) bossBar.method_5408(class_3532.method_15363(method_6032() / method_6063(), 0.0F, 1.0F));
 }

 @Override public boolean method_6034() { return !frozen && super.method_6034(); }
 @Override protected net.minecraft.class_3414 method_5994() {
  return dev.dreamwalker.bloodbornerp.content.RpSounds.mob(assetId,"idle",class_3417.field_15174);
 }
 @Override protected net.minecraft.class_3414 method_6011(net.minecraft.class_1282 source) {
  return dev.dreamwalker.bloodbornerp.content.RpSounds.mob(assetId,"hurt",class_3417.field_15088);
 }
 @Override protected net.minecraft.class_3414 method_6002() {
  return dev.dreamwalker.bloodbornerp.content.RpSounds.mob(assetId,"death",class_3417.field_14930);
 }
 @Override public boolean method_5987() { return frozen || super.method_5987(); }
 @Override public boolean method_5974(double distanceSquared) { return false; }
 @Override public void method_5837(class_3222 player) { super.method_5837(player); if (bossBar != null) bossBar.method_14088(player); }
 @Override public void method_5742(class_3222 player) { super.method_5742(player); if (bossBar != null) bossBar.method_14089(player); }
 @Override public void method_6078(net.minecraft.class_1282 source) { if (bossBar != null) bossBar.method_14094(); super.method_6078(source); }
 @Override public void method_5652(class_2487 nbt) { super.method_5652(nbt); nbt.method_10556(FROZEN_NBT, frozen); }
 @Override public void method_5749(class_2487 nbt) { super.method_5749(nbt); setFrozen(nbt.method_10577(FROZEN_NBT)); }

 @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
  controllers.add(new AnimationController<>(this, "main", 0, state -> {
   String suffix = field_6213 > 0 ? MobAnimationSelector.death(asset()) : field_6235 > 0 ? MobAnimationSelector.hit(asset()) : attackAnimationSuffix();
   if (suffix.isEmpty()) suffix = state.isMoving() && asset().clip("walk") != null ? "walk" : MobAnimationSelector.idle(asset());
   AssetSpec.Clip clip = asset().clip(suffix);
   if (clip == null || clip.name().isBlank()) return PlayState.STOP;
   return state.setAndContinue(RawAnimation.begin().then(clip.name(), clip.loop() ? Animation.LoopType.LOOP : Animation.LoopType.PLAY_ONCE));
  }));
 }
 @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return animationCache; }

 private int beginAttackAnimation() {
  List<String> options = attackOptions();
  method_5841().method_12778(ATTACK_VARIANT, options.isEmpty() ? 0 : field_5974.method_43048(options.size()) + 1);
  if (options.isEmpty()) return 1;
  animationTicks = Math.max(1, (int)Math.ceil(asset().clip(options.get(method_5841().method_12789(ATTACK_VARIANT) - 1)).seconds() * 20.0F));
  return animationTicks;
 }

 private List<String> attackOptions() {
  return MobAnimationSelector.attacks(assetId).stream().filter(suffix -> asset().clip(suffix) != null).toList();
 }

 private String attackAnimationSuffix() {
  int variant = method_5841().method_12789(ATTACK_VARIANT);
  List<String> options = attackOptions();
  return variant > 0 && variant <= options.size() ? options.get(variant - 1) : "";
 }

 private final class TelegraphedAttackGoal extends class_1352 {
  private int ticks;
  private int windupTicks;
  private boolean ranged;
  TelegraphedAttackGoal(RpMobEntity ignored) { method_6265(java.util.EnumSet.of(class_4134.field_18405, class_4134.field_18406)); }
  @Override public boolean method_6264() { return validTarget(method_5968()) && !frozen; }
  @Override public boolean method_6266() { return validTarget(method_5968()) && !frozen; }
   @Override public void method_6269() { ticks = 0; windupTicks = 0; ranged = usesRangedAttack(); }
  @Override public void method_6270() { ticks = 0; windupTicks = 0; method_5942().method_6340(); }
  @Override public void method_6268() {
   class_1309 target = method_5968();
   if (!validTarget(target)) return;
   method_5988().method_6226(target, 30.0F, 30.0F);
   double distance = method_5858(target);
   boolean inRange = ranged ? AttackRules.withinRangedReach(distance)
    : AttackRules.withinMeleeReach(distance, method_17681(), target.method_17681());
   if (!inRange || !method_6057(target)) { method_5942().method_6335(target, ranged ? 0.85D : 1.0D); ticks = 0; return; }
   method_5942().method_6340();
   if (ticks++ == 0) windupTicks = beginAttackAnimation();
   if (ticks >= windupTicks) {
    if (ranged) fireAt(target); else strike(target);
    ticks = 0;
   }
  }
  private boolean validTarget(@Nullable class_1309 target) {
   return target instanceof class_1657 && target.method_5805() && RpConfig.INSTANCE.monstersAttackPlayers && !frozen;
  }
  private void strike(class_1309 target) {
   if (method_6057(target) && AttackRules.withinMeleeReach(method_5858(target), method_17681(), target.method_17681())) {
    method_6121(target);
   }
  }
  private void fireAt(class_1309 target) {
   if (!method_6057(target) || !AttackRules.withinRangedReach(method_5858(target))) return;
   class_1667 arrow = new class_1667(method_37908(), RpMobEntity.this);
   class_243 direction = target.method_33571().method_1020(method_33571());
   arrow.method_7485(direction.field_1352, direction.field_1351, direction.field_1350, 1.6F, 4.0F);
   arrow.method_7438(method_26825(class_5134.field_23721));
   method_37908().method_8649(arrow);
   method_5783(class_3417.field_14600, 1.0F, 0.85F + field_5974.method_43057() * 0.3F);
  }
 }
}
