package dev.dreamwalker.bloodbornerp.client.weapon;

import dev.dreamwalker.bloodbornerp.content.AssetCatalog;
import dev.dreamwalker.bloodbornerp.content.AssetSpec;
import dev.dreamwalker.bloodbornerp.weapon.TrickWeaponItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import software.bernie.geckolib.model.GeoModel;

/** Resolves the catalog entry for the stack currently being rendered, with public fallbacks. */
@Environment(EnvType.CLIENT)
public final class TrickWeaponModel extends GeoModel<TrickWeaponItem> {
  private static final class_2960 FALLBACK_MODEL=new class_2960("bloodborne_rp","geo/fallback_weapon.geo.json");
  private static final class_2960 FALLBACK_ANIMATION=new class_2960("bloodborne_rp","animations/fallback.animation.json");
  private static final class_2960 FALLBACK_TEXTURE=new class_2960("minecraft","textures/block/iron_block.png");
  private class_1799 currentStack=class_1799.field_8037;

  void setCurrentStack(class_1799 stack) { currentStack=stack; }

  @Override public class_2960 getModelResource(TrickWeaponItem weapon) { return resource(weapon,AssetPart.MODEL); }
  @Override public class_2960 getTextureResource(TrickWeaponItem weapon) { return resource(weapon,AssetPart.TEXTURE); }
  @Override public class_2960 getAnimationResource(TrickWeaponItem weapon) { return resource(weapon,AssetPart.ANIMATION); }

  private class_2960 resource(TrickWeaponItem weapon, AssetPart part) {
    class_1799 stack=currentStack;
    String assetId=stack.method_7909()==weapon ? weapon.formId(stack) : weapon.assetId();
    AssetSpec spec=AssetCatalog.get(assetId);
    String path=part.value(spec);
    class_2960 requested=path.indexOf(':')>=0 ? new class_2960(path) : new class_2960("bloodborne_rp",path);
    return class_310.method_1551().method_1478().method_14486(requested).isPresent() ? requested : part.fallback;
  }

  private enum AssetPart {
    MODEL(FALLBACK_MODEL) { @Override String value(AssetSpec spec) { return spec.model(); } },
    TEXTURE(FALLBACK_TEXTURE) { @Override String value(AssetSpec spec) { return spec.texture(); } },
    ANIMATION(FALLBACK_ANIMATION) { @Override String value(AssetSpec spec) { return spec.animation(); } };
    final class_2960 fallback;
    AssetPart(class_2960 fallback) { this.fallback=fallback; }
    abstract String value(AssetSpec spec);
  }
}
