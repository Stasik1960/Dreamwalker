package dev.dreamwalker.bloodbornerp.client;

import dev.dreamwalker.bloodbornerp.BloodborneRp;
import dev.dreamwalker.bloodbornerp.content.AssetBacked;
import dev.dreamwalker.bloodbornerp.content.AssetCatalog;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.model.GeoModel;

public final class CatalogEntityModel<T extends class_1297 & GeoAnimatable & AssetBacked> extends GeoModel<T> {
 private class_2960 resolve(String path,class_2960 fallback) {
  class_2960 requested=path.contains(":")?new class_2960(path):BloodborneRp.id(path);
  return class_310.method_1551().method_1478().method_14486(requested).isPresent()?requested:fallback;
 }
 @Override public class_2960 getModelResource(T entity) {
  return resolve(AssetCatalog.get(entity.assetId()).model(),BloodborneRp.id("geo/fallback.geo.json"));
 }
 @Override public class_2960 getTextureResource(T entity) {
  return resolve(AssetCatalog.get(entity.assetId()).texture(),new class_2960("minecraft","textures/entity/zombie/zombie.png"));
 }
 @Override public class_2960 getAnimationResource(T entity) {
  return resolve(AssetCatalog.get(entity.assetId()).animation(),BloodborneRp.id("animations/fallback.animation.json"));
 }
}
