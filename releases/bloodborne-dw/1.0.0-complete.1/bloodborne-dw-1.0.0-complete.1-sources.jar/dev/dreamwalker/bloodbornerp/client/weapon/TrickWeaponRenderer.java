package dev.dreamwalker.bloodbornerp.client.weapon;

import dev.dreamwalker.bloodbornerp.weapon.TrickWeaponItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import software.bernie.geckolib.renderer.GeoItemRenderer;

@Environment(EnvType.CLIENT)
public final class TrickWeaponRenderer extends GeoItemRenderer<TrickWeaponItem> {
  private final TrickWeaponModel weaponModel;
  public TrickWeaponRenderer() { this(new TrickWeaponModel()); }
  private TrickWeaponRenderer(TrickWeaponModel weaponModel) { super(weaponModel); this.weaponModel=weaponModel; }
  @Override public void method_3166(class_1799 stack, class_811 mode, class_4587 matrices, class_4597 vertices, int light, int overlay) {
    weaponModel.setCurrentStack(stack);
    super.method_3166(stack,mode,matrices,vertices,light,overlay);
  }
}
