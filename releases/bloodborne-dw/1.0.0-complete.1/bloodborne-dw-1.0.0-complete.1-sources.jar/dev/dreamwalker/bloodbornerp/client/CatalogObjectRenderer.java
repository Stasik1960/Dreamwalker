package dev.dreamwalker.bloodbornerp.client;

import dev.dreamwalker.bloodbornerp.object.RpObjectEntity;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Nonliving objects need their own yaw; the default renderer only reads LivingEntity body yaw. */
public final class CatalogObjectRenderer extends GeoEntityRenderer<RpObjectEntity> {
 public CatalogObjectRenderer(class_5617.class_5618 context,float scale) {
  super(context,new CatalogEntityModel<>()); withScale(scale); field_4673=0;
 }
 @Override protected void applyRotations(RpObjectEntity entity,class_4587 matrices,float age,float yaw,float delta) {
  super.applyRotations(entity,matrices,age,entity.method_36454(),delta);
 }
}
