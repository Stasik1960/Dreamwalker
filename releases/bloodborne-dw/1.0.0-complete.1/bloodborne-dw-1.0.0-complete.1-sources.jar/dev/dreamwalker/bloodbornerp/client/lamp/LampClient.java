package dev.dreamwalker.bloodbornerp.client.lamp;

import dev.dreamwalker.bloodbornerp.lamp.LampService;
import io.netty.buffer.Unpooled;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public final class LampClient {
 private LampClient(){}
 public static void initialize(){ClientPlayNetworking.registerGlobalReceiver(LampService.LIST_PACKET,(client,handler,buf,response)->{if(buf.readableBytes()<9)return;long token=buf.readLong();int count=buf.method_10816();if(count<0||count>256)return;List<Entry> entries=new ArrayList<>();for(int i=0;i<count;i++){if(buf.readableBytes()<16)return;entries.add(new Entry(buf.method_10790(),buf.method_10800(64)));}client.execute(()->{if(token==0&&entries.isEmpty()){if(client.field_1755 instanceof LampScreen)client.method_1507(null);}else client.method_1507(new LampScreen(token,entries));});});}
 private record Entry(UUID id,String name){}
 private static final class LampScreen extends class_437 {
  private final long token;private final List<Entry> entries;private int page;
  LampScreen(long token,List<Entry> entries){super(class_2561.method_43471("screen.bloodborne_rp.lamp.title"));this.token=token;this.entries=entries;}
  @Override protected void method_25426(){
   int start=page*6,end=Math.min(entries.size(),start+6),y=field_22790/2-80;
   for(Entry entry:entries.subList(start,end)){method_37063(class_4185.method_46430(class_2561.method_43470(entry.name),(button)->travel(entry.id)).method_46434(field_22789/2-100,y,200,20).method_46431());y+=24;}
   if(page>0)method_37063(class_4185.method_46430(class_2561.method_43470("<"),button->{page--;method_41843();}).method_46434(field_22789/2-100,field_22790/2+75,45,20).method_46431());
   if(end<entries.size())method_37063(class_4185.method_46430(class_2561.method_43470(">"),button->{page++;method_41843();}).method_46434(field_22789/2+55,field_22790/2+75,45,20).method_46431());
  }
  private void travel(UUID id){class_2540 out=new class_2540(Unpooled.buffer(24));out.method_10797(id);out.writeLong(token);ClientPlayNetworking.send(LampService.TRAVEL_PACKET,out);method_25419();}
 }
}
