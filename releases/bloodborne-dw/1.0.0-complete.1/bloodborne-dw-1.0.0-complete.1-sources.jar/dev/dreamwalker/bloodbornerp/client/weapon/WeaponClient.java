package dev.dreamwalker.bloodbornerp.client.weapon;

import dev.dreamwalker.bloodbornerp.weapon.TrickWeaponItem;
import dev.dreamwalker.bloodbornerp.weapon.WeaponRegistry;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_2540;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import software.bernie.geckolib.animatable.client.RenderProvider;

/** Client-only input and GeoItem renderer registration. */
@Environment(EnvType.CLIENT)
public final class WeaponClient {
  private static class_304 transformKey;
  private WeaponClient() {}

  public static void initialize() {
    TrickWeaponItem.clientRendererConsumer=WeaponClient::installRenderer;
    transformKey=KeyBindingHelper.registerKeyBinding(new class_304("key.bloodborne_rp.transform_weapon",class_3675.class_307.field_1668,GLFW.GLFW_KEY_R,"category.bloodborne_rp"));
    ClientTickEvents.END_CLIENT_TICK.register(client -> {
      while(transformKey.method_1436()) sendTransform(client.field_1724==null ? null : handFor(client.field_1724.method_6047(),client.field_1724.method_6079()));
    });
  }

  private static void installRenderer(java.util.function.Consumer<Object> consumer) {
    consumer.accept(new RenderProvider() {
      private TrickWeaponRenderer renderer;
      @Override public net.minecraft.class_756 getCustomRenderer() {
        if(renderer==null) renderer=new TrickWeaponRenderer();
        return renderer;
      }
    });
  }

  private static class_1268 handFor(net.minecraft.class_1799 main, net.minecraft.class_1799 off) {
    if(main.method_7909() instanceof TrickWeaponItem) return class_1268.field_5808;
    return off.method_7909() instanceof TrickWeaponItem ? class_1268.field_5810 : null;
  }

  private static void sendTransform(class_1268 hand) {
    if(hand==null || !ClientPlayNetworking.canSend(WeaponRegistry.TRANSFORM_PACKET)) return;
    class_2540 payload=new class_2540(Unpooled.buffer(1));
    payload.writeByte(hand==class_1268.field_5808 ? 0 : 1);
    ClientPlayNetworking.send(WeaponRegistry.TRANSFORM_PACKET,payload);
  }
}
