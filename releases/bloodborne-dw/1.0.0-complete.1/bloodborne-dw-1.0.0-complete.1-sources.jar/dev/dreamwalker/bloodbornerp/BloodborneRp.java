package dev.dreamwalker.bloodbornerp;
import dev.dreamwalker.bloodbornerp.content.AssetCatalog;
import dev.dreamwalker.bloodbornerp.mob.MobRegistry;
import dev.dreamwalker.bloodbornerp.weapon.WeaponRegistry;
import dev.dreamwalker.bloodbornerp.object.ObjectRegistry;
import dev.dreamwalker.bloodbornerp.lamp.LampService;
import dev.dreamwalker.bloodbornerp.command.RpCommands;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public final class BloodborneRp implements ModInitializer {
 public static final String ID="bloodborne_rp";
 public static final Logger LOGGER=LoggerFactory.getLogger(ID);
 public static class_2960 id(String path) { return new class_2960(ID,path); }
 @Override public void onInitialize() {
  AssetCatalog.load(); RpConfig.load(); dev.dreamwalker.bloodbornerp.content.RpSounds.register();
  MobRegistry.register(); WeaponRegistry.register(); ObjectRegistry.register();
  class_2378.method_10230(class_7923.field_41178,id("blood_vial"),new dev.dreamwalker.bloodbornerp.content.BloodVialItem());
  LampService.initialize(); RpCommands.register();
  class_2378.method_10230(class_7923.field_44687,id("adventures"),FabricItemGroup.builder().method_47321(class_2561.method_43471("itemGroup.bloodborne_rp.adventures"))
   .method_47320(()->new class_1799(WeaponRegistry.SAW_CLEAVER)).method_47317((context,entries)->{
    for(var item:class_7923.field_41178) if(class_7923.field_41178.method_10221(item).method_12836().equals(ID)) entries.method_45421(item);
   }).method_47324());
  LOGGER.info("Bloodborne RP initialized: standard Minecraft health; independent namespace");
 }
}
