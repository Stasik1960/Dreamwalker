package dev.dreamwalker.bloodbornerp.object;

import dev.dreamwalker.bloodbornerp.content.AssetBacked;
import dev.dreamwalker.bloodbornerp.content.AssetCatalog;
import dev.dreamwalker.bloodbornerp.content.AssetSpec;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public final class RpObjectEntity extends class_1297 implements GeoEntity, AssetBacked {
 private static final class_2940<Boolean> OPEN=class_2945.method_12791(RpObjectEntity.class,class_2943.field_13323);
 private static final class_2940<Boolean> LOCKED=class_2945.method_12791(RpObjectEntity.class,class_2943.field_13323);
 private final String assetId;
 private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);
 private final List<UUID> links=new ArrayList<>();
 private String transition="";private int transitionTicks;
 public RpObjectEntity(class_1299<? extends RpObjectEntity> type,class_1937 world,String assetId){super(type,world);this.assetId=assetId;refreshCollider();}
 @Override protected void method_5693(){field_6011.method_12784(OPEN,false);field_6011.method_12784(LOCKED,false);}
 @Override public class_2596<class_2602> method_18002(){return new class_2604(this);}
 @Override public String assetId(){return assetId;} public AssetSpec asset(){return AssetCatalog.get(assetId);}
 public boolean isOpen(){return field_6011.method_12789(OPEN);} public boolean isLocked(){return field_6011.method_12789(LOCKED);}
 public boolean setOpen(boolean open){if(!open&&canBeLinked()&&!method_37908().field_9236&&(!method_37908().method_8587(this,closedCollider())||!method_37908().method_8333(this,closedCollider(),e->e instanceof net.minecraft.class_1309&&e.method_5805()).isEmpty()))return false;if(isOpen()!=open){transition=open?"open":"close";transitionTicks=transitionTicks(transition);}field_6011.method_12778(OPEN,open);refreshCollider();return true;}
 public void setLocked(boolean locked){field_6011.method_12778(LOCKED,locked);}
 public boolean isMechanism(){return assetId.startsWith("lever_");}
 public boolean canBeLinked(){return assetId.contains("door")||assetId.contains("gate")||assetId.contains("chest");}
 public List<UUID> links(){return List.copyOf(links);}
 public boolean addLink(RpObjectEntity target){if(!isMechanism()||!target.canBeLinked()||target.method_37908()!=method_37908()||!target.method_37908().method_22340(target.method_24515())||links.size()>=dev.dreamwalker.bloodbornerp.RpConfig.INSTANCE.maxMechanismLinks||links.contains(target.method_5667()))return false;links.add(target.method_5667());return true;}
 public boolean removeLink(UUID target){return isMechanism()&&links.remove(target);}
 @Override public class_1269 method_5688(class_1657 player,class_1268 hand){
  if(method_37908().field_9236)return class_1269.field_5812;
  if(isLocked())return class_1269.field_5814;
  if(assetId.equals("hunterlamp")&&player instanceof net.minecraft.class_3222 serverPlayer){dev.dreamwalker.bloodbornerp.lamp.LampService.open(serverPlayer);return class_1269.field_21466;}
  if(isMechanism()){setOpen(!isOpen());for(UUID id:List.copyOf(links)){class_1297 e=((class_3218)method_37908()).method_14190(id);if(e instanceof RpObjectEntity target&&target.canBeLinked()&&!target.isLocked())target.setOpen(!target.isOpen());}return class_1269.field_21466;}
  if(canBeLinked()){setOpen(!isOpen());return class_1269.field_21466;} return class_1269.field_5811;
 }
 @Override public boolean method_30948(){return canBeLinked()&&!isOpen();}
 @Override public boolean method_5863(){return true;}
 @Override public float method_5871(){return .35F;}
 @Override public void method_5773(){super.method_5773();if(transitionTicks>0)transitionTicks--;}
 @Override protected void method_5749(class_2487 nbt){field_6011.method_12778(OPEN,nbt.method_10577("Open"));setLocked(nbt.method_10577("Locked"));links.clear();for(class_2520 entry:nbt.method_10554("Links",class_2520.field_33261)){if(links.size()>=dev.dreamwalker.bloodbornerp.RpConfig.INSTANCE.maxMechanismLinks)break;try{UUID id=net.minecraft.class_2512.method_25930(entry);if(!links.contains(id))links.add(id);}catch(IllegalArgumentException ignored){}}refreshCollider();}
 @Override protected void method_5652(class_2487 nbt){nbt.method_10556("Open",isOpen());nbt.method_10556("Locked",isLocked());class_2499 out=new class_2499();for(UUID id:links){if(out.size()>=dev.dreamwalker.bloodbornerp.RpConfig.INSTANCE.maxMechanismLinks)break;out.add(net.minecraft.class_2512.method_25929(id));}nbt.method_10566("Links",out);}
 @Override public void method_5674(class_2940<?> data){super.method_5674(data);if(data==OPEN){if(assetId!=null&&method_37908().field_9236){transition=isOpen()?"open":"close";transitionTicks=transitionTicks(transition);}refreshCollider();}}
 @Override public void method_5814(double x,double y,double z){super.method_5814(x,y,z);if(assetId!=null)refreshCollider();}
 @Override public void method_36456(float yaw){super.method_36456(yaw);if(assetId!=null)refreshCollider();}
 public void refreshCollider(){if(assetId==null||!canBeLinked())return;method_5857(closedCollider());}
 private net.minecraft.class_238 closedCollider(){float width=Math.max(.2f,asset().width());double depth=Math.min(.25d,width);double radians=Math.toRadians(Math.round(method_36454()/90f)*90f);double x=Math.abs(Math.cos(radians))>.5?depth:width;double z=Math.abs(Math.cos(radians))>.5?width:depth;return new net.minecraft.class_238(method_23317()-x/2,method_23318(),method_23321()-z/2,method_23317()+x/2,method_23318()+Math.max(.2f,asset().height()),method_23321()+z/2);}
 @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers){controllers.add(new AnimationController<>(this,"main",0,state->{String suffix=transitionTicks>0?transition:stableSuffix();AssetSpec.Clip clip=asset().clip(suffix);if(clip==null||clip.name().isBlank())return PlayState.STOP;Animation.LoopType loop=transitionTicks>0?Animation.LoopType.PLAY_ONCE:(clip.loop()?Animation.LoopType.LOOP:Animation.LoopType.HOLD_ON_LAST_FRAME);return state.setAndContinue(RawAnimation.begin().then(clip.name(),loop));}));}
 private String stableSuffix(){if(isOpen()){if(asset().clip("open_idle")!=null)return "open_idle";if(asset().clip("opened")!=null)return "opened";return "open";}if(asset().clip("closed_idle")!=null)return "closed_idle";if(asset().clip("closed")!=null)return "closed";return "idle";}
 private int transitionTicks(String suffix){AssetSpec.Clip clip=asset().clip(suffix);return clip==null?8:Math.max(1,Math.min(200,(int)(clip.seconds()*20)));}
 @Override public AnimatableInstanceCache getAnimatableInstanceCache(){return cache;}
}
