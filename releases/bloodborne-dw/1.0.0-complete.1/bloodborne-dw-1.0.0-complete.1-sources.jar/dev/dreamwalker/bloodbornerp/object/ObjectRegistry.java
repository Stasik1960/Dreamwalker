package dev.dreamwalker.bloodbornerp.object;

import dev.dreamwalker.bloodbornerp.BloodborneRp;
import dev.dreamwalker.bloodbornerp.content.AssetCatalog;
import dev.dreamwalker.bloodbornerp.content.AssetSpec;
import dev.dreamwalker.bloodbornerp.mob.MobRegistry;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

public final class ObjectRegistry {
 public static final Map<String,class_1299<RpObjectEntity>> TYPES=new LinkedHashMap<>(); private static boolean registered;
 private static final Set<String> NON_OBJECTS=Set.of("sawcleaver_false","sawcleaver_true","sawspear_false","sawspear_true","boomhammer_false","boomhammer_true","bullet","blood_puddle");
 private ObjectRegistry(){}
 public static void register(){if(registered)return;registered=true;for(var entry:AssetCatalog.all().entrySet()){String id=entry.getKey();if(NON_OBJECTS.contains(id)||MobRegistry.TYPES.containsKey(id))continue;AssetSpec spec=entry.getValue();class_1299<RpObjectEntity> type=class_2378.method_10230(class_7923.field_41177,BloodborneRp.id(id),FabricEntityTypeBuilder.<RpObjectEntity>create(class_1311.field_17715,(t,w)->new RpObjectEntity(t,w,id)).dimensions(class_4048.method_18385(Math.max(.1f,spec.width()),Math.max(.1f,spec.height()))).trackRangeChunks(8).build());TYPES.put(id,type);class_2378.method_10230(class_7923.field_41178,BloodborneRp.id(id+"_placer"),new PlacementObjectItem(id));}}
 public static boolean place(class_1657 player,String id,class_2338 pos,float yaw){if(!(player.method_37908() instanceof class_3218 world)||(!player.method_7337()&&!player.method_5687(2))||!world.method_8621().method_11952(pos)||!world.method_22340(pos)||!world.method_8320(pos).method_26215())return false;class_1299<RpObjectEntity> type=TYPES.get(id);if(type==null)return false;RpObjectEntity entity=new RpObjectEntity(type,world,id);float rotation=Math.round(yaw/90f)*90f;entity.method_5808(pos.method_10263()+.5,pos.method_10264(),pos.method_10260()+.5,rotation,0);entity.refreshCollider();class_238 box=entity.method_5829();if(!world.method_8587(entity,box)||!world.method_8335(entity,box).isEmpty())return false;return world.method_8649(entity);}
 public static RpObjectEntity objectAt(class_1657 player){return player.method_37908().method_8333(player,player.method_5829().method_1014(6),e->e instanceof RpObjectEntity).stream().map(e->(RpObjectEntity)e).min(java.util.Comparator.comparingDouble(player::method_5858)).orElse(null);}
}
