package dev.dreamwalker.bloodbornerp.object;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;

/** Builder-only placement item; the server revalidates all placement geometry. */
final class PlacementObjectItem extends class_1792 {
 private final String objectId;
 PlacementObjectItem(String objectId) { super(new class_1793().method_7889(16)); this.objectId=objectId; }
 @Override public class_1269 method_7884(net.minecraft.class_1838 context) {
  class_1657 player=context.method_8036(); if(player==null || (!player.method_7337() && !player.method_5687(2))) return class_1269.field_5814;
  if(context.method_8045().field_9236) return class_1269.field_5812;
  return ObjectRegistry.place(player,objectId,context.method_8037().method_10093(context.method_8038()),player.method_36454()) ? class_1269.field_21466 : class_1269.field_5814;
 }
}
