package dev.dreamwalker.bloodbornerp.lamp;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;

final class LampState extends class_18 {
 static final int SCHEMA=1; final Map<UUID,Node> nodes=new LinkedHashMap<>();
 static LampState get(class_3218 world){return world.method_17983().method_17924(LampState::fromNbt,LampState::new,"bloodborne_rp_lamps");}
 static LampState fromNbt(class_2487 nbt){LampState state=new LampState();if(nbt.method_10550("Schema")!=SCHEMA)return state;for(class_2520 raw:nbt.method_10554("Nodes",class_2520.field_33260)){if(state.nodes.size()>=256)break;class_2487 tag=(class_2487)raw;try{UUID id=tag.method_25926("Id"),lamp=tag.method_25926("Lamp");String name=tag.method_10558("Name");String dimension=tag.method_10558("Dimension");if(name.isBlank()||name.length()>64||dimension.length()>128||net.minecraft.class_2960.method_12829(dimension)==null||state.nodes.containsKey(id))continue;Node node=new Node(id,lamp,name,dimension,class_2338.method_10092(tag.method_10537("Pos")));for(class_2520 route:tag.method_10554("Routes",class_2520.field_33261)){if(node.routes.size()>=256)break;UUID routeId=net.minecraft.class_2512.method_25930(route);if(!routeId.equals(id)&&!node.routes.contains(routeId))node.routes.add(routeId);}state.nodes.put(id,node);}catch(Exception ignored){}}return state;}
 @Override public class_2487 method_75(class_2487 nbt){nbt.method_10569("Schema",SCHEMA);class_2499 out=new class_2499();for(Node node:nodes.values()){if(out.size()>=256)break;class_2487 tag=new class_2487();tag.method_25927("Id",node.id);tag.method_25927("Lamp",node.lamp);tag.method_10582("Name",node.name);tag.method_10582("Dimension",node.dimension);tag.method_10544("Pos",node.pos.method_10063());class_2499 routes=new class_2499();for(UUID route:node.routes){if(routes.size()>=256)break;routes.add(net.minecraft.class_2512.method_25929(route));}tag.method_10566("Routes",routes);out.add(tag);}nbt.method_10566("Nodes",out);return nbt;}
 static final class Node {final UUID id,lamp;String name,dimension;class_2338 pos;final List<UUID> routes=new ArrayList<>();Node(UUID id,UUID lamp,String name,String dimension,class_2338 pos){this.id=id;this.lamp=lamp;this.name=name;this.dimension=dimension;this.pos=pos;}}
}
