package dev.dreamwalker.bloodbornerp.lamp;

import dev.dreamwalker.bloodbornerp.BloodborneRp;
import dev.dreamwalker.bloodbornerp.RpConfig;
import dev.dreamwalker.bloodbornerp.object.RpObjectEntity;
import io.netty.buffer.Unpooled;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2540;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

/** Server-owned lamp graph and opaque-destination travel protocol. */
public final class LampService {
 public static final class_2960 LIST_PACKET=BloodborneRp.id("lamp_list"),TRAVEL_PACKET=BloodborneRp.id("lamp_travel");
 private static final Map<UUID,Context> CONTEXTS=new HashMap<>();
 private static final Map<UUID,Long> COOLDOWNS=new HashMap<>();
 private static final java.util.Set<UUID> PENDING=java.util.concurrent.ConcurrentHashMap.newKeySet();
 private static boolean initialized;
 private LampService(){}
 public static void initialize(){if(initialized)return;initialized=true;ServerPlayNetworking.registerGlobalReceiver(TRAVEL_PACKET,(server,player,handler,buf,response)->{if(buf.readableBytes()!=24)return;UUID destination=buf.method_10790();long context=buf.readLong();if(!PENDING.add(player.method_5667()))return;server.execute(()->{try{if(server.method_3760().method_14602(player.method_5667())==player)travel(player,destination,context);}finally{PENDING.remove(player.method_5667());}});});ServerTickEvents.END_SERVER_TICK.register(server->{long tick=server.method_3780();CONTEXTS.entrySet().removeIf(entry->entry.getValue().expiresAt<tick);COOLDOWNS.entrySet().removeIf(entry->entry.getValue()<=tick);});ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->clearPlayer(handler.field_14140.method_5667()));ServerLifecycleEvents.SERVER_STOPPING.register(server->{CONTEXTS.clear();COOLDOWNS.clear();PENDING.clear();});}
 public static void open(class_3222 player){if(!RpConfig.INSTANCE.playerTravelEnabled)return;LampState.Node source=nearbySource(player);if(source==null)return;long token=player.method_6051().method_43055();CONTEXTS.put(player.method_5667(),new Context(token,source.id,player.method_5682().method_3780()+200));class_2540 out=new class_2540(Unpooled.buffer());out.writeLong(token);List<LampState.Node> destinations=destinations(player.method_5682(),source);out.method_10804(destinations.size());for(LampState.Node node:destinations){out.method_10797(node.id);out.method_10788(node.name,64);}ServerPlayNetworking.send(player,LIST_PACKET,out);}
 private static List<LampState.Node> destinations(MinecraftServer server,LampState.Node source){List<LampState.Node> out=new ArrayList<>();LampState state=state(server);for(UUID id:source.routes){LampState.Node node=state.nodes.get(id);if(node!=null&&out.size()<RpConfig.INSTANCE.maxLampDestinations)out.add(node);}return out;}
 private static boolean travel(class_3222 player,UUID destination,long token){long tick=player.method_5682().method_3780();Context context=CONTEXTS.remove(player.method_5667());if(context==null||!LampPolicy.validContext(context.token,token,context.expiresAt,tick)||!player.method_5805()||player.method_7325()||!RpConfig.INSTANCE.playerTravelEnabled||COOLDOWNS.getOrDefault(player.method_5667(),0L)>tick)return fail(player);LampState.Node source=nearbySource(player);if(source==null||!source.id.equals(context.source))return fail(player);LampState state=state(player.method_5682());if(!source.routes.contains(destination))return fail(player);LampState.Node target=state.nodes.get(destination);if(target==null||class_2960.method_12829(target.dimension)==null)return fail(player);class_3218 targetWorld=player.method_5682().method_3847(class_5321.method_29179(class_7924.field_41223,new class_2960(target.dimension)));if(targetWorld==null||!targetWorld.method_22340(target.pos)||!targetWorld.method_8621().method_11952(target.pos))return fail(player);class_1297 targetEntity=targetWorld.method_14190(target.lamp);if(!(targetEntity instanceof RpObjectEntity lamp)||!lamp.assetId().equals("hunterlamp"))return fail(player);class_2338 landing=findLanding(targetWorld,player,lamp.method_24515());if(landing==null)return fail(player);player.method_14251(targetWorld,landing.method_10263()+.5,landing.method_10264(),landing.method_10260()+.5,player.method_36454(),player.method_36455());COOLDOWNS.put(player.method_5667(),tick+RpConfig.INSTANCE.lampTravelCooldownTicks);return true;}
 private static boolean fail(class_3222 player){clear(player);return false;}
 static long contextTokenForTest(UUID player){Context context=CONTEXTS.get(player);return context==null?Long.MIN_VALUE:context.token;}
 static boolean travelForTest(class_3222 player,UUID destination,long token){return travel(player,destination,token);}
 static void clearPlayerForTest(UUID player){clearPlayer(player);}
 private static void clearPlayer(UUID player){CONTEXTS.remove(player);COOLDOWNS.remove(player);}
 private static void clear(class_3222 player){class_2540 out=new class_2540(Unpooled.buffer(9));out.writeLong(0);out.method_10804(0);ServerPlayNetworking.send(player,LIST_PACKET,out);}
 private static LampState.Node nearbySource(class_3222 player){LampState state=state(player.method_5682());for(LampState.Node node:state.nodes.values()){if(!node.dimension.equals(player.method_37908().method_27983().method_29177().toString())||!player.method_51469().method_22340(node.pos))continue;class_1297 entity=player.method_51469().method_14190(node.lamp);if(entity instanceof RpObjectEntity object&&object.assetId().equals("hunterlamp")&&object.method_5858(player)<=25)return node;}return null;}
 private static class_2338 findLanding(class_3218 world,class_3222 player,class_2338 lamp){
  float height=Math.max(1.8F,player.method_17682());
  for(int[] offset:new int[][]{{2,0},{-2,0},{0,2},{0,-2}}){
   class_2338 pos=lamp.method_10069(offset[0],0,offset[1]);
   if(pos.method_10264()<=world.method_31607()||pos.method_10264()+height>=world.method_31600()||!world.method_22340(pos))continue;
   if(!world.method_8316(pos).method_15769()||!world.method_8316(pos.method_10084()).method_15769())continue;
   if(hazard(world.method_8320(pos))||hazard(world.method_8320(pos.method_10084())))continue;
   var support=world.method_8320(pos.method_10074());
   if(support.method_26220(world,pos.method_10074()).method_1110()||!world.method_8316(pos.method_10074()).method_15769()
       ||support.method_27852(net.minecraft.class_2246.field_10092)||support.method_27852(net.minecraft.class_2246.field_17350)
       ||support.method_27852(net.minecraft.class_2246.field_23860)||support.method_27852(net.minecraft.class_2246.field_10029))continue;
   var box=new net.minecraft.class_238(pos.method_10263()+.5-player.method_17681()/2,pos.method_10264(),pos.method_10260()+.5-player.method_17681()/2,
       pos.method_10263()+.5+player.method_17681()/2,pos.method_10264()+height,pos.method_10260()+.5+player.method_17681()/2);
   if(world.method_8621().method_11966(box)&&world.method_8587(player,box)
       &&world.method_8333(player,box,e->e instanceof net.minecraft.class_1309&&e.method_5805()).isEmpty())return pos;
  }
  return null;
 }
 private static boolean hazard(net.minecraft.class_2680 state){
  return state.method_26164(net.minecraft.class_3481.field_21952)||state.method_27852(net.minecraft.class_2246.field_10606)
      ||state.method_27852(net.minecraft.class_2246.field_16999)||state.method_27852(net.minecraft.class_2246.field_27879)
      ||state.method_27852(net.minecraft.class_2246.field_10316)||state.method_27852(net.minecraft.class_2246.field_10027)
      ||state.method_27852(net.minecraft.class_2246.field_10613);
 }
 private static LampState state(MinecraftServer server){return LampState.get(server.method_30002());}
 public static boolean register(class_3222 player,String name){if(!LampPolicy.validName(name))return false;RpObjectEntity object=dev.dreamwalker.bloodbornerp.object.ObjectRegistry.objectAt(player);if(object==null||!object.assetId().equals("hunterlamp"))return false;LampState state=state(player.method_5682());if(state.nodes.size()>=RpConfig.INSTANCE.maxLampDestinations)return false;for(LampState.Node node:state.nodes.values())if(node.lamp.equals(object.method_5667()))return false;UUID id=UUID.randomUUID();state.nodes.put(id,new LampState.Node(id,object.method_5667(),name,player.method_37908().method_27983().method_29177().toString(),object.method_24515()));state.method_80();return true;}
 public static boolean rename(MinecraftServer server,UUID id,String name){LampState.Node node=state(server).nodes.get(id);if(node==null||!LampPolicy.validName(name))return false;node.name=name;state(server).method_80();return true;}
 public static boolean remove(MinecraftServer server,UUID id){LampState state=state(server);if(state.nodes.remove(id)==null)return false;for(LampState.Node node:state.nodes.values())node.routes.remove(id);state.method_80();return true;}
 public static void removeByEntity(MinecraftServer server,UUID entityId){LampState state=state(server);List<UUID> removed=new ArrayList<>();for(LampState.Node node:state.nodes.values())if(node.lamp.equals(entityId))removed.add(node.id);if(removed.isEmpty())return;for(UUID id:removed)state.nodes.remove(id);for(LampState.Node node:state.nodes.values())node.routes.removeIf(removed::contains);state.method_80();}
 public static boolean route(MinecraftServer server,UUID from,UUID to,boolean open){LampState state=state(server);LampState.Node source=state.nodes.get(from);if(source==null||state.nodes.get(to)==null||from.equals(to))return false;if(open){if(!LampPolicy.validRoute(source.routes.size(),RpConfig.INSTANCE.maxLampDestinations,source.routes.contains(to)))return false;source.routes.add(to);}else if(!source.routes.remove(to))return false;state.method_80();return true;}
 public static List<LampInfo> list(MinecraftServer server){List<LampInfo> out=new ArrayList<>();for(LampState.Node node:state(server).nodes.values()){if(out.size()>=RpConfig.INSTANCE.maxLampDestinations)break;out.add(new LampInfo(node.id,node.name));}return List.copyOf(out);}
 public record LampInfo(UUID id,String name){}
 private record Context(long token,UUID source,long expiresAt){}
}
