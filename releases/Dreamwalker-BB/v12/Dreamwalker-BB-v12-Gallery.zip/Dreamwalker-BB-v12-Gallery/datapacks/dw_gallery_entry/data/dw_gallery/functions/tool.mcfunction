give @s bloodborne_dw:bb_tool
tellraw @s {"text": "BB инструмент: ПКМ — режим, ЛКМ — применить. /bb select <радиус>; /bb none. Подробнее: TOOL-INSTRUCTIONS.txt.", "color": "gold"}
