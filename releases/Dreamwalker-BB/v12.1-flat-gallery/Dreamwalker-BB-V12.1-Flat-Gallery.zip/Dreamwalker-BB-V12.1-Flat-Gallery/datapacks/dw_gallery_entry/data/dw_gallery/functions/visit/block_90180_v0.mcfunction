tp @s 209.0 63.88 1111.0 0 14.0362
tellraw @s {"text": "Пилястра · вариант 3 | ID 90180 | bloodborne_dw:source_addon_pilaster_2 | вариант 0 | absent", "color": "gold"}
