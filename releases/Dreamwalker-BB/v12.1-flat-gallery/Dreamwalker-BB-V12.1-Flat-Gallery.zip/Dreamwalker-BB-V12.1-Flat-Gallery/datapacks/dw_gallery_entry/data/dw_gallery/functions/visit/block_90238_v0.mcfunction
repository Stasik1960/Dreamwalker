tp @s 90.0 64.88 237.2 0 11.7683
tellraw @s {"text": "Надгробие · вариант 3 | ID 90238 | bloodborne_dw:source_addon_tombstone_gathered_2 | вариант 0 | new", "color": "gold"}
