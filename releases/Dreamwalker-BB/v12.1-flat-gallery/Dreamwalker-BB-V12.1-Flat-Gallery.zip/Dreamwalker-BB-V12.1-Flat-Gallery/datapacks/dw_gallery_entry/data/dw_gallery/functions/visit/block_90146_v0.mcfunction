tp @s 183.0 64.38 184.0 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 3 | ID 90146 | bloodborne_dw:source_addon_grass_2 | вариант 0 | new", "color": "gold"}
