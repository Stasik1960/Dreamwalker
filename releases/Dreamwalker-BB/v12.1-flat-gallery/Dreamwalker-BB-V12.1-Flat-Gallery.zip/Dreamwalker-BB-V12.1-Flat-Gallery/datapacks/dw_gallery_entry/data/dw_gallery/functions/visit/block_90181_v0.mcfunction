tp @s 221.5 63.88 1110.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · вариант 1 | ID 90181 | bloodborne_dw:source_addon_pink_glazed_terracotta_0 | вариант 0 | absent", "color": "gold"}
