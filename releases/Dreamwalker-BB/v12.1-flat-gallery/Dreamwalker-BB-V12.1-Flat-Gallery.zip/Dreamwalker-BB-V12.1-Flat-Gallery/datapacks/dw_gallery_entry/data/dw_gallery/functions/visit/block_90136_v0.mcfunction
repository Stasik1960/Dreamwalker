tp @s 274.5 64.38 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 6 | ID 90136 | bloodborne_dw:source_addon_floor_panels_5 | вариант 0 | new", "color": "gold"}
