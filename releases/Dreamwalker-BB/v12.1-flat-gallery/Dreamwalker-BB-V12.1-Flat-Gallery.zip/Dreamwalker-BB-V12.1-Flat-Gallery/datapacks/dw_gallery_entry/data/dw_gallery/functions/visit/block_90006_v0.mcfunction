tp @s 117.5 63.9523 -0.5 0 14.0362
tellraw @s {"text": "Вертикальная деревянная лестница | ID 90006 | bloodborne_dw:prototype_ladder | вариант 0 | v12", "color": "gold"}
