tp @s 239.0 64.38 184.0 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 6 | ID 90149 | bloodborne_dw:source_addon_grass_5 | вариант 0 | new", "color": "gold"}
