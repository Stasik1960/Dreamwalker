tp @s 288.5 64.38 267.5 0 14.0362
tellraw @s {"text": "Остроконечный готический фронтон · наклон 90° | ID 90286 | bloodborne_dw:source_birch_wood | вариант 1 | new", "color": "gold"}
