tp @s 275.5 64.88 155.5 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 2 | ID 90094 | bloodborne_dw:source_addon_crimson_button_1 | вариант 0 | new", "color": "gold"}
