tp @s 117.5 64.38 175.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 8 | ID 90127 | bloodborne_dw:source_addon_floor_dec_7 | вариант 0 | new", "color": "gold"}
