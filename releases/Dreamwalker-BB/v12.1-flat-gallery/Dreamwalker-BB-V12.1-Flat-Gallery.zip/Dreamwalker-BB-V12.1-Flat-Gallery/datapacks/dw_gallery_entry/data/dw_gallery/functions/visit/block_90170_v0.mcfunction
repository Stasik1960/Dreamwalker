tp @s 224.5 64.78 190.6 0 9.4623
tellraw @s {"text": "Каменный фриз с орнаментом · вариант 2 | ID 90170 | bloodborne_dw:source_addon_note_1 | вариант 0 | new", "color": "gold"}
