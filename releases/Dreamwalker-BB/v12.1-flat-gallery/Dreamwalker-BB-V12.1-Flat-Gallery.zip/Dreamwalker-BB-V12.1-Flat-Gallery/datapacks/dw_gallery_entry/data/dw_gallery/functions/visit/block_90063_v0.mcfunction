tp @s 209.5 64.88 1101.5 0 14.0362
tellraw @s {"text": "Составное декоративное украшение | ID 90063 | bloodborne_dw:source_addon_brown_terracotta | вариант 0 | absent", "color": "gold"}
