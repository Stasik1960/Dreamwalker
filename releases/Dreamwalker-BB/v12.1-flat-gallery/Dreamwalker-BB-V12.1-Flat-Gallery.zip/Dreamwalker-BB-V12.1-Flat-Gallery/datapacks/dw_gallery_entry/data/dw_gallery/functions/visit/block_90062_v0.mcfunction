tp @s 288.0 64.88 136.0 0 14.0362
tellraw @s {"text": "Свечи · вариант 2 | ID 90062 | bloodborne_dw:source_addon_brown_candel_1 | вариант 0 | new", "color": "gold"}
