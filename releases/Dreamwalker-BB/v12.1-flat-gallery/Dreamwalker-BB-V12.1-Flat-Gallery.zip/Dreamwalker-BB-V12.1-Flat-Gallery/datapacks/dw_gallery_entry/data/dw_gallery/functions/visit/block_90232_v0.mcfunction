tp @s 256.5 64.38 227.5 0 14.0362
tellraw @s {"text": "Поваленное бревно со свисающим мхом · вариант 3 | ID 90232 | bloodborne_dw:source_addon_stripped_oka_log_2 | вариант 0 | new", "color": "gold"}
