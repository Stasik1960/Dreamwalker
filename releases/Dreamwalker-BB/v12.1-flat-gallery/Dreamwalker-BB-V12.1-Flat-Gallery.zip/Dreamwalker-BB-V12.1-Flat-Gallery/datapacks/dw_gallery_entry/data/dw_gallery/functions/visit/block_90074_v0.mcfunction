tp @s 209.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка · вариант 7 | ID 90074 | bloodborne_dw:source_addon_button_6 | вариант 0 | new", "color": "gold"}
