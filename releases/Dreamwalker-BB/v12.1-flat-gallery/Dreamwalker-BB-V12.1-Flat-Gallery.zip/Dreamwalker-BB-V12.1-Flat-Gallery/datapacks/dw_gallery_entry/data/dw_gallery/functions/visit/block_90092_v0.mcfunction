tp @s 238.5 64.88 156.0 0 14.0362
tellraw @s {"text": "Решётчатая напольная панель | ID 90092 | bloodborne_dw:source_addon_coral_dead_horn_coral_wall_fan | вариант 0 | new", "color": "gold"}
