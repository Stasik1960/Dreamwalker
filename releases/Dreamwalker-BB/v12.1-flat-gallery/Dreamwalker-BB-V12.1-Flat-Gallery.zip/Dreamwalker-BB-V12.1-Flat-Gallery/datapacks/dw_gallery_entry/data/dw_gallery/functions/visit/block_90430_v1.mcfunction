tp @s 182.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 180° | ID 90430 | bloodborne_dw:source_cobbled_deepslate_stairs_we | вариант 1 | new", "color": "gold"}
