tp @s 287.5 63.88 347.5 0 14.0362
tellraw @s {"text": "Архитектурная плита | ID 90421 | bloodborne_dw:source_cobbled_deepslate_slab | вариант 0 | new", "color": "gold"}
