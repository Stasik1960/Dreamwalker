tp @s 133.5 64.88 1110.5 0 14.0362
tellraw @s {"text": "Светильник | ID 90157 | bloodborne_dw:source_addon_lamp | вариант 0 | absent", "color": "gold"}
