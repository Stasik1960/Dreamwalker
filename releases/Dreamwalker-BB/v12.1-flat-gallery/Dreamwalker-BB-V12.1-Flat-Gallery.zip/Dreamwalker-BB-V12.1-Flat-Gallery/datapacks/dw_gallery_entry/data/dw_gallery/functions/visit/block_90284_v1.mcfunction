tp @s 239.0 64.38 267.5 0 14.0362
tellraw @s {"text": "Дверная секция · наклон 180° | ID 90284 | bloodborne_dw:source_birch_trapdoor | вариант 1 | new", "color": "gold"}
