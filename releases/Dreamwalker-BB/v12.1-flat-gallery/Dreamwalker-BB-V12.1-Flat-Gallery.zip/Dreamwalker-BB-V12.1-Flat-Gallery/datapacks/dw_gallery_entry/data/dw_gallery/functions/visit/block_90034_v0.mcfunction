tp @s 209.0 64.38 127.0 0 14.0362
tellraw @s {"text": "Дверная секция · открытая | ID 90034 | bloodborne_dw:source_acacia_trapdoor_open | вариант 0 | new", "color": "gold"}
