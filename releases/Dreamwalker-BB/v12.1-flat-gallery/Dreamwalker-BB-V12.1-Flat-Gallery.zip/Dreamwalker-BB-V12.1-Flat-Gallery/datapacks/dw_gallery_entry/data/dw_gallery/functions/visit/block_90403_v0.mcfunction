tp @s 147.5 64.88 338.0 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка | ID 90403 | bloodborne_dw:source_buttons_dark_oak_dark_oak_button | вариант 0 | new", "color": "gold"}
