tp @s 116.5 63.88 257.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90275 | bloodborne_dw:source_bamboo_mosaic_stairs | вариант 0 | new", "color": "gold"}
