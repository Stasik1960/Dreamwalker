tp @s 239.0 63.88 1111.0 0 14.0362
tellraw @s {"text": "Кровельный модуль · секция | ID 90186 | bloodborne_dw:source_addon_roof_spike_side | вариант 0 | absent", "color": "gold"}
