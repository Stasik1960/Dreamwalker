tp @s 287.5 63.88 1120.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка | ID 90450 | bloodborne_dw:source_cracked_stone_bricks | вариант 0 | absent", "color": "gold"}
