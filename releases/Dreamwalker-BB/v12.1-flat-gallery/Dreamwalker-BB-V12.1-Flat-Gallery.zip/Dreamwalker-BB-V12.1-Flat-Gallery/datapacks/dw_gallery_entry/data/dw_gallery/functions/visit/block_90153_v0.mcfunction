tp @s 3.0 64.38 192.5 0 14.0362
tellraw @s {"text": "Кирпичный парапет с зубцами · вариант 1 | ID 90153 | bloodborne_dw:source_addon_green_glazed_0 | вариант 0 | new", "color": "gold"}
