tp @s 102.0 64.88 183.5 0 14.0362
tellraw @s {"text": "Секция ворот · вариант 1 | ID 90142 | bloodborne_dw:source_addon_gate2_0 | вариант 0 | new", "color": "gold"}
