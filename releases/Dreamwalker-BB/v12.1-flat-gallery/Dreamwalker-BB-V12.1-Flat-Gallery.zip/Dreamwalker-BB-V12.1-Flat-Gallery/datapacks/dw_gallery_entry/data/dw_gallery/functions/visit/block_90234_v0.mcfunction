tp @s 2.5 63.88 237.5 0 14.0362
tellraw @s {"text": "Длинное поваленное бревно · вариант 5 | ID 90234 | bloodborne_dw:source_addon_stripped_oka_log_4 | вариант 0 | new", "color": "gold"}
