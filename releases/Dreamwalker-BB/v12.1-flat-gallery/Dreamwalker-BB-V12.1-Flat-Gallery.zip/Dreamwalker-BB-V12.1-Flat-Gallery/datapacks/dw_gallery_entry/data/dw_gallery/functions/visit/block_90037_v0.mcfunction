tp @s 256.5 64.38 127.5 0 14.0362
tellraw @s {"text": "Секция ворот · открытая, вариант 1 | ID 90037 | bloodborne_dw:source_addon_acacia_fence_gate_open_0 | вариант 0 | new", "color": "gold"}
