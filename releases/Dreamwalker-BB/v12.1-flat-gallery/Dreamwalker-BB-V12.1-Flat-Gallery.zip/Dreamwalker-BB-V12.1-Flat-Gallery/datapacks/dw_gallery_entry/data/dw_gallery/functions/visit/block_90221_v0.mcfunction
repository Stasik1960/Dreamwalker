tp @s 133.5 64.88 227.0 0 14.0362
tellraw @s {"text": "Секция ворот · открытая, вариант 1 | ID 90221 | bloodborne_dw:source_addon_spruce_fence_gate_open_0 | вариант 0 | new", "color": "gold"}
