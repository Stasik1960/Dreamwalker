tp @s 89.5 64.38 136.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 2 | ID 90045 | bloodborne_dw:source_addon_barrel_1 | вариант 0 | new", "color": "gold"}
