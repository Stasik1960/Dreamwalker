tp @s 158.5 64.38 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 1 | ID 90130 | bloodborne_dw:source_addon_floor_panels_0 | вариант 0 | new", "color": "gold"}
