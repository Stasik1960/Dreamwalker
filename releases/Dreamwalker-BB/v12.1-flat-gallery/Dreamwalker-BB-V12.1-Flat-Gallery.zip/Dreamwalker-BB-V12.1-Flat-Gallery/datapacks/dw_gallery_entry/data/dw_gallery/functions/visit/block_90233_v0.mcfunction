tp @s 287.5 64.38 227.5 0 14.0362
tellraw @s {"text": "Поваленное бревно с редким мхом · вариант 4 | ID 90233 | bloodborne_dw:source_addon_stripped_oka_log_3 | вариант 0 | new", "color": "gold"}
