tp @s 73.0 64.38 205.0 0 14.0362
tellraw @s {"text": "Пилястра · вариант 1 | ID 90178 | bloodborne_dw:source_addon_pilaster_0 | вариант 0 | new", "color": "gold"}
