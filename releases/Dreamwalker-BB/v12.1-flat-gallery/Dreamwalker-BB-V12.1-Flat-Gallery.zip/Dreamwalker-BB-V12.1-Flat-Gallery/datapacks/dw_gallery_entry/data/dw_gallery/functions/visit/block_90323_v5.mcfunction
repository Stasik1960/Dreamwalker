tp @s 37.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · внутренний угол · наклон 180° | ID 90323 | bloodborne_dw:source_brick_stairs_inner | вариант 5 | new", "color": "gold"}
