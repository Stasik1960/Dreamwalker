tp @s 116.5 64.38 127.0 0 14.0362
tellraw @s {"text": "Настенный орнамент · верхняя, вариант 3 | ID 90027 | bloodborne_dw:source__wall_dec_top_2 | вариант 0 | new", "color": "gold"}
