tp @s 238.5 63.88 313.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90343 | bloodborne_dw:source_bricks_cracked_bricks_1 | вариант 0 | new", "color": "gold"}
