tp @s 2.5 64.88 246.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 8 | ID 90251 | bloodborne_dw:source_addon_wall_deco_7 | вариант 0 | new", "color": "gold"}
