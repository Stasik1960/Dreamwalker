tp @s 146.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · внешний угол · наклон 180° | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 3 | new", "color": "gold"}
