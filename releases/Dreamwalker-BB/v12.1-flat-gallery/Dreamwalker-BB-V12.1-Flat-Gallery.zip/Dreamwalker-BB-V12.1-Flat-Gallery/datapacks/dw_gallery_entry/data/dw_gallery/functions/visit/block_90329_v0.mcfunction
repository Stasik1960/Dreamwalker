tp @s 274.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90329 | bloodborne_dw:source_bricks_bricks_0 | вариант 0 | new", "color": "gold"}
