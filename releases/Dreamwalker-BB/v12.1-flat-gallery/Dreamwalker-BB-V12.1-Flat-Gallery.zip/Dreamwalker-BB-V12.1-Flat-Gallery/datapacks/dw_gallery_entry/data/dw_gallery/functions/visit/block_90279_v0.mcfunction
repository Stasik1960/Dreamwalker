tp @s 146.5 63.88 266.5 0 14.0362
tellraw @s {"text": "Перекладина на каменных опорах | ID 90279 | bloodborne_dw:source_bell_floor | вариант 0 | new", "color": "gold"}
