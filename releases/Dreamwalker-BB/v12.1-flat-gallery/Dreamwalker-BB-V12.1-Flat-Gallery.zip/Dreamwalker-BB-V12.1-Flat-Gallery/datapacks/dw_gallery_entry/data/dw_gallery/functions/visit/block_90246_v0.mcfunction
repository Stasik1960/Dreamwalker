tp @s 102.5 64.38 1120.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 3 | ID 90246 | bloodborne_dw:source_addon_wall_deco_2 | вариант 0 | absent", "color": "gold"}
