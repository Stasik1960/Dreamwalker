tp @s 72.5 63.88 297.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь | ID 90320 | bloodborne_dw:source_brick_slab | вариант 0 | new", "color": "gold"}
