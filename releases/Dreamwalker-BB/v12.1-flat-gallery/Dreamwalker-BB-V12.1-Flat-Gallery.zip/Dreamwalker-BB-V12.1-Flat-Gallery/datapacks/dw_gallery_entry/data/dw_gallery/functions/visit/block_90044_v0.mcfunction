tp @s 72.5 64.38 135.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 1 | ID 90044 | bloodborne_dw:source_addon_barrel_0 | вариант 0 | new", "color": "gold"}
