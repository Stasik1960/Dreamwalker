tp @s 146.5 63.88 165.5 0 14.0362
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 5 | ID 90103 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_4 | вариант 0 | new", "color": "gold"}
