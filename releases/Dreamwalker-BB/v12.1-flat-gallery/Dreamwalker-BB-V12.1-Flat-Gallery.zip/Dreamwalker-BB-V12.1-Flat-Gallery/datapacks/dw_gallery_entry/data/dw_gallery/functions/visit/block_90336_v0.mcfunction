tp @s 117.5 63.88 314.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90336 | bloodborne_dw:source_bricks_bricks_r_3 | вариант 0 | new", "color": "gold"}
