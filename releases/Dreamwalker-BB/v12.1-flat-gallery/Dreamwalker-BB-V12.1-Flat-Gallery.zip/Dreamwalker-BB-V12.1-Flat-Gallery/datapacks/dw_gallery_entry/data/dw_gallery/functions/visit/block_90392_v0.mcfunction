tp @s 73.5 64.88 337.5 0 14.0362
tellraw @s {"text": "Наклонная ажурная секция ограды | ID 90392 | bloodborne_dw:source_brown_glazed_terracotta | вариант 0 | new", "color": "gold"}
