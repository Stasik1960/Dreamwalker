tp @s 274.5 63.88 347.5 0 14.0362
tellraw @s {"text": "Гладкий тёмно-серый камень | ID 90420 | bloodborne_dw:source_cobbled_deepslate | вариант 0 | new", "color": "gold"}
