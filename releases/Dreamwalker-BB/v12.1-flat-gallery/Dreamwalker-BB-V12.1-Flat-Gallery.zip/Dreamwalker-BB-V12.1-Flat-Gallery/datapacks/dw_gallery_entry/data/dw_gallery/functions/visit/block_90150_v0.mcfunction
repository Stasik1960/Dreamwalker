tp @s 257.0 63.88 183.5 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 7 | ID 90150 | bloodborne_dw:source_addon_grass_6 | вариант 0 | new", "color": "gold"}
