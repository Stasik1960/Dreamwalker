tp @s 88.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 9 | ID 90350 | bloodborne_dw:source_bricks_cracked_bricks_8 | вариант 0 | new", "color": "gold"}
