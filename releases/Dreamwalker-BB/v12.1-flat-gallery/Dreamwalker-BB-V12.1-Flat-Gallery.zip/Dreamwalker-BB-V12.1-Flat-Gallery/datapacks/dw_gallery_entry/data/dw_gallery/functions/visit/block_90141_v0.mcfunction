tp @s 88.5 64.38 183.5 0 14.0362
tellraw @s {"text": "Напольная панель | ID 90141 | bloodborne_dw:source_addon_floor_panels_empty | вариант 0 | new", "color": "gold"}
