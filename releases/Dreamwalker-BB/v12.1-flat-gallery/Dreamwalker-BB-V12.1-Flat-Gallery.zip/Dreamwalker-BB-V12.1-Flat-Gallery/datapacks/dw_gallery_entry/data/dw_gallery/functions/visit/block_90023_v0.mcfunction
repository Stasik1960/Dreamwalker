tp @s 2.5 64.38 127.0 0 14.0362
tellraw @s {"text": "Настенный орнамент · нижняя | ID 90023 | bloodborne_dw:source__wall_dec_bottom | вариант 0 | new", "color": "gold"}
