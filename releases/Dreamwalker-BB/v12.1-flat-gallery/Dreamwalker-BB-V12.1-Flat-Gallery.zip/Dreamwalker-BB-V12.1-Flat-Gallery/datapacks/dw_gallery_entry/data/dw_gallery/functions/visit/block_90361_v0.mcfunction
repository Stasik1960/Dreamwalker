tp @s 182.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90361 | bloodborne_dw:source_bricks_purpur_block_1 | вариант 0 | new", "color": "gold"}
