tp @s 158.5 63.88 297.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · закреплённые UV 90° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 4 | new", "color": "gold"}
