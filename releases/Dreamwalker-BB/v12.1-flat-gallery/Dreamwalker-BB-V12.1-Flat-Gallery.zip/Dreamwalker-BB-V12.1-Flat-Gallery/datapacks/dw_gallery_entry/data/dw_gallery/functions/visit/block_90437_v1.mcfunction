tp @s 287.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90437 | bloodborne_dw:source_cobblestone_stairs | вариант 1 | new", "color": "gold"}
