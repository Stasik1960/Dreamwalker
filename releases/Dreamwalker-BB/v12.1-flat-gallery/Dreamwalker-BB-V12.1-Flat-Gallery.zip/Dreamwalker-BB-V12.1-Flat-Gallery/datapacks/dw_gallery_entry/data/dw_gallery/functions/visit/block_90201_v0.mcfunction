tp @s 102.5 64.38 216.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 4 | ID 90201 | bloodborne_dw:source_addon_slabs_1_3 | вариант 0 | new", "color": "gold"}
