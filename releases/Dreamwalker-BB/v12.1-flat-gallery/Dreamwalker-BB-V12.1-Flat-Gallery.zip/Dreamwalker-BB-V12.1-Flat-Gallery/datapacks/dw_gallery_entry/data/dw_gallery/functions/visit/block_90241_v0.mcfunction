tp @s 135.0 65.38 236.7 0 11.7683
tellraw @s {"text": "Надгробие · вариант 6 | ID 90241 | bloodborne_dw:source_addon_tombstone_gathered_5 | вариант 0 | new", "color": "gold"}
