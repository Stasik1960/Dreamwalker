tp @s 221.5 63.88 135.5 0 14.0362
tellraw @s {"text": "Пузырьки крови | ID 90055 | bloodborne_dw:source_addon_bloodviles | вариант 0 | new", "color": "gold"}
