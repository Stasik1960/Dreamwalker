tp @s 209.5 63.88 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 11 | ID 90132 | bloodborne_dw:source_addon_floor_panels_10 | вариант 0 | new", "color": "gold"}
