tp @s 101.5 63.88 165.5 0 14.0362
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 2 | ID 90100 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_1 | вариант 0 | new", "color": "gold"}
