tp @s 2.5 63.88 257.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90270 | bloodborne_dw:source_andesite_slab_top | вариант 0 | new", "color": "gold"}
