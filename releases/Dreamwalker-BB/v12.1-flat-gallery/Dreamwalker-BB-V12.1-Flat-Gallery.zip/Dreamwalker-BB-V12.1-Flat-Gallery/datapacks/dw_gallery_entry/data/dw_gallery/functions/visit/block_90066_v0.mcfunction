tp @s 73.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Напольная декоративная пластина · вариант 12 | ID 90066 | bloodborne_dw:source_addon_button_11 | вариант 0 | new", "color": "gold"}
