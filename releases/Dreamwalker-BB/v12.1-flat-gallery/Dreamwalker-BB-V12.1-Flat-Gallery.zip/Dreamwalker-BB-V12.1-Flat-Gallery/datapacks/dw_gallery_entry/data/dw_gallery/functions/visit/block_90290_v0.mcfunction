tp @s 73.5 63.88 276.5 0 14.0362
tellraw @s {"text": "Решётчатая секция с ромбовым узором | ID 90290 | bloodborne_dw:source_black_stained_glass | вариант 0 | new", "color": "gold"}
