tp @s 148.5 63.88 246.5 0 9.4623
tellraw @s {"text": "Пилястра · вариант 6 | ID 90258 | bloodborne_dw:source_addon_wall_pilaster_5 | вариант 0 | new", "color": "gold"}
