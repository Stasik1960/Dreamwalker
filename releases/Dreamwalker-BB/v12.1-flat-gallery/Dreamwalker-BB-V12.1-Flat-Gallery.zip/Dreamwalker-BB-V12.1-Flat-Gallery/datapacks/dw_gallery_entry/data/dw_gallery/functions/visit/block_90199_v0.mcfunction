tp @s 73.0 64.38 216.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 12 | ID 90199 | bloodborne_dw:source_addon_slabs_1_11 | вариант 0 | new", "color": "gold"}
