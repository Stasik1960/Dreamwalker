tp @s 117.5 64.38 136.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 3 | ID 90047 | bloodborne_dw:source_addon_barrel_2 | вариант 0 | new", "color": "gold"}
