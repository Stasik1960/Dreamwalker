tp @s 287.5 63.88 246.5 0 14.0362
tellraw @s {"text": "Плита из серого зернистого камня | ID 90269 | bloodborne_dw:source_andesite | вариант 0 | new", "color": "gold"}
