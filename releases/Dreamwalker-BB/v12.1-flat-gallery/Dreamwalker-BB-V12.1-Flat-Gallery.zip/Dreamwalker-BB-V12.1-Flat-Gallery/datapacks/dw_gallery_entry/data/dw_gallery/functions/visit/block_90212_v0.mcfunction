tp @s 288.5 64.38 216.2 0 11.7683
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90212 | bloodborne_dw:source_addon_slabs_5_top | вариант 0 | new", "color": "gold"}
