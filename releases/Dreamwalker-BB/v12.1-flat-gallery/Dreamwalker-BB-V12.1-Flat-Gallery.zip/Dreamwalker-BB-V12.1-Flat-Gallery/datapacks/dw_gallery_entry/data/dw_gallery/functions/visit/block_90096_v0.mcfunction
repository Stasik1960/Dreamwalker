tp @s 3.5 64.38 165.5 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 4 | ID 90096 | bloodborne_dw:source_addon_crimson_button_3 | вариант 0 | new", "color": "gold"}
