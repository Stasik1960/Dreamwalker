tp @s 3.0 63.88 136.0 0 14.0362
tellraw @s {"text": "Мешок · вариант 3 | ID 90040 | bloodborne_dw:source_addon_bag_2 | вариант 0 | new", "color": "gold"}
