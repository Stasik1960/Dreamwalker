tp @s 158.5 64.38 183.5 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 2 | ID 90145 | bloodborne_dw:source_addon_grass_1 | вариант 0 | new", "color": "gold"}
