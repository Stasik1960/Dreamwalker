tp @s 238.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90364 | bloodborne_dw:source_bricks_purpur_block_4 | вариант 0 | new", "color": "gold"}
