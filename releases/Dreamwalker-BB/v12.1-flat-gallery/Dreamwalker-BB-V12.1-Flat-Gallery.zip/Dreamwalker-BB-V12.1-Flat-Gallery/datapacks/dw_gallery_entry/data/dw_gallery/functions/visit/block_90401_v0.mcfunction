tp @s 117.5 64.88 338.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка | ID 90401 | bloodborne_dw:source_buttons_acacia_acacia_button | вариант 0 | new", "color": "gold"}
