tp @s 37.5 64.88 297.5 0 14.0362
tellraw @s {"text": "Высокая декоративная стойка | ID 90318 | bloodborne_dw:source_blue_wool | вариант 0 | new", "color": "gold"}
