tp @s 89.5 64.88 156.5 0 14.0362
tellraw @s {"text": "Стопка старых чемоданов · вариант 1 | ID 90083 | bloodborne_dw:source_addon_cases_0 | вариант 0 | new", "color": "gold"}
