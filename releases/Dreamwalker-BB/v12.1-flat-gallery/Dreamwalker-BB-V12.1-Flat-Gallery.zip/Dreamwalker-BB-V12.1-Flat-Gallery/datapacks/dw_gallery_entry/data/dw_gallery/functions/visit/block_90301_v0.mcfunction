tp @s 147.5 64.88 276.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · верхняя | ID 90301 | bloodborne_dw:source_blackstone_stairs_top | вариант 0 | new", "color": "gold"}
