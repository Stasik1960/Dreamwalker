tp @s 135.5 63.88 -3.0 0 9.4623
tellraw @s {"text": "Деревянные панели окна | ID 90007 | bloodborne_dw:prototype_wood_window | вариант 0 | v12", "color": "gold"}
