tp @s 88.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90424 | bloodborne_dw:source_cobbled_deepslate_stairs_e | вариант 2 | new", "color": "gold"}
