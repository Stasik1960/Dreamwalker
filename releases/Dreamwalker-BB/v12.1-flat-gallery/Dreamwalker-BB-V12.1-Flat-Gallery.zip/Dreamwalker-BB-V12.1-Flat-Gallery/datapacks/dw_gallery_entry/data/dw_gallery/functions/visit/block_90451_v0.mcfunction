tp @s 257.5 63.88 379.5 0 14.0362
tellraw @s {"text": "Деревянный горизонтальный карниз · нижняя | ID 90451 | bloodborne_dw:source_crimson_bottom | вариант 0 | new", "color": "gold"}
