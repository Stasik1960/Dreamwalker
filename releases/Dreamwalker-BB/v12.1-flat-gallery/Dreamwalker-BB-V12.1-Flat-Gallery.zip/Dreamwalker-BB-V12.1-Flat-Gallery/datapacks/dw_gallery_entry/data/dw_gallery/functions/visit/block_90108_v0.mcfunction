tp @s 238.5 63.88 165.5 0 14.0362
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 10 | ID 90108 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_9 | вариант 0 | new", "color": "gold"}
