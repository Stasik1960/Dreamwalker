tp @s 159.5 64.88 276.5 0 14.0362
tellraw @s {"text": "Обрамление круглого окна | ID 90304 | bloodborne_dw:source_blue_concrete | вариант 0 | new", "color": "gold"}
