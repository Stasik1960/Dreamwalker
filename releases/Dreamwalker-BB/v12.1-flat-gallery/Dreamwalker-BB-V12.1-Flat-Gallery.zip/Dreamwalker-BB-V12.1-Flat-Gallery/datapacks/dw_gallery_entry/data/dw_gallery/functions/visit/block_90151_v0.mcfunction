tp @s 275.5 63.88 184.0 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 8 | ID 90151 | bloodborne_dw:source_addon_grass_7 | вариант 0 | new", "color": "gold"}
