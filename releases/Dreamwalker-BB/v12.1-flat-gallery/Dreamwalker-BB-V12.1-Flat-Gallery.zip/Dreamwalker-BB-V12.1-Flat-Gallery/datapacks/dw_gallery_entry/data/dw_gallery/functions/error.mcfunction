function dw_gallery:visit/block_93148_v0
