tp @s 183.5 64.38 204.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 1 | ID 90190 | bloodborne_dw:source_addon_slabs_0 | вариант 0 | new", "color": "gold"}
