tp @s 147.5 64.38 175.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 10 | ID 90129 | bloodborne_dw:source_addon_floor_dec_9 | вариант 0 | new", "color": "gold"}
