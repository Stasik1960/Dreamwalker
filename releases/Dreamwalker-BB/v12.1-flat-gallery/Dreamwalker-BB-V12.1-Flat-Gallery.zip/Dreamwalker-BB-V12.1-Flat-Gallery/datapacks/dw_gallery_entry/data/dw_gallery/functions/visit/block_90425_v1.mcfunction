tp @s 116.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · закреплённые UV 270° | ID 90425 | bloodborne_dw:source_cobbled_deepslate_stairs_inner | вариант 1 | new", "color": "gold"}
