tp @s 159.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка · вариант 5 | ID 90072 | bloodborne_dw:source_addon_button_4 | вариант 0 | new", "color": "gold"}
