tp @s 134.5 64.38 348.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка | ID 90411 | bloodborne_dw:source_chiseled_nether_bricks | вариант 0 | new", "color": "gold"}
