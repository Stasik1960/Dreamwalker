tp @s 276.5 64.38 215.5 0 9.4623
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90211 | bloodborne_dw:source_addon_slabs_4_top | вариант 0 | new", "color": "gold"}
