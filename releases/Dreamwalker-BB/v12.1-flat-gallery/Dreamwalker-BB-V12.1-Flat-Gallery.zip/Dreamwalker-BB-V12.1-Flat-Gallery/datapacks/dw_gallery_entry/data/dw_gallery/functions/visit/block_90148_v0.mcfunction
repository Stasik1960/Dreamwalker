tp @s 222.0 64.38 184.0 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 5 | ID 90148 | bloodborne_dw:source_addon_grass_4 | вариант 0 | new", "color": "gold"}
