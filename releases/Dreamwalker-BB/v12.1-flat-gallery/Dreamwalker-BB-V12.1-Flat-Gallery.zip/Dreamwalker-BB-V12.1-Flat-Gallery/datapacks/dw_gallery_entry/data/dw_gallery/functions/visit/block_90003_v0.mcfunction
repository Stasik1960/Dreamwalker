tp @s 73.5 64.38 -0.5 0 14.0362
tellraw @s {"text": "Наклонный кровельный модуль | ID 90003 | bloodborne_dw:prototype_roof | вариант 0 | v12", "color": "gold"}
