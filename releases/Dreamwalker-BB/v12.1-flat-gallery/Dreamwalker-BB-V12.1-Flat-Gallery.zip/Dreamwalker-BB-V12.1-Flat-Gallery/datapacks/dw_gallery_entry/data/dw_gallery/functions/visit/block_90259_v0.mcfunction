tp @s 159.5 64.88 246.5 0 14.0362
tellraw @s {"text": "Секция ворот | ID 90259 | bloodborne_dw:source_addon_warped_fence_gate | вариант 0 | new", "color": "gold"}
