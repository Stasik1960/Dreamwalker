tp @s 256.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка | ID 90328 | bloodborne_dw:source_bricks | вариант 0 | new", "color": "gold"}
