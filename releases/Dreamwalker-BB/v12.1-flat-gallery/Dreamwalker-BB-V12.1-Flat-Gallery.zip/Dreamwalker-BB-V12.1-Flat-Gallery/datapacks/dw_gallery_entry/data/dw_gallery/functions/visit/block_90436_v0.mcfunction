tp @s 256.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90436 | bloodborne_dw:source_cobblestone_slab_top | вариант 0 | new", "color": "gold"}
