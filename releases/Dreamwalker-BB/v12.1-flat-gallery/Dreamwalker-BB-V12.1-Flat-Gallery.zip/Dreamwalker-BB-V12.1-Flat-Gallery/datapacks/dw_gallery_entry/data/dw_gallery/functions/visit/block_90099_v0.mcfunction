tp @s 89.5 64.38 166.5 0 14.0362
tellraw @s {"text": "Секция ворот · открытая | ID 90099 | bloodborne_dw:source_addon_crimson_fence_gate_open | вариант 0 | new", "color": "gold"}
