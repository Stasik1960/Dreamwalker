tp @s 275.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Свечи · вариант 1 | ID 90078 | bloodborne_dw:source_addon_candles_0 | вариант 0 | new", "color": "gold"}
