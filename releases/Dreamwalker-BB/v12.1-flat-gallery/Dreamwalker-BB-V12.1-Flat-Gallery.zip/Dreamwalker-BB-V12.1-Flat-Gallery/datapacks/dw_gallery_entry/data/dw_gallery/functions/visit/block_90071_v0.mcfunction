tp @s 147.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка · вариант 4 | ID 90071 | bloodborne_dw:source_addon_button_3 | вариант 0 | new", "color": "gold"}
