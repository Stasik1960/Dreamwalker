tp @s 275.5 64.88 267.5 0 14.0362
tellraw @s {"text": "Остроконечный готический фронтон | ID 90286 | bloodborne_dw:source_birch_wood | вариант 0 | new", "color": "gold"}
