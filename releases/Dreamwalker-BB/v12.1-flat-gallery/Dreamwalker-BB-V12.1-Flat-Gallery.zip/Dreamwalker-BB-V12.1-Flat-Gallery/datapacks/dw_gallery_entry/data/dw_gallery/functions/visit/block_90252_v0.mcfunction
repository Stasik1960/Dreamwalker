tp @s 37.5 63.88 246.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 9 | ID 90252 | bloodborne_dw:source_addon_wall_deco_8 | вариант 0 | new", "color": "gold"}
