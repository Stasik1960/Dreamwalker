tp @s 221.5 64.38 204.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 2 | ID 90192 | bloodborne_dw:source_addon_slabs_1 | вариант 0 | new", "color": "gold"}
