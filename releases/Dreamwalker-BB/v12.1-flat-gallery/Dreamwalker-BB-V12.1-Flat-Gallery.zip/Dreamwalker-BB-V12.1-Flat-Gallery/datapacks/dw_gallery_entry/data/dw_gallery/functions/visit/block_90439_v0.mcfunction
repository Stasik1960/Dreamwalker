tp @s 274.5 63.88 372.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внешний угол | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 0 | new", "color": "gold"}
