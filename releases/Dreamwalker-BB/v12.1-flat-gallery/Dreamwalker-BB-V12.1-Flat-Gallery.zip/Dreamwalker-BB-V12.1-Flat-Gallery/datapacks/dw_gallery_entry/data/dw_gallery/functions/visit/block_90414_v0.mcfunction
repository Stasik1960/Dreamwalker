tp @s 184.5 63.88 347.5 0 9.4623
tellraw @s {"text": "Плита из грубого серого камня | ID 90414 | bloodborne_dw:source_chiseled_red_sandstone | вариант 0 | new", "color": "gold"}
