tp @s 209.5 64.88 338.5 0 14.0362
tellraw @s {"text": "Объёмное украшение с прямоугольным основанием · вариант 3 | ID 90406 | bloodborne_dw:source_buttons_spruce_spruce_button_powered_2 | вариант 0 | new", "color": "gold"}
