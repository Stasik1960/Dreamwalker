tp @s 134.5 64.38 136.0 0 14.0362
tellraw @s {"text": "Бочка · вариант 4 | ID 90048 | bloodborne_dw:source_addon_barrel_3 | вариант 0 | new", "color": "gold"}
