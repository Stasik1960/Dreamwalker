tp @s 116.5 63.88 1110.5 0 14.0362
tellraw @s {"text": "Ящик с бутылками · вариант 1 | ID 90119 | bloodborne_dw:source_addon_dead_tube_coral_0 | вариант 0 | absent", "color": "gold"}
