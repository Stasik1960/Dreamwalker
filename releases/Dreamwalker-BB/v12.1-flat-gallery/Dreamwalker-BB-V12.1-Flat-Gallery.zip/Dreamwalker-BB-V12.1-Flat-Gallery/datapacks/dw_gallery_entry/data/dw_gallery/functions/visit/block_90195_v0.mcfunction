tp @s 276.0 63.88 204.7 0 11.7683
tellraw @s {"text": "Архитектурная плита · вариант 12 | ID 90195 | bloodborne_dw:source_addon_slabs_11 | вариант 0 | new", "color": "gold"}
