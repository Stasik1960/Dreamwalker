tp @s 275.5 63.88 136.2 0 11.7683
tellraw @s {"text": "Книги · вариант 2 | ID 90058 | bloodborne_dw:source_addon_books_1 | вариант 0 | new", "color": "gold"}
