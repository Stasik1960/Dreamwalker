tp @s 221.5 63.88 297.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · наклон 180° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 7 | new", "color": "gold"}
