tp @s 222.5 64.38 338.5 0 14.0362
tellraw @s {"text": "Низкое объёмное украшение · вариант 4 | ID 90407 | bloodborne_dw:source_buttons_spruce_spruce_button_powered_3 | вариант 0 | new", "color": "gold"}
