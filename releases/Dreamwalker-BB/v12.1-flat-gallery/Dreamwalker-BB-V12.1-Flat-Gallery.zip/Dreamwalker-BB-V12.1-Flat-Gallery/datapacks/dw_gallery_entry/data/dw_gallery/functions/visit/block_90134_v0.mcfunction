tp @s 238.5 64.38 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 4 | ID 90134 | bloodborne_dw:source_addon_floor_panels_3 | вариант 0 | new", "color": "gold"}
