tp @s 182.5 64.88 1120.5 0 14.0362
tellraw @s {"text": "Высокий ажурный шпиль | ID 90300 | bloodborne_dw:source_blackstone | вариант 0 | absent", "color": "gold"}
