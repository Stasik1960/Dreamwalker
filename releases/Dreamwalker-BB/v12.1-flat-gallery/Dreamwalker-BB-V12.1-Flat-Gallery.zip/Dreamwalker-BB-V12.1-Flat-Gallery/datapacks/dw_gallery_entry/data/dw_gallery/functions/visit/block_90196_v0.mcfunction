tp @s 289.5 64.38 204.5 0 9.4623
tellraw @s {"text": "Архитектурная плита · вариант 13 | ID 90196 | bloodborne_dw:source_addon_slabs_12 | вариант 0 | new", "color": "gold"}
