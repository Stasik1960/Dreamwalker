tp @s 134.0 64.88 380.0 0 14.0362
tellraw @s {"text": "Фигурное каменное навершие | ID 90443 | bloodborne_dw:source_cobweb | вариант 0 | new", "color": "gold"}
