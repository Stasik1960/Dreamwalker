tp @s 274.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90437 | bloodborne_dw:source_cobblestone_stairs | вариант 0 | new", "color": "gold"}
