tp @s 158.5 63.88 379.5 0 14.0362
tellraw @s {"text": "Тонкие вертикальные каменные стойки | ID 90445 | bloodborne_dw:source_copper_ore | вариант 0 | new", "color": "gold"}
