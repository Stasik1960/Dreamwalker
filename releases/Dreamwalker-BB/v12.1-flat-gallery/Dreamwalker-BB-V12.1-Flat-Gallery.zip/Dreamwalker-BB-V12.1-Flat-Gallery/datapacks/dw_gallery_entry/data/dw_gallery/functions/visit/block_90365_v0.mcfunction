tp @s 256.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 6 | ID 90365 | bloodborne_dw:source_bricks_purpur_block_5 | вариант 0 | new", "color": "gold"}
