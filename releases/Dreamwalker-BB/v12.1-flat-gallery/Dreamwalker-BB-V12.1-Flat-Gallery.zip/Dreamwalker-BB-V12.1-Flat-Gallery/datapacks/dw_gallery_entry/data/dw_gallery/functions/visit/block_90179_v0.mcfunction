tp @s 89.0 63.88 205.0 0 14.0362
tellraw @s {"text": "Пилястра · вариант 2 | ID 90179 | bloodborne_dw:source_addon_pilaster_1 | вариант 0 | new", "color": "gold"}
