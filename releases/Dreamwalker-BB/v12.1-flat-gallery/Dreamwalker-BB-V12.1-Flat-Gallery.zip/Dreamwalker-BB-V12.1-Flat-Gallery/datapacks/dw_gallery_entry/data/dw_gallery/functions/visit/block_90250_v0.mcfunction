tp @s 288.5 64.88 236.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 7 | ID 90250 | bloodborne_dw:source_addon_wall_deco_6 | вариант 0 | new", "color": "gold"}
