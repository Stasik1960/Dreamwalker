tp @s 89.5 64.38 216.0 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 3 | ID 90200 | bloodborne_dw:source_addon_slabs_1_2 | вариант 0 | new", "color": "gold"}
