tp @s 147.5 64.88 1120.5 0 14.0362
tellraw @s {"text": "Декоративная панель | ID 90266 | bloodborne_dw:source_allium | вариант 0 | absent", "color": "gold"}
