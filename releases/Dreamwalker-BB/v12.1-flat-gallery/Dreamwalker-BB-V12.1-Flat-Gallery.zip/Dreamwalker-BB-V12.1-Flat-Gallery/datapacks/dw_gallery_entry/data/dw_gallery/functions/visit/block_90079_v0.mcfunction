tp @s 289.0 64.38 146.7 0 11.7683
tellraw @s {"text": "Свечи · вариант 2 | ID 90079 | bloodborne_dw:source_addon_candles_1 | вариант 0 | new", "color": "gold"}
