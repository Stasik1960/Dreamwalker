tp @s 135.5 63.88 246.5 0 9.4623
tellraw @s {"text": "Пилястра · вариант 5 | ID 90257 | bloodborne_dw:source_addon_wall_pilaster_4 | вариант 0 | new", "color": "gold"}
