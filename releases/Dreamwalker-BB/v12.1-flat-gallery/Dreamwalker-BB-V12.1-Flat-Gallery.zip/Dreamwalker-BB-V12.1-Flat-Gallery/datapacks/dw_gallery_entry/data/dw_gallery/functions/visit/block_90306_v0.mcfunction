tp @s 209.5 63.88 1120.5 0 14.0362
tellraw @s {"text": "Декоративная панель | ID 90306 | bloodborne_dw:source_blue_glazed_terracotta | вариант 0 | absent", "color": "gold"}
