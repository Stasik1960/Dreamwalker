tp @s 133.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90380 | bloodborne_dw:source_bricks_stonebrick_1 | вариант 0 | new", "color": "gold"}
