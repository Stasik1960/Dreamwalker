tp @s 89.5 64.88 193.0 0 14.0362
tellraw @s {"text": "Секция ворот · открытая, вариант 1 | ID 90156 | bloodborne_dw:source_addon_jungle_fence_gate_open_0 | вариант 0 | new", "color": "gold"}
