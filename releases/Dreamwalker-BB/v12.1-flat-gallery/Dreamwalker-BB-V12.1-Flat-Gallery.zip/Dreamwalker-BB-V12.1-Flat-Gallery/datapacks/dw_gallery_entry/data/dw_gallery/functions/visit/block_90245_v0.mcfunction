tp @s 183.5 64.88 236.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 2 | ID 90245 | bloodborne_dw:source_addon_wall_deco_1 | вариант 0 | new", "color": "gold"}
