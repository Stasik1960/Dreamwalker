tp @s 274.5 64.38 277.5 0 14.0362
tellraw @s {"text": "Составное декоративное украшение · вариант 4 | ID 90311 | bloodborne_dw:source_blue_orchid_3 | вариант 0 | new", "color": "gold"}
