tp @s 3.5 64.38 227.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 7 | ID 90213 | bloodborne_dw:source_addon_slabs_6 | вариант 0 | new", "color": "gold"}
