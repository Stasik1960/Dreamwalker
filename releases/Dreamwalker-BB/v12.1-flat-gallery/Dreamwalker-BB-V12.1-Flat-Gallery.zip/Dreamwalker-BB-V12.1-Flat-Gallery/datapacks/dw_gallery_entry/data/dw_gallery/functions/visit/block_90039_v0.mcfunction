tp @s 288.0 63.88 127.0 0 14.0362
tellraw @s {"text": "Мешок · вариант 2 | ID 90039 | bloodborne_dw:source_addon_bag_1 | вариант 0 | new", "color": "gold"}
