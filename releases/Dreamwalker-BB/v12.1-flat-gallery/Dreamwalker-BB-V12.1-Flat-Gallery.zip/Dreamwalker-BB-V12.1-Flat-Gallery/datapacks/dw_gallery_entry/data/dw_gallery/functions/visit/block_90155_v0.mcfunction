tp @s 73.5 64.38 193.5 0 14.0362
tellraw @s {"text": "Шляпа охотника | ID 90155 | bloodborne_dw:source_addon_hat | вариант 0 | new", "color": "gold"}
