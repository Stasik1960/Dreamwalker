tp @s 116.5 64.88 192.5 0 14.0362
tellraw @s {"text": "Вертикальное деревянное украшение · вариант 1 | ID 90160 | bloodborne_dw:source_addon_log_vertical_0 | вариант 0 | new", "color": "gold"}
