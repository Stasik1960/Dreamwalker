tp @s 116.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · внешний угол · закреплённые UV 270° | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 1 | new", "color": "gold"}
