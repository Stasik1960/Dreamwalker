tp @s 134.0 64.88 183.5 0 14.0362
tellraw @s {"text": "Секция ворот · вариант 2 | ID 90143 | bloodborne_dw:source_addon_gate2_1 | вариант 0 | new", "color": "gold"}
