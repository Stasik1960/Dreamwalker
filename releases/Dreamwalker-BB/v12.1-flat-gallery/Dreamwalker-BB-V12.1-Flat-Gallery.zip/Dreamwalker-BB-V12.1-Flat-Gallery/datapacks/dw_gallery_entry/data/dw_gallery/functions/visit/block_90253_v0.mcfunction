tp @s 73.5 63.88 247.5 0 14.0362
tellraw @s {"text": "Пилястра · вариант 1 | ID 90253 | bloodborne_dw:source_addon_wall_pilaster_0 | вариант 0 | new", "color": "gold"}
