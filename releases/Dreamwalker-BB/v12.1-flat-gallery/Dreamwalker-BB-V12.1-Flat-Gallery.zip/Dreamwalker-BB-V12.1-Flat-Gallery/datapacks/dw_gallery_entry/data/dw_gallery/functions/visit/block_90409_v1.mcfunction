tp @s 274.5 63.88 337.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 1 | new", "color": "gold"}
