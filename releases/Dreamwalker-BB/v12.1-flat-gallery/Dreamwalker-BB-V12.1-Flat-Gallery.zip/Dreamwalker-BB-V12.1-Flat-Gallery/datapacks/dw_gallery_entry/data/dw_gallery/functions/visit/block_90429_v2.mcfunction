tp @s 146.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90429 | bloodborne_dw:source_cobbled_deepslate_stairs_s | вариант 2 | new", "color": "gold"}
