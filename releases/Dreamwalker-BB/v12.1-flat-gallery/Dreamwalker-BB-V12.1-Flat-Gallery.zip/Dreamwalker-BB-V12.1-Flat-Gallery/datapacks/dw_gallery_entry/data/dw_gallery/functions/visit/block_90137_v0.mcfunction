tp @s 287.5 63.88 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 7 | ID 90137 | bloodborne_dw:source_addon_floor_panels_6 | вариант 0 | new", "color": "gold"}
