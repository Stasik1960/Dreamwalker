tp @s 222.5 64.38 247.5 0 14.0362
tellraw @s {"text": "Деревянное украшение · вариант 2 | ID 90262 | bloodborne_dw:source_addon_wood_obj_1 | вариант 0 | new", "color": "gold"}
