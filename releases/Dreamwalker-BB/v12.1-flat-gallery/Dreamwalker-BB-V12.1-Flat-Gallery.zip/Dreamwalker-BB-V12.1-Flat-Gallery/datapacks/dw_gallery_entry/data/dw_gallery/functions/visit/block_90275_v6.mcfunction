tp @s 221.5 63.88 257.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 180° | ID 90275 | bloodborne_dw:source_bamboo_mosaic_stairs | вариант 6 | new", "color": "gold"}
