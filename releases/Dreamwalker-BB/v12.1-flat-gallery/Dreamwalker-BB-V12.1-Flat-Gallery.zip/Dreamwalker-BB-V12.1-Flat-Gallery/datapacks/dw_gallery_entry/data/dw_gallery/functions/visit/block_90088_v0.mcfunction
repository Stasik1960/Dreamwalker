tp @s 159.5 64.38 156.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 1 | ID 90088 | bloodborne_dw:source_addon_chains_0 | вариант 0 | new", "color": "gold"}
