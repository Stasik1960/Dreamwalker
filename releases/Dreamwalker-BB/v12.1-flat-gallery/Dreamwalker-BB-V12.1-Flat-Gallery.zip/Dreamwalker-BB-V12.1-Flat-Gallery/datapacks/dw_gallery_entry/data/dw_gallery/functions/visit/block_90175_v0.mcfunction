tp @s 2.5 64.88 205.0 0 14.0362
tellraw @s {"text": "Секция ворот · открытая, вариант 1 | ID 90175 | bloodborne_dw:source_addon_oak_fence_gate_open_0 | вариант 0 | new", "color": "gold"}
