tp @s 238.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 8 | ID 90386 | bloodborne_dw:source_bricks_stonebrick_7 | вариант 0 | new", "color": "gold"}
