tp @s 223.5 64.38 1120.5 0 9.4623
tellraw @s {"text": "Книги | ID 90319 | bloodborne_dw:source_bookshelf | вариант 0 | absent", "color": "gold"}
