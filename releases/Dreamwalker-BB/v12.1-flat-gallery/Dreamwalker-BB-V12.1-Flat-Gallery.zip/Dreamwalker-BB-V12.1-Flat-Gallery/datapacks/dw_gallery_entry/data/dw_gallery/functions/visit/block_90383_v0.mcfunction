tp @s 182.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90383 | bloodborne_dw:source_bricks_stonebrick_4 | вариант 0 | new", "color": "gold"}
