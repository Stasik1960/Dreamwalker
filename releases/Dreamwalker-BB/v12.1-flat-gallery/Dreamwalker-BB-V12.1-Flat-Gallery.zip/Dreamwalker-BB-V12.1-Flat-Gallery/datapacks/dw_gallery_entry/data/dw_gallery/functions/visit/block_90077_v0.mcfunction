tp @s 257.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Напольная декоративная пластина · вариант 10 | ID 90077 | bloodborne_dw:source_addon_button_9 | вариант 0 | new", "color": "gold"}
