tp @s 102.5 63.88 247.5 0 14.0362
tellraw @s {"text": "Пилястра · вариант 3 | ID 90255 | bloodborne_dw:source_addon_wall_pilaster_2 | вариант 0 | new", "color": "gold"}
