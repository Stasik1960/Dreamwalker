tp @s 147.5 64.88 226.5 0 14.0362
tellraw @s {"text": "Секция ворот · открытая, вариант 2 | ID 90222 | bloodborne_dw:source_addon_spruce_fence_gate_open_1 | вариант 0 | new", "color": "gold"}
