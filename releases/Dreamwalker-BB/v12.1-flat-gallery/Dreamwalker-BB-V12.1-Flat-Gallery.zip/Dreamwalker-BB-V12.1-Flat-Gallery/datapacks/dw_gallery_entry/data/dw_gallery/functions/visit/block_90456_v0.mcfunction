tp @s 2.5 63.88 388.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь | ID 90456 | bloodborne_dw:source_crimson_pressure_plate | вариант 0 | new", "color": "gold"}
