tp @s 159.5 64.38 205.5 0 14.0362
tellraw @s {"text": "Осколки стекла · вариант 4 | ID 90189 | bloodborne_dw:source_addon_shattered_glass_3 | вариант 0 | new", "color": "gold"}
