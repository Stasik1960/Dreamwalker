tp @s 72.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внешний угол · закреплённые UV 180° | ID 90428 | bloodborne_dw:source_cobbled_deepslate_stairs_outer_we | вариант 3 | new", "color": "gold"}
