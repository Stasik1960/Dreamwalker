tp @s 222.5 64.88 127.0 0 14.0362
tellraw @s {"text": "Дверная секция · открытая, вариант 2 | ID 90035 | bloodborne_dw:source_acacia_trapdoor_open_1 | вариант 0 | new", "color": "gold"}
