tp @s 134.5 64.38 175.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 9 | ID 90128 | bloodborne_dw:source_addon_floor_dec_8 | вариант 0 | new", "color": "gold"}
