tp @s 182.5 63.88 126.5 0 14.0362
tellraw @s {"text": "Дверная секция · нижняя | ID 90033 | bloodborne_dw:source_acacia_trapdoor_bottom | вариант 0 | new", "color": "gold"}
