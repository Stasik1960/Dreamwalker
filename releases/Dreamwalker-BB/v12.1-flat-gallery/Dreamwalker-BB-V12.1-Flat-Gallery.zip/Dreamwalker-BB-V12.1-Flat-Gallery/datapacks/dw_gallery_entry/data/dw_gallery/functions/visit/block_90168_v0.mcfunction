tp @s 183.5 64.88 193.5 0 14.0362
tellraw @s {"text": "Статуя · вариант 4 | ID 90168 | bloodborne_dw:source_addon_new_statue_3 | вариант 0 | new", "color": "gold"}
