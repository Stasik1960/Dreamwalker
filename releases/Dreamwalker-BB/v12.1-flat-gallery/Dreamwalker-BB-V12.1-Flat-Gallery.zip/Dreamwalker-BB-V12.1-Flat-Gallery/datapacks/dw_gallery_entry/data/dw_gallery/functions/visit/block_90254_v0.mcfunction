tp @s 89.5 63.88 247.5 0 14.0362
tellraw @s {"text": "Пилястра · вариант 2 | ID 90254 | bloodborne_dw:source_addon_wall_pilaster_1 | вариант 0 | new", "color": "gold"}
