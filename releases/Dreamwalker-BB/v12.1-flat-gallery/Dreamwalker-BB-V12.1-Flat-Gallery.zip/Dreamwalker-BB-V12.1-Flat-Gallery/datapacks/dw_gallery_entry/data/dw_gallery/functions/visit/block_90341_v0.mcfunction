tp @s 209.5 63.88 314.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90341 | bloodborne_dw:source_bricks_bricks_rl_2 | вариант 0 | new", "color": "gold"}
