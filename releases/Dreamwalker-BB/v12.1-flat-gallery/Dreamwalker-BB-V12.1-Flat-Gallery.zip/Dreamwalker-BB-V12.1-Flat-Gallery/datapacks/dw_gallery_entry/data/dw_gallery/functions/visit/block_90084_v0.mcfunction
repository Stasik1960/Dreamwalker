tp @s 101.5 63.88 155.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 1 | ID 90084 | bloodborne_dw:source_addon_chain_0 | вариант 0 | new", "color": "gold"}
