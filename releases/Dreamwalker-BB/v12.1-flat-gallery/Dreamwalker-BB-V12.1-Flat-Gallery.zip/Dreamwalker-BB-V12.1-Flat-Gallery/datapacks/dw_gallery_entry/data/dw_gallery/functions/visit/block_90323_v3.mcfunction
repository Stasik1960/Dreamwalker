tp @s 287.5 63.88 297.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · внутренний угол · наклон 180° | ID 90323 | bloodborne_dw:source_brick_stairs_inner | вариант 3 | new", "color": "gold"}
