tp @s 3.5 64.88 337.5 0 14.0362
tellraw @s {"text": "Тонкое кольцевое обрамление окна | ID 90390 | bloodborne_dw:source_brown_concrete | вариант 0 | new", "color": "gold"}
