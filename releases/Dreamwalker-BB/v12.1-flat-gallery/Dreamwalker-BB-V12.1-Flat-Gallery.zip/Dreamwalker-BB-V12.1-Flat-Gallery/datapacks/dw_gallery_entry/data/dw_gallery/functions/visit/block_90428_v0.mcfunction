tp @s 287.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внешний угол | ID 90428 | bloodborne_dw:source_cobbled_deepslate_stairs_outer_we | вариант 0 | new", "color": "gold"}
