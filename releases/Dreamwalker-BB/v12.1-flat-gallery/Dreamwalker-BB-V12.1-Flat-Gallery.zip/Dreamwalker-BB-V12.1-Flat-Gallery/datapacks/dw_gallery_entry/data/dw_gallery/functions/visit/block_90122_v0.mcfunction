tp @s 3.5 64.38 175.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 3 | ID 90122 | bloodborne_dw:source_addon_floor_dec_2 | вариант 0 | new", "color": "gold"}
