tp @s 37.5 64.38 1101.0 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · вариант 2 | ID 90022 | bloodborne_dw:source_1_wall_001 | вариант 0 | absent", "color": "gold"}
