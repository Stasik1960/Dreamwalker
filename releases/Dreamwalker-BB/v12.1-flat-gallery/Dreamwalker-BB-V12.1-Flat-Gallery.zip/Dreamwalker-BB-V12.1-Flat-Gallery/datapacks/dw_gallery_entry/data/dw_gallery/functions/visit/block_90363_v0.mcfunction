tp @s 221.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90363 | bloodborne_dw:source_bricks_purpur_block_3 | вариант 0 | new", "color": "gold"}
