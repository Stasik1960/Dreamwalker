tp @s 147.5 64.38 205.5 0 14.0362
tellraw @s {"text": "Осколки стекла · вариант 3 | ID 90188 | bloodborne_dw:source_addon_shattered_glass_2 | вариант 0 | new", "color": "gold"}
