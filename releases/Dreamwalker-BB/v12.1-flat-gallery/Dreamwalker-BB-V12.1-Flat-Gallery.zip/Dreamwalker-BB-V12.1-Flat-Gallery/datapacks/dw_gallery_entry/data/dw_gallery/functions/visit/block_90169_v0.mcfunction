tp @s 209.5 64.38 193.5 0 14.0362
tellraw @s {"text": "Резной каменный фриз с широкими поясами · вариант 1 | ID 90169 | bloodborne_dw:source_addon_note_0 | вариант 0 | new", "color": "gold"}
