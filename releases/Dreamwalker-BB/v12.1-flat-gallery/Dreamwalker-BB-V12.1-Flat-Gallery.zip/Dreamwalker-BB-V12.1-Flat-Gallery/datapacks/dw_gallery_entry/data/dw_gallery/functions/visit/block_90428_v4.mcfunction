tp @s 88.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внешний угол · наклон 180° | ID 90428 | bloodborne_dw:source_cobbled_deepslate_stairs_outer_we | вариант 4 | new", "color": "gold"}
