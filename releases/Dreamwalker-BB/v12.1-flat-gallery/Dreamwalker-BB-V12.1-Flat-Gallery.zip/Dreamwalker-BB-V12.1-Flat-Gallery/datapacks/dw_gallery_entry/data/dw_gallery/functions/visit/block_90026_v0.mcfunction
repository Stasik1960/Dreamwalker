tp @s 101.5 64.38 127.0 0 14.0362
tellraw @s {"text": "Настенный орнамент · верхняя, вариант 2 | ID 90026 | bloodborne_dw:source__wall_dec_top_1 | вариант 0 | new", "color": "gold"}
