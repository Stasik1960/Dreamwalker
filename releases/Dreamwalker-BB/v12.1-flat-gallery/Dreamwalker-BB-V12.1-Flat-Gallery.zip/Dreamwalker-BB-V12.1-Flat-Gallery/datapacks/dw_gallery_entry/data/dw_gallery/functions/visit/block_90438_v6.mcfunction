tp @s 238.5 63.88 372.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · закреплённые UV 90° | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 6 | new", "color": "gold"}
