tp @s 257.5 64.38 276.5 0 14.0362
tellraw @s {"text": "Составное декоративное украшение · вариант 3 | ID 90310 | bloodborne_dw:source_blue_orchid_2 | вариант 0 | new", "color": "gold"}
