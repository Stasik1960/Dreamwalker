tp @s 159.5 65.38 192.7 0 11.7683
tellraw @s {"text": "Статуя · вариант 3 | ID 90167 | bloodborne_dw:source_addon_new_statue_2 | вариант 0 | new", "color": "gold"}
