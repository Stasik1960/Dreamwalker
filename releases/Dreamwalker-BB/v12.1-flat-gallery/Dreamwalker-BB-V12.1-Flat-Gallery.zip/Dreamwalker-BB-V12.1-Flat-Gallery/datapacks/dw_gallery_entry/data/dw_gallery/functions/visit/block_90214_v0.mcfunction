tp @s 38.5 64.38 227.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90214 | bloodborne_dw:source_addon_slabs_6_top | вариант 0 | new", "color": "gold"}
