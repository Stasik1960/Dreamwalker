tp @s 101.5 64.38 1100.5 0 14.0362
tellraw @s {"text": "Мешок · вариант 6 | ID 90043 | bloodborne_dw:source_addon_bag_5 | вариант 0 | absent", "color": "gold"}
