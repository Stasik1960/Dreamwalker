tp @s 158.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90360 | bloodborne_dw:source_bricks_purpur_block_0 | вариант 0 | new", "color": "gold"}
