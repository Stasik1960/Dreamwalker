tp @s 88.5 63.88 337.5 0 14.0362
tellraw @s {"text": "Карета с большими колёсами | ID 90394 | bloodborne_dw:source_brown_stained_glass | вариант 0 | new", "color": "gold"}
