tp @s 183.5 63.88 338.5 0 14.0362
tellraw @s {"text": "Напольный орнамент с наклонными плоскостями | ID 90405 | bloodborne_dw:source_buttons_spruce_spruce_button_powered | вариант 0 | new", "color": "gold"}
