tp @s 37.5 64.38 -1.5 0 14.0362
tellraw @s {"text": "Художественная ограда | ID 90002 | bloodborne_dw:prototype_wall | вариант 0 | v12", "color": "gold"}
