tp @s 102.5 64.88 338.2 0 11.7683
tellraw @s {"text": "Каменный мемориал со свечами | ID 90400 | bloodborne_dw:source_brown_terracotta | вариант 0 | new", "color": "gold"}
