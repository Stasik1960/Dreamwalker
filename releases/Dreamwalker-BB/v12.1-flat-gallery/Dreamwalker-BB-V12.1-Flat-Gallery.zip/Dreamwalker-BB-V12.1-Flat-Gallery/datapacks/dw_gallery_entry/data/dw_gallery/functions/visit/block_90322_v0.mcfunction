tp @s 101.5 63.88 297.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 0 | new", "color": "gold"}
