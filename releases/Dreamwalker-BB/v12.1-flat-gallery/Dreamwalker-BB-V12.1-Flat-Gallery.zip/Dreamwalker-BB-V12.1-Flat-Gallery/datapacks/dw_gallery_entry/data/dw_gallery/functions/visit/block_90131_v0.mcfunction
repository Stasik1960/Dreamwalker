tp @s 182.5 64.38 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 2 | ID 90131 | bloodborne_dw:source_addon_floor_panels_1 | вариант 0 | new", "color": "gold"}
