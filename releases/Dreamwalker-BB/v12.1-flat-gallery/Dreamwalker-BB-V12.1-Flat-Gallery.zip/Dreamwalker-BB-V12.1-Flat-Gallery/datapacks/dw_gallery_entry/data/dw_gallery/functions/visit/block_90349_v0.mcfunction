tp @s 72.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 8 | ID 90349 | bloodborne_dw:source_bricks_cracked_bricks_7 | вариант 0 | new", "color": "gold"}
