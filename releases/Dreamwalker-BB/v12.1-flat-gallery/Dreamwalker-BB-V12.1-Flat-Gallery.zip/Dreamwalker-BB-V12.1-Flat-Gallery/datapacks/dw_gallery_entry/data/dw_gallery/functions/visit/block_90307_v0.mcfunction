tp @s 209.5 64.88 277.5 0 14.0362
tellraw @s {"text": "Синий лёд · текстура BB | ID 90307 | bloodborne_dw:source_blue_ice | вариант 0 | new", "color": "gold"}
