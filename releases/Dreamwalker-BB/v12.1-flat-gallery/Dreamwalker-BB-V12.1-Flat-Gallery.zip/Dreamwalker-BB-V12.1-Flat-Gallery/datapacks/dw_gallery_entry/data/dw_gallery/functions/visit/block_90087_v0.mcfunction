tp @s 147.5 63.88 156.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 4 | ID 90087 | bloodborne_dw:source_addon_chain_3 | вариант 0 | new", "color": "gold"}
