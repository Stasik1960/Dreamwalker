tp @s 274.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90388 | bloodborne_dw:source_bricks_wallbrick_1 | вариант 0 | new", "color": "gold"}
