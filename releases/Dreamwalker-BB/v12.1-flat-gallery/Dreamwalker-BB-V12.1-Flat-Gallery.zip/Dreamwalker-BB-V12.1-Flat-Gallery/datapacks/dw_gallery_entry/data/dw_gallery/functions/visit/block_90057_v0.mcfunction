tp @s 258.5 63.88 135.5 0 9.4623
tellraw @s {"text": "Книги · вариант 1 | ID 90057 | bloodborne_dw:source_addon_books_0 | вариант 0 | new", "color": "gold"}
