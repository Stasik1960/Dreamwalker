tp @s 89.5 64.88 -1.0 0 14.0362
tellraw @s {"text": "Тонкое остекление · window01 | ID 90004 | bloodborne_dw:prototype_thin_window | вариант 0 | v12", "color": "gold"}
