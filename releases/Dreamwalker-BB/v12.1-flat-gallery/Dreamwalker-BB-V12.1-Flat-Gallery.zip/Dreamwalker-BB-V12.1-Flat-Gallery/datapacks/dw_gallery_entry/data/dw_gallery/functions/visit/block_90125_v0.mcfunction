tp @s 89.5 64.38 175.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 6 | ID 90125 | bloodborne_dw:source_addon_floor_dec_5 | вариант 0 | new", "color": "gold"}
