tp @s 183.5 64.38 216.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 10 | ID 90206 | bloodborne_dw:source_addon_slabs_1_9 | вариант 0 | new", "color": "gold"}
