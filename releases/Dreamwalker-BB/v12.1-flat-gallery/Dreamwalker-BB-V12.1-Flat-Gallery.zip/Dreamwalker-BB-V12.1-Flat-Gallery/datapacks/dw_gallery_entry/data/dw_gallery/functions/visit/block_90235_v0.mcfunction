tp @s 72.5 64.38 1120.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · вариант 1 | ID 90235 | bloodborne_dw:source_addon_test_upperward_0 | вариант 0 | absent", "color": "gold"}
