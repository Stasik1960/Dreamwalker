tp @s 158.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90430 | bloodborne_dw:source_cobbled_deepslate_stairs_we | вариант 0 | new", "color": "gold"}
