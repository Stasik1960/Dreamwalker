tp @s 3.5 64.38 1101.5 0 14.0362
tellraw @s {"text": "Светильник · вариант 2 | ID 90021 | bloodborne_dw:source_1_spirelamp_001 | вариант 0 | absent", "color": "gold"}
