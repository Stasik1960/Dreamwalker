tp @s 37.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 7 | ID 90348 | bloodborne_dw:source_bricks_cracked_bricks_6 | вариант 0 | new", "color": "gold"}
