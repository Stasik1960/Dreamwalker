tp @s 116.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 15 | ID 90069 | bloodborne_dw:source_addon_button_14 | вариант 0 | new", "color": "gold"}
