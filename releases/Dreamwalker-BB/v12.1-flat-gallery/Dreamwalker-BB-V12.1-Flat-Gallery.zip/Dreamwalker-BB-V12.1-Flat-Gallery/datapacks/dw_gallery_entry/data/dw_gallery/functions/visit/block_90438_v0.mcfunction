tp @s 133.5 63.88 372.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внутренний угол | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 0 | new", "color": "gold"}
