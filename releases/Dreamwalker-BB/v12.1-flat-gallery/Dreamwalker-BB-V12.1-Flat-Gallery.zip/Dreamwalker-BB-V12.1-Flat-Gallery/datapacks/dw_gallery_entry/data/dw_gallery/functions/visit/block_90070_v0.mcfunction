tp @s 133.5 64.38 146.5 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 3 | ID 90070 | bloodborne_dw:source_addon_button_2 | вариант 0 | new", "color": "gold"}
