tp @s 38.5 63.88 338.5 0 14.0362
tellraw @s {"text": "Декоративная каменная поверхность · коричневый | ID 90391 | bloodborne_dw:source_brown_concrete_powder | вариант 0 | new", "color": "gold"}
