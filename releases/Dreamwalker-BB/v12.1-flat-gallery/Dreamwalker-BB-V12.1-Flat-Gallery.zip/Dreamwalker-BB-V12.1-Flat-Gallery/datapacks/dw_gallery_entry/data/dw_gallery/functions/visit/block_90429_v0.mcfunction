tp @s 116.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90429 | bloodborne_dw:source_cobbled_deepslate_stairs_s | вариант 0 | new", "color": "gold"}
