tp @s 102.5 64.88 204.5 0 14.0362
tellraw @s {"text": "Резная каменная база с широким верхом · секция | ID 90182 | bloodborne_dw:source_addon_quartz_pillar_side | вариант 0 | new", "color": "gold"}
