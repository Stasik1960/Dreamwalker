execute as @a[tag=!dw_gallery_entered] run gamemode creative @s
execute as @a[tag=!dw_gallery_entered] run tp @s 0.5 64 -5.5 0 0
execute as @a[tag=!dw_gallery_entered] run tellraw @s {"text":"Галерея BB: /function dw_gallery:help. Секции: v12, new, absent, error.","color":"gold"}
tag @a[tag=!dw_gallery_entered] add dw_gallery_entered
