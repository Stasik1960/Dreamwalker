tp @s 209.5 64.88 226.5 0 14.0362
tellraw @s {"text": "Блок рыжей древесины | ID 90229 | bloodborne_dw:source_addon_stripped_dark_oak_log | вариант 0 | new", "color": "gold"}
