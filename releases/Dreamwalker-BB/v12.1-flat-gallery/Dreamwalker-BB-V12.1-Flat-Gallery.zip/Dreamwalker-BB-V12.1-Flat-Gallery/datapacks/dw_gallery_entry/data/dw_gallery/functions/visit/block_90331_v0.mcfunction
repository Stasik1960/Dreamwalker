tp @s 2.5 63.88 313.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90331 | bloodborne_dw:source_bricks_bricks_2 | вариант 0 | new", "color": "gold"}
