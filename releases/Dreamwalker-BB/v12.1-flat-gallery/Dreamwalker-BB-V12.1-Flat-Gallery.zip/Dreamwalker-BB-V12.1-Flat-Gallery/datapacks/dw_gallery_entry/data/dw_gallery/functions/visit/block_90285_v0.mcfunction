tp @s 257.0 64.38 267.5 0 14.0362
tellraw @s {"text": "Дверная секция · нижняя | ID 90285 | bloodborne_dw:source_birch_trapdoor_bottom | вариант 0 | new", "color": "gold"}
