tp @s 102.5 64.38 136.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 11 | ID 90046 | bloodborne_dw:source_addon_barrel_10 | вариант 0 | new", "color": "gold"}
