tp @s 288.5 64.38 166.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 2 | ID 90121 | bloodborne_dw:source_addon_floor_dec_1 | вариант 0 | new", "color": "gold"}
