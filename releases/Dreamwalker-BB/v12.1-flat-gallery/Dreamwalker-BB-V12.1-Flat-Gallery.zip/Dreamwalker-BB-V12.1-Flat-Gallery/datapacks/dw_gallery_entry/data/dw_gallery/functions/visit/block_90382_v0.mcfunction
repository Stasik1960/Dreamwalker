tp @s 158.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90382 | bloodborne_dw:source_bricks_stonebrick_3 | вариант 0 | new", "color": "gold"}
