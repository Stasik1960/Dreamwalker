tp @s 287.5 63.88 192.5 0 14.0362
tellraw @s {"text": "Секция ворот · вариант 1 | ID 90174 | bloodborne_dw:source_addon_oak_fence_gate_0 | вариант 0 | new", "color": "gold"}
