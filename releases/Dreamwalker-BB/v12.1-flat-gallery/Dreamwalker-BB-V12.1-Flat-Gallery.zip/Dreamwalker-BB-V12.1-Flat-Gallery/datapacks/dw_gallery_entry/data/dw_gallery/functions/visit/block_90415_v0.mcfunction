tp @s 208.5 64.38 347.5 0 14.0362
tellraw @s {"text": "Каменная панель со стрельчатой нишей | ID 90415 | bloodborne_dw:source_chiseled_sandstone | вариант 0 | new", "color": "gold"}
