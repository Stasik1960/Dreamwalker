tp @s 133.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 90° | ID 90429 | bloodborne_dw:source_cobbled_deepslate_stairs_s | вариант 1 | new", "color": "gold"}
