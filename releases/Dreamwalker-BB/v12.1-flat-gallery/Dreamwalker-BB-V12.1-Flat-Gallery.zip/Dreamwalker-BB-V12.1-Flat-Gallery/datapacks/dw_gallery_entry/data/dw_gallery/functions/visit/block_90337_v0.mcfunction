tp @s 134.5 63.88 314.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90337 | bloodborne_dw:source_bricks_bricks_r_4 | вариант 0 | new", "color": "gold"}
