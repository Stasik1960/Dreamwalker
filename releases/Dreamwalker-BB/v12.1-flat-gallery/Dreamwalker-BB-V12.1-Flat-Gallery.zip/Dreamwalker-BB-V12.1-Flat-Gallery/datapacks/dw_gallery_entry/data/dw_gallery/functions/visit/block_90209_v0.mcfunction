tp @s 238.5 64.38 215.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 4 | ID 90209 | bloodborne_dw:source_addon_slabs_3 | вариант 0 | new", "color": "gold"}
