tp @s 184.5 64.88 246.5 0 9.4623
tellraw @s {"text": "Мелкая кладка с угловыми рёбрами | ID 90260 | bloodborne_dw:source_addon_waxed_oxidized_cut_copper | вариант 0 | new", "color": "gold"}
