tp @s 275.5 64.38 166.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 1 | ID 90120 | bloodborne_dw:source_addon_floor_dec_0 | вариант 0 | new", "color": "gold"}
