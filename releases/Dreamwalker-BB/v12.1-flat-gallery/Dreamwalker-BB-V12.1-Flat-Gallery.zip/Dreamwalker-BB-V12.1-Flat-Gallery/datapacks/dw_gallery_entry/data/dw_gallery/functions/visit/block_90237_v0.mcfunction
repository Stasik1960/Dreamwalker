tp @s 73.5 64.88 237.2 0 11.7683
tellraw @s {"text": "Надгробие · вариант 2 | ID 90237 | bloodborne_dw:source_addon_tombstone_gathered_1 | вариант 0 | new", "color": "gold"}
