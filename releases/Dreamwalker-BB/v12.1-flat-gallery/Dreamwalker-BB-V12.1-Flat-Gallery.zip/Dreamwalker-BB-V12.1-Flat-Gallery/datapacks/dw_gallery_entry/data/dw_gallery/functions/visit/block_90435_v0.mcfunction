tp @s 238.5 63.88 365.5 0 14.0362
tellraw @s {"text": "Архитектурная плита | ID 90435 | bloodborne_dw:source_cobblestone_slab | вариант 0 | new", "color": "gold"}
