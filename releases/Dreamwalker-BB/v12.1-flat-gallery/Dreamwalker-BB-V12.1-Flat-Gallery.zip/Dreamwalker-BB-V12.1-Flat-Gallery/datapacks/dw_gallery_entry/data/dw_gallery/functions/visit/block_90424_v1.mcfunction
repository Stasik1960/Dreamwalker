tp @s 72.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 0° | ID 90424 | bloodborne_dw:source_cobbled_deepslate_stairs_e | вариант 1 | new", "color": "gold"}
