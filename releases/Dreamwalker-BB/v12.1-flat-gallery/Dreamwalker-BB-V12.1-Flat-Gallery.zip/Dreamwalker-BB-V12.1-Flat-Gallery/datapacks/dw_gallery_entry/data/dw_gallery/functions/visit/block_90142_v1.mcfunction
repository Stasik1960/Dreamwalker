tp @s 117.0 63.88 184.5 0 14.0362
tellraw @s {"text": "Секция ворот · вариант 1 · наклон 90° | ID 90142 | bloodborne_dw:source_addon_gate2_0 | вариант 1 | new", "color": "gold"}
