tp @s 118.0 64.38 227.2 0 11.7683
tellraw @s {"text": "Архитектурная плита · вариант 10 | ID 90219 | bloodborne_dw:source_addon_slabs_9 | вариант 0 | new", "color": "gold"}
