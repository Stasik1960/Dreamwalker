tp @s 90.0 65.38 1120.5 0 9.4623
tellraw @s {"text": "Надгробие · вариант 9 | ID 90244 | bloodborne_dw:source_addon_tombstone_gathered_8 | вариант 0 | absent", "color": "gold"}
