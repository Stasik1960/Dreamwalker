tp @s 274.5 63.88 1120.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внешний угол | ID 90427 | bloodborne_dw:source_cobbled_deepslate_stairs_outer | вариант 0 | absent", "color": "gold"}
