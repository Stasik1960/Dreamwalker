tp @s 183.5 64.38 156.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 2 | ID 90089 | bloodborne_dw:source_addon_chains_1 | вариант 0 | new", "color": "gold"}
