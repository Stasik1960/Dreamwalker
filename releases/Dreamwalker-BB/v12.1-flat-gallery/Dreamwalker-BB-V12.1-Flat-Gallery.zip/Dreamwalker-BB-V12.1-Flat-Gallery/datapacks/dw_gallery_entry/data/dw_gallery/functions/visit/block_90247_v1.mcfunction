tp @s 222.5 63.88 237.0 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 4 · наклон 90° | ID 90247 | bloodborne_dw:source_addon_wall_deco_3 | вариант 1 | new", "color": "gold"}
