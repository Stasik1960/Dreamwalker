tp @s 256.5 64.38 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 5 | ID 90135 | bloodborne_dw:source_addon_floor_panels_4 | вариант 0 | new", "color": "gold"}
