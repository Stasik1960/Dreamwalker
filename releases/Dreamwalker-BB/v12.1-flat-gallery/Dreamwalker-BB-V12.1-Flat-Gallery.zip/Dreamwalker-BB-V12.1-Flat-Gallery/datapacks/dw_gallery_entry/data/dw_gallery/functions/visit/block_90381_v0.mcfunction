tp @s 146.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90381 | bloodborne_dw:source_bricks_stonebrick_2 | вариант 0 | new", "color": "gold"}
