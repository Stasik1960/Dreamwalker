tp @s 73.5 64.38 175.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 5 | ID 90124 | bloodborne_dw:source_addon_floor_dec_4 | вариант 0 | new", "color": "gold"}
