tp @s 146.5 63.88 257.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 270° | ID 90275 | bloodborne_dw:source_bamboo_mosaic_stairs | вариант 2 | new", "color": "gold"}
