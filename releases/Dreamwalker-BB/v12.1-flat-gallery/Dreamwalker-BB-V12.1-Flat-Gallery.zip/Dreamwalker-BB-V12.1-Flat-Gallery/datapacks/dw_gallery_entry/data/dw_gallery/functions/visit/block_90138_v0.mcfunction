tp @s 2.5 63.88 183.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 8 | ID 90138 | bloodborne_dw:source_addon_floor_panels_7 | вариант 0 | new", "color": "gold"}
