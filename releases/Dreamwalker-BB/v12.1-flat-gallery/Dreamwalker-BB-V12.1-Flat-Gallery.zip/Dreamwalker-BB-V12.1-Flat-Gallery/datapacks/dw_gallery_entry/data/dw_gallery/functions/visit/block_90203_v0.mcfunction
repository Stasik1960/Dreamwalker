tp @s 133.5 64.38 215.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 7 | ID 90203 | bloodborne_dw:source_addon_slabs_1_6 | вариант 0 | new", "color": "gold"}
