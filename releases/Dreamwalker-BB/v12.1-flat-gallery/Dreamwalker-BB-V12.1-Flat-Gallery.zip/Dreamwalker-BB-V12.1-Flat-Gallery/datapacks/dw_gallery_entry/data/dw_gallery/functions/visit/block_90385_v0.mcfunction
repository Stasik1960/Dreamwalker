tp @s 221.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 7 | ID 90385 | bloodborne_dw:source_bricks_stonebrick_6 | вариант 0 | new", "color": "gold"}
