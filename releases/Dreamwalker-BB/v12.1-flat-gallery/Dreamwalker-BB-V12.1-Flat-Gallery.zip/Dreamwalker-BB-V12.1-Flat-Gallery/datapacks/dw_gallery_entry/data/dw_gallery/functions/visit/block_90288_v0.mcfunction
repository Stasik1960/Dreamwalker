tp @s 9.5 66.88 269.5 0 9.4623
tellraw @s {"text": "Декоративная каменная поверхность · чёрный | ID 90288 | bloodborne_dw:source_black_concrete_powder | вариант 0 | new", "color": "gold"}
