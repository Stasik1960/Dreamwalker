tp @s 117.5 63.88 348.5 0 14.0362
tellraw @s {"text": "Широкий ступенчатый каменный карниз | ID 90410 | bloodborne_dw:source_chiseled_deepslate | вариант 0 | new", "color": "gold"}
