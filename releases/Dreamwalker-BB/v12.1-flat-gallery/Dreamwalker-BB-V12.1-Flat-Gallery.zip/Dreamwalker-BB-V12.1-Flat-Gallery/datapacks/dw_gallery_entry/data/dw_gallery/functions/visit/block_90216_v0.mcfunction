tp @s 89.5 64.38 227.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90216 | bloodborne_dw:source_addon_slabs_7_top | вариант 0 | new", "color": "gold"}
