tp @s 258.5 64.38 246.5 0 9.4623
tellraw @s {"text": "Ступенчатая каменная капитель | ID 90267 | bloodborne_dw:source_amethyst_block | вариант 0 | new", "color": "gold"}
