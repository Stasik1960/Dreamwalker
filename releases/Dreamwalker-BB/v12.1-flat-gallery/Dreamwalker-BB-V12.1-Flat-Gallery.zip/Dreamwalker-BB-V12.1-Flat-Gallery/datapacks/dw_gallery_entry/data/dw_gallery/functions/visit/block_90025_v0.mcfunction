tp @s 88.5 64.38 127.0 0 14.0362
tellraw @s {"text": "Настенный орнамент · верхняя | ID 90025 | bloodborne_dw:source__wall_dec_top | вариант 0 | new", "color": "gold"}
