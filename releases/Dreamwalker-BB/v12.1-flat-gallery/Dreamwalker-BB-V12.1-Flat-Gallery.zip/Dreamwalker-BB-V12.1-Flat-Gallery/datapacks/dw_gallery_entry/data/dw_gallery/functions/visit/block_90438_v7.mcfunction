tp @s 256.5 63.88 372.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · наклон 180° | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 7 | new", "color": "gold"}
