tp @s 72.5 64.38 1110.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90115 | bloodborne_dw:source_addon_cyan_terracotta_polished_blackstone_stairs7 | вариант 0 | absent", "color": "gold"}
