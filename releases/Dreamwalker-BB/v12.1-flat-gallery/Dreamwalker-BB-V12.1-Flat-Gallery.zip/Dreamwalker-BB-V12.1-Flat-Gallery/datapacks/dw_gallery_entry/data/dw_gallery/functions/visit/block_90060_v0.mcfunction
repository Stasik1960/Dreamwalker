tp @s 158.5 63.88 1101.5 0 14.0362
tellraw @s {"text": "Дверная секция · верхняя | ID 90060 | bloodborne_dw:source_addon_brich_trapdoor_top | вариант 0 | absent", "color": "gold"}
