tp @s 183.5 64.88 136.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 8 | ID 90052 | bloodborne_dw:source_addon_barrel_7 | вариант 0 | new", "color": "gold"}
