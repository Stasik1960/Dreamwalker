tp @s 258.0 63.88 215.7 0 11.7683
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90210 | bloodborne_dw:source_addon_slabs_3_top | вариант 0 | new", "color": "gold"}
