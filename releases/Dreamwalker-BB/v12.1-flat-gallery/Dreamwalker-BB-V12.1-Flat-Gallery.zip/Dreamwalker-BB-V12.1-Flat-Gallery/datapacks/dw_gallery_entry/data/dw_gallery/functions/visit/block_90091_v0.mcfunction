tp @s 222.5 64.38 156.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 4 | ID 90091 | bloodborne_dw:source_addon_chains_3 | вариант 0 | new", "color": "gold"}
