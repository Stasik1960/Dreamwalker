tp @s 239.5 64.88 236.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 5 | ID 90248 | bloodborne_dw:source_addon_wall_deco_4 | вариант 0 | new", "color": "gold"}
