tp @s 147.5 64.88 -1.0 0 14.0362
tellraw @s {"text": "Тонкое остекление · window02 | ID 90010 | bloodborne_dw:prototype_glass_window_02 | вариант 0 | v12", "color": "gold"}
