tp @s 158.5 63.88 126.5 0 14.0362
tellraw @s {"text": "Ребристое готическое навершие | ID 90032 | bloodborne_dw:source_acacia_sapling | вариант 0 | new", "color": "gold"}
