tp @s 210.5 64.88 246.5 0 9.4623
tellraw @s {"text": "Кирпичная кладка с выступающими гранями | ID 90261 | bloodborne_dw:source_addon_waxed_weathered_cut_copper | вариант 0 | new", "color": "gold"}
