tp @s 102.5 63.88 277.5 0 14.0362
tellraw @s {"text": "Мелкая серая кладка · вариант 1 | ID 90297 | bloodborne_dw:source_black_terracotta_0 | вариант 0 | new", "color": "gold"}
