tp @s 238.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · секция | ID 90327 | bloodborne_dw:source_brick_wall_side_tall | вариант 0 | new", "color": "gold"}
