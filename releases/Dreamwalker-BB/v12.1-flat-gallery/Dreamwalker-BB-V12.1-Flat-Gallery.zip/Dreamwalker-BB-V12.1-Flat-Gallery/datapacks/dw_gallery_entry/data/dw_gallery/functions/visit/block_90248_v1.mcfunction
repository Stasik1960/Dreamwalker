tp @s 257.5 63.88 237.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 5 · наклон 90° | ID 90248 | bloodborne_dw:source_addon_wall_deco_4 | вариант 1 | new", "color": "gold"}
