tp @s 275.5 64.88 247.5 0 14.0362
tellraw @s {"text": "Зубчатое каменное ребро | ID 90268 | bloodborne_dw:source_ancient_debris | вариант 0 | new", "color": "gold"}
