tp @s 147.0 64.38 136.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 5 | ID 90049 | bloodborne_dw:source_addon_barrel_4 | вариант 0 | new", "color": "gold"}
