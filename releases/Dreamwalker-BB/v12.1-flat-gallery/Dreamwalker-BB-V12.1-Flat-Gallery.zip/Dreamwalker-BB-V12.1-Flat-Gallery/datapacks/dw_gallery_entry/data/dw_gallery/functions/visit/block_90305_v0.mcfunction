tp @s 183.5 64.88 277.5 0 14.0362
tellraw @s {"text": "Декоративная каменная поверхность · синий | ID 90305 | bloodborne_dw:source_blue_concrete_powder | вариант 0 | new", "color": "gold"}
