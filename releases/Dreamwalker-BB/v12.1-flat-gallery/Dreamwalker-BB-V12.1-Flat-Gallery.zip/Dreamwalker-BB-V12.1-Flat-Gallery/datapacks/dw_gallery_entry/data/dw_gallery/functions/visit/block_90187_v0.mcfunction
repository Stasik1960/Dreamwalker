tp @s 134.5 64.38 205.5 0 14.0362
tellraw @s {"text": "Осколки стекла · вариант 2 | ID 90187 | bloodborne_dw:source_addon_shattered_glass_1 | вариант 0 | new", "color": "gold"}
