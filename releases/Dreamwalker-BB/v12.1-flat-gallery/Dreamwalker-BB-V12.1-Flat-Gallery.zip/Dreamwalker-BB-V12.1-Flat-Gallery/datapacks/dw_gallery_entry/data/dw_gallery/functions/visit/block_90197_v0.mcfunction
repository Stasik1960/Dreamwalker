tp @s 3.5 64.38 216.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 2 | ID 90197 | bloodborne_dw:source_addon_slabs_1_1 | вариант 0 | new", "color": "gold"}
