tp @s 209.5 64.38 156.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 3 | ID 90090 | bloodborne_dw:source_addon_chains_2 | вариант 0 | new", "color": "gold"}
