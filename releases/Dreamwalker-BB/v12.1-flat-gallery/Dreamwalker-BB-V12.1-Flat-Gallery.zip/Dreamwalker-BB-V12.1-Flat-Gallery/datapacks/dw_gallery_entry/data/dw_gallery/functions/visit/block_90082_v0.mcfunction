tp @s 73.0 64.38 156.2 0 11.7683
tellraw @s {"text": "Свечи · вариант 5 | ID 90082 | bloodborne_dw:source_addon_candles_4 | вариант 0 | new", "color": "gold"}
