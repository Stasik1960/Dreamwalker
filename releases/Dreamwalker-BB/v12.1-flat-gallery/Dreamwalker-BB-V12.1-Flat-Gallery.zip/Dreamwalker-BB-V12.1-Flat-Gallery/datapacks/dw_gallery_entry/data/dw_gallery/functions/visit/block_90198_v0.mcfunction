tp @s 38.0 64.38 216.0 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 11 | ID 90198 | bloodborne_dw:source_addon_slabs_1_10 | вариант 0 | new", "color": "gold"}
