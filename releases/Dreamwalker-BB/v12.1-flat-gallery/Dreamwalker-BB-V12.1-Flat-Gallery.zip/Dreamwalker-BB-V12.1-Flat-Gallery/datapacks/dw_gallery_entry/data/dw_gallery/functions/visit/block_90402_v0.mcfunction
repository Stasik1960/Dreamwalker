tp @s 134.5 64.38 338.0 0 14.0362
tellraw @s {"text": "Составное декоративное украшение | ID 90402 | bloodborne_dw:source_buttons_birch_birch_button | вариант 0 | new", "color": "gold"}
