tp @s 37.5 64.38 1110.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90114 | bloodborne_dw:source_addon_cyan_terracotta_polished_blackstone_stairs6 | вариант 0 | absent", "color": "gold"}
