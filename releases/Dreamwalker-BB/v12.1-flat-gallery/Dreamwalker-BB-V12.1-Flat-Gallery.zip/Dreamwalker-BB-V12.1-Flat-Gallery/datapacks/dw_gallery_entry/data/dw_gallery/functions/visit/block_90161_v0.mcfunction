tp @s 133.5 64.88 192.5 0 14.0362
tellraw @s {"text": "Вертикальное деревянное украшение · вариант 2 | ID 90161 | bloodborne_dw:source_addon_log_vertical_1 | вариант 0 | new", "color": "gold"}
