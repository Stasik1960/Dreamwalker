tp @s 134.5 64.38 1101.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 9 | ID 90053 | bloodborne_dw:source_addon_barrel_8 | вариант 0 | absent", "color": "gold"}
