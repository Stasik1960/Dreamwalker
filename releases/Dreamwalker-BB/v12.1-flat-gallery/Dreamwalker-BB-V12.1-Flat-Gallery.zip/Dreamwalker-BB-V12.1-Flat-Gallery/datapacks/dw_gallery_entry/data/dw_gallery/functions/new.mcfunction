function dw_gallery:visit/block_90023_v0
