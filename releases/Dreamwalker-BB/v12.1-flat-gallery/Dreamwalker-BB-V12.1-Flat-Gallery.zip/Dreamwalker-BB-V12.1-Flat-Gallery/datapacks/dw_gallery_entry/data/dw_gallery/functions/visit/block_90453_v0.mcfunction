tp @s 3.5 64.38 1132.5 0 14.0362
tellraw @s {"text": "Декоративная напольная деталь | ID 90453 | bloodborne_dw:source_crimson_hyphae | вариант 0 | absent", "color": "gold"}
