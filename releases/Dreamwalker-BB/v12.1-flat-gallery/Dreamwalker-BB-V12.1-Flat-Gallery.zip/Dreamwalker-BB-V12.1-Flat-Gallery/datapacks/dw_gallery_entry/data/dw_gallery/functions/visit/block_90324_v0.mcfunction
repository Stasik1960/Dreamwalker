tp @s 101.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · внешний угол | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 0 | new", "color": "gold"}
