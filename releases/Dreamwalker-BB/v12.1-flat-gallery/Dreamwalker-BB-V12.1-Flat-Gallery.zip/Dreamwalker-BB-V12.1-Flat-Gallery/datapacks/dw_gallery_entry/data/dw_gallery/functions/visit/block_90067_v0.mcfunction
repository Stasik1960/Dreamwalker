tp @s 89.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Напольная декоративная пластина · вариант 13 | ID 90067 | bloodborne_dw:source_addon_button_12 | вариант 0 | new", "color": "gold"}
