tp @s 102.0 64.38 323.0 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 1 | ID 90351 | bloodborne_dw:source_bricks_grass_block_0 | вариант 0 | new", "color": "gold"}
