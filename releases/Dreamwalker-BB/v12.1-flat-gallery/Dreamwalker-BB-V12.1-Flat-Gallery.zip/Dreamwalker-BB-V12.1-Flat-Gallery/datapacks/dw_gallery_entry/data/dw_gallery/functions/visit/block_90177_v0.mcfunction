tp @s 182.5 63.88 1110.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · открытая | ID 90177 | bloodborne_dw:source_addon_openspace | вариант 0 | absent", "color": "gold"}
