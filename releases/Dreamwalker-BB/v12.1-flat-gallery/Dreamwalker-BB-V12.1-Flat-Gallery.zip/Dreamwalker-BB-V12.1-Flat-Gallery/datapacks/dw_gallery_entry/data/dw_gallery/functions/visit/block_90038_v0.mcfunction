tp @s 274.5 63.88 126.5 0 14.0362
tellraw @s {"text": "Мешок · вариант 1 | ID 90038 | bloodborne_dw:source_addon_bag_0 | вариант 0 | new", "color": "gold"}
