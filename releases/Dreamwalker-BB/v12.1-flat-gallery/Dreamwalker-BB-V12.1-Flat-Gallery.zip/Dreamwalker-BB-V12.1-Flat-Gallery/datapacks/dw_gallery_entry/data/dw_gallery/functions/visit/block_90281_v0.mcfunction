tp @s 158.5 64.88 267.0 0 14.0362
tellraw @s {"text": "Секция ворот | ID 90281 | bloodborne_dw:source_birch_fence_gate | вариант 0 | new", "color": "gold"}
