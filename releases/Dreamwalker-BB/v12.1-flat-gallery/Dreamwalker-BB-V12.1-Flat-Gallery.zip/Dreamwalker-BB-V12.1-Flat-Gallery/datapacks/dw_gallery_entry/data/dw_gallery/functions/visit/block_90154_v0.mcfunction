tp @s 38.0 64.38 192.5 0 14.0362
tellraw @s {"text": "Кирпичный парапет с зубцами · вариант 2 | ID 90154 | bloodborne_dw:source_addon_green_glazed_1 | вариант 0 | new", "color": "gold"}
