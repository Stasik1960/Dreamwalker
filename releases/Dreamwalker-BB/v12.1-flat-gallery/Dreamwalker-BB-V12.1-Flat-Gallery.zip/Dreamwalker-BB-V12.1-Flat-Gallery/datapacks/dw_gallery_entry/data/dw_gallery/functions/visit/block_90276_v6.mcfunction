tp @s 88.5 63.88 266.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 180° | ID 90276 | bloodborne_dw:source_bamboo_stairs | вариант 6 | new", "color": "gold"}
