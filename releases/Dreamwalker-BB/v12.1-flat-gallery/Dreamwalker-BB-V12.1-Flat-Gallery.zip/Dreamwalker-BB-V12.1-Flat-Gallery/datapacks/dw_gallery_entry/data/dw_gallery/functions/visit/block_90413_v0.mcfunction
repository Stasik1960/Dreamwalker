tp @s 159.5 63.88 348.5 0 14.0362
tellraw @s {"text": "Ровная мелкая кирпичная кладка | ID 90413 | bloodborne_dw:source_chiseled_quartz_block | вариант 0 | new", "color": "gold"}
