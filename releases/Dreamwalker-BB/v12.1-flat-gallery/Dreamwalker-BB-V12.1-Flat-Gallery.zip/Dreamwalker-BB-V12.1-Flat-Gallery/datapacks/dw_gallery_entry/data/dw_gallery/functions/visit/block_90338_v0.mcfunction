tp @s 147.5 63.88 314.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 6 | ID 90338 | bloodborne_dw:source_bricks_bricks_r_5 | вариант 0 | new", "color": "gold"}
