tp @s 183.5 64.88 227.5 0 14.0362
tellraw @s {"text": "Статуя · вариант 2 | ID 90224 | bloodborne_dw:source_addon_statue_1 | вариант 0 | new", "color": "gold"}
