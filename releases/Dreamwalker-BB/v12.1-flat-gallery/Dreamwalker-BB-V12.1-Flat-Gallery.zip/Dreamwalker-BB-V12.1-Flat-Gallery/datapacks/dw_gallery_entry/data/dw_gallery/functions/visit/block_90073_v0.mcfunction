tp @s 183.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка · вариант 6 | ID 90073 | bloodborne_dw:source_addon_button_5 | вариант 0 | new", "color": "gold"}
