tp @s 158.5 64.38 1111.0 0 14.0362
tellraw @s {"text": "Фонарь | ID 90162 | bloodborne_dw:source_addon_mini_lantern | вариант 0 | absent", "color": "gold"}
