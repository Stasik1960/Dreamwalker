tp @s 37.5 63.88 183.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 9 | ID 90139 | bloodborne_dw:source_addon_floor_panels_8 | вариант 0 | new", "color": "gold"}
