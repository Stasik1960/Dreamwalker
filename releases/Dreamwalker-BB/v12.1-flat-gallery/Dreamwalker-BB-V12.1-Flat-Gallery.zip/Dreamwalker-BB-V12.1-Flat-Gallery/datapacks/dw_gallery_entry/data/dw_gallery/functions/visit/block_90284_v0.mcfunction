tp @s 222.0 64.38 267.5 0 14.0362
tellraw @s {"text": "Дверная секция | ID 90284 | bloodborne_dw:source_birch_trapdoor | вариант 0 | new", "color": "gold"}
