tp @s 239.5 64.38 193.5 0 14.0362
tellraw @s {"text": "Каменный фриз с орнаментом · вариант 3 | ID 90171 | bloodborne_dw:source_addon_note_2 | вариант 0 | new", "color": "gold"}
