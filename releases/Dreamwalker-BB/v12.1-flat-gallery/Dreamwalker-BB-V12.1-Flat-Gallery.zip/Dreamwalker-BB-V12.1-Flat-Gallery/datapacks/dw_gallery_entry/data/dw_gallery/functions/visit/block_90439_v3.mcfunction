tp @s 37.5 63.88 379.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внешний угол · наклон 180° | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 3 | new", "color": "gold"}
