tp @s 159.0 64.38 136.0 0 14.0362
tellraw @s {"text": "Бочка · вариант 6 | ID 90050 | bloodborne_dw:source_addon_barrel_5 | вариант 0 | new", "color": "gold"}
