tp @s 209.5 64.88 -1.5 0 14.0362
tellraw @s {"text": "Тонкое остекление · window03 | ID 90020 | bloodborne_dw:prototype_glass_window_03 | вариант 0 | v12", "color": "gold"}
