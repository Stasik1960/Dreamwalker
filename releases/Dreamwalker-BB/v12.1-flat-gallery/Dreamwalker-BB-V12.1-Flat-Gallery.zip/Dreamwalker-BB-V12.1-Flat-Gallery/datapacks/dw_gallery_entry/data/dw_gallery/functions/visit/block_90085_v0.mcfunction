tp @s 221.5 63.88 1100.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 2 | ID 90085 | bloodborne_dw:source_addon_chain_1 | вариант 0 | absent", "color": "gold"}
