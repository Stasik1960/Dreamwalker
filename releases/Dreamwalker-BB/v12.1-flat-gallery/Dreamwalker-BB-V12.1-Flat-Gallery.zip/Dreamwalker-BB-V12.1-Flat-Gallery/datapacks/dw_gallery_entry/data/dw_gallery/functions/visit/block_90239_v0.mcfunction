tp @s 102.5 64.88 237.2 0 11.7683
tellraw @s {"text": "Надгробие · вариант 4 | ID 90239 | bloodborne_dw:source_addon_tombstone_gathered_3 | вариант 0 | new", "color": "gold"}
