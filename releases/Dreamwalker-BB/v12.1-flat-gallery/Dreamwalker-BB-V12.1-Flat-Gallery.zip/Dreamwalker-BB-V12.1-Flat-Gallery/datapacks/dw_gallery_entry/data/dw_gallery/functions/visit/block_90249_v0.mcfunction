tp @s 275.5 64.88 236.5 0 14.0362
tellraw @s {"text": "Настенный орнамент · вариант 6 | ID 90249 | bloodborne_dw:source_addon_wall_deco_5 | вариант 0 | new", "color": "gold"}
