tp @s 209.5 64.88 266.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь | ID 90283 | bloodborne_dw:source_birch_pressure_plate | вариант 0 | new", "color": "gold"}
