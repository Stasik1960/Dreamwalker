tp @s 72.5 64.38 166.0 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 6 | ID 90098 | bloodborne_dw:source_addon_crimson_button_5 | вариант 0 | new", "color": "gold"}
