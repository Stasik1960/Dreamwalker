tp @s 256.5 63.88 192.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка · секция | ID 90172 | bloodborne_dw:source_addon_oak_button_side | вариант 0 | new", "color": "gold"}
