tp @s 287.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90330 | bloodborne_dw:source_bricks_bricks_1 | вариант 0 | new", "color": "gold"}
