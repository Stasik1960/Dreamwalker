tp @s 158.5 64.38 -1.5 0 14.0362
tellraw @s {"text": "Ограда · исходный материал 0 | ID 90011 | bloodborne_dw:prototype_wall_skin_0 | вариант 0 | v12", "color": "gold"}
