tp @s 221.5 63.88 227.5 0 14.0362
tellraw @s {"text": "Длинное поваленное бревно · вариант 1 | ID 90230 | bloodborne_dw:source_addon_stripped_oka_log_0 | вариант 0 | new", "color": "gold"}
