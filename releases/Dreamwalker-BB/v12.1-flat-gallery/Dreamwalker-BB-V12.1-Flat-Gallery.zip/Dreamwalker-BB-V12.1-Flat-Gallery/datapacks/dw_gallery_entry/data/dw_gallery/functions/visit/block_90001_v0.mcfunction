tp @s 3.5 65.38 -2.2687 0 11.7684
tellraw @s {"text": "Входная дверь | ID 90001 | bloodborne_dw:prototype_double_door | вариант 0 | v12", "color": "gold"}
