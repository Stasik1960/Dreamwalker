tp @s 134.5 64.88 277.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь | ID 90299 | bloodborne_dw:source_black_wool | вариант 0 | new", "color": "gold"}
