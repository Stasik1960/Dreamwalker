tp @s 38.5 65.38 236.7 0 11.7683
tellraw @s {"text": "Надгробие · вариант 1 | ID 90236 | bloodborne_dw:source_addon_tombstone_gathered_0 | вариант 0 | new", "color": "gold"}
