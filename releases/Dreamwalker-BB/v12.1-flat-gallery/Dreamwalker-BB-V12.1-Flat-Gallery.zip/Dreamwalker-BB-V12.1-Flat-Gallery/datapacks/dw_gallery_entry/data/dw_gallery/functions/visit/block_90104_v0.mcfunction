tp @s 158.5 63.88 165.5 0 14.0362
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 6 | ID 90104 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_5 | вариант 0 | new", "color": "gold"}
