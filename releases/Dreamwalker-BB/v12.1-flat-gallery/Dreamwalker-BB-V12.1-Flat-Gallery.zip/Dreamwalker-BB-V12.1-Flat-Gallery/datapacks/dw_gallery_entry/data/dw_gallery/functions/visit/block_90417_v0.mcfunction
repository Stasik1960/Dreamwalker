tp @s 222.5 64.88 348.5 0 14.0362
tellraw @s {"text": "Узкое ребро с каменными зубцами | ID 90417 | bloodborne_dw:source_coal_block | вариант 0 | new", "color": "gold"}
