tp @s 88.5 63.88 297.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · верхняя | ID 90321 | bloodborne_dw:source_brick_slab_top | вариант 0 | new", "color": "gold"}
