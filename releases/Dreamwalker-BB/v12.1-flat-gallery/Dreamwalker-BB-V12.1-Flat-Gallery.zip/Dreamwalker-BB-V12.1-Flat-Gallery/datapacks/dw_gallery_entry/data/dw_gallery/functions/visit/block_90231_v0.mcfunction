tp @s 238.5 64.38 227.5 0 14.0362
tellraw @s {"text": "Замшелое поваленное бревно · вариант 2 | ID 90231 | bloodborne_dw:source_addon_stripped_oka_log_1 | вариант 0 | new", "color": "gold"}
