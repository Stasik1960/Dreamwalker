tp @s 184.0 63.88 267.2 0 11.7683
tellraw @s {"text": "Резной блок с вертикальными панелями | ID 90282 | bloodborne_dw:source_birch_planks | вариант 0 | new", "color": "gold"}
