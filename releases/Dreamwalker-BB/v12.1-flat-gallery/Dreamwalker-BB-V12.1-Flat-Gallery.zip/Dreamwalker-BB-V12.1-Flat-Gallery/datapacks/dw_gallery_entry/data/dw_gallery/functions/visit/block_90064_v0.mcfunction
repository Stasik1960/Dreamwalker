tp @s 3.5 64.38 146.5 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 2 | ID 90064 | bloodborne_dw:source_addon_button_1 | вариант 0 | new", "color": "gold"}
