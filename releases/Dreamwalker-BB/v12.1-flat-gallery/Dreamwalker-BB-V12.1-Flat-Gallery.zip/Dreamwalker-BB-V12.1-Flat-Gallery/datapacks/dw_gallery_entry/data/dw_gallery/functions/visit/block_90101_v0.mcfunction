tp @s 116.5 63.88 165.5 0 14.0362
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 3 | ID 90101 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_2 | вариант 0 | new", "color": "gold"}
