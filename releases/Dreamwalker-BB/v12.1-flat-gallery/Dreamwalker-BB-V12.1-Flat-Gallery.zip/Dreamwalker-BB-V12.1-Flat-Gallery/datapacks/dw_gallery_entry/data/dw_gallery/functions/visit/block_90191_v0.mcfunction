tp @s 209.5 64.38 204.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90191 | bloodborne_dw:source_addon_slabs_0_top | вариант 0 | new", "color": "gold"}
