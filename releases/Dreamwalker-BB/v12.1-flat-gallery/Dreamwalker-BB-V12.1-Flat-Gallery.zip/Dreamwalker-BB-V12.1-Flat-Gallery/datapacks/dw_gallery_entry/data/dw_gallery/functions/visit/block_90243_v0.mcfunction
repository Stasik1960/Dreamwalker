tp @s 159.5 64.88 237.5 0 14.0362
tellraw @s {"text": "Надгробие · вариант 8 | ID 90243 | bloodborne_dw:source_addon_tombstone_gathered_7 | вариант 0 | new", "color": "gold"}
