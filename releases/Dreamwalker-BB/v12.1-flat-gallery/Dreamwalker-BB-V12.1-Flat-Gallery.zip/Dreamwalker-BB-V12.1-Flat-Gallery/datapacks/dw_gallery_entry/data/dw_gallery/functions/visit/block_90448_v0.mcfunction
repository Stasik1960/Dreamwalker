tp @s 222.5 64.88 380.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка | ID 90448 | bloodborne_dw:source_cracked_nether_bricks | вариант 0 | new", "color": "gold"}
