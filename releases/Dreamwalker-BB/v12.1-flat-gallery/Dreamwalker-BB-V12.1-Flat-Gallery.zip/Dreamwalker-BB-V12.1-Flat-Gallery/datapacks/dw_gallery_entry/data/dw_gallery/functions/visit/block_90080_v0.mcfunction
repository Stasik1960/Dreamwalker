tp @s 4.0 64.38 155.7 0 11.7683
tellraw @s {"text": "Свечи · вариант 3 | ID 90080 | bloodborne_dw:source_addon_candles_2 | вариант 0 | new", "color": "gold"}
