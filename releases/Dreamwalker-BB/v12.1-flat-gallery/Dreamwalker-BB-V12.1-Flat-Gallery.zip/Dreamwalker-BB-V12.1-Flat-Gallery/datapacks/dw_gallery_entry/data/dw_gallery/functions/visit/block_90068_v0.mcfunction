tp @s 102.0 64.38 147.0 0 14.0362
tellraw @s {"text": "Напольная декоративная пластина · вариант 14 | ID 90068 | bloodborne_dw:source_addon_button_13 | вариант 0 | new", "color": "gold"}
