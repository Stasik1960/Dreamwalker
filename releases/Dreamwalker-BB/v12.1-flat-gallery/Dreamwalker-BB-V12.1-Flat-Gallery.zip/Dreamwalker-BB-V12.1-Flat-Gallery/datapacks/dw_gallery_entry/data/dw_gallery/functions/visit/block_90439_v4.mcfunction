tp @s 72.5 63.88 379.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внешний угол · закреплённые UV 180° | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 4 | new", "color": "gold"}
