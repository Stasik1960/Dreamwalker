tp @s 287.5 63.88 337.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 270° | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 2 | new", "color": "gold"}
