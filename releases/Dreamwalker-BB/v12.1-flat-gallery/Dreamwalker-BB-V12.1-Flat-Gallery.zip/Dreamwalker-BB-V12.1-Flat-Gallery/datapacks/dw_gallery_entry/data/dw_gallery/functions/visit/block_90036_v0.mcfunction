tp @s 239.5 64.88 126.5 0 14.0362
tellraw @s {"text": "Ажурное завершение ограды | ID 90036 | bloodborne_dw:source_acacia_wood | вариант 0 | new", "color": "gold"}
