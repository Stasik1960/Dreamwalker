tp @s 38.0 64.38 165.5 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 5 | ID 90097 | bloodborne_dw:source_addon_crimson_button_4 | вариант 0 | new", "color": "gold"}
