tp @s 38.5 64.88 258.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь | ID 90271 | bloodborne_dw:source_azure_bluet | вариант 0 | new", "color": "gold"}
