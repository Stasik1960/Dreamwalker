tp @s 159.5 63.88 314.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90339 | bloodborne_dw:source_bricks_bricks_rl_0 | вариант 0 | new", "color": "gold"}
