tp @s 147.5 64.38 348.5 0 14.0362
tellraw @s {"text": "Резная колонна с арочными панелями | ID 90412 | bloodborne_dw:source_chiseled_polished_blackstone | вариант 0 | new", "color": "gold"}
