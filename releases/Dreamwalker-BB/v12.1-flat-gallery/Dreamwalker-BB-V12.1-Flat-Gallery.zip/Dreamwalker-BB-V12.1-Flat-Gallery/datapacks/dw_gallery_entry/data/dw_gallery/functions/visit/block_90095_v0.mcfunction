tp @s 288.5 64.88 155.5 0 14.0362
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 3 | ID 90095 | bloodborne_dw:source_addon_crimson_button_2 | вариант 0 | new", "color": "gold"}
