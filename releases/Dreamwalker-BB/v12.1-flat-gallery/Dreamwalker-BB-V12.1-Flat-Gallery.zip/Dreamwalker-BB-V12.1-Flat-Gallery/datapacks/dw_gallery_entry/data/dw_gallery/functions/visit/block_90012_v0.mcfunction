tp @s 182.5 64.38 -1.5 0 14.0362
tellraw @s {"text": "Ограда · исходный материал 1 | ID 90012 | bloodborne_dw:prototype_wall_skin_1 | вариант 0 | v12", "color": "gold"}
