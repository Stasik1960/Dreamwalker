tp @s 208.5 63.88 379.5 0 14.0362
tellraw @s {"text": "Кладка из разноразмерных камней | ID 90447 | bloodborne_dw:source_cracked_deepslate_tiles | вариант 0 | new", "color": "gold"}
