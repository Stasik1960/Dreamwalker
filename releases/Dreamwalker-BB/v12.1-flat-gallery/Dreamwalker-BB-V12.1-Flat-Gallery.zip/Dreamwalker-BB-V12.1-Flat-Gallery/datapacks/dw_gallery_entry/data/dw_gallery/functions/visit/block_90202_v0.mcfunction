tp @s 118.0 63.88 216.2 0 11.7683
tellraw @s {"text": "Архитектурная плита · вариант 6 | ID 90202 | bloodborne_dw:source_addon_slabs_1_5 | вариант 0 | new", "color": "gold"}
