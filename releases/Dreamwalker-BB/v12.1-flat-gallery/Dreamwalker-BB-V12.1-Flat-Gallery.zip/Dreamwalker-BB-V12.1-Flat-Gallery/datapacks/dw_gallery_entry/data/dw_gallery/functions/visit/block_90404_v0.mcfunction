tp @s 159.5 64.38 337.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка | ID 90404 | bloodborne_dw:source_buttons_dark_oak_dark_oak_button_on | вариант 0 | new", "color": "gold"}
