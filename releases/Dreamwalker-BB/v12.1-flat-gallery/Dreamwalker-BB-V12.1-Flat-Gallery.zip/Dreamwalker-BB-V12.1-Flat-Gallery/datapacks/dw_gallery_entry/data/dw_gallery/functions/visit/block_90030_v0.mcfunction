tp @s 72.5 64.88 1100.5 0 14.0362
tellraw @s {"text": "Плита из рыжих досок | ID 90030 | bloodborne_dw:source_acacia_planks | вариант 0 | absent", "color": "gold"}
