tp @s 239.5 63.88 135.5 0 14.0362
tellraw @s {"text": "Прямоугольная панель с рамкой · вариант 1 | ID 90056 | bloodborne_dw:source_addon_blue_glazed_terracotta_0 | вариант 0 | new", "color": "gold"}
