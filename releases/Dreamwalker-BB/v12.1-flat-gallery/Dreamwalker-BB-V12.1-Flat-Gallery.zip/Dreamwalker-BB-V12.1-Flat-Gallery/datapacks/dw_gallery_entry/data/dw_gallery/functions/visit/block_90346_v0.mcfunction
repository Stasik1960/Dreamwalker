tp @s 287.5 63.88 313.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90346 | bloodborne_dw:source_bricks_cracked_bricks_4 | вариант 0 | new", "color": "gold"}
