tp @s 287.5 63.88 276.5 0 14.0362
tellraw @s {"text": "Пустотелая секция каменной стены | ID 90312 | bloodborne_dw:source_blue_stained_glass | вариант 0 | new", "color": "gold"}
