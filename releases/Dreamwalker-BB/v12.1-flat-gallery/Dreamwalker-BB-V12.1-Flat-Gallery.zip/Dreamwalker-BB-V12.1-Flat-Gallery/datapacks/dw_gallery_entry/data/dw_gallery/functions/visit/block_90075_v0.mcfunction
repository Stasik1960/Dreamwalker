tp @s 222.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка · вариант 8 | ID 90075 | bloodborne_dw:source_addon_button_7 | вариант 0 | new", "color": "gold"}
