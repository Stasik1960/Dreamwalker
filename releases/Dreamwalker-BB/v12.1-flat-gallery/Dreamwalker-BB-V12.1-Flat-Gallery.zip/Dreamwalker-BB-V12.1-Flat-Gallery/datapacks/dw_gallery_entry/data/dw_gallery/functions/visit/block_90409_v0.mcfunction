tp @s 256.5 63.88 337.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 0 | new", "color": "gold"}
