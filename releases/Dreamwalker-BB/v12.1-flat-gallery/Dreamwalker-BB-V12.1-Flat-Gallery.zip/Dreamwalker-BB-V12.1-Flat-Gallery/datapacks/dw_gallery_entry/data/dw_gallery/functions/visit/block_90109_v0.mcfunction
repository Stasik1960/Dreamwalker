tp @s 238.5 64.38 1100.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90109 | bloodborne_dw:source_addon_cyan_terracotta_polished_blackstone_stairs1 | вариант 0 | absent", "color": "gold"}
