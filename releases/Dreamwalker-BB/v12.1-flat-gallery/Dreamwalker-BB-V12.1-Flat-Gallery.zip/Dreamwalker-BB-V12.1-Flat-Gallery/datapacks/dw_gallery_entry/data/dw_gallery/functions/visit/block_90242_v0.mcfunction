tp @s 147.5 64.88 237.2 0 11.7683
tellraw @s {"text": "Надгробие · вариант 7 | ID 90242 | bloodborne_dw:source_addon_tombstone_gathered_6 | вариант 0 | new", "color": "gold"}
