tp @s 208.5 63.88 165.5 0 14.0362
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 8 | ID 90106 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_7 | вариант 0 | new", "color": "gold"}
