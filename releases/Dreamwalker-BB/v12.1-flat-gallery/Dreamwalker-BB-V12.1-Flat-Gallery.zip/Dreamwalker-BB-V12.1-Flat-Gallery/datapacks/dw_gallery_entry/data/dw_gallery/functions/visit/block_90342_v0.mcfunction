tp @s 221.5 63.88 313.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90342 | bloodborne_dw:source_bricks_cracked_bricks_0 | вариант 0 | new", "color": "gold"}
