tp @s 183.5 63.88 314.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90340 | bloodborne_dw:source_bricks_bricks_rl_1 | вариант 0 | new", "color": "gold"}
