tp @s 37.5 63.88 347.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 90° | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 4 | new", "color": "gold"}
