tp @s 117.5 64.38 267.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь | ID 90277 | bloodborne_dw:source_basalt | вариант 0 | new", "color": "gold"}
