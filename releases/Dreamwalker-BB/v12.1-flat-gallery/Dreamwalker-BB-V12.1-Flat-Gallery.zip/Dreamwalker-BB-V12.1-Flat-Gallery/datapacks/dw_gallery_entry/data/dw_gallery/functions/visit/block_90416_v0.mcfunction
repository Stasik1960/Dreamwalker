tp @s 239.5 63.88 1121.5 0 14.0362
tellraw @s {"text": "Глина · текстура BB | ID 90416 | bloodborne_dw:source_clay | вариант 0 | absent", "color": "gold"}
