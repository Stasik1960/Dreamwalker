tp @s 102.5 64.88 258.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · вариант 4 | ID 90274 | bloodborne_dw:source_azure_bluet_3 | вариант 0 | new", "color": "gold"}
