tp @s 102.5 64.38 227.0 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90218 | bloodborne_dw:source_addon_slabs_8_top | вариант 0 | new", "color": "gold"}
