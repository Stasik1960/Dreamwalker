tp @s 101.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 7 | ID 90378 | bloodborne_dw:source_bricks_stone_6 | вариант 0 | new", "color": "gold"}
