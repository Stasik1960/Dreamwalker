tp @s 256.5 64.38 205.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90194 | bloodborne_dw:source_addon_slabs_10_top | вариант 0 | new", "color": "gold"}
