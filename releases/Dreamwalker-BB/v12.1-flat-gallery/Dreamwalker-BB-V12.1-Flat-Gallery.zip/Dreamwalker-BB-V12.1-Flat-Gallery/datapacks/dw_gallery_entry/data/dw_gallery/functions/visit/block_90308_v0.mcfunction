tp @s 222.5 64.38 276.5 0 14.0362
tellraw @s {"text": "Составное декоративное украшение | ID 90308 | bloodborne_dw:source_blue_orchid | вариант 0 | new", "color": "gold"}
