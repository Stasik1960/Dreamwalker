tp @s 134.5 64.38 1121.5 0 14.0362
tellraw @s {"text": "Деревянный ящик | ID 90265 | bloodborne_dw:source_addon_wooden_box | вариант 0 | absent", "color": "gold"}
