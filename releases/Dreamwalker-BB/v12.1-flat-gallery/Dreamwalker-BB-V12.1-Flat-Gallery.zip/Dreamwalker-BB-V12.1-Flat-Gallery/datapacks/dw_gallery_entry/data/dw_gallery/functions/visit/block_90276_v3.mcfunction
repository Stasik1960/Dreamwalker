tp @s 2.5 63.88 266.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90276 | bloodborne_dw:source_bamboo_stairs | вариант 3 | new", "color": "gold"}
