tp @s 158.5 63.88 257.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90275 | bloodborne_dw:source_bamboo_mosaic_stairs | вариант 3 | new", "color": "gold"}
