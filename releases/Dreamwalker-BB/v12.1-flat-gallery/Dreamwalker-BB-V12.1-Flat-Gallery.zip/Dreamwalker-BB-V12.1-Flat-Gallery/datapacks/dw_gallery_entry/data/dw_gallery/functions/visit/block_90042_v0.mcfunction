tp @s 88.5 64.38 1100.5 0 14.0362
tellraw @s {"text": "Мешок · вариант 5 | ID 90042 | bloodborne_dw:source_addon_bag_4 | вариант 0 | absent", "color": "gold"}
