tp @s 275.5 63.88 380.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь | ID 90454 | bloodborne_dw:source_crimson_nylium | вариант 0 | new", "color": "gold"}
