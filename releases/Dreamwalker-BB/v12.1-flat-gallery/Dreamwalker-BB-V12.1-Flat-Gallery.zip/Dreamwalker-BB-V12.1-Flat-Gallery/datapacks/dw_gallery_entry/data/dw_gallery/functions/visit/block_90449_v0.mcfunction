tp @s 238.5 64.88 379.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка | ID 90449 | bloodborne_dw:source_cracked_polished_blackstone_bricks | вариант 0 | new", "color": "gold"}
