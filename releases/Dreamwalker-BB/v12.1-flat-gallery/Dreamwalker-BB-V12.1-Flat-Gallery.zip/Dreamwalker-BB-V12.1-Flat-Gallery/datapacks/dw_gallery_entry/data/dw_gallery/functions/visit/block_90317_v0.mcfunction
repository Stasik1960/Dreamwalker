tp @s 3.5 64.88 298.5 0 14.0362
tellraw @s {"text": "Готическая ниша с фигурным завершением | ID 90317 | bloodborne_dw:source_blue_terracotta | вариант 0 | new", "color": "gold"}
