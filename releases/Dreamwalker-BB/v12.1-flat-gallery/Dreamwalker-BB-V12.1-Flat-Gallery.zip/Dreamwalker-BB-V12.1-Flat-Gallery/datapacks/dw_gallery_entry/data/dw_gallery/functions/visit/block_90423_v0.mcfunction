tp @s 256.5 63.88 1120.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль | ID 90423 | bloodborne_dw:source_cobbled_deepslate_stairs | вариант 0 | absent", "color": "gold"}
