tp @s 38.5 64.38 314.0 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90332 | bloodborne_dw:source_bricks_bricks_3 | вариант 0 | new", "color": "gold"}
