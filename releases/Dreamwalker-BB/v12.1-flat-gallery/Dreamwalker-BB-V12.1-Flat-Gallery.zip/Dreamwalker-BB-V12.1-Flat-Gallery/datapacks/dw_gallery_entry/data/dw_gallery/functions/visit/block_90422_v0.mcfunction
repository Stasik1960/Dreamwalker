tp @s 2.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90422 | bloodborne_dw:source_cobbled_deepslate_slab_top | вариант 0 | new", "color": "gold"}
