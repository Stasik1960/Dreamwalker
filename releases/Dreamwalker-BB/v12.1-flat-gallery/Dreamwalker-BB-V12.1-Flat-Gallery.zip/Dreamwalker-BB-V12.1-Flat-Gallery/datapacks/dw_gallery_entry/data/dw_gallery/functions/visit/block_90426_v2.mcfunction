tp @s 274.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90426 | bloodborne_dw:source_cobbled_deepslate_stairs_n | вариант 2 | new", "color": "gold"}
