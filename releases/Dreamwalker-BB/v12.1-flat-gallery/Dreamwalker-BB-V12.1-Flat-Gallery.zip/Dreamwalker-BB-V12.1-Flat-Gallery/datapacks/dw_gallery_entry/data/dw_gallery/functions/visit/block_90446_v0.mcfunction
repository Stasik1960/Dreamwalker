tp @s 183.5 64.38 380.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка | ID 90446 | bloodborne_dw:source_cracked_deepslate_bricks | вариант 0 | new", "color": "gold"}
