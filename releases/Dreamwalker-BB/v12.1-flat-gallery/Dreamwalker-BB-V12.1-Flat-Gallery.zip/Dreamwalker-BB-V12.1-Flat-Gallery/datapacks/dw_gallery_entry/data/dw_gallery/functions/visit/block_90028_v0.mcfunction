tp @s 134.5 64.88 126.5 0 14.0362
tellraw @s {"text": "Секция ворот | ID 90028 | bloodborne_dw:source_acacia_fence_gate | вариант 0 | new", "color": "gold"}
