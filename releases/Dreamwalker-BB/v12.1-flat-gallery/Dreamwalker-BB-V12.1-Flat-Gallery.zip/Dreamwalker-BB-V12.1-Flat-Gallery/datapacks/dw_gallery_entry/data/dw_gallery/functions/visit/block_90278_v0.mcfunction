tp @s 133.5 63.88 266.5 0 14.0362
tellraw @s {"text": "Бирюзовый светильник на основании | ID 90278 | bloodborne_dw:source_beacon | вариант 0 | new", "color": "gold"}
