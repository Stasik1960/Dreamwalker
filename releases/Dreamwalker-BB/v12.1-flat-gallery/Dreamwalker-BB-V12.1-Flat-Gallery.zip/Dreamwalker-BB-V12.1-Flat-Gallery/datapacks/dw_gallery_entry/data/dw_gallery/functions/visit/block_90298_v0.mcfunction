tp @s 117.5 63.88 277.5 0 14.0362
tellraw @s {"text": "Мелкая серая кладка · вариант 2 | ID 90298 | bloodborne_dw:source_black_terracotta_1 | вариант 0 | new", "color": "gold"}
