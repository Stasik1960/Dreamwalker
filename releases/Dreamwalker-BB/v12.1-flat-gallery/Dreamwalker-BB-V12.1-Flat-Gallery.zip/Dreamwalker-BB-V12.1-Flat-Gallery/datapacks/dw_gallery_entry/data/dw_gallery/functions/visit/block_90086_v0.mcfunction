tp @s 134.5 63.88 156.5 0 14.0362
tellraw @s {"text": "Цепь · вариант 3 | ID 90086 | bloodborne_dw:source_addon_chain_2 | вариант 0 | new", "color": "gold"}
