tp @s 147.0 64.38 1111.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · вариант 1 | ID 90159 | bloodborne_dw:source_addon_light_gray_glazed_terracotta_0 | вариант 0 | absent", "color": "gold"}
