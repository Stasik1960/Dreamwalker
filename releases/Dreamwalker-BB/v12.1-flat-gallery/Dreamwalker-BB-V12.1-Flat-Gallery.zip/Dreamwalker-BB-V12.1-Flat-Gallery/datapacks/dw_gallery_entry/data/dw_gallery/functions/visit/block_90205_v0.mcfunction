tp @s 159.0 64.38 215.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 9 | ID 90205 | bloodborne_dw:source_addon_slabs_1_8 | вариант 0 | new", "color": "gold"}
