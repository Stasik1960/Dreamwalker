tp @s 118.5 64.88 235.5 0 9.4623
tellraw @s {"text": "Надгробие · вариант 5 | ID 90240 | bloodborne_dw:source_addon_tombstone_gathered_4 | вариант 0 | new", "color": "gold"}
