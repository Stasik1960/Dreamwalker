tp @s 89.5 64.88 258.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · вариант 3 | ID 90273 | bloodborne_dw:source_azure_bluet_2 | вариант 0 | new", "color": "gold"}
