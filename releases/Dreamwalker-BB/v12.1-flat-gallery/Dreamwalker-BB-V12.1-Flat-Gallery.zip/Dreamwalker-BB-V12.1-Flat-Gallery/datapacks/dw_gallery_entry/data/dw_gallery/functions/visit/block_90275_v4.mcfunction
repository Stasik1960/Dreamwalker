tp @s 182.5 63.88 257.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 90° | ID 90275 | bloodborne_dw:source_bamboo_mosaic_stairs | вариант 4 | new", "color": "gold"}
