tp @s 257.5 64.38 1111.2 0 11.7683
tellraw @s {"text": "Архитектурная плита · вариант 9 | ID 90217 | bloodborne_dw:source_addon_slabs_8 | вариант 0 | absent", "color": "gold"}
