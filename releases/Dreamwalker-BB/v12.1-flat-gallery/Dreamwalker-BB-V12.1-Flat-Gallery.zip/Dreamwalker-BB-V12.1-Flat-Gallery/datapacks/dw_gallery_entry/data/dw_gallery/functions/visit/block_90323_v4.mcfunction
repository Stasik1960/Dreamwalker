tp @s 2.5 63.88 306.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · внутренний угол · закреплённые UV 180° | ID 90323 | bloodborne_dw:source_brick_stairs_inner | вариант 4 | new", "color": "gold"}
