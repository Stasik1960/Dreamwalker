tp @s 89.5 63.88 277.5 0 14.0362
tellraw @s {"text": "Мелкая серая кладка | ID 90296 | bloodborne_dw:source_black_terracotta | вариант 0 | new", "color": "gold"}
