tp @s 38.5 64.38 175.5 0 14.0362
tellraw @s {"text": "Напольный орнамент · вариант 4 | ID 90123 | bloodborne_dw:source_addon_floor_dec_3 | вариант 0 | new", "color": "gold"}
