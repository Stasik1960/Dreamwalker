tp @s 147.5 65.38 192.7 0 11.7683
tellraw @s {"text": "Статуя · вариант 2 | ID 90166 | bloodborne_dw:source_addon_new_statue_1 | вариант 0 | new", "color": "gold"}
