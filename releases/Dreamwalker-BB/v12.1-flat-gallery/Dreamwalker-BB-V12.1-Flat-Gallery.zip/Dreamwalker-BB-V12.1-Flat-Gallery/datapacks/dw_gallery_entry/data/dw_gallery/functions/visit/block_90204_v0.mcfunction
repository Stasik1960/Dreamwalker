tp @s 146.5 64.38 215.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 8 | ID 90204 | bloodborne_dw:source_addon_slabs_1_7 | вариант 0 | new", "color": "gold"}
