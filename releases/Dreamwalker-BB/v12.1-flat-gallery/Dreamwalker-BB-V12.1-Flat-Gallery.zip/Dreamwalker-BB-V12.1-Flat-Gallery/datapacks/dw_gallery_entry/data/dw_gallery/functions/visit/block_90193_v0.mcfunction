tp @s 238.5 64.38 205.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 11 | ID 90193 | bloodborne_dw:source_addon_slabs_10 | вариант 0 | new", "color": "gold"}
