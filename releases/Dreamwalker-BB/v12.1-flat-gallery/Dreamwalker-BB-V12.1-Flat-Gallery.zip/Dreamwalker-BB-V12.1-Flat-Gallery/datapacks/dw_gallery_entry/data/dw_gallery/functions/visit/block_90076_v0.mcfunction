tp @s 239.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка · вариант 9 | ID 90076 | bloodborne_dw:source_addon_button_8 | вариант 0 | new", "color": "gold"}
