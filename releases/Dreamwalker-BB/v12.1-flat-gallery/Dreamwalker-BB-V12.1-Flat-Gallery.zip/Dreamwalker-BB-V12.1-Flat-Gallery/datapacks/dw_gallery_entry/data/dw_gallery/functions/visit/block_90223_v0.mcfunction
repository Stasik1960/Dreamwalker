tp @s 159.0 64.38 227.5 0 14.0362
tellraw @s {"text": "Статуя · вариант 1 | ID 90223 | bloodborne_dw:source_addon_statue_0 | вариант 0 | new", "color": "gold"}
