tp @s 101.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внутренний угол | ID 90425 | bloodborne_dw:source_cobbled_deepslate_stairs_inner | вариант 0 | new", "color": "gold"}
