tp @s 73.5 64.88 258.5 0 14.0362
tellraw @s {"text": "Объёмная декоративная деталь · вариант 2 | ID 90272 | bloodborne_dw:source_azure_bluet_1 | вариант 0 | new", "color": "gold"}
