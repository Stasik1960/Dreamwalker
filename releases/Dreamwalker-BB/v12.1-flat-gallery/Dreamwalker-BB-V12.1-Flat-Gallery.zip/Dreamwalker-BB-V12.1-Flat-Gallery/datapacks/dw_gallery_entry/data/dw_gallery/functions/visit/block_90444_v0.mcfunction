tp @s 147.5 64.88 380.5 0 14.0362
tellraw @s {"text": "Каменное ребро с выступающими зубцами | ID 90444 | bloodborne_dw:source_copper_block | вариант 0 | new", "color": "gold"}
