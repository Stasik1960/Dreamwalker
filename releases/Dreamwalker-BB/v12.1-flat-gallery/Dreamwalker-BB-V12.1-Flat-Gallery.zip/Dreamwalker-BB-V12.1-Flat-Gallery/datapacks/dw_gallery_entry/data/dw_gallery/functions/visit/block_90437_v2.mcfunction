tp @s 2.5 63.88 372.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 270° | ID 90437 | bloodborne_dw:source_cobblestone_stairs | вариант 2 | new", "color": "gold"}
