tp @s 146.5 63.88 372.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · закреплённые UV 270° | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 1 | new", "color": "gold"}
