tp @s 159.5 64.88 1121.5 0 14.0362
tellraw @s {"text": "Составное декоративное украшение | ID 90287 | bloodborne_dw:source_black_carpet | вариант 0 | absent", "color": "gold"}
