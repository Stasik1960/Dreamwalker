tp @s 73.0 64.38 127.0 0 14.0362
tellraw @s {"text": "Настенный орнамент · наклон 180° | ID 90024 | bloodborne_dw:source__wall_dec_out | вариант 1 | new", "color": "gold"}
