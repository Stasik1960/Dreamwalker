tp @s 117.5 64.38 1101.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 7 | ID 90051 | bloodborne_dw:source_addon_barrel_6 | вариант 0 | absent", "color": "gold"}
