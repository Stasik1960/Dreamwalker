tp @s 288.0 64.88 380.0 0 14.0362
tellraw @s {"text": "Тонкий декоративный шпиль | ID 90455 | bloodborne_dw:source_crimson_planks | вариант 0 | new", "color": "gold"}
