tp @s 72.5 63.88 183.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 10 | ID 90140 | bloodborne_dw:source_addon_floor_panels_9 | вариант 0 | new", "color": "gold"}
