tp @s 208.5 63.88 322.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90362 | bloodborne_dw:source_bricks_purpur_block_2 | вариант 0 | new", "color": "gold"}
