tp @s 38.0 64.38 127.0 0 14.0362
tellraw @s {"text": "Настенный орнамент | ID 90024 | bloodborne_dw:source__wall_dec_out | вариант 0 | new", "color": "gold"}
