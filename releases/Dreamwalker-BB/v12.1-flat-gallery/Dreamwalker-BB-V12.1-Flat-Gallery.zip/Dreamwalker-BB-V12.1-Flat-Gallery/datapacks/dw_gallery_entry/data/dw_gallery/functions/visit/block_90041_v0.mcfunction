tp @s 37.5 63.88 135.5 0 14.0362
tellraw @s {"text": "Мешок · вариант 4 | ID 90041 | bloodborne_dw:source_addon_bag_3 | вариант 0 | new", "color": "gold"}
