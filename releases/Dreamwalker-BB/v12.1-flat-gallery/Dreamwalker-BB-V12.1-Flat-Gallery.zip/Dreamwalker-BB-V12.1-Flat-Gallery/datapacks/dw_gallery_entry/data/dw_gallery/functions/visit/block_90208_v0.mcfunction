tp @s 221.5 64.38 216.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 3 | ID 90208 | bloodborne_dw:source_addon_slabs_2 | вариант 0 | new", "color": "gold"}
