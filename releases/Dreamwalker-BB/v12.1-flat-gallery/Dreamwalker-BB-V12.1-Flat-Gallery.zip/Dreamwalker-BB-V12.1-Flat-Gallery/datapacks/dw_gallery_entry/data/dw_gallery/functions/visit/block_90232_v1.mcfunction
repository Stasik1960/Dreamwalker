tp @s 274.5 64.88 227.0 0 14.0362
tellraw @s {"text": "Поваленное бревно со свисающим мхом · вариант 3 · наклон 90° | ID 90232 | bloodborne_dw:source_addon_stripped_oka_log_2 | вариант 1 | new", "color": "gold"}
