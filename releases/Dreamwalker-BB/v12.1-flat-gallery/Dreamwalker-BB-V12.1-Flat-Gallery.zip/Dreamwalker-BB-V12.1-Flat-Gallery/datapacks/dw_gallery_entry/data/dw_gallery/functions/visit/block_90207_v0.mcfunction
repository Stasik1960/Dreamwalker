tp @s 208.5 64.38 215.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90207 | bloodborne_dw:source_addon_slabs_1_top | вариант 0 | new", "color": "gold"}
