function dw_gallery:visit/block_90021_v0
