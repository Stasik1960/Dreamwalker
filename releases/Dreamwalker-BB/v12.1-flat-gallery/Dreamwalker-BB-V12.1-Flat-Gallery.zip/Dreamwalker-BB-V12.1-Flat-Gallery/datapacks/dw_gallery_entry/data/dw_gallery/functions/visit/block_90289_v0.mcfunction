tp @s 38.0 64.88 277.0 0 14.0362
tellraw @s {"text": "Узкая резная стеновая панель | ID 90289 | bloodborne_dw:source_black_glazed_terracotta | вариант 0 | new", "color": "gold"}
