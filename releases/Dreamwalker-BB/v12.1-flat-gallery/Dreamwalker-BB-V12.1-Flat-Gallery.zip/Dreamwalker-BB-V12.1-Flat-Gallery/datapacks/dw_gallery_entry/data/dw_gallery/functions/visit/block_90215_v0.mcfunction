tp @s 73.5 64.38 227.5 0 14.0362
tellraw @s {"text": "Архитектурная плита · вариант 8 | ID 90215 | bloodborne_dw:source_addon_slabs_7 | вариант 0 | new", "color": "gold"}
