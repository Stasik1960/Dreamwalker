tp @s 239.5 64.88 247.5 0 14.0362
tellraw @s {"text": "Деревянное украшение · вариант 3 | ID 90263 | bloodborne_dw:source_addon_wood_obj_2 | вариант 0 | new", "color": "gold"}
