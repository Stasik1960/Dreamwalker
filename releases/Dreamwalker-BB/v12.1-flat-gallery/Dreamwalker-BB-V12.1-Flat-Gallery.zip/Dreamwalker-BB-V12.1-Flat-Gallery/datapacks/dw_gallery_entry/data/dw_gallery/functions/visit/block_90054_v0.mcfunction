tp @s 209.5 64.88 136.5 0 14.0362
tellraw @s {"text": "Бочка · вариант 10 | ID 90054 | bloodborne_dw:source_addon_barrel_9 | вариант 0 | new", "color": "gold"}
