give @s bloodborne_dw:bb_tool
