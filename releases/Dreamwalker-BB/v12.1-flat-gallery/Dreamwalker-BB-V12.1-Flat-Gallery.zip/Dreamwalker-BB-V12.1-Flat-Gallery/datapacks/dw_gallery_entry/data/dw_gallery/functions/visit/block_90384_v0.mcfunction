tp @s 208.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 6 | ID 90384 | bloodborne_dw:source_bricks_stonebrick_5 | вариант 0 | new", "color": "gold"}
