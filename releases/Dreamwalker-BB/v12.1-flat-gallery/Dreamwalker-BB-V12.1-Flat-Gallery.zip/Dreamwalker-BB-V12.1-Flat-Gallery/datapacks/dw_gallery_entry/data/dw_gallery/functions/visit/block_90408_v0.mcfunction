tp @s 238.5 63.88 337.5 0 14.0362
tellraw @s {"text": "Кладка из крупных гладких плит | ID 90408 | bloodborne_dw:source_calcite | вариант 0 | new", "color": "gold"}
