tp @s 38.5 64.38 147.5 0 14.0362
tellraw @s {"text": "Напольная декоративная пластина · вариант 11 | ID 90065 | bloodborne_dw:source_addon_button_10 | вариант 0 | new", "color": "gold"}
