tp @s 133.5 63.88 358.5 0 14.0362
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · наклон 180° | ID 90425 | bloodborne_dw:source_cobbled_deepslate_stairs_inner | вариант 2 | new", "color": "gold"}
