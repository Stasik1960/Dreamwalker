tp @s 147.5 63.88 1101.2 0 11.7683
tellraw @s {"text": "Книги | ID 90059 | bloodborne_dw:source_addon_books_test | вариант 0 | absent", "color": "gold"}
