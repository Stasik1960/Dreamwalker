tp @s 146.5 64.38 183.5 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 1 | ID 90144 | bloodborne_dw:source_addon_grass_0 | вариант 0 | new", "color": "gold"}
