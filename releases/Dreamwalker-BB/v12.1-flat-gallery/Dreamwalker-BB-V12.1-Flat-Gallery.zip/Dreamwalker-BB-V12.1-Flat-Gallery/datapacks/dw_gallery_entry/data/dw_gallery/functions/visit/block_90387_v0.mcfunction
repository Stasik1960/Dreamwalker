tp @s 256.5 63.88 330.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90387 | bloodborne_dw:source_bricks_wallbrick_0 | вариант 0 | new", "color": "gold"}
