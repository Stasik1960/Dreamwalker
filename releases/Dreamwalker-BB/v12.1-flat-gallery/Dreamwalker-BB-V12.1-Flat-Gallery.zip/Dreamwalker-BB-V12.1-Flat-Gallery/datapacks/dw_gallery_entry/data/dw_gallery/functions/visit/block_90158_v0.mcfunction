tp @s 102.5 64.88 193.0 0 14.0362
tellraw @s {"text": "Рыжая деревянная планка | ID 90158 | bloodborne_dw:source_addon_leaves | вариант 0 | new", "color": "gold"}
