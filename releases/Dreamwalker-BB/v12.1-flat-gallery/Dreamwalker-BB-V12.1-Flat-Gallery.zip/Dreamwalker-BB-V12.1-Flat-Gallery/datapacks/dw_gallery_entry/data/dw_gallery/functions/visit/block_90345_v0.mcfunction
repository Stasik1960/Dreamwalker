tp @s 274.5 63.88 313.5 0 14.0362
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90345 | bloodborne_dw:source_bricks_cracked_bricks_3 | вариант 0 | new", "color": "gold"}
