tp @s 133.5 63.88 165.5 0 14.0362
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 4 | ID 90102 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_3 | вариант 0 | new", "color": "gold"}
