tp @s 238.5 64.38 277.5 0 14.0362
tellraw @s {"text": "Составное декоративное украшение · вариант 2 | ID 90309 | bloodborne_dw:source_blue_orchid_1 | вариант 0 | new", "color": "gold"}
