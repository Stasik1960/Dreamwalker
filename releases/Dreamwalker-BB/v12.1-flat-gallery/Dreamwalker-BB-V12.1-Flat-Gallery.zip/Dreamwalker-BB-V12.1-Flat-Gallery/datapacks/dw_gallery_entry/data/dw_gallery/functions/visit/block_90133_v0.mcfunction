tp @s 221.5 64.38 174.5 0 14.0362
tellraw @s {"text": "Напольная панель · вариант 3 | ID 90133 | bloodborne_dw:source_addon_floor_panels_2 | вариант 0 | new", "color": "gold"}
