tp @s 182.5 63.88 1100.5 0 14.0362
tellraw @s {"text": "Кирпичная деталь · секция | ID 90061 | bloodborne_dw:source_addon_brick_side | вариант 0 | absent", "color": "gold"}
