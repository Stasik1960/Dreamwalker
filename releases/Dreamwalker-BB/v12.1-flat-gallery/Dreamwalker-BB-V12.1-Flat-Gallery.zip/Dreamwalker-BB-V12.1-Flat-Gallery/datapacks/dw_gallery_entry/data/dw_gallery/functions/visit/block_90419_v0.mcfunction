tp @s 256.5 63.88 347.5 0 14.0362
tellraw @s {"text": "Плотная тёмная кирпичная кладка | ID 90419 | bloodborne_dw:source_coarse_dirt | вариант 0 | new", "color": "gold"}
