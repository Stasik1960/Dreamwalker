tp @s 239.5 64.38 348.5 0 14.0362
tellraw @s {"text": "Каменная панель с геометрическим орнаментом | ID 90418 | bloodborne_dw:source_coal_ore | вариант 0 | new", "color": "gold"}
