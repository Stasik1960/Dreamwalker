tp @s 105.5 74.98 -15.1 0 9.4623
tellraw @s {"text": "Плоское составное дерево | ID 90005 | bloodborne_dw:prototype_tree | вариант 0 | v12", "color": "gold"}
