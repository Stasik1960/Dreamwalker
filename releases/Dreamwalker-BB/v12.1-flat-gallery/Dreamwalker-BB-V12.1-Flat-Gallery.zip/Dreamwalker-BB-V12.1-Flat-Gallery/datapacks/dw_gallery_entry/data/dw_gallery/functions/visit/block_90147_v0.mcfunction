tp @s 209.0 64.38 184.0 0 14.0362
tellraw @s {"text": "Пучок травы · вариант 4 | ID 90147 | bloodborne_dw:source_addon_grass_3 | вариант 0 | new", "color": "gold"}
