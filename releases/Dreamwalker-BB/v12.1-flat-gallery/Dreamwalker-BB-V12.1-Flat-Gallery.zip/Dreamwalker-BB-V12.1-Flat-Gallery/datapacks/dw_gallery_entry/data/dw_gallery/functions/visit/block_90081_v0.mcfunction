tp @s 39.0 64.38 155.7 0 11.7683
tellraw @s {"text": "Свечи · вариант 4 | ID 90081 | bloodborne_dw:source_addon_candles_3 | вариант 0 | new", "color": "gold"}
