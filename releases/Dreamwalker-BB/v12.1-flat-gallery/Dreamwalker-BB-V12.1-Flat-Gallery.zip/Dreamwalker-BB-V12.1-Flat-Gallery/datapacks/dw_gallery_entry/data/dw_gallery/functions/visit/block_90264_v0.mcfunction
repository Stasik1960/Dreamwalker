tp @s 117.5 64.88 1121.5 0 14.0362
tellraw @s {"text": "Деревянное украшение · вариант 4 | ID 90264 | bloodborne_dw:source_addon_wood_obj_3 | вариант 0 | absent", "color": "gold"}
