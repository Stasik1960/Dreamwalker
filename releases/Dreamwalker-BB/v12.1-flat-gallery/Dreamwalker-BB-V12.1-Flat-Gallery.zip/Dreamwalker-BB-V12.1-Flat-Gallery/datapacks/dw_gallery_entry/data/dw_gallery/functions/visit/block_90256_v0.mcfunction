tp @s 118.5 63.88 246.5 0 9.4623
tellraw @s {"text": "Пилястра · вариант 4 | ID 90256 | bloodborne_dw:source_addon_wall_pilaster_3 | вариант 0 | new", "color": "gold"}
