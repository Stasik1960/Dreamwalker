tp @s 44.0 64.38 1164.0 0 14.03624
tellraw @s {"text": "Статуя · вариант 5 | ID 90227 | bloodborne_dw:source_addon_statue_4 | вариант 0 | absent", "color": "gold"}
