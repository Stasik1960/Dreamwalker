tp @s 38.0 64.1925 403.0 0 14.03624
tellraw @s {"text": "Пучок травы · вариант 1 | ID 90351 | bloodborne_dw:source_bricks_grass_block_0 | вариант 0 | new", "color": "gold"}
