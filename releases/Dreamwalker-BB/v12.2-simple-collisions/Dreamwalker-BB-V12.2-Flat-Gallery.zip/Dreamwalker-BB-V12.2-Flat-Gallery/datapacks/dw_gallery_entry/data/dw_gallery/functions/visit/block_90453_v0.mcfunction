tp @s 44.5 64.01 1135.5 0 22.1589
tellraw @s {"text": "Декоративная напольная деталь | ID 90453 | bloodborne_dw:source_crimson_hyphae | вариант 0 | absent", "color": "gold"}
