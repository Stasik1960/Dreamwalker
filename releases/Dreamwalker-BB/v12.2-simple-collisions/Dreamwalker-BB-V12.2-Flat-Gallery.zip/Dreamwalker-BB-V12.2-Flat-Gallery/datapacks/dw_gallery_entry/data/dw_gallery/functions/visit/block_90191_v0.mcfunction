tp @s 79.5 64.01 462.5 0 22.1589
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90191 | bloodborne_dw:source_addon_slabs_0_top | вариант 0 | new", "color": "gold"}
