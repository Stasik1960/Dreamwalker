tp @s 31.5 64.505 373.0 0 14.03624
tellraw @s {"text": "Секция ворот | ID 90281 | bloodborne_dw:source_birch_fence_gate | вариант 0 | new", "color": "gold"}
