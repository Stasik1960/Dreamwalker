tp @s 36.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90330 | bloodborne_dw:source_bricks_bricks_1 | вариант 0 | new", "color": "gold"}
