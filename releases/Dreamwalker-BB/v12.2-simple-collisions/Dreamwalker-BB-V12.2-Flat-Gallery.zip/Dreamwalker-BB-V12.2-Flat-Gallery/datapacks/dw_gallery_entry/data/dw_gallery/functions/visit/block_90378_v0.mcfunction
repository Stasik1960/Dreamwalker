tp @s 6.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 7 | ID 90378 | bloodborne_dw:source_bricks_stone_6 | вариант 0 | new", "color": "gold"}
