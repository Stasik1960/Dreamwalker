tp @s 51.5 64.01 527.5 0 19.03443
tellraw @s {"text": "Архитектурная плита | ID 90421 | bloodborne_dw:source_cobbled_deepslate_slab | вариант 0 | new", "color": "gold"}
