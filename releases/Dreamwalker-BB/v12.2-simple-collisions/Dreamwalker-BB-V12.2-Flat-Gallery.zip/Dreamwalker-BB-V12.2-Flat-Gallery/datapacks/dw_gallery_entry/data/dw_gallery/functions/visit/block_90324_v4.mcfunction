tp @s 1.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · внешний угол · закреплённые UV 180° | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 4 | new", "color": "gold"}
