tp @s 30.5 64.88 951.0 0 14.03624
tellraw @s {"text": "Секция ворот | ID 90259 | bloodborne_dw:source_addon_warped_fence_gate | вариант 0 | new", "color": "gold"}
