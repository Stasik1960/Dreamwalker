tp @s 44.5 64.88 467.5 0 14.03624
tellraw @s {"text": "Наклонная ажурная секция ограды | ID 90392 | bloodborne_dw:source_brown_glazed_terracotta | вариант 0 | new", "color": "gold"}
