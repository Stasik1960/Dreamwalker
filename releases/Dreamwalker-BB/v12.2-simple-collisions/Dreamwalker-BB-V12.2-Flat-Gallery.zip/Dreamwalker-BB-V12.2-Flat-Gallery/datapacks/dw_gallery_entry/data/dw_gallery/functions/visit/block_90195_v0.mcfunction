tp @s 3.0 64.01 974.5 0 15.77499
tellraw @s {"text": "Архитектурная плита · вариант 12 | ID 90195 | bloodborne_dw:source_addon_slabs_11 | вариант 0 | new", "color": "gold"}
