tp @s 51.0 64.01 981.54523 0 14.23348
tellraw @s {"text": "Пилястра · вариант 6 | ID 90258 | bloodborne_dw:source_addon_wall_pilaster_5 | вариант 0 | new", "color": "gold"}
