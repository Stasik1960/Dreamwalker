tp @s 23.5 64.13 1135.5 0 14.03624
tellraw @s {"text": "Деревянный ящик | ID 90265 | bloodborne_dw:source_addon_wooden_box | вариант 0 | absent", "color": "gold"}
