tp @s 46.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Гладкий тёмно-серый камень | ID 90420 | bloodborne_dw:source_cobbled_deepslate | вариант 0 | new", "color": "gold"}
