tp @s 6.5 64.88 1148.5 0 14.03624
tellraw @s {"text": "Плита из рыжих досок | ID 90030 | bloodborne_dw:source_acacia_planks | вариант 0 | absent", "color": "gold"}
