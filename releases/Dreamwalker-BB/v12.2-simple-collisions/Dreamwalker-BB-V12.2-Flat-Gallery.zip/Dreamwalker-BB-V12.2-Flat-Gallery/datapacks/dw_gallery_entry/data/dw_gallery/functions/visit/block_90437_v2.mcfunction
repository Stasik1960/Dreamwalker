tp @s 56.5 64.01 537.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 270° | ID 90437 | bloodborne_dw:source_cobblestone_stairs | вариант 2 | new", "color": "gold"}
