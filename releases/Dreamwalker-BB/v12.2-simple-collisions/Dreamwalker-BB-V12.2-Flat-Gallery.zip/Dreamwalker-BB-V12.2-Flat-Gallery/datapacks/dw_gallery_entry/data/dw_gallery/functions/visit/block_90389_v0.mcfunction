tp @s 61.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90389 | bloodborne_dw:source_bricks_wallbrick_2 | вариант 0 | new", "color": "gold"}
