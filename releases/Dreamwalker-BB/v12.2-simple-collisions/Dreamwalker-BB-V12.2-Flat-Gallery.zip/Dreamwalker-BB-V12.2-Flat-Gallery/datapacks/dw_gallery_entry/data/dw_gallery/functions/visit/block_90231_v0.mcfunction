tp @s 31.5 64.16125 833.5 0 14.03624
tellraw @s {"text": "Замшелое поваленное бревно · вариант 2 | ID 90231 | bloodborne_dw:source_addon_stripped_oka_log_1 | вариант 0 | new", "color": "gold"}
