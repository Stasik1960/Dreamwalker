tp @s 23.5 64.01 868.5 0 17.6307
tellraw @s {"text": "Напольный орнамент с наклонными плоскостями | ID 90405 | bloodborne_dw:source_buttons_spruce_spruce_button_powered | вариант 0 | new", "color": "gold"}
