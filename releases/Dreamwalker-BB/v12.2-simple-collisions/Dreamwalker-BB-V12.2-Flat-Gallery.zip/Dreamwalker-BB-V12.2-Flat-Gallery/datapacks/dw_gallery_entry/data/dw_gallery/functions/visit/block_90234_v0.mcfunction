tp @s 46.5 64.01 833.5 0 19.03443
tellraw @s {"text": "Длинное поваленное бревно · вариант 5 | ID 90234 | bloodborne_dw:source_addon_stripped_oka_log_4 | вариант 0 | new", "color": "gold"}
