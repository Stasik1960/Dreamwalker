tp @s 2.0 64.16125 391.0 0 14.03624
tellraw @s {"text": "Настенный орнамент | ID 90024 | bloodborne_dw:source__wall_dec_out | вариант 0 | new", "color": "gold"}
