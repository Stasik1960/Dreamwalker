tp @s 41.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 7 | ID 90385 | bloodborne_dw:source_bricks_stonebrick_6 | вариант 0 | new", "color": "gold"}
