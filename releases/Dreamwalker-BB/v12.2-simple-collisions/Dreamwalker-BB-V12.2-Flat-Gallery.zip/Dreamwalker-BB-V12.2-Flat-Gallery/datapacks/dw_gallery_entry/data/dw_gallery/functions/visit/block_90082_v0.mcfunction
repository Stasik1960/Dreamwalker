tp @s 14.0 64.01 921.5 0 14.52389
tellraw @s {"text": "Свечи · вариант 5 | ID 90082 | bloodborne_dw:source_addon_candles_4 | вариант 0 | new", "color": "gold"}
