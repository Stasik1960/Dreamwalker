tp @s 61.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90373 | bloodborne_dw:source_bricks_stone_1 | вариант 0 | new", "color": "gold"}
