tp @s 19.0 64.01 982.0 0 22.08447
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90211 | bloodborne_dw:source_addon_slabs_4_top | вариант 0 | new", "color": "gold"}
