tp @s 26.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90337 | bloodborne_dw:source_bricks_bricks_r_4 | вариант 0 | new", "color": "gold"}
