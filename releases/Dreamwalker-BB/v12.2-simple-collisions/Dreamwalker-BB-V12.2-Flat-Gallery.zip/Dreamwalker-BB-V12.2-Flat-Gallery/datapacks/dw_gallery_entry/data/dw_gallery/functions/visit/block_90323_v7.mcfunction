tp @s 56.5 64.01 507.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · внутренний угол · наклон 180° | ID 90323 | bloodborne_dw:source_brick_stairs_inner | вариант 7 | new", "color": "gold"}
