tp @s 1.5 64.01 497.5 0 22.1589
tellraw @s {"text": "Архитектурная плита · вариант 4 | ID 90209 | bloodborne_dw:source_addon_slabs_3 | вариант 0 | new", "color": "gold"}
