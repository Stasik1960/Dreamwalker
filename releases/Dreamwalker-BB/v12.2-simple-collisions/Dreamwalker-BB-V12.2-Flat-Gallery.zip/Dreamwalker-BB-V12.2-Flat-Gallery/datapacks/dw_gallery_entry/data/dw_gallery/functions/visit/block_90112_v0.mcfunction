tp @s 46.5 64.01 1148.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90112 | bloodborne_dw:source_addon_cyan_terracotta_polished_blackstone_stairs4 | вариант 0 | absent", "color": "gold"}
