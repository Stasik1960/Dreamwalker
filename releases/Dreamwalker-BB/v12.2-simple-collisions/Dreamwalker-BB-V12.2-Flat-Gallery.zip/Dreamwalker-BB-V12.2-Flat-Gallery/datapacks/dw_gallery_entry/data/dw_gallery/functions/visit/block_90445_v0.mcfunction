tp @s 6.5 64.01 547.5 0 15.77499
tellraw @s {"text": "Тонкие вертикальные каменные стойки | ID 90445 | bloodborne_dw:source_copper_ore | вариант 0 | new", "color": "gold"}
