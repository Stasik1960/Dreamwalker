tp @s 23.5 64.88 462.5 0 14.03624
tellraw @s {"text": "Ажурное завершение ограды | ID 90036 | bloodborne_dw:source_acacia_wood | вариант 0 | new", "color": "gold"}
