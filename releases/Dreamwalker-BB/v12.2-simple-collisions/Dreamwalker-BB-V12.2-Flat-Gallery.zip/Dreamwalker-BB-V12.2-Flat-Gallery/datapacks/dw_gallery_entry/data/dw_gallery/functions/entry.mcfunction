execute as @a[tag=!dw_gallery_v122_entered] run gamemode creative @s
execute as @a[tag=!dw_gallery_v122_entered] run tp @s 0.5 64 -5.5 0 0
execute as @a[tag=!dw_gallery_v122_entered] run tellraw @s {"text":"Галерея BB V12.2: /function dw_gallery:help. Секции: v12, new, absent, items.","color":"gold"}
tag @a[tag=!dw_gallery_v122_entered] add dw_gallery_v122_entered
