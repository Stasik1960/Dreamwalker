tp @s 65.5 64.01 854.5 0 22.1589
tellraw @s {"text": "Напольный орнамент · вариант 10 | ID 90129 | bloodborne_dw:source_addon_floor_dec_9 | вариант 0 | new", "color": "gold"}
