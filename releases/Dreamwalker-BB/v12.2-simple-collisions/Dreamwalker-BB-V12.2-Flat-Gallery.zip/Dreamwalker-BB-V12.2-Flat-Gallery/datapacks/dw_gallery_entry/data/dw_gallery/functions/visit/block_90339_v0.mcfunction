tp @s 107.5 64.01 861.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90339 | bloodborne_dw:source_bricks_bricks_rl_0 | вариант 0 | new", "color": "gold"}
