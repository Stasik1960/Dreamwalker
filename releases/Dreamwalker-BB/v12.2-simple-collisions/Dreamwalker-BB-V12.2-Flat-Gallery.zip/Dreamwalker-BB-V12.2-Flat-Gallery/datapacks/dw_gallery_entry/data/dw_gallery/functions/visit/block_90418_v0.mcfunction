tp @s 80.0 64.38 403.0 0 14.03624
tellraw @s {"text": "Каменная панель с геометрическим орнаментом | ID 90418 | bloodborne_dw:source_coal_ore | вариант 0 | new", "color": "gold"}
