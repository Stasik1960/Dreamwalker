tp @s 3.0 65.07695 1184.9257 0 13.7901
tellraw @s {"text": "Надгробие · вариант 9 | ID 90244 | bloodborne_dw:source_addon_tombstone_gathered_8 | вариант 0 | absent", "color": "gold"}
