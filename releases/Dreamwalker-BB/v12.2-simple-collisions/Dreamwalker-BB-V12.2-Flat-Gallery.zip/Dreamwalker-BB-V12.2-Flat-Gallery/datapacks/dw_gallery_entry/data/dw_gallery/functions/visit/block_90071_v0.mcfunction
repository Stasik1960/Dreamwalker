tp @s 9.5 64.01 847.5 0 22.1589
tellraw @s {"text": "Рыжая деревянная планка · вариант 4 | ID 90071 | bloodborne_dw:source_addon_button_3 | вариант 0 | new", "color": "gold"}
