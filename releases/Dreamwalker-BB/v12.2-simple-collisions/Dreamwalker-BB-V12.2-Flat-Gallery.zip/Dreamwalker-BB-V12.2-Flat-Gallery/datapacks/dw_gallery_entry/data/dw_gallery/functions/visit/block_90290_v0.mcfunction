tp @s 23.5 64.01 467.5 0 15.77499
tellraw @s {"text": "Решётчатая секция с ромбовым узором | ID 90290 | bloodborne_dw:source_black_stained_glass | вариант 0 | new", "color": "gold"}
