tp @s 26.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 180° | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 6 | new", "color": "gold"}
