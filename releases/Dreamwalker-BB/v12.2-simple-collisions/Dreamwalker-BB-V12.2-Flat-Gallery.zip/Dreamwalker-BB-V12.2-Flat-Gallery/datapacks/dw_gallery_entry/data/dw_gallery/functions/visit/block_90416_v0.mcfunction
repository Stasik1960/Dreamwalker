tp @s 37.5 64.01 1135.5 0 15.77499
tellraw @s {"text": "Глина · текстура BB | ID 90416 | bloodborne_dw:source_clay | вариант 0 | absent", "color": "gold"}
