tp @s 74.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Ровная мелкая кирпичная кладка | ID 90413 | bloodborne_dw:source_chiseled_quartz_block | вариант 0 | new", "color": "gold"}
