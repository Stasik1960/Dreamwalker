tp @s 9.5 64.88 1135.5 0 14.03624
tellraw @s {"text": "Составное декоративное украшение | ID 90063 | bloodborne_dw:source_addon_brown_terracotta | вариант 0 | absent", "color": "gold"}
