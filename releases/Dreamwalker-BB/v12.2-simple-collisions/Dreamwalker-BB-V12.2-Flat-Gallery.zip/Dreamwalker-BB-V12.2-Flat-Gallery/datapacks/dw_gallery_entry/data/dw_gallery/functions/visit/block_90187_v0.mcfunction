tp @s 37.5 64.01 903.0 0 22.1589
tellraw @s {"text": "Осколки стекла · вариант 2 | ID 90187 | bloodborne_dw:source_addon_shattered_glass_1 | вариант 0 | new", "color": "gold"}
