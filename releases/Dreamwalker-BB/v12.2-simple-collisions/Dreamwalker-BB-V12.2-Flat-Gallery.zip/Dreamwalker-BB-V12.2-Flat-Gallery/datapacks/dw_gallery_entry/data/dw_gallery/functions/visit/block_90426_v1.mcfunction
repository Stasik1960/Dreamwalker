tp @s 41.5 64.01 532.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 270° | ID 90426 | bloodborne_dw:source_cobbled_deepslate_stairs_n | вариант 1 | new", "color": "gold"}
