tp @s 41.5 64.01 1148.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90111 | bloodborne_dw:source_addon_cyan_terracotta_polished_blackstone_stairs3 | вариант 0 | absent", "color": "gold"}
