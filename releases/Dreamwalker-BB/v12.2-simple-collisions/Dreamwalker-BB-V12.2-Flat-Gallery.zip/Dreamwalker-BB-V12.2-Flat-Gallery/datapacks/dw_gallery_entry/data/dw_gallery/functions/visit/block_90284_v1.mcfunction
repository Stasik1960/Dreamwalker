tp @s 56.5 64.01 833.5 0 14.94256
tellraw @s {"text": "Дверная секция · наклон 180° | ID 90284 | bloodborne_dw:source_birch_trapdoor | вариант 1 | new", "color": "gold"}
