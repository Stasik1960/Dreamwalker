tp @s 51.5 64.01 462.5 0 20.22569
tellraw @s {"text": "Напольная панель · вариант 11 | ID 90132 | bloodborne_dw:source_addon_floor_panels_10 | вариант 0 | new", "color": "gold"}
