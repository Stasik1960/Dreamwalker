tp @s 35.0 64.01 981.54523 0 14.23348
tellraw @s {"text": "Пилястра · вариант 4 | ID 90256 | bloodborne_dw:source_addon_wall_pilaster_3 | вариант 0 | new", "color": "gold"}
