tp @s 26.0 64.01 921.5 0 21.39897
tellraw @s {"text": "Секция ворот · вариант 1 · наклон 90° | ID 90142 | bloodborne_dw:source_addon_gate2_0 | вариант 1 | new", "color": "gold"}
