tp @s 38.0 64.0675 397.0 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь | ID 90277 | bloodborne_dw:source_basalt | вариант 0 | new", "color": "gold"}
