tp @s 68.0 64.38 403.0 0 14.03624
tellraw @s {"text": "Резная колонна с арочными панелями | ID 90412 | bloodborne_dw:source_chiseled_polished_blackstone | вариант 0 | new", "color": "gold"}
