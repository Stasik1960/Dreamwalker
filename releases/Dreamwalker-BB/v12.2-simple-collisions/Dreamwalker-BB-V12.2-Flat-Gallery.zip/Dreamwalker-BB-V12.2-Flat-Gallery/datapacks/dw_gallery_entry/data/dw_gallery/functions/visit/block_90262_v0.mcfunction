tp @s 50.0 64.01 921.5 0 14.62871
tellraw @s {"text": "Деревянное украшение · вариант 2 | ID 90262 | bloodborne_dw:source_addon_wood_obj_1 | вариант 0 | new", "color": "gold"}
