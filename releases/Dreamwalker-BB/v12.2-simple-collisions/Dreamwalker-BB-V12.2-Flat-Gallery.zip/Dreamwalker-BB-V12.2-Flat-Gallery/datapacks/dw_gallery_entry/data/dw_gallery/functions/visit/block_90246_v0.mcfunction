tp @s 2.5 64.16125 1191.0 0 14.03624
tellraw @s {"text": "Настенный орнамент · вариант 3 | ID 90246 | bloodborne_dw:source_addon_wall_deco_2 | вариант 0 | absent", "color": "gold"}
