tp @s 32.0 64.9459 921.5 0 14.0362
tellraw @s {"text": "Статуя · вариант 2 | ID 90166 | bloodborne_dw:source_addon_new_statue_1 | вариант 0 | new", "color": "gold"}
