tp @s 31.5 64.01 1153.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол | ID 90427 | bloodborne_dw:source_cobbled_deepslate_stairs_outer | вариант 0 | absent", "color": "gold"}
