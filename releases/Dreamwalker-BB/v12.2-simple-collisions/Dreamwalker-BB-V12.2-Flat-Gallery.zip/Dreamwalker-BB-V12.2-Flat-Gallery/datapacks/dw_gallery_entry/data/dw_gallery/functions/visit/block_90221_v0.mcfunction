tp @s 6.5 64.38978 497.5 0 14.03631
tellraw @s {"text": "Секция ворот · открытая, вариант 1 | ID 90221 | bloodborne_dw:source_addon_spruce_fence_gate_open_0 | вариант 0 | new", "color": "gold"}
