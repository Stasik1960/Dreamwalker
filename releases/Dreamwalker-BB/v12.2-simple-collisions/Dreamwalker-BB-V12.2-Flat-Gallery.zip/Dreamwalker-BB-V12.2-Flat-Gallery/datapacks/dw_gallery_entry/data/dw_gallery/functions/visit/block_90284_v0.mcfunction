tp @s 51.5 64.01 833.5 0 14.94256
tellraw @s {"text": "Дверная секция | ID 90284 | bloodborne_dw:source_birch_trapdoor | вариант 0 | new", "color": "gold"}
