tp @s 2.0 64.88 409.0 0 14.03624
tellraw @s {"text": "Кирпичная кладка | ID 90448 | bloodborne_dw:source_cracked_nether_bricks | вариант 0 | new", "color": "gold"}
