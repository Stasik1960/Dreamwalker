tp @s 20.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90336 | bloodborne_dw:source_bricks_bricks_r_3 | вариант 0 | new", "color": "gold"}
