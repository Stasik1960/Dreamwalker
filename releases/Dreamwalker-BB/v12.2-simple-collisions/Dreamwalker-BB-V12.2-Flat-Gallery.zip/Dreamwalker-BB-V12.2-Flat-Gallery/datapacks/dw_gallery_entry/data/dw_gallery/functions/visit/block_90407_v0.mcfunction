tp @s 50.0 64.01 403.0 0 15.741
tellraw @s {"text": "Низкое объёмное украшение · вариант 4 | ID 90407 | bloodborne_dw:source_buttons_spruce_spruce_button_powered_3 | вариант 0 | new", "color": "gold"}
