tp @s 37.5 64.88 868.5 0 14.03624
tellraw @s {"text": "Каменное ребро с выступающими зубцами | ID 90444 | bloodborne_dw:source_copper_block | вариант 0 | new", "color": "gold"}
