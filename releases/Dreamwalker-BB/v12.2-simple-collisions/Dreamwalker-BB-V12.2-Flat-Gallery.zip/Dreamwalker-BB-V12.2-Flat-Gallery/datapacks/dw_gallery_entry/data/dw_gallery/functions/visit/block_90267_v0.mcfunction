tp @s 12.5 64.01 935.475 0 11.65213
tellraw @s {"text": "Ступенчатая каменная капитель | ID 90267 | bloodborne_dw:source_amethyst_block | вариант 0 | new", "color": "gold"}
