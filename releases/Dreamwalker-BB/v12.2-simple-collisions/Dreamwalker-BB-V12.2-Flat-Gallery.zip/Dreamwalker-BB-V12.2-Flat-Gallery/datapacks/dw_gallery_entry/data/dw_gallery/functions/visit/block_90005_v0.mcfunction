tp @s 5.5 74.98 -0.1 0 9.46232
tellraw @s {"text": "Плоское составное дерево | ID 90005 | bloodborne_dw:prototype_tree | вариант 0 | v12", "color": "gold"}
