tp @s 65.5 64.53625 462.5 0 14.03624
tellraw @s {"text": "Рыжая деревянная планка | ID 90158 | bloodborne_dw:source_addon_leaves | вариант 0 | new", "color": "gold"}
