tp @s 36.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90362 | bloodborne_dw:source_bricks_purpur_block_2 | вариант 0 | new", "color": "gold"}
