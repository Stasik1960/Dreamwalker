tp @s 61.5 64.01 833.5 0 14.94256
tellraw @s {"text": "Дверная секция · нижняя | ID 90285 | bloodborne_dw:source_birch_trapdoor_bottom | вариант 0 | new", "color": "gold"}
