tp @s 79.5 64.32698 854.5 0 14.03627
tellraw @s {"text": "Резной каменный фриз с широкими поясами · вариант 1 | ID 90169 | bloodborne_dw:source_addon_note_0 | вариант 0 | new", "color": "gold"}
