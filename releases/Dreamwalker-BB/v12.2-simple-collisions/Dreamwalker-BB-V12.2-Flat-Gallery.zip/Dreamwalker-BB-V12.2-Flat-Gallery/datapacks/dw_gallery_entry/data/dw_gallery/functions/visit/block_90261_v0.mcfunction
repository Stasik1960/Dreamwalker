tp @s 67.0 64.88 981.43916 0 12.36685
tellraw @s {"text": "Кирпичная кладка с выступающими гранями | ID 90261 | bloodborne_dw:source_addon_waxed_weathered_cut_copper | вариант 0 | new", "color": "gold"}
