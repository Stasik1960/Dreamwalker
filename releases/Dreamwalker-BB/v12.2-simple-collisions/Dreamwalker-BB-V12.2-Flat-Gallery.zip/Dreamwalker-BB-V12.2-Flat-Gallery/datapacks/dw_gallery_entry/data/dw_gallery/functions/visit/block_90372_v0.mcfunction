tp @s 56.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90372 | bloodborne_dw:source_bricks_stone_0 | вариант 0 | new", "color": "gold"}
