tp @s 16.5 64.01 847.5 0 22.1589
tellraw @s {"text": "Рыжая деревянная планка · вариант 5 | ID 90072 | bloodborne_dw:source_addon_button_4 | вариант 0 | new", "color": "gold"}
