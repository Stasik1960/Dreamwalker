tp @s 38.0 64.03625 391.0 0 14.03624
tellraw @s {"text": "Бочка · вариант 6 | ID 90050 | bloodborne_dw:source_addon_barrel_5 | вариант 0 | new", "color": "gold"}
