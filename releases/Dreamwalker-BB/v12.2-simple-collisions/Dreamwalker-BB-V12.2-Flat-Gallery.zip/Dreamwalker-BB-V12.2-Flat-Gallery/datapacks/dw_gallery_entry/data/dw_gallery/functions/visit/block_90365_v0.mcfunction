tp @s 51.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 6 | ID 90365 | bloodborne_dw:source_bricks_purpur_block_5 | вариант 0 | new", "color": "gold"}
