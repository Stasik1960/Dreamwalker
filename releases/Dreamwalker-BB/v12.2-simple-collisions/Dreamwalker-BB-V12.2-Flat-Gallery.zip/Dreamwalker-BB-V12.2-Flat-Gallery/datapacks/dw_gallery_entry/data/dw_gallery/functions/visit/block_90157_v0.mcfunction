tp @s 1.5 64.38772 1153.5 0 14.0362
tellraw @s {"text": "Светильник | ID 90157 | bloodborne_dw:source_addon_lamp | вариант 0 | absent", "color": "gold"}
