tp @s 51.5 64.01 854.5 0 22.1589
tellraw @s {"text": "Напольный орнамент · вариант 8 | ID 90127 | bloodborne_dw:source_addon_floor_dec_7 | вариант 0 | new", "color": "gold"}
