tp @s 11.5 64.01 833.5 0 21.82456
tellraw @s {"text": "Архитектурная плита · вариант 11 | ID 90193 | bloodborne_dw:source_addon_slabs_10 | вариант 0 | new", "color": "gold"}
