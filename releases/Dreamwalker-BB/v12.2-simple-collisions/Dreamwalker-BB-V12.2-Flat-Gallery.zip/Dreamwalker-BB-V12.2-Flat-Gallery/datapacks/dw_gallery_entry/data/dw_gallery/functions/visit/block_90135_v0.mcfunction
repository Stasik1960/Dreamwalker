tp @s 46.5 64.01 487.5 0 22.1589
tellraw @s {"text": "Напольная панель · вариант 5 | ID 90135 | bloodborne_dw:source_addon_floor_panels_4 | вариант 0 | new", "color": "gold"}
