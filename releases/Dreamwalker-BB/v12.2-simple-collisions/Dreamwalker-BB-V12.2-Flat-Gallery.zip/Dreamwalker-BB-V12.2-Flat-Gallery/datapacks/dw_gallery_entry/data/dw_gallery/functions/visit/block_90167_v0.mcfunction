tp @s 38.0 65.27824 920.94424 0 12.38028
tellraw @s {"text": "Статуя · вариант 3 | ID 90167 | bloodborne_dw:source_addon_new_statue_2 | вариант 0 | new", "color": "gold"}
