tp @s 62.0 64.01 391.0 0 20.22569
tellraw @s {"text": "Цепь · вариант 4 | ID 90087 | bloodborne_dw:source_addon_chain_3 | вариант 0 | new", "color": "gold"}
