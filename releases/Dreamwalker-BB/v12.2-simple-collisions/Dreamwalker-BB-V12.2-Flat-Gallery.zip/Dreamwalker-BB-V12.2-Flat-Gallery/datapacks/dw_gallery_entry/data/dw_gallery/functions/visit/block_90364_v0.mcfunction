tp @s 46.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90364 | bloodborne_dw:source_bricks_purpur_block_4 | вариант 0 | new", "color": "gold"}
