tp @s 38.0 64.01 817.5 0 15.3596
tellraw @s {"text": "Кирпичный парапет с зубцами · вариант 1 | ID 90153 | bloodborne_dw:source_addon_green_glazed_0 | вариант 0 | new", "color": "gold"}
