tp @s 11.5 64.01 507.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · закреплённые UV 180° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 6 | new", "color": "gold"}
