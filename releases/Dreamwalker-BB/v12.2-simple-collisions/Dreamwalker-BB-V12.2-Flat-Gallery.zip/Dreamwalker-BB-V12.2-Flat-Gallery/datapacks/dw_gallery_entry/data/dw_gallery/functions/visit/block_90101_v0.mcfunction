tp @s 66.5 64.01 482.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 3 | ID 90101 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_2 | вариант 0 | new", "color": "gold"}
