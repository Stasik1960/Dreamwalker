tp @s 26.5 64.01 833.5 0 19.03443
tellraw @s {"text": "Длинное поваленное бревно · вариант 1 | ID 90230 | bloodborne_dw:source_addon_stripped_oka_log_0 | вариант 0 | new", "color": "gold"}
