tp @s 21.5 64.505 547.5 0 14.03624
tellraw @s {"text": "Тонкий декоративный шпиль | ID 90455 | bloodborne_dw:source_crimson_planks | вариант 0 | new", "color": "gold"}
