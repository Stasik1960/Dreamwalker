tp @s 76.5 64.01 482.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 5 | ID 90103 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_4 | вариант 0 | new", "color": "gold"}
