tp @s 86.5 64.01 847.5 0 22.1589
tellraw @s {"text": "Цепь · вариант 1 | ID 90088 | bloodborne_dw:source_addon_chains_0 | вариант 0 | new", "color": "gold"}
