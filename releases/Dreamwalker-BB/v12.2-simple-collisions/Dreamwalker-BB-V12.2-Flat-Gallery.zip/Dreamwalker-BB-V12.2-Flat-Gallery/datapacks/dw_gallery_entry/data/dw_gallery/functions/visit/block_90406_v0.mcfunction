tp @s 74.0 64.43256 921.5 0 14.03622
tellraw @s {"text": "Объёмное украшение с прямоугольным основанием · вариант 3 | ID 90406 | bloodborne_dw:source_buttons_spruce_spruce_button_powered_2 | вариант 0 | new", "color": "gold"}
