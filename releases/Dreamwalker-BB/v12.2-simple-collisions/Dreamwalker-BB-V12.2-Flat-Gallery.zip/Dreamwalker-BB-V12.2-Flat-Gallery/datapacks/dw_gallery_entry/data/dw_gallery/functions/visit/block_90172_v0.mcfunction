tp @s 41.5 64.01 492.5 0 15.77499
tellraw @s {"text": "Рыжая деревянная планка · секция | ID 90172 | bloodborne_dw:source_addon_oak_button_side | вариант 0 | new", "color": "gold"}
