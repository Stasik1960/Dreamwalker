tp @s 16.5 64.8175 462.5 0 14.03624
tellraw @s {"text": "Дверная секция · открытая, вариант 2 | ID 90035 | bloodborne_dw:source_acacia_trapdoor_open_1 | вариант 0 | new", "color": "gold"}
