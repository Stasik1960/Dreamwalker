tp @s 26.5 64.01 537.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90430 | bloodborne_dw:source_cobbled_deepslate_stairs_we | вариант 2 | new", "color": "gold"}
