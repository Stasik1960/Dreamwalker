tp @s 26.0 64.01 1164.0 0 15.77499
tellraw @s {"text": "Кровельный модуль · секция | ID 90186 | bloodborne_dw:source_addon_roof_spike_side | вариант 0 | absent", "color": "gold"}
