tp @s 23.5 64.01 847.5 0 22.1589
tellraw @s {"text": "Рыжая деревянная планка · вариант 6 | ID 90073 | bloodborne_dw:source_addon_button_5 | вариант 0 | new", "color": "gold"}
