tp @s 30.5 64.88 1135.5 0 14.03624
tellraw @s {"text": "Составное декоративное украшение | ID 90287 | bloodborne_dw:source_black_carpet | вариант 0 | absent", "color": "gold"}
