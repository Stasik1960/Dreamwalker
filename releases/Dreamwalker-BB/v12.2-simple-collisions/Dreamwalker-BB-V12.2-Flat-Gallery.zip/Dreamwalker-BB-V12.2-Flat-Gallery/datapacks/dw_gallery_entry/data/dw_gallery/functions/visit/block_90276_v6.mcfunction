tp @s 21.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 180° | ID 90276 | bloodborne_dw:source_bamboo_stairs | вариант 6 | new", "color": "gold"}
