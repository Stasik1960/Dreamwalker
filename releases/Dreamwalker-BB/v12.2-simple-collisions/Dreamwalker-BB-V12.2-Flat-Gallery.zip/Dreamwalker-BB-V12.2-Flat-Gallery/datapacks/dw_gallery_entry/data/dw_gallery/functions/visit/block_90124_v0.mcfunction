tp @s 30.5 64.01 854.5 0 22.1325
tellraw @s {"text": "Напольный орнамент · вариант 5 | ID 90124 | bloodborne_dw:source_addon_floor_dec_4 | вариант 0 | new", "color": "gold"}
