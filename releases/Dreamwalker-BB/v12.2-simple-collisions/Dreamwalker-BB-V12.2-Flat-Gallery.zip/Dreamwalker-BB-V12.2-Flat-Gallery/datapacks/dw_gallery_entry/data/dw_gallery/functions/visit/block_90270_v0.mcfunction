tp @s 26.5 64.01 497.5 0 19.03443
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90270 | bloodborne_dw:source_andesite_slab_top | вариант 0 | new", "color": "gold"}
