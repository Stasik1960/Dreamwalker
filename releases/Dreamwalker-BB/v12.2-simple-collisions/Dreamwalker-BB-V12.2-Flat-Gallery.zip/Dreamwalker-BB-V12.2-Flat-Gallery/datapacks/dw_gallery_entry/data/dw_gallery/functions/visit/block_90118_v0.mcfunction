tp @s 20.0 64.27062 921.5 0 14.03618
tellraw @s {"text": "Секция ворот · открытая | ID 90118 | bloodborne_dw:source_addon_dark_oak_fence_gate_open | вариант 0 | new", "color": "gold"}
