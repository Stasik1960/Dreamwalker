tp @s 86.5 64.21113 854.5 0 14.03623
tellraw @s {"text": "Каменный фриз с орнаментом · вариант 3 | ID 90171 | bloodborne_dw:source_addon_note_2 | вариант 0 | new", "color": "gold"}
