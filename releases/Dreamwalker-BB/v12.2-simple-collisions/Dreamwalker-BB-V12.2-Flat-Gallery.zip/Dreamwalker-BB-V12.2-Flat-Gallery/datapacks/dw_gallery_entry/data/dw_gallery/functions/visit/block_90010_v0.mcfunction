tp @s 16.5 64.755 -2.5 0 14.03624
tellraw @s {"text": "Тонкое остекление · window02 | ID 90010 | bloodborne_dw:prototype_glass_window_02 | вариант 0 | v12", "color": "gold"}
