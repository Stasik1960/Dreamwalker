tp @s 80.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Синий лёд · текстура BB | ID 90307 | bloodborne_dw:source_blue_ice | вариант 0 | new", "color": "gold"}
