tp @s 36.5 64.01 482.5 0 17.75482
tellraw @s {"text": "Пузырьки крови | ID 90055 | bloodborne_dw:source_addon_bloodviles | вариант 0 | new", "color": "gold"}
