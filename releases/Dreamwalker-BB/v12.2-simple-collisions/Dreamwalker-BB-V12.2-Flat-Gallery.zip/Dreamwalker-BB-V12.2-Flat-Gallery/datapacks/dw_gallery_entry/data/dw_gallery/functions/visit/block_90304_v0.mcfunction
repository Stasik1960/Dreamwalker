tp @s 30.5 64.88 467.5 0 14.03624
tellraw @s {"text": "Обрамление круглого окна | ID 90304 | bloodborne_dw:source_blue_concrete | вариант 0 | new", "color": "gold"}
