tp @s 56.0 64.01 817.5 0 15.77499
tellraw @s {"text": "Пилястра · вариант 2 | ID 90179 | bloodborne_dw:source_addon_pilaster_1 | вариант 0 | new", "color": "gold"}
