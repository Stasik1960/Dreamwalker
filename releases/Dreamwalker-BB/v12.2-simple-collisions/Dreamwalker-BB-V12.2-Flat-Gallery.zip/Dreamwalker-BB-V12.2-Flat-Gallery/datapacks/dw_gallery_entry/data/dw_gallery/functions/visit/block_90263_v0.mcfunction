tp @s 56.0 64.755 921.5 0 14.03624
tellraw @s {"text": "Деревянное украшение · вариант 3 | ID 90263 | bloodborne_dw:source_addon_wood_obj_2 | вариант 0 | new", "color": "gold"}
