tp @s 21.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90381 | bloodborne_dw:source_bricks_stonebrick_2 | вариант 0 | new", "color": "gold"}
