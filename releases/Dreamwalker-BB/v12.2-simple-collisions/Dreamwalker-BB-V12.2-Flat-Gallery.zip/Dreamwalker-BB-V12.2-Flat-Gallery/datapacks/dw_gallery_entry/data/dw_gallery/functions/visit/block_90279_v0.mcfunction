tp @s 36.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Перекладина на каменных опорах | ID 90279 | bloodborne_dw:source_bell_floor | вариант 0 | new", "color": "gold"}
