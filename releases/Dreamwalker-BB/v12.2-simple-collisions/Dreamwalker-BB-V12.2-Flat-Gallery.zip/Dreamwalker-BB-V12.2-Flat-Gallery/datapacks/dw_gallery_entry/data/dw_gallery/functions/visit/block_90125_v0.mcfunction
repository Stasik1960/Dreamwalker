tp @s 37.5 64.01 854.5 0 22.1589
tellraw @s {"text": "Напольный орнамент · вариант 6 | ID 90125 | bloodborne_dw:source_addon_floor_dec_5 | вариант 0 | new", "color": "gold"}
