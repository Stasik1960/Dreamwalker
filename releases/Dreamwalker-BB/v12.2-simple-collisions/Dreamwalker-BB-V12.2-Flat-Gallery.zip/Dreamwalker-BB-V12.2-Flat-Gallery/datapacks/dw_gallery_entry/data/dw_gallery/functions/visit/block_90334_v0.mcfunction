tp @s 8.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90334 | bloodborne_dw:source_bricks_bricks_r_1 | вариант 0 | new", "color": "gold"}
