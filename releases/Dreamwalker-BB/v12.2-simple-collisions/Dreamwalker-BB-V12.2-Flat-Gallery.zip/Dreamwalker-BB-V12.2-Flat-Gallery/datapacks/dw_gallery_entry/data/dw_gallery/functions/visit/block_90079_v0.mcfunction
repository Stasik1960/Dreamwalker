tp @s 65.5 64.16125 847.5 0 14.03624
tellraw @s {"text": "Свечи · вариант 2 | ID 90079 | bloodborne_dw:source_addon_candles_1 | вариант 0 | new", "color": "gold"}
