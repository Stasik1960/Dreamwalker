tp @s 16.5 64.01 497.5 0 15.77499
tellraw @s {"text": "Настенный орнамент · вариант 9 | ID 90252 | bloodborne_dw:source_addon_wall_deco_8 | вариант 0 | new", "color": "gold"}
