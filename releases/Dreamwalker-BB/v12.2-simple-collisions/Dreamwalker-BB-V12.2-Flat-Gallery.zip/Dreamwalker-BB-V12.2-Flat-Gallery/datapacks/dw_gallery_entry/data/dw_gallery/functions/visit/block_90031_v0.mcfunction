tp @s 9.5 64.88 462.5 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь | ID 90031 | bloodborne_dw:source_acacia_pressure_plate | вариант 0 | new", "color": "gold"}
