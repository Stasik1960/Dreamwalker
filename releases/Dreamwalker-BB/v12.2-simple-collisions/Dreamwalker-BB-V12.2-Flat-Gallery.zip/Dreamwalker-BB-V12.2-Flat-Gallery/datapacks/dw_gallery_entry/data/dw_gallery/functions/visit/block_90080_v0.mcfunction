tp @s 72.5 64.03625 847.5 0 14.03624
tellraw @s {"text": "Свечи · вариант 3 | ID 90080 | bloodborne_dw:source_addon_candles_2 | вариант 0 | new", "color": "gold"}
