tp @s 31.5 64.88 492.5 0 14.03624
tellraw @s {"text": "Вертикальное деревянное украшение · вариант 1 | ID 90160 | bloodborne_dw:source_addon_log_vertical_0 | вариант 0 | new", "color": "gold"}
