tp @s 6.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90276 | bloodborne_dw:source_bamboo_stairs | вариант 3 | new", "color": "gold"}
