tp @s 68.0 64.01 391.0 0 17.41925
tellraw @s {"text": "Пучок травы · вариант 8 | ID 90151 | bloodborne_dw:source_addon_grass_7 | вариант 0 | new", "color": "gold"}
