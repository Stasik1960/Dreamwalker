tp @s 71.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кладка из крупных гладких плит | ID 90408 | bloodborne_dw:source_calcite | вариант 0 | new", "color": "gold"}
