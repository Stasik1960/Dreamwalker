tp @s 8.0 64.01 921.5 0 22.1589
tellraw @s {"text": "Напольная декоративная пластина · вариант 11 | ID 90065 | bloodborne_dw:source_addon_button_10 | вариант 0 | new", "color": "gold"}
