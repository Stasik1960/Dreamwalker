tp @s 46.5 64.01 532.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90426 | bloodborne_dw:source_cobbled_deepslate_stairs_n | вариант 2 | new", "color": "gold"}
