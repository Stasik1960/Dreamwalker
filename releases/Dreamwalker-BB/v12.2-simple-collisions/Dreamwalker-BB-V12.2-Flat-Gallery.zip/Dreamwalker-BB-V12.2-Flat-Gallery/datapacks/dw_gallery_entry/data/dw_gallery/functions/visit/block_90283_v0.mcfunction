tp @s 16.5 64.38273 467.5 0 14.03621
tellraw @s {"text": "Объёмная декоративная деталь | ID 90283 | bloodborne_dw:source_birch_pressure_plate | вариант 0 | new", "color": "gold"}
