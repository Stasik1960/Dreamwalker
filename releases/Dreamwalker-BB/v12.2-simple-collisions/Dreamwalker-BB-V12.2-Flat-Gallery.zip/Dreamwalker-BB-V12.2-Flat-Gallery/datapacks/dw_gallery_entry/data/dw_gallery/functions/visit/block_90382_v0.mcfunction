tp @s 26.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90382 | bloodborne_dw:source_bricks_stonebrick_3 | вариант 0 | new", "color": "gold"}
