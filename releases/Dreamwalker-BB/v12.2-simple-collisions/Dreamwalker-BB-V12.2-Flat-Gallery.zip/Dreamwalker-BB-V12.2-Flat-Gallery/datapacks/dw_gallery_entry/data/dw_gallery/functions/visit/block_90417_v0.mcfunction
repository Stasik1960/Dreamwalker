tp @s 30.5 64.88 868.5 0 14.03624
tellraw @s {"text": "Узкое ребро с каменными зубцами | ID 90417 | bloodborne_dw:source_coal_block | вариант 0 | new", "color": "gold"}
