tp @s 16.5 64.01 537.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90430 | bloodborne_dw:source_cobbled_deepslate_stairs_we | вариант 0 | new", "color": "gold"}
