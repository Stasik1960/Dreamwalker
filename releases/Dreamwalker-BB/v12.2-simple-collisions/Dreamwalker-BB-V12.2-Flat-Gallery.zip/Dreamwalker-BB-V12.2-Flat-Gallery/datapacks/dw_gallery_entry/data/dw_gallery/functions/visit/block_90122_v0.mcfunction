tp @s 16.5 64.01 854.5 0 22.1325
tellraw @s {"text": "Напольный орнамент · вариант 3 | ID 90122 | bloodborne_dw:source_addon_floor_dec_2 | вариант 0 | new", "color": "gold"}
