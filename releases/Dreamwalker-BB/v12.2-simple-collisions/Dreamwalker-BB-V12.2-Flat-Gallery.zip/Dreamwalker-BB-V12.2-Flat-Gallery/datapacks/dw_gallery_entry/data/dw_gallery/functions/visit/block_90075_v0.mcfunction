tp @s 37.5 64.01 847.5 0 22.07486
tellraw @s {"text": "Рыжая деревянная планка · вариант 8 | ID 90075 | bloodborne_dw:source_addon_button_7 | вариант 0 | new", "color": "gold"}
