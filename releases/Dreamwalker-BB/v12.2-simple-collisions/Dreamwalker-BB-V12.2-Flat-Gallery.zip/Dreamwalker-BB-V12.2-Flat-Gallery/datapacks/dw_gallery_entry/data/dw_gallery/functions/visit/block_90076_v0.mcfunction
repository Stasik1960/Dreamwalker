tp @s 44.5 64.01 847.5 0 22.07486
tellraw @s {"text": "Рыжая деревянная планка · вариант 9 | ID 90076 | bloodborne_dw:source_addon_button_8 | вариант 0 | new", "color": "gold"}
