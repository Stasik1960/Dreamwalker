tp @s 6.5 64.01 482.5 0 15.77499
tellraw @s {"text": "Дверная секция · нижняя | ID 90033 | bloodborne_dw:source_acacia_trapdoor_bottom | вариант 0 | new", "color": "gold"}
