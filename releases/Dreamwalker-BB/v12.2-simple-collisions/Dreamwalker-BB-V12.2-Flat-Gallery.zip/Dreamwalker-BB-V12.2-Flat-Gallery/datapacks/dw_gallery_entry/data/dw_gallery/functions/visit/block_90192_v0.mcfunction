tp @s 61.5 64.01 492.5 0 22.1589
tellraw @s {"text": "Архитектурная плита · вариант 2 | ID 90192 | bloodborne_dw:source_addon_slabs_1 | вариант 0 | new", "color": "gold"}
