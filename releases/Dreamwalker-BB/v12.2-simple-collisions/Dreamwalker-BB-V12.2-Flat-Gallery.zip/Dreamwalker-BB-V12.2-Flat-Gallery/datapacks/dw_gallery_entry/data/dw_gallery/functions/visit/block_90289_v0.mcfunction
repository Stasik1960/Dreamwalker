tp @s 50.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Узкая резная стеновая панель | ID 90289 | bloodborne_dw:source_black_glazed_terracotta | вариант 0 | new", "color": "gold"}
