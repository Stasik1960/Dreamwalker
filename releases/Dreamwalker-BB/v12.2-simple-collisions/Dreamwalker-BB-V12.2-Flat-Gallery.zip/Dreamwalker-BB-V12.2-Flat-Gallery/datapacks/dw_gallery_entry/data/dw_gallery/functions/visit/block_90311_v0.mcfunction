tp @s 41.5 64.01 373.0 0 15.45809
tellraw @s {"text": "Составное декоративное украшение · вариант 4 | ID 90311 | bloodborne_dw:source_blue_orchid_3 | вариант 0 | new", "color": "gold"}
