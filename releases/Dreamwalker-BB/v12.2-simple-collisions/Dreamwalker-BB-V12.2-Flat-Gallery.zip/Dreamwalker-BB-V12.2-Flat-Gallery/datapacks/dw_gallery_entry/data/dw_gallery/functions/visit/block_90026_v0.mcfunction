tp @s 11.5 64.16125 373.0 0 14.03624
tellraw @s {"text": "Настенный орнамент · верхняя, вариант 2 | ID 90026 | bloodborne_dw:source__wall_dec_top_1 | вариант 0 | new", "color": "gold"}
