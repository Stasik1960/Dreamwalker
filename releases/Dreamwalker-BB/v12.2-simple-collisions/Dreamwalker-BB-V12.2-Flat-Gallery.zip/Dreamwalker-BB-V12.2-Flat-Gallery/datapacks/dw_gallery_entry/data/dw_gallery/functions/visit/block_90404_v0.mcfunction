tp @s 92.0 64.01 817.5 0 15.3596
tellraw @s {"text": "Рыжая деревянная планка | ID 90404 | bloodborne_dw:source_buttons_dark_oak_dark_oak_button_on | вариант 0 | new", "color": "gold"}
