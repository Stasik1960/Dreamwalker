tp @s 3.5 64.01 935.40883 0 16.54902
tellraw @s {"text": "Книги · вариант 1 | ID 90057 | bloodborne_dw:source_addon_books_0 | вариант 0 | new", "color": "gold"}
