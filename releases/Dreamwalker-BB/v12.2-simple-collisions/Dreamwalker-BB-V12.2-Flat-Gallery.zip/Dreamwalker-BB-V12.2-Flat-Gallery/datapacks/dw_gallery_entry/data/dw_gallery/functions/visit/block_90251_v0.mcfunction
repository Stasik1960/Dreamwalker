tp @s 11.5 64.88 497.5 0 14.03624
tellraw @s {"text": "Настенный орнамент · вариант 8 | ID 90251 | bloodborne_dw:source_addon_wall_deco_7 | вариант 0 | new", "color": "gold"}
