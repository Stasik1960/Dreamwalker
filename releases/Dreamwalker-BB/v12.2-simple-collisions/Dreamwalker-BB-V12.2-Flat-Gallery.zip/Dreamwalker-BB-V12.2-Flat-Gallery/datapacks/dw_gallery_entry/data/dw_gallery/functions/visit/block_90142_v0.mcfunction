tp @s 20.0 64.88 817.5 0 14.03624
tellraw @s {"text": "Секция ворот · вариант 1 | ID 90142 | bloodborne_dw:source_addon_gate2_0 | вариант 0 | new", "color": "gold"}
