tp @s 62.0 64.38 403.0 0 14.03624
tellraw @s {"text": "Кирпичная кладка | ID 90411 | bloodborne_dw:source_chiseled_nether_bricks | вариант 0 | new", "color": "gold"}
