tp @s 79.5 64.01 861.5 0 15.77499
tellraw @s {"text": "Пилястра · вариант 3 | ID 90255 | bloodborne_dw:source_addon_wall_pilaster_2 | вариант 0 | new", "color": "gold"}
