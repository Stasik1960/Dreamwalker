tp @s 1.5 64.01 487.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 6 | ID 90104 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_5 | вариант 0 | new", "color": "gold"}
