tp @s 44.0 64.01 921.5 0 22.1589
tellraw @s {"text": "Осколки стекла · вариант 4 | ID 90189 | bloodborne_dw:source_addon_shattered_glass_3 | вариант 0 | new", "color": "gold"}
