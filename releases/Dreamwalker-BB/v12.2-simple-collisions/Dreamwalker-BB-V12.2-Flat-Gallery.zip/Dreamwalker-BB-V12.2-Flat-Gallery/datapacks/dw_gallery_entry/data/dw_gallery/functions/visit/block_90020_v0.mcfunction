tp @s 23.5 64.755 -2.5 0 14.03624
tellraw @s {"text": "Тонкое остекление · window03 | ID 90020 | bloodborne_dw:prototype_glass_window_03 | вариант 0 | v12", "color": "gold"}
