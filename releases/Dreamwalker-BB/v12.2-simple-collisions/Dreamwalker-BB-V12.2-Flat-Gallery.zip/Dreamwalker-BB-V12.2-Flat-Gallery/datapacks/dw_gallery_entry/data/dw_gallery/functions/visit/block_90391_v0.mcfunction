tp @s 44.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Декоративная каменная поверхность · коричневый | ID 90391 | bloodborne_dw:source_brown_concrete_powder | вариант 0 | new", "color": "gold"}
