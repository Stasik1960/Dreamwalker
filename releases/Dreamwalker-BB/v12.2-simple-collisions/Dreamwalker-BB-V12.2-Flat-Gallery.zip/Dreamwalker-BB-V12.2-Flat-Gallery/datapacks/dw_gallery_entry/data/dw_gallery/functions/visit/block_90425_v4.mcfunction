tp @s 16.5 64.01 532.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · закреплённые UV 180° | ID 90425 | bloodborne_dw:source_cobbled_deepslate_stairs_inner | вариант 4 | new", "color": "gold"}
