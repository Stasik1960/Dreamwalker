tp @s 14.0 64.01 1164.0 0 14.94256
tellraw @s {"text": "Объёмная декоративная деталь · вариант 1 | ID 90159 | bloodborne_dw:source_addon_light_gray_glazed_terracotta_0 | вариант 0 | absent", "color": "gold"}
