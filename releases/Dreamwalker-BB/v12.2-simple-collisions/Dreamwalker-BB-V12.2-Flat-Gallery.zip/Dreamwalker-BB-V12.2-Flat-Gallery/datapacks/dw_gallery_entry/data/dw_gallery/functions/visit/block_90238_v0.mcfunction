tp @s 27.0 64.8211 982.0 0 14.03623
tellraw @s {"text": "Надгробие · вариант 3 | ID 90238 | bloodborne_dw:source_addon_tombstone_gathered_2 | вариант 0 | new", "color": "gold"}
