tp @s 36.5 64.88 492.5 0 14.03624
tellraw @s {"text": "Вертикальное деревянное украшение · вариант 2 | ID 90161 | bloodborne_dw:source_addon_log_vertical_1 | вариант 0 | new", "color": "gold"}
