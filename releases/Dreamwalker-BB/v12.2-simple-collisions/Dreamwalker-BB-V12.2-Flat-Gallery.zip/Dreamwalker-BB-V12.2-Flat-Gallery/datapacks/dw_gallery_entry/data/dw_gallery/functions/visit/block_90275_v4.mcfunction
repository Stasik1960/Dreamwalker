tp @s 51.5 64.01 497.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 90° | ID 90275 | bloodborne_dw:source_bamboo_mosaic_stairs | вариант 4 | new", "color": "gold"}
