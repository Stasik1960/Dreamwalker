tp @s 100.5 64.01 854.5 0 21.00991
tellraw @s {"text": "Архитектурная плита · вариант 10 | ID 90206 | bloodborne_dw:source_addon_slabs_1_9 | вариант 0 | new", "color": "gold"}
