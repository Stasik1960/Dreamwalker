tp @s 16.5 64.01 482.5 0 16.18867
tellraw @s {"text": "Мешок · вариант 2 | ID 90039 | bloodborne_dw:source_addon_bag_1 | вариант 0 | new", "color": "gold"}
