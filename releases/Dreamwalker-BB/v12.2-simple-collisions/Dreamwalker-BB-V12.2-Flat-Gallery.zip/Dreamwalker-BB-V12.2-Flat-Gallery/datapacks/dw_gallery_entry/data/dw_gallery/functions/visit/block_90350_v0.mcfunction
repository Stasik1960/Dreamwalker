tp @s 6.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 9 | ID 90350 | bloodborne_dw:source_bricks_cracked_bricks_8 | вариант 0 | new", "color": "gold"}
