tp @s 100.5 64.38 462.5 0 14.03624
tellraw @s {"text": "Настенный орнамент · вариант 4 | ID 90247 | bloodborne_dw:source_addon_wall_deco_3 | вариант 0 | new", "color": "gold"}
