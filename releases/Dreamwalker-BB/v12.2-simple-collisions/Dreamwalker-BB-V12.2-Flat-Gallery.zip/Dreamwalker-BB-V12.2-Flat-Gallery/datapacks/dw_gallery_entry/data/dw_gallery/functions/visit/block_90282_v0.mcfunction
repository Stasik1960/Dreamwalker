tp @s 93.5 64.01 861.5 0 15.77499
tellraw @s {"text": "Резной блок с вертикальными панелями | ID 90282 | bloodborne_dw:source_birch_planks | вариант 0 | new", "color": "gold"}
