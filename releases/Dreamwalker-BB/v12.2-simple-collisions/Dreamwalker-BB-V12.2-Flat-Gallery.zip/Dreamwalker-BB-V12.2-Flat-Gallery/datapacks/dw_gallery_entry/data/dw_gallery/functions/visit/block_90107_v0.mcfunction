tp @s 16.5 64.01 487.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 9 | ID 90107 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_8 | вариант 0 | new", "color": "gold"}
