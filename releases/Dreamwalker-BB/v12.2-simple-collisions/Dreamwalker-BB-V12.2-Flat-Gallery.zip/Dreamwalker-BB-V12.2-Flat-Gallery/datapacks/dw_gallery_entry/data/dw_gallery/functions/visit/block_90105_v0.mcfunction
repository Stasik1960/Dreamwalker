tp @s 6.5 64.01 487.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 7 | ID 90105 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_6 | вариант 0 | new", "color": "gold"}
