tp @s 72.5 64.01 462.5 0 22.1589
tellraw @s {"text": "Архитектурная плита · вариант 1 | ID 90190 | bloodborne_dw:source_addon_slabs_0 | вариант 0 | new", "color": "gold"}
