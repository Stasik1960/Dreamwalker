tp @s 43.0 64.01 981.54523 0 14.23348
tellraw @s {"text": "Пилястра · вариант 5 | ID 90257 | bloodborne_dw:source_addon_wall_pilaster_4 | вариант 0 | new", "color": "gold"}
