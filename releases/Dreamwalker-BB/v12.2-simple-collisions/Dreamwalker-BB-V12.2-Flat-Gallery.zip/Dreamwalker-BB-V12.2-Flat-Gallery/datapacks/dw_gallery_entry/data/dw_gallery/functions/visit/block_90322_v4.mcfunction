tp @s 1.5 64.01 507.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · закреплённые UV 90° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 4 | new", "color": "gold"}
