tp @s 2.5 64.01 1171.0 0 20.71677
tellraw @s {"text": "Книги | ID 90059 | bloodborne_dw:source_addon_books_test | вариант 0 | absent", "color": "gold"}
