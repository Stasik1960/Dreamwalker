tp @s 21.5 64.01 833.5 0 22.1589
tellraw @s {"text": "Архитектурная плита · вариант 3 | ID 90208 | bloodborne_dw:source_addon_slabs_2 | вариант 0 | new", "color": "gold"}
