tp @s 21.5 64.01 482.5 0 16.18867
tellraw @s {"text": "Мешок · вариант 3 | ID 90040 | bloodborne_dw:source_addon_bag_2 | вариант 0 | new", "color": "gold"}
