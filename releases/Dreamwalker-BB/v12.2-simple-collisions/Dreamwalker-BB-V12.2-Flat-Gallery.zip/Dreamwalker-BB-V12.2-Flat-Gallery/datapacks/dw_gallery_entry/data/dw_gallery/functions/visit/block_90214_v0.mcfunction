tp @s 9.5 64.01 861.5 0 21.78597
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90214 | bloodborne_dw:source_addon_slabs_6_top | вариант 0 | new", "color": "gold"}
