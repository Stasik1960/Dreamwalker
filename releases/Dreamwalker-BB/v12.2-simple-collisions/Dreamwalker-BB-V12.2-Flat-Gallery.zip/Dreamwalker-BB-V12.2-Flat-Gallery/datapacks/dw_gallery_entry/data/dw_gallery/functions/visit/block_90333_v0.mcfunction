tp @s 2.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90333 | bloodborne_dw:source_bricks_bricks_r_0 | вариант 0 | new", "color": "gold"}
