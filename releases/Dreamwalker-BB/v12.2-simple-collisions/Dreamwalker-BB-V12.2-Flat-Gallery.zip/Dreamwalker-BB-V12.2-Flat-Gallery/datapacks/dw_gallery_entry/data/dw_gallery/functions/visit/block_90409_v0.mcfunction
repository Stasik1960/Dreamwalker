tp @s 76.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 0 | new", "color": "gold"}
