tp @s 80.0 64.80084 391.0 0 14.03622
tellraw @s {"text": "Статуя · вариант 4 | ID 90168 | bloodborne_dw:source_addon_new_statue_3 | вариант 0 | new", "color": "gold"}
