tp @s 37.5 64.0675 462.5 0 14.03624
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 2 | ID 90064 | bloodborne_dw:source_addon_button_1 | вариант 0 | new", "color": "gold"}
