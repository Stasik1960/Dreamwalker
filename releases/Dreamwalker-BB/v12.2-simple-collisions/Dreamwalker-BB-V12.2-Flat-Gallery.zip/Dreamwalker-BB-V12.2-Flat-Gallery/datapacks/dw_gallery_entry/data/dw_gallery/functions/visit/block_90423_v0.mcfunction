tp @s 26.5 64.01 1153.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90423 | bloodborne_dw:source_cobbled_deepslate_stairs | вариант 0 | absent", "color": "gold"}
