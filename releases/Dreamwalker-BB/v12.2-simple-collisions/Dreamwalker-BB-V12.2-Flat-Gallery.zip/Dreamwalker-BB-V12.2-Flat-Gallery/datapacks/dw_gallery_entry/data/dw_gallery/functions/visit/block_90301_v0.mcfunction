tp @s 68.0 64.73133 817.5 0 14.03621
tellraw @s {"text": "Ступенчатый модуль · верхняя | ID 90301 | bloodborne_dw:source_blackstone_stairs_top | вариант 0 | new", "color": "gold"}
