tp @s 21.5 64.01 1148.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · секция | ID 90061 | bloodborne_dw:source_addon_brick_side | вариант 0 | absent", "color": "gold"}
