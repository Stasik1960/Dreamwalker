tp @s 19.0 64.88 974.5 0 14.03624
tellraw @s {"text": "Надгробие · вариант 5 | ID 90240 | bloodborne_dw:source_addon_tombstone_gathered_4 | вариант 0 | new", "color": "gold"}
