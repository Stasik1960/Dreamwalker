tp @s 86.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Готическая ниша с фигурным завершением | ID 90317 | bloodborne_dw:source_blue_terracotta | вариант 0 | new", "color": "gold"}
