tp @s 86.5 64.88 861.5 0 14.03624
tellraw @s {"text": "Зубчатое каменное ребро | ID 90268 | bloodborne_dw:source_ancient_debris | вариант 0 | new", "color": "gold"}
