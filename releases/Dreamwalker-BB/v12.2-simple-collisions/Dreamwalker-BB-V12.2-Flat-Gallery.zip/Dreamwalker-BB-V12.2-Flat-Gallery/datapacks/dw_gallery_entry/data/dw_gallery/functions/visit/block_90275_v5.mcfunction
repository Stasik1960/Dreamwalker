tp @s 56.5 64.01 497.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90275 | bloodborne_dw:source_bamboo_mosaic_stairs | вариант 5 | new", "color": "gold"}
