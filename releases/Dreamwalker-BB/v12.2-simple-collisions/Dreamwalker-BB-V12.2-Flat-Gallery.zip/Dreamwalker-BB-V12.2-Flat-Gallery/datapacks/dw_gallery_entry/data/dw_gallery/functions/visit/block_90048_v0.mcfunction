tp @s 26.0 64.03625 391.0 0 14.03624
tellraw @s {"text": "Бочка · вариант 4 | ID 90048 | bloodborne_dw:source_addon_barrel_3 | вариант 0 | new", "color": "gold"}
