tp @s 62.0 64.08711 921.5 0 14.03629
tellraw @s {"text": "Остроконечный готический фронтон · наклон 90° | ID 90286 | bloodborne_dw:source_birch_wood | вариант 1 | new", "color": "gold"}
