tp @s 51.5 64.88 861.5 0 14.03624
tellraw @s {"text": "Надгробие · вариант 8 | ID 90243 | bloodborne_dw:source_addon_tombstone_gathered_7 | вариант 0 | new", "color": "gold"}
