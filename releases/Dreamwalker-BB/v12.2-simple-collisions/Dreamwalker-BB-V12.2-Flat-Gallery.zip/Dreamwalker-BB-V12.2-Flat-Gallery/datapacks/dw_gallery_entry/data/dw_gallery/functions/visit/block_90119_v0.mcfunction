tp @s 76.5 64.01 1148.5 0 17.41925
tellraw @s {"text": "Ящик с бутылками · вариант 1 | ID 90119 | bloodborne_dw:source_addon_dead_tube_coral_0 | вариант 0 | absent", "color": "gold"}
