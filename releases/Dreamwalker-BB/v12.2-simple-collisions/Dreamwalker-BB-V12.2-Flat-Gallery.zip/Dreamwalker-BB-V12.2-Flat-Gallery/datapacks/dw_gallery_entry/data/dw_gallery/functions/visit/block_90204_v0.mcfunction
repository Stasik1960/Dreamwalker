tp @s 71.5 64.01 492.5 0 21.39897
tellraw @s {"text": "Архитектурная плита · вариант 8 | ID 90204 | bloodborne_dw:source_addon_slabs_1_7 | вариант 0 | new", "color": "gold"}
