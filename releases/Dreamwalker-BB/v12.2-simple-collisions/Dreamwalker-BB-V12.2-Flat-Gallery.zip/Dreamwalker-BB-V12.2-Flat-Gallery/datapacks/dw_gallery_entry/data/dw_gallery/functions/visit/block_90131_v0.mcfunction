tp @s 31.5 64.01 487.5 0 22.1589
tellraw @s {"text": "Напольная панель · вариант 2 | ID 90131 | bloodborne_dw:source_addon_floor_panels_1 | вариант 0 | new", "color": "gold"}
