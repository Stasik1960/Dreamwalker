tp @s 41.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90331 | bloodborne_dw:source_bricks_bricks_2 | вариант 0 | new", "color": "gold"}
