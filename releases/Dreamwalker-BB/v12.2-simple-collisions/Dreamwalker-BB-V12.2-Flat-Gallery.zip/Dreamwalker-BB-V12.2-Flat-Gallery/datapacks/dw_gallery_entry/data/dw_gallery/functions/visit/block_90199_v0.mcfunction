tp @s 2.0 64.01 397.0 0 18.41212
tellraw @s {"text": "Архитектурная плита · вариант 12 | ID 90199 | bloodborne_dw:source_addon_slabs_1_11 | вариант 0 | new", "color": "gold"}
