tp @s 1.5 64.3175 833.5 0 14.03624
tellraw @s {"text": "Секция ворот · открытая, вариант 1 | ID 90037 | bloodborne_dw:source_addon_acacia_fence_gate_open_0 | вариант 0 | new", "color": "gold"}
