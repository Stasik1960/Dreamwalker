tp @s 26.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь · вариант 3 | ID 90273 | bloodborne_dw:source_azure_bluet_2 | вариант 0 | new", "color": "gold"}
