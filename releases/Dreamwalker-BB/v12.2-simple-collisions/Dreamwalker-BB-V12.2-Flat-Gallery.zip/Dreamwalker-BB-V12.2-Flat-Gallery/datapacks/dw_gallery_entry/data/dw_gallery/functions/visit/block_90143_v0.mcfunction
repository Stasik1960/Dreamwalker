tp @s 26.0 64.88 817.5 0 14.03624
tellraw @s {"text": "Секция ворот · вариант 2 | ID 90143 | bloodborne_dw:source_addon_gate2_1 | вариант 0 | new", "color": "gold"}
