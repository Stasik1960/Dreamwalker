tp @s 32.0 64.01 817.5 0 17.41925
tellraw @s {"text": "Пучок травы · вариант 7 | ID 90150 | bloodborne_dw:source_addon_grass_6 | вариант 0 | new", "color": "gold"}
