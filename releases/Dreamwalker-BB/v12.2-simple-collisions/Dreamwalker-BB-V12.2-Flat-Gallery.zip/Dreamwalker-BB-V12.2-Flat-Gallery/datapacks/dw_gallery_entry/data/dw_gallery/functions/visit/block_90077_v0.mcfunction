tp @s 51.5 64.01 847.5 0 22.1589
tellraw @s {"text": "Напольная декоративная пластина · вариант 10 | ID 90077 | bloodborne_dw:source_addon_button_9 | вариант 0 | new", "color": "gold"}
