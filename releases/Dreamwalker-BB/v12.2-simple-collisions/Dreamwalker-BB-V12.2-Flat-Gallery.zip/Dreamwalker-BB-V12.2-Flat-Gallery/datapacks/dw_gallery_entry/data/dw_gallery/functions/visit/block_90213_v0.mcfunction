tp @s 2.5 64.01 861.5 0 21.78597
tellraw @s {"text": "Архитектурная плита · вариант 7 | ID 90213 | bloodborne_dw:source_addon_slabs_6 | вариант 0 | new", "color": "gold"}
