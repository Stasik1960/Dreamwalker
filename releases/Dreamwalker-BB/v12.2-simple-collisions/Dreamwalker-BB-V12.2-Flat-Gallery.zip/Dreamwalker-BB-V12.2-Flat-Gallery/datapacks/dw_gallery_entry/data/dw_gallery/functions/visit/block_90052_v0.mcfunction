tp @s 2.5 64.41125 903.0 0 14.03624
tellraw @s {"text": "Бочка · вариант 8 | ID 90052 | bloodborne_dw:source_addon_barrel_7 | вариант 0 | new", "color": "gold"}
