tp @s 76.5 64.01 497.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90276 | bloodborne_dw:source_bamboo_stairs | вариант 1 | new", "color": "gold"}
