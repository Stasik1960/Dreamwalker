tp @s 72.5 64.01 861.5 0 15.77499
tellraw @s {"text": "Пилястра · вариант 2 | ID 90254 | bloodborne_dw:source_addon_wall_pilaster_1 | вариант 0 | new", "color": "gold"}
