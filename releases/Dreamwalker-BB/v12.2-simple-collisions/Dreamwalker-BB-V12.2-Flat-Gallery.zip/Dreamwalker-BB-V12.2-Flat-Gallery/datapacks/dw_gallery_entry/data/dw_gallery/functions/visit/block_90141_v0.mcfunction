tp @s 76.5 64.01 487.5 0 22.1589
tellraw @s {"text": "Напольная панель | ID 90141 | bloodborne_dw:source_addon_floor_panels_empty | вариант 0 | new", "color": "gold"}
