tp @s 31.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90361 | bloodborne_dw:source_bricks_purpur_block_1 | вариант 0 | new", "color": "gold"}
