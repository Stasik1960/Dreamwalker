tp @s 72.5 64.66125 854.5 0 14.03624
tellraw @s {"text": "Каменная капитель с фигурным низом · вариант 1 | ID 90152 | bloodborne_dw:source_addon_gray_glazed_terracotta_0 | вариант 0 | new", "color": "gold"}
