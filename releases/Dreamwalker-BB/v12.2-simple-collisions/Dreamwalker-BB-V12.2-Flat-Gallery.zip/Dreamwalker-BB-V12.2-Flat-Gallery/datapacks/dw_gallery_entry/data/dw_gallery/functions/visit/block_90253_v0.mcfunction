tp @s 65.5 64.01 861.5 0 15.77499
tellraw @s {"text": "Пилястра · вариант 1 | ID 90253 | bloodborne_dw:source_addon_wall_pilaster_0 | вариант 0 | new", "color": "gold"}
