tp @s 86.0 64.66125 817.5 0 14.03624
tellraw @s {"text": "Рыжая деревянная планка | ID 90403 | bloodborne_dw:source_buttons_dark_oak_dark_oak_button | вариант 0 | new", "color": "gold"}
