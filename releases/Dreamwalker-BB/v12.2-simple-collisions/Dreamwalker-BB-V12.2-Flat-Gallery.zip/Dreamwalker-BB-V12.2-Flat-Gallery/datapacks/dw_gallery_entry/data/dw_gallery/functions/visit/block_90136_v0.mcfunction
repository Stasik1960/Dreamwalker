tp @s 51.5 64.01 487.5 0 22.1589
tellraw @s {"text": "Напольная панель · вариант 6 | ID 90136 | bloodborne_dw:source_addon_floor_panels_5 | вариант 0 | new", "color": "gold"}
