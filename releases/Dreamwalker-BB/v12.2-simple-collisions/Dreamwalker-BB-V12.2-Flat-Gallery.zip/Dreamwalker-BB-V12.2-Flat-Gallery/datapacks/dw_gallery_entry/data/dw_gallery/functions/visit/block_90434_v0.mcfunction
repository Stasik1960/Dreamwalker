tp @s 31.5 64.01 537.5 0 15.77499
tellraw @s {"text": "Неровная булыжная кладка | ID 90434 | bloodborne_dw:source_cobblestone | вариант 0 | new", "color": "gold"}
