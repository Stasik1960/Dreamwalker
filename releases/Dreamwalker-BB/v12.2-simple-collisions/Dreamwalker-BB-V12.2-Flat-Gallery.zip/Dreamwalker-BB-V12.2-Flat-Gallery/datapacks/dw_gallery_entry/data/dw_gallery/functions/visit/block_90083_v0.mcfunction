tp @s 50.0 64.01 391.0 0 14.94256
tellraw @s {"text": "Стопка старых чемоданов · вариант 1 | ID 90083 | bloodborne_dw:source_addon_cases_0 | вариант 0 | new", "color": "gold"}
