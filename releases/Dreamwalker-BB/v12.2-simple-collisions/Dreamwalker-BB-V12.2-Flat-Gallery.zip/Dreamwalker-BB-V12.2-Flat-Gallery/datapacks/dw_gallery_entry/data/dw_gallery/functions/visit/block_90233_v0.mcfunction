tp @s 41.5 64.16125 833.5 0 14.03624
tellraw @s {"text": "Поваленное бревно с редким мхом · вариант 4 | ID 90233 | bloodborne_dw:source_addon_stripped_oka_log_3 | вариант 0 | new", "color": "gold"}
