tp @s 23.5 64.90752 861.5 0 14.03627
tellraw @s {"text": "Надгробие · вариант 1 | ID 90236 | bloodborne_dw:source_addon_tombstone_gathered_0 | вариант 0 | new", "color": "gold"}
