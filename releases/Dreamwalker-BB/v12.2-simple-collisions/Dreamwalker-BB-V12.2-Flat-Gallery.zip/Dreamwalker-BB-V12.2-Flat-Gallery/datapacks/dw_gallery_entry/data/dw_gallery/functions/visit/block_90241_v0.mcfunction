tp @s 27.0 65.03097 974.34951 0 13.54645
tellraw @s {"text": "Надгробие · вариант 6 | ID 90241 | bloodborne_dw:source_addon_tombstone_gathered_5 | вариант 0 | new", "color": "gold"}
