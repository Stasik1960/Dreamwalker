tp @s 1.5 64.03625 492.5 0 14.03624
tellraw @s {"text": "Пучок травы · вариант 1 | ID 90144 | bloodborne_dw:source_addon_grass_0 | вариант 0 | new", "color": "gold"}
