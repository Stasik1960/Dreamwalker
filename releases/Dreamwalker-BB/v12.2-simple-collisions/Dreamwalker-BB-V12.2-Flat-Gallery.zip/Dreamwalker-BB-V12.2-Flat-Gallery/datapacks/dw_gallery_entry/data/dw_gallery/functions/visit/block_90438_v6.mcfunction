tp @s 36.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · закреплённые UV 90° | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 6 | new", "color": "gold"}
