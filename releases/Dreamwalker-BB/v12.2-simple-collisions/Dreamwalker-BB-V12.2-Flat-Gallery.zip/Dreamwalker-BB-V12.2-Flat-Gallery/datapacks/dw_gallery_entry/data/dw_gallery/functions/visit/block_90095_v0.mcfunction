tp @s 2.5 64.505 951.0 0 14.03624
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 3 | ID 90095 | bloodborne_dw:source_addon_crimson_button_2 | вариант 0 | new", "color": "gold"}
