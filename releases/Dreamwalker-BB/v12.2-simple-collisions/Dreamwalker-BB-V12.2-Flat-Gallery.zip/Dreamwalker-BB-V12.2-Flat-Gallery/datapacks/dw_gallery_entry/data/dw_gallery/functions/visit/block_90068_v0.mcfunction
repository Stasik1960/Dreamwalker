tp @s 44.0 64.01 391.0 0 22.1589
tellraw @s {"text": "Напольная декоративная пластина · вариант 14 | ID 90068 | bloodborne_dw:source_addon_button_13 | вариант 0 | new", "color": "gold"}
