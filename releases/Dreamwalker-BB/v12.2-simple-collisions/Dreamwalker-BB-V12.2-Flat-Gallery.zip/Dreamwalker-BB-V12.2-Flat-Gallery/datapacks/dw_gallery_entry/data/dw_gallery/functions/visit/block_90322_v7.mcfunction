tp @s 16.5 64.01 507.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · наклон 180° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 7 | new", "color": "gold"}
