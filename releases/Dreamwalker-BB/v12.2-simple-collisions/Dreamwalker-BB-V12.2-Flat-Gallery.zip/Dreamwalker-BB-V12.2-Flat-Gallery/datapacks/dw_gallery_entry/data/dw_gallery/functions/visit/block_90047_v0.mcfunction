tp @s 20.0 64.03625 391.0 0 14.03624
tellraw @s {"text": "Бочка · вариант 3 | ID 90047 | bloodborne_dw:source_addon_barrel_2 | вариант 0 | new", "color": "gold"}
