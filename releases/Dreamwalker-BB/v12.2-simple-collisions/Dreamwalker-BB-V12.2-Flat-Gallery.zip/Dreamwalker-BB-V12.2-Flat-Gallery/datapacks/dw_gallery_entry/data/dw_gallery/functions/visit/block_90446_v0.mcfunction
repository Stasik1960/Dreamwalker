tp @s 92.0 64.38 403.0 0 14.03624
tellraw @s {"text": "Кирпичная кладка | ID 90446 | bloodborne_dw:source_cracked_deepslate_bricks | вариант 0 | new", "color": "gold"}
