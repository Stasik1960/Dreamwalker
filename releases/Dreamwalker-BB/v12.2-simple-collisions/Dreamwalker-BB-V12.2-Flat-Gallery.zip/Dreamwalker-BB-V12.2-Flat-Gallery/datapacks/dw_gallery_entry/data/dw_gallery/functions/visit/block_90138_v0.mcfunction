tp @s 61.5 64.01 487.5 0 19.83057
tellraw @s {"text": "Напольная панель · вариант 8 | ID 90138 | bloodborne_dw:source_addon_floor_panels_7 | вариант 0 | new", "color": "gold"}
