tp @s 56.0 64.01 397.0 0 15.77499
tellraw @s {"text": "Мелкая серая кладка | ID 90296 | bloodborne_dw:source_black_terracotta | вариант 0 | new", "color": "gold"}
