tp @s 46.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 0 | new", "color": "gold"}
