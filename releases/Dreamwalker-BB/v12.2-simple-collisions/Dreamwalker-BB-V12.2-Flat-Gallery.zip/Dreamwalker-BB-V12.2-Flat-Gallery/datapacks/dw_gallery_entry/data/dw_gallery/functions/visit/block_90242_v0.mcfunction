tp @s 44.5 64.88 861.5 0 14.03624
tellraw @s {"text": "Надгробие · вариант 7 | ID 90242 | bloodborne_dw:source_addon_tombstone_gathered_6 | вариант 0 | new", "color": "gold"}
