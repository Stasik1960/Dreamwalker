tp @s 2.5 64.27141 847.5 0 14.03629
tellraw @s {"text": "Бочка · вариант 11 | ID 90046 | bloodborne_dw:source_addon_barrel_10 | вариант 0 | new", "color": "gold"}
