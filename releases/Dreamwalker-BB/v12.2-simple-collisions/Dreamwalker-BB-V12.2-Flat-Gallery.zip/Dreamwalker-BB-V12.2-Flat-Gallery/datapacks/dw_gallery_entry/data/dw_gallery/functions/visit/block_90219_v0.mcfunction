tp @s 16.5 64.01 861.5 0 21.78597
tellraw @s {"text": "Архитектурная плита · вариант 10 | ID 90219 | bloodborne_dw:source_addon_slabs_9 | вариант 0 | new", "color": "gold"}
