tp @s 36.5 64.01 487.5 0 22.1589
tellraw @s {"text": "Напольная панель · вариант 3 | ID 90133 | bloodborne_dw:source_addon_floor_panels_2 | вариант 0 | new", "color": "gold"}
