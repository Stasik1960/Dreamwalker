tp @s 31.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Бирюзовый светильник на основании | ID 90278 | bloodborne_dw:source_beacon | вариант 0 | new", "color": "gold"}
