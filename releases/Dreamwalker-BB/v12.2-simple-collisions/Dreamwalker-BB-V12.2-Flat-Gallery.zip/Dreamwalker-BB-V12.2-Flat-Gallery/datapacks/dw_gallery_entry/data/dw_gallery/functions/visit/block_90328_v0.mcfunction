tp @s 26.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка | ID 90328 | bloodborne_dw:source_bricks | вариант 0 | new", "color": "gold"}
