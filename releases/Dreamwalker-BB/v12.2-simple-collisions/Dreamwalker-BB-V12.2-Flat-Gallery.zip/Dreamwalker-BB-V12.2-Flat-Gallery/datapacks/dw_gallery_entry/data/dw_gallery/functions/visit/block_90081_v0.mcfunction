tp @s 79.5 64.01 847.5 0 14.52389
tellraw @s {"text": "Свечи · вариант 4 | ID 90081 | bloodborne_dw:source_addon_candles_3 | вариант 0 | new", "color": "gold"}
