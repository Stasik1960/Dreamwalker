tp @s 21.5 64.01 497.5 0 15.77499
tellraw @s {"text": "Плита из серого зернистого камня | ID 90269 | bloodborne_dw:source_andesite | вариант 0 | new", "color": "gold"}
