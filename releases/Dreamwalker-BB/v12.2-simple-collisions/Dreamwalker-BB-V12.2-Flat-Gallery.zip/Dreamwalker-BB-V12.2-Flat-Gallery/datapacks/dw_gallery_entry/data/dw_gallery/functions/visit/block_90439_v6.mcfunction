tp @s 76.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол · закреплённые UV 90° | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 6 | new", "color": "gold"}
