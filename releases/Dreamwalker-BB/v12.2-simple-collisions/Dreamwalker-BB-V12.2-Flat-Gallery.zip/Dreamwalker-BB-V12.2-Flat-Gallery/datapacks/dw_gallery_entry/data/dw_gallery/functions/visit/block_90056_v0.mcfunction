tp @s 30.5 64.01 462.5 0 15.77499
tellraw @s {"text": "Прямоугольная панель с рамкой · вариант 1 | ID 90056 | bloodborne_dw:source_addon_blue_glazed_terracotta_0 | вариант 0 | new", "color": "gold"}
