tp @s 41.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Пустотелая секция каменной стены | ID 90312 | bloodborne_dw:source_blue_stained_glass | вариант 0 | new", "color": "gold"}
