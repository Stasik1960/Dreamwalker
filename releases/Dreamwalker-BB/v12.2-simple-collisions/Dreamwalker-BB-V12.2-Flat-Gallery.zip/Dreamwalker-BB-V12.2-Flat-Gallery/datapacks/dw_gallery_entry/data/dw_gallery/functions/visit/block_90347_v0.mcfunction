tp @s 71.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 6 | ID 90347 | bloodborne_dw:source_bricks_cracked_bricks_5 | вариант 0 | new", "color": "gold"}
