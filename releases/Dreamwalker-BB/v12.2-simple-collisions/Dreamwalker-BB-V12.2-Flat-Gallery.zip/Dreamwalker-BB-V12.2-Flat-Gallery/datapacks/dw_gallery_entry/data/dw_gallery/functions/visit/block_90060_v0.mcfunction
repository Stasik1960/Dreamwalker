tp @s 1.5 64.01 1178.0 0 15.77499
tellraw @s {"text": "Дверная секция · верхняя | ID 90060 | bloodborne_dw:source_addon_brich_trapdoor_top | вариант 0 | absent", "color": "gold"}
