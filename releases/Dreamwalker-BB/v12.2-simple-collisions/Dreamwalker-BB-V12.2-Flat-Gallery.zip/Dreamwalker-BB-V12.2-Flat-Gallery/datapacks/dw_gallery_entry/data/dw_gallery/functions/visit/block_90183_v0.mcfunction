tp @s 30.5 64.50161 903.0 0 14.03625
tellraw @s {"text": "Кровельная секция с боковыми шипами · вариант 1 | ID 90183 | bloodborne_dw:source_addon_red_glazed_0 | вариант 0 | new", "color": "gold"}
