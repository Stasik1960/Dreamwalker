tp @s 92.0 64.01 397.0 0 14.94256
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90332 | bloodborne_dw:source_bricks_bricks_3 | вариант 0 | new", "color": "gold"}
