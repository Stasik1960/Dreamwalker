tp @s 8.0 64.01 409.0 0 15.77499
tellraw @s {"text": "Объёмная декоративная деталь | ID 90454 | bloodborne_dw:source_crimson_nylium | вариант 0 | new", "color": "gold"}
