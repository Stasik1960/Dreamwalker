tp @s 68.0 64.01 397.0 0 15.77499
tellraw @s {"text": "Мелкая серая кладка · вариант 2 | ID 90298 | bloodborne_dw:source_black_terracotta_1 | вариант 0 | new", "color": "gold"}
