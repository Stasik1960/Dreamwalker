tp @s 36.5 64.01 1153.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка | ID 90450 | bloodborne_dw:source_cracked_stone_bricks | вариант 0 | absent", "color": "gold"}
