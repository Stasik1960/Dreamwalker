tp @s 1.5 64.01 547.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол · наклон 180° | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 7 | new", "color": "gold"}
