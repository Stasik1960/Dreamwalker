tp @s 2.47167 64.01 26.01888 0 14.81138
tellraw @s {"text": "Вертикальная деревянная лестница | ID 90006 | bloodborne_dw:prototype_ladder | вариант 0 | v12", "color": "gold"}
