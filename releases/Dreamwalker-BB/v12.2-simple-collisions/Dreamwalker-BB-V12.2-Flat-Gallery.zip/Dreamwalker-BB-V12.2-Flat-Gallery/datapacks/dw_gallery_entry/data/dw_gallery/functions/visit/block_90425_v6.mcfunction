tp @s 26.5 64.01 532.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · закреплённые UV 90° | ID 90425 | bloodborne_dw:source_cobbled_deepslate_stairs_inner | вариант 6 | new", "color": "gold"}
