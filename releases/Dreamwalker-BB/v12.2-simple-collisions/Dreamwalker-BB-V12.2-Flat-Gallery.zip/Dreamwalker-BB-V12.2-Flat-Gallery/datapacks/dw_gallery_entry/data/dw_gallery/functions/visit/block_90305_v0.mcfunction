tp @s 100.5 64.88 861.5 0 14.03624
tellraw @s {"text": "Декоративная каменная поверхность · синий | ID 90305 | bloodborne_dw:source_blue_concrete_powder | вариант 0 | new", "color": "gold"}
