tp @s 9.5 64.755 -2.5 0 14.03624
tellraw @s {"text": "Тонкое остекление · window01 | ID 90004 | bloodborne_dw:prototype_thin_window | вариант 0 | v12", "color": "gold"}
