tp @s 26.5 64.01 547.5 0 17.82584
tellraw @s {"text": "Объёмная декоративная деталь | ID 90456 | bloodborne_dw:source_crimson_pressure_plate | вариант 0 | new", "color": "gold"}
