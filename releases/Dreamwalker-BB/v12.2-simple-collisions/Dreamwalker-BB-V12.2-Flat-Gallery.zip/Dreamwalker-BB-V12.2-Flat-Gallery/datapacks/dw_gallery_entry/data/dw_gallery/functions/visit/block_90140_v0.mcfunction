tp @s 71.5 64.01 487.5 0 18.23059
tellraw @s {"text": "Напольная панель · вариант 10 | ID 90140 | bloodborne_dw:source_addon_floor_panels_9 | вариант 0 | new", "color": "gold"}
