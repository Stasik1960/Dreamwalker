tp @s 86.0 64.88 403.0 0 14.03624
tellraw @s {"text": "Фигурное каменное навершие | ID 90443 | bloodborne_dw:source_cobweb | вариант 0 | new", "color": "gold"}
