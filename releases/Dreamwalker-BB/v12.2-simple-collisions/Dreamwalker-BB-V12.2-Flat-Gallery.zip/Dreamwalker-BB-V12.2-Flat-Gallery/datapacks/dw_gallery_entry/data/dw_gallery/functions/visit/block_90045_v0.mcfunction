tp @s 14.0 64.03625 391.0 0 14.03624
tellraw @s {"text": "Бочка · вариант 2 | ID 90045 | bloodborne_dw:source_addon_barrel_1 | вариант 0 | new", "color": "gold"}
