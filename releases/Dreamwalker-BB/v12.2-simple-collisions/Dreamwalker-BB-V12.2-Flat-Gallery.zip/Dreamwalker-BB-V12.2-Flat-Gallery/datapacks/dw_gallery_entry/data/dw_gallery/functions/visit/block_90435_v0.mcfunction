tp @s 36.5 64.01 537.5 0 19.03443
tellraw @s {"text": "Архитектурная плита | ID 90435 | bloodborne_dw:source_cobblestone_slab | вариант 0 | new", "color": "gold"}
