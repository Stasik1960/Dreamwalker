tp @s 32.0 64.38 1164.0 0 14.03624
tellraw @s {"text": "Статуя · вариант 3 | ID 90225 | bloodborne_dw:source_addon_statue_2 | вариант 0 | absent", "color": "gold"}
