tp @s 62.0 64.01 817.5 0 21.00991
tellraw @s {"text": "Архитектурная плита · вариант 9 | ID 90205 | bloodborne_dw:source_addon_slabs_1_8 | вариант 0 | new", "color": "gold"}
