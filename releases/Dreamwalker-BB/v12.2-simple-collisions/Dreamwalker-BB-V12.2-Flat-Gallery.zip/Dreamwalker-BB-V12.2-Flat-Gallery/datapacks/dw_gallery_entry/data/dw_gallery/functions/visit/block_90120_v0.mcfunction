tp @s 2.5 64.01 854.5 0 22.1589
tellraw @s {"text": "Напольный орнамент · вариант 1 | ID 90120 | bloodborne_dw:source_addon_floor_dec_0 | вариант 0 | new", "color": "gold"}
