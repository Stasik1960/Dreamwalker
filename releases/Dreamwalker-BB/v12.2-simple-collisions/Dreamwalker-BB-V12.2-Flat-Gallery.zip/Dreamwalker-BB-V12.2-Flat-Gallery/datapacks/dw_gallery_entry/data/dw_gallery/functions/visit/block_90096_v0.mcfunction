tp @s 9.5 64.16125 951.0 0 14.03624
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 4 | ID 90096 | bloodborne_dw:source_addon_crimson_button_3 | вариант 0 | new", "color": "gold"}
