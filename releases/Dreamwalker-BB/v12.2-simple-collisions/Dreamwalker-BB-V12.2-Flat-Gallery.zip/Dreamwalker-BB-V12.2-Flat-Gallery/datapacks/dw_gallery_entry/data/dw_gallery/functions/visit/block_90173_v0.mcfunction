tp @s 46.5 64.01 492.5 0 15.77499
tellraw @s {"text": "Рыжая деревянная планка · секция | ID 90173 | bloodborne_dw:source_addon_oak_button_side_on | вариант 0 | new", "color": "gold"}
