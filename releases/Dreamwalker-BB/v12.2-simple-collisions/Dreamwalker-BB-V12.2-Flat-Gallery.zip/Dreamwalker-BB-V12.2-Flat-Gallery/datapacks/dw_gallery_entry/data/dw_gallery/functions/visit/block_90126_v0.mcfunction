tp @s 44.5 64.01 854.5 0 22.1325
tellraw @s {"text": "Напольный орнамент · вариант 7 | ID 90126 | bloodborne_dw:source_addon_floor_dec_6 | вариант 0 | new", "color": "gold"}
