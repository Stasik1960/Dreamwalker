tp @s 9.5 64.01 903.0 0 22.1589
tellraw @s {"text": "Напольная декоративная пластина · вариант 12 | ID 90066 | bloodborne_dw:source_addon_button_11 | вариант 0 | new", "color": "gold"}
