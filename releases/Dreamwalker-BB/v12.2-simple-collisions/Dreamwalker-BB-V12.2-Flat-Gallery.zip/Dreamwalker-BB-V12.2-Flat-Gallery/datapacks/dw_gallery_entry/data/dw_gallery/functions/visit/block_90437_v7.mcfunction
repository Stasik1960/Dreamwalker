tp @s 1.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90437 | bloodborne_dw:source_cobblestone_stairs | вариант 7 | new", "color": "gold"}
