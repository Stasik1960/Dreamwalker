tp @s 44.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Остроконечный готический фронтон | ID 90286 | bloodborne_dw:source_birch_wood | вариант 0 | new", "color": "gold"}
