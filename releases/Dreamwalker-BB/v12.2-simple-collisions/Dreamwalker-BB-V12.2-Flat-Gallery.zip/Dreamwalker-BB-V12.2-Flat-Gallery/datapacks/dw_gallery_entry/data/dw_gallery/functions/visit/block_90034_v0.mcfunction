tp @s 2.0 64.38 817.5 0 14.03624
tellraw @s {"text": "Дверная секция · открытая | ID 90034 | bloodborne_dw:source_acacia_trapdoor_open | вариант 0 | new", "color": "gold"}
