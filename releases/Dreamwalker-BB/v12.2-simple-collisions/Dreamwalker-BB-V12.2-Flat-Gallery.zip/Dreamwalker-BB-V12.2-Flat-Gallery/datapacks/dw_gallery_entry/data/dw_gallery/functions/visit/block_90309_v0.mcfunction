tp @s 36.5 64.01 373.0 0 15.45809
tellraw @s {"text": "Составное декоративное украшение · вариант 2 | ID 90309 | bloodborne_dw:source_blue_orchid_1 | вариант 0 | new", "color": "gold"}
