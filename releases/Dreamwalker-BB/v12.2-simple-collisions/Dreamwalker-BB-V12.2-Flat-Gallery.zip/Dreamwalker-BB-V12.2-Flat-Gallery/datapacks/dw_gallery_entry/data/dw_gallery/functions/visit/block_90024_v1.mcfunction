tp @s 8.0 64.16125 391.0 0 14.03624
tellraw @s {"text": "Настенный орнамент · наклон 180° | ID 90024 | bloodborne_dw:source__wall_dec_out | вариант 1 | new", "color": "gold"}
