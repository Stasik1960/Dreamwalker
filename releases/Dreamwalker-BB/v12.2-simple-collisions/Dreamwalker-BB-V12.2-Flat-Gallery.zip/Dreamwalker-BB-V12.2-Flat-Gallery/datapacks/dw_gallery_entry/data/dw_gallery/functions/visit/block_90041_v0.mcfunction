tp @s 26.5 64.01 482.5 0 16.18867
tellraw @s {"text": "Мешок · вариант 4 | ID 90041 | bloodborne_dw:source_addon_bag_3 | вариант 0 | new", "color": "gold"}
