tp @s 76.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внутренний угол | ID 90425 | bloodborne_dw:source_cobbled_deepslate_stairs_inner | вариант 0 | new", "color": "gold"}
