tp @s 51.5 64.01 492.5 0 15.77499
tellraw @s {"text": "Секция ворот · вариант 1 | ID 90174 | bloodborne_dw:source_addon_oak_fence_gate_0 | вариант 0 | new", "color": "gold"}
