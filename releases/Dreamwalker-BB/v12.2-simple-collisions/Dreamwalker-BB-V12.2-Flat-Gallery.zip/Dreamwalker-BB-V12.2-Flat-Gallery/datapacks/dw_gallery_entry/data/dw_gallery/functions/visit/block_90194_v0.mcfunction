tp @s 16.5 64.01 833.5 0 21.82456
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90194 | bloodborne_dw:source_addon_slabs_10_top | вариант 0 | new", "color": "gold"}
