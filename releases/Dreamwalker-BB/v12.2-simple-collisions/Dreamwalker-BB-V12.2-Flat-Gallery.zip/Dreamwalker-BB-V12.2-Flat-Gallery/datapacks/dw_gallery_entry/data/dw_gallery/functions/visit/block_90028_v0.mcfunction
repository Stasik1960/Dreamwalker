tp @s 2.5 64.88 462.5 0 14.03624
tellraw @s {"text": "Секция ворот | ID 90028 | bloodborne_dw:source_acacia_fence_gate | вариант 0 | new", "color": "gold"}
