tp @s 56.5 64.01 502.5 0 19.03443
tellraw @s {"text": "Кирпичная деталь · верхняя | ID 90321 | bloodborne_dw:source_brick_slab_top | вариант 0 | new", "color": "gold"}
