tp @s 76.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90376 | bloodborne_dw:source_bricks_stone_4 | вариант 0 | new", "color": "gold"}
