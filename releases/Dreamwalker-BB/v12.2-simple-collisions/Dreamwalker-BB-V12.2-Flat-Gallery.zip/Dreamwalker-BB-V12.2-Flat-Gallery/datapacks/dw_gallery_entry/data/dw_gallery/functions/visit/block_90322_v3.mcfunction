tp @s 76.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · наклон 180° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 3 | new", "color": "gold"}
