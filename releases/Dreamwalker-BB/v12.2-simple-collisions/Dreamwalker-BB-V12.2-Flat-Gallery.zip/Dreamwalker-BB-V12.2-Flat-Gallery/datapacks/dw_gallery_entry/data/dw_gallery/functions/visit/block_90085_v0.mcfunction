tp @s 26.5 64.01 1148.5 0 15.77499
tellraw @s {"text": "Цепь · вариант 2 | ID 90085 | bloodborne_dw:source_addon_chain_1 | вариант 0 | absent", "color": "gold"}
