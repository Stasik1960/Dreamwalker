tp @s 50.0 64.38 817.5 0 14.03624
tellraw @s {"text": "Пилястра · вариант 1 | ID 90178 | bloodborne_dw:source_addon_pilaster_0 | вариант 0 | new", "color": "gold"}
