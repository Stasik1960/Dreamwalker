tp @s 74.0 64.41125 397.0 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь | ID 90299 | bloodborne_dw:source_black_wool | вариант 0 | new", "color": "gold"}
