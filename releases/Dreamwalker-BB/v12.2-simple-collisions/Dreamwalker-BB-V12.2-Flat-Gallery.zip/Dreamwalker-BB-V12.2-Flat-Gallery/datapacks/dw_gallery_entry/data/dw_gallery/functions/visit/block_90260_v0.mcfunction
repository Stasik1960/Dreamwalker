tp @s 59.0 64.88 981.22703 0 11.83306
tellraw @s {"text": "Мелкая кладка с угловыми рёбрами | ID 90260 | bloodborne_dw:source_addon_waxed_oxidized_cut_copper | вариант 0 | new", "color": "gold"}
