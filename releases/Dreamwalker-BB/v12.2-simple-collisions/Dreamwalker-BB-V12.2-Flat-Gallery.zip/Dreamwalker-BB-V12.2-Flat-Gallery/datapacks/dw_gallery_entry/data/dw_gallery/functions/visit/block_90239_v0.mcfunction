tp @s 37.5 64.8175 861.5 0 14.03624
tellraw @s {"text": "Надгробие · вариант 4 | ID 90239 | bloodborne_dw:source_addon_tombstone_gathered_3 | вариант 0 | new", "color": "gold"}
