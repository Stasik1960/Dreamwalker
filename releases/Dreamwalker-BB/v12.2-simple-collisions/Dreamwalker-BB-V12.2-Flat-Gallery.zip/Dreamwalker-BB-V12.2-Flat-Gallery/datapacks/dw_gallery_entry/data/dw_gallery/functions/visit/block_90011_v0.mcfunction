tp @s 6.5 64.01 2.375 0 15.77499
tellraw @s {"text": "Ограда · исходный материал 0 | ID 90011 | bloodborne_dw:prototype_wall_skin_0 | вариант 0 | v12", "color": "gold"}
