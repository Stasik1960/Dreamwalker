tp @s 68.0 64.88 921.5 0 14.03624
tellraw @s {"text": "Рыжая деревянная планка | ID 90401 | bloodborne_dw:source_buttons_acacia_acacia_button | вариант 0 | new", "color": "gold"}
