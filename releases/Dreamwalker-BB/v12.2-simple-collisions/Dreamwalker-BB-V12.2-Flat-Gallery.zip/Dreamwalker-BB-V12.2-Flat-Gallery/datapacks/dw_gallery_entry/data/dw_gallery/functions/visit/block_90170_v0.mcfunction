tp @s 4.0 64.32201 963.475 0 9.46236
tellraw @s {"text": "Каменный фриз с орнаментом · вариант 2 | ID 90170 | bloodborne_dw:source_addon_note_1 | вариант 0 | new", "color": "gold"}
