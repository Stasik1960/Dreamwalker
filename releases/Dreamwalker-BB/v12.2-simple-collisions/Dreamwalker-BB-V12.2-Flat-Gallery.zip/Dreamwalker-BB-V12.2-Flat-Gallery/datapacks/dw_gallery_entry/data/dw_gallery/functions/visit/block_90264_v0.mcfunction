tp @s 2.0 64.43256 1196.5 0 14.03622
tellraw @s {"text": "Деревянное украшение · вариант 4 | ID 90264 | bloodborne_dw:source_addon_wood_obj_3 | вариант 0 | absent", "color": "gold"}
