tp @s 36.5 64.16125 833.5 0 14.03624
tellraw @s {"text": "Поваленное бревно со свисающим мхом · вариант 3 | ID 90232 | bloodborne_dw:source_addon_stripped_oka_log_2 | вариант 0 | new", "color": "gold"}
