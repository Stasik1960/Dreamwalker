tp @s 1.5 64.01 2.375 0 15.77499
tellraw @s {"text": "Художественная ограда | ID 90002 | bloodborne_dw:prototype_wall | вариант 0 | v12", "color": "gold"}
