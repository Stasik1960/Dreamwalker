tp @s 58.5 64.01 854.5 0 22.1325
tellraw @s {"text": "Напольный орнамент · вариант 9 | ID 90128 | bloodborne_dw:source_addon_floor_dec_8 | вариант 0 | new", "color": "gold"}
