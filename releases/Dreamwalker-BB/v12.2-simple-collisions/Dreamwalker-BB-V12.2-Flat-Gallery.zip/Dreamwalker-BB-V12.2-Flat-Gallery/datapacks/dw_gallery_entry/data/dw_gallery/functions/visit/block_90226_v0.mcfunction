tp @s 38.0 64.38 1164.0 0 14.03624
tellraw @s {"text": "Статуя · вариант 4 | ID 90226 | bloodborne_dw:source_addon_statue_3 | вариант 0 | absent", "color": "gold"}
