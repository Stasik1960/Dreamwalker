tp @s 21.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · наклон 180° | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 3 | new", "color": "gold"}
