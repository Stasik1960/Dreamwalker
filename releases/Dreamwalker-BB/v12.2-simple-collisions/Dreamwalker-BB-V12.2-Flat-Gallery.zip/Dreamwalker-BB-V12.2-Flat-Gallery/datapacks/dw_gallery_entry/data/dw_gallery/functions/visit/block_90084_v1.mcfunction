tp @s 51.5 64.01 482.5 0 20.22569
tellraw @s {"text": "Цепь · вариант 1 · наклон 90° | ID 90084 | bloodborne_dw:source_addon_chain_0 | вариант 1 | new", "color": "gold"}
