tp @s 86.0 64.01 391.0 0 21.9787
tellraw @s {"text": "Архитектурная плита · вариант 2 | ID 90197 | bloodborne_dw:source_addon_slabs_1_1 | вариант 0 | new", "color": "gold"}
