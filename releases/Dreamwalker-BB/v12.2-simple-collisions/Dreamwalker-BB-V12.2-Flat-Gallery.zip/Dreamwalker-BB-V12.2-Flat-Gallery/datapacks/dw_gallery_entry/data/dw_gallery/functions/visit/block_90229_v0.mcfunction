tp @s 86.5 64.88 462.5 0 14.03624
tellraw @s {"text": "Блок рыжей древесины | ID 90229 | bloodborne_dw:source_addon_stripped_dark_oak_log | вариант 0 | new", "color": "gold"}
