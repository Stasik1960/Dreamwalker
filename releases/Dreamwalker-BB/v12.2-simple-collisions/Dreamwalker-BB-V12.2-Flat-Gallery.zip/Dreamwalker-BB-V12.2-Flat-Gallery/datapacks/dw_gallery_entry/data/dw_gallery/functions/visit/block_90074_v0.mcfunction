tp @s 30.5 64.01 847.5 0 22.01718
tellraw @s {"text": "Рыжая деревянная планка · вариант 7 | ID 90074 | bloodborne_dw:source_addon_button_6 | вариант 0 | new", "color": "gold"}
