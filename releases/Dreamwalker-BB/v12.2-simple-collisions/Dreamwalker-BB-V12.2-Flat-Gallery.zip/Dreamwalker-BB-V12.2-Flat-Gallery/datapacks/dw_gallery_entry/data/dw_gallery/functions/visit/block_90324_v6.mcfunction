tp @s 11.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · внешний угол · закреплённые UV 90° | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 6 | new", "color": "gold"}
