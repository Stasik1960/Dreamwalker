tp @s 76.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 7 | ID 90348 | bloodborne_dw:source_bricks_cracked_bricks_6 | вариант 0 | new", "color": "gold"}
