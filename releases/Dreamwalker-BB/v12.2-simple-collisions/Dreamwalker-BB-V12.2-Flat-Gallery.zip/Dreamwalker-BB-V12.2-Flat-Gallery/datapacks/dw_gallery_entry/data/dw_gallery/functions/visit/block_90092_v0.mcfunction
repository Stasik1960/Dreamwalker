tp @s 56.5 64.87672 482.5 0 14.03618
tellraw @s {"text": "Решётчатая напольная панель | ID 90092 | bloodborne_dw:source_addon_coral_dead_horn_coral_wall_fan | вариант 0 | new", "color": "gold"}
