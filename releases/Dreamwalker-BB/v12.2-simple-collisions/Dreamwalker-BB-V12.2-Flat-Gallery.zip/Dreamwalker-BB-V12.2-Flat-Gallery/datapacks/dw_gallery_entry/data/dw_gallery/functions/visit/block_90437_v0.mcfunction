tp @s 46.5 64.01 537.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90437 | bloodborne_dw:source_cobblestone_stairs | вариант 0 | new", "color": "gold"}
