tp @s 66.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол · закреплённые UV 180° | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 4 | new", "color": "gold"}
