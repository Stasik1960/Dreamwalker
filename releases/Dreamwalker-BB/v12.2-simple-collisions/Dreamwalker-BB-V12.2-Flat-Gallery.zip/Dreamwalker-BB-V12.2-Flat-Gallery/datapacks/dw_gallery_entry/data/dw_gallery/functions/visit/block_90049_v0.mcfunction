tp @s 32.0 64.03625 391.0 0 14.03624
tellraw @s {"text": "Бочка · вариант 5 | ID 90049 | bloodborne_dw:source_addon_barrel_4 | вариант 0 | new", "color": "gold"}
