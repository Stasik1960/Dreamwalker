tp @s 61.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 0 | new", "color": "gold"}
