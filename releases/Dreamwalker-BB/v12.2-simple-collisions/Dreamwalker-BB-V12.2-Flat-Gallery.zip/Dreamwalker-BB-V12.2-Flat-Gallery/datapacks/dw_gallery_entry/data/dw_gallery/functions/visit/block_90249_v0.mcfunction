tp @s 2.5 64.88 467.5 0 14.03624
tellraw @s {"text": "Настенный орнамент · вариант 6 | ID 90249 | bloodborne_dw:source_addon_wall_deco_5 | вариант 0 | new", "color": "gold"}
