tp @s 11.5 64.01 547.5 0 15.77499
tellraw @s {"text": "Кладка из разноразмерных камней | ID 90447 | bloodborne_dw:source_cracked_deepslate_tiles | вариант 0 | new", "color": "gold"}
