tp @s 56.0 64.01 391.0 0 20.22569
tellraw @s {"text": "Цепь · вариант 3 | ID 90086 | bloodborne_dw:source_addon_chain_2 | вариант 0 | new", "color": "gold"}
