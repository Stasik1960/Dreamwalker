tp @s 46.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90342 | bloodborne_dw:source_bricks_cracked_bricks_0 | вариант 0 | new", "color": "gold"}
