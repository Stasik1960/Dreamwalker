tp @s 11.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 90° | ID 90276 | bloodborne_dw:source_bamboo_stairs | вариант 4 | new", "color": "gold"}
