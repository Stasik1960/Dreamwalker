tp @s 6.5 64.03625 492.5 0 14.03624
tellraw @s {"text": "Пучок травы · вариант 2 | ID 90145 | bloodborne_dw:source_addon_grass_1 | вариант 0 | new", "color": "gold"}
