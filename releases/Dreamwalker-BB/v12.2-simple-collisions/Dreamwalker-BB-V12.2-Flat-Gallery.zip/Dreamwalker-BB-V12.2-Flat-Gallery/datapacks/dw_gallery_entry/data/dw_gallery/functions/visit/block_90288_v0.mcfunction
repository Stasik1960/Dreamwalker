tp @s 8.0 66.305 990.2 0 9.46232
tellraw @s {"text": "Декоративная каменная поверхность · чёрный | ID 90288 | bloodborne_dw:source_black_concrete_powder | вариант 0 | new", "color": "gold"}
