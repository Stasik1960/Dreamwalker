tp @s 66.5 64.01 507.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · внешний угол · закреплённые UV 270° | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 1 | new", "color": "gold"}
