tp @s 11.5 64.01 487.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 8 | ID 90106 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_7 | вариант 0 | new", "color": "gold"}
