tp @s 46.5 64.88 502.5 0 14.03624
tellraw @s {"text": "Высокая декоративная стойка | ID 90318 | bloodborne_dw:source_blue_wool | вариант 0 | new", "color": "gold"}
