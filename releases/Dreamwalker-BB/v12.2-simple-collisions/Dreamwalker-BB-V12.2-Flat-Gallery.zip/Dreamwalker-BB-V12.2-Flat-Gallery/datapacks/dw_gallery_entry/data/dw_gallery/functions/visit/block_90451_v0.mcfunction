tp @s 2.0 64.01 822.5 0 19.43348
tellraw @s {"text": "Деревянный горизонтальный карниз · нижняя | ID 90451 | bloodborne_dw:source_crimson_bottom | вариант 0 | new", "color": "gold"}
