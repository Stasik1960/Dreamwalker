tp @s 9.5 64.01 854.5 0 22.1589
tellraw @s {"text": "Напольный орнамент · вариант 2 | ID 90121 | bloodborne_dw:source_addon_floor_dec_1 | вариант 0 | new", "color": "gold"}
