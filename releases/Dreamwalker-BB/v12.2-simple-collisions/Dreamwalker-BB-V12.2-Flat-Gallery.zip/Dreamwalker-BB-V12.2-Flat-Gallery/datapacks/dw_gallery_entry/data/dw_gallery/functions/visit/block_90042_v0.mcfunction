tp @s 11.5 64.01 1148.5 0 14.41767
tellraw @s {"text": "Мешок · вариант 5 | ID 90042 | bloodborne_dw:source_addon_bag_4 | вариант 0 | absent", "color": "gold"}
