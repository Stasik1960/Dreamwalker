tp @s 100.5 64.01 847.5 0 22.1589
tellraw @s {"text": "Цепь · вариант 3 | ID 90090 | bloodborne_dw:source_addon_chains_2 | вариант 0 | new", "color": "gold"}
