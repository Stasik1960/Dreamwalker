tp @s 6.5 64.22375 1178.0 0 14.03624
tellraw @s {"text": "Фонарь | ID 90162 | bloodborne_dw:source_addon_mini_lantern | вариант 0 | absent", "color": "gold"}
