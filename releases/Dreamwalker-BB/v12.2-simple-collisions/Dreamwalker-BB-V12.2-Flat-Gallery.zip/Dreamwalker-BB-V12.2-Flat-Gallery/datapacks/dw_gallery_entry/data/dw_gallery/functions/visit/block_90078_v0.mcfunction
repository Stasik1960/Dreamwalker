tp @s 58.5 64.16125 847.5 0 14.03624
tellraw @s {"text": "Свечи · вариант 1 | ID 90078 | bloodborne_dw:source_addon_candles_0 | вариант 0 | new", "color": "gold"}
