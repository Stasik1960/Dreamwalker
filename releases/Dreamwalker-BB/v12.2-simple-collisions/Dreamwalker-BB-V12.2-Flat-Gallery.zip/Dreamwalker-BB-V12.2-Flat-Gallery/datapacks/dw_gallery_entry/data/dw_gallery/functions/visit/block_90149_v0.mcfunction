tp @s 26.5 64.03625 492.5 0 14.03624
tellraw @s {"text": "Пучок травы · вариант 6 | ID 90149 | bloodborne_dw:source_addon_grass_5 | вариант 0 | new", "color": "gold"}
