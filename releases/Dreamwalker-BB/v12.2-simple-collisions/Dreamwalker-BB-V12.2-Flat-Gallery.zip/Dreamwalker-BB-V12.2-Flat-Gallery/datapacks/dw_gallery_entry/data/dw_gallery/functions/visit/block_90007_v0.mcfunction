tp @s 3.0 64.01 32.0 0 15.77499
tellraw @s {"text": "Деревянные панели окна | ID 90007 | bloodborne_dw:prototype_wood_window | вариант 0 | v12", "color": "gold"}
