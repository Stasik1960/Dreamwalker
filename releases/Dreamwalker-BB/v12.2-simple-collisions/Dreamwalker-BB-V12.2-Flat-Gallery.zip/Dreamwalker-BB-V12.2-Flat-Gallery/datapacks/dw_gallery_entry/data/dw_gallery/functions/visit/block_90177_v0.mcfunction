tp @s 6.5 64.01 1153.5 0 15.77499
tellraw @s {"text": "Объёмная декоративная деталь · открытая | ID 90177 | bloodborne_dw:source_addon_openspace | вариант 0 | absent", "color": "gold"}
