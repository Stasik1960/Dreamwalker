tp @s 71.5 64.01 497.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90276 | bloodborne_dw:source_bamboo_stairs | вариант 0 | new", "color": "gold"}
