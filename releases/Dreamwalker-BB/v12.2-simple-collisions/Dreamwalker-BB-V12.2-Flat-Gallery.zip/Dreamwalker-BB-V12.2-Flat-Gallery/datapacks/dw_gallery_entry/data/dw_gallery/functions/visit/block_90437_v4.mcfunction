tp @s 66.5 64.01 537.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 90° | ID 90437 | bloodborne_dw:source_cobblestone_stairs | вариант 4 | new", "color": "gold"}
