tp @s 11.5 64.01 482.5 0 16.18867
tellraw @s {"text": "Мешок · вариант 1 | ID 90038 | bloodborne_dw:source_addon_bag_0 | вариант 0 | new", "color": "gold"}
