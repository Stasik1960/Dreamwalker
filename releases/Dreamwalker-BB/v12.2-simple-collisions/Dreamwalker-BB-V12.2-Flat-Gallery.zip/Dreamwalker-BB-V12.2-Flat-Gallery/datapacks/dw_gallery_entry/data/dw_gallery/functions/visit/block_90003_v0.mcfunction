tp @s 2.0 64.35352 8.0 0 14.03628
tellraw @s {"text": "Наклонный кровельный модуль | ID 90003 | bloodborne_dw:prototype_roof | вариант 0 | v12", "color": "gold"}
