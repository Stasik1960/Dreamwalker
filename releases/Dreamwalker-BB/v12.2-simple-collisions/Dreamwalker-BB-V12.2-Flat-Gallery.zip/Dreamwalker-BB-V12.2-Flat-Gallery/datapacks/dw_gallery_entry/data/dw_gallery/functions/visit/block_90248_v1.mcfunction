tp @s 58.5 64.01 861.5 0 21.39897
tellraw @s {"text": "Настенный орнамент · вариант 5 · наклон 90° | ID 90248 | bloodborne_dw:source_addon_wall_deco_4 | вариант 1 | new", "color": "gold"}
