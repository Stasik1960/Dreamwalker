tp @s 2.0 64.41125 921.5 0 14.03624
tellraw @s {"text": "Бочка · вариант 10 | ID 90054 | bloodborne_dw:source_addon_barrel_9 | вариант 0 | new", "color": "gold"}
