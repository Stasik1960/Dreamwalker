tp @s 50.0 64.38 1164.0 0 14.03624
tellraw @s {"text": "Статуя · вариант 6 | ID 90228 | bloodborne_dw:source_addon_statue_5 | вариант 0 | absent", "color": "gold"}
