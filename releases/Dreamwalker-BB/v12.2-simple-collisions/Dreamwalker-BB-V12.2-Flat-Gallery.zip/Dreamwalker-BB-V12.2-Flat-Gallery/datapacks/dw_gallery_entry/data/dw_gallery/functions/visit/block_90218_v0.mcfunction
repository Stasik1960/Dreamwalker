tp @s 72.5 64.01 903.0 0 21.78597
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90218 | bloodborne_dw:source_addon_slabs_8_top | вариант 0 | new", "color": "gold"}
