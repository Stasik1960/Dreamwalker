tp @s 11.5 64.01 537.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90429 | bloodborne_dw:source_cobbled_deepslate_stairs_s | вариант 2 | new", "color": "gold"}
