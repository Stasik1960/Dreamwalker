tp @s 1.5 64.01 482.5 0 15.77499
tellraw @s {"text": "Ребристое готическое навершие | ID 90032 | bloodborne_dw:source_acacia_sapling | вариант 0 | new", "color": "gold"}
