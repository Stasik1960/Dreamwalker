tp @s 1.5 64.34875 1148.5 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь · вариант 2 | ID 90022 | bloodborne_dw:source_1_wall_001 | вариант 0 | absent", "color": "gold"}
