tp @s 93.5 64.01 854.5 0 22.05564
tellraw @s {"text": "Архитектурная плита · вариант 4 | ID 90201 | bloodborne_dw:source_addon_slabs_1_3 | вариант 0 | new", "color": "gold"}
