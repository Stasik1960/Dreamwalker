tp @s 30.5 64.88 861.5 0 14.03624
tellraw @s {"text": "Надгробие · вариант 2 | ID 90237 | bloodborne_dw:source_addon_tombstone_gathered_1 | вариант 0 | new", "color": "gold"}
