tp @s 56.5 64.01 532.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол · наклон 180° | ID 90428 | bloodborne_dw:source_cobbled_deepslate_stairs_outer_we | вариант 1 | new", "color": "gold"}
