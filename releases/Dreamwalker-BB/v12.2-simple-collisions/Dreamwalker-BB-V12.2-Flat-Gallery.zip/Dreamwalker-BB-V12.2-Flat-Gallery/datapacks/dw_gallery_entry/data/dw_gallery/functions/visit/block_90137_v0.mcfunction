tp @s 56.5 64.01 487.5 0 19.83057
tellraw @s {"text": "Напольная панель · вариант 7 | ID 90137 | bloodborne_dw:source_addon_floor_panels_6 | вариант 0 | new", "color": "gold"}
