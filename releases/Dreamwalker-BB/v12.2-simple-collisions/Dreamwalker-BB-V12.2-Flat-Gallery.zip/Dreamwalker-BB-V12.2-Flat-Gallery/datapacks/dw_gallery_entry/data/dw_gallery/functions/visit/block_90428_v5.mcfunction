tp @s 76.5 64.01 532.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол · закреплённые UV 90° | ID 90428 | bloodborne_dw:source_cobbled_deepslate_stairs_outer_we | вариант 5 | new", "color": "gold"}
