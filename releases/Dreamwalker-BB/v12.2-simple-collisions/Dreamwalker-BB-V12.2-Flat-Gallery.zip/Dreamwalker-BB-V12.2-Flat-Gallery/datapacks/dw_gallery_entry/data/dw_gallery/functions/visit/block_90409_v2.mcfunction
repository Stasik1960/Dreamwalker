tp @s 6.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 270° | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 2 | new", "color": "gold"}
