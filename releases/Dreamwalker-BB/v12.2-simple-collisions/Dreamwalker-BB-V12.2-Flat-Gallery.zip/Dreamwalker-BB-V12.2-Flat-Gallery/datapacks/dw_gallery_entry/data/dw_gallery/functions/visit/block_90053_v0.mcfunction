tp @s 8.0 64.25734 1164.0 0 14.03619
tellraw @s {"text": "Бочка · вариант 9 | ID 90053 | bloodborne_dw:source_addon_barrel_8 | вариант 0 | absent", "color": "gold"}
