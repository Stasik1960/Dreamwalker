tp @s 14.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90335 | bloodborne_dw:source_bricks_bricks_r_2 | вариант 0 | new", "color": "gold"}
