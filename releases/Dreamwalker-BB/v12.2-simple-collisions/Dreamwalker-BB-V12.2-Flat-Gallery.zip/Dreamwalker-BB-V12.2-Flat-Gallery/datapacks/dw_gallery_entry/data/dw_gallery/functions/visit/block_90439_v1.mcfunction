tp @s 51.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внешний угол · закреплённые UV 270° | ID 90439 | bloodborne_dw:source_cobblestone_stairs_outer | вариант 1 | new", "color": "gold"}
