tp @s 75.0 64.01 981.75736 0 14.91413
tellraw @s {"text": "Плита из грубого серого камня | ID 90414 | bloodborne_dw:source_chiseled_red_sandstone | вариант 0 | new", "color": "gold"}
