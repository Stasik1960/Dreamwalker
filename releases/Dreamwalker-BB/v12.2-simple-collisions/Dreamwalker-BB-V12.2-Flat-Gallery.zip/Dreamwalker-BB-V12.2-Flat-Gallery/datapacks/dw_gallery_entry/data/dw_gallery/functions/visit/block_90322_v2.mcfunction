tp @s 71.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · закреплённые UV 270° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 2 | new", "color": "gold"}
