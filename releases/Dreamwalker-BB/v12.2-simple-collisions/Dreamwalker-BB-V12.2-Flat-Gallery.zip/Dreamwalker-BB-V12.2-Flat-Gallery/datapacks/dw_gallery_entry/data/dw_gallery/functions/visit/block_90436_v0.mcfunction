tp @s 41.5 64.01 537.5 0 19.03443
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90436 | bloodborne_dw:source_cobblestone_slab_top | вариант 0 | new", "color": "gold"}
