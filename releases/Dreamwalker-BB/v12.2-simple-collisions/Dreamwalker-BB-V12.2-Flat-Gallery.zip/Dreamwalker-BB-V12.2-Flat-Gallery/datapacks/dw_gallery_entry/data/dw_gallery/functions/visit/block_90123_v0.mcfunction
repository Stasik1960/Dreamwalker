tp @s 23.5 64.01 854.5 0 22.1589
tellraw @s {"text": "Напольный орнамент · вариант 4 | ID 90123 | bloodborne_dw:source_addon_floor_dec_3 | вариант 0 | new", "color": "gold"}
