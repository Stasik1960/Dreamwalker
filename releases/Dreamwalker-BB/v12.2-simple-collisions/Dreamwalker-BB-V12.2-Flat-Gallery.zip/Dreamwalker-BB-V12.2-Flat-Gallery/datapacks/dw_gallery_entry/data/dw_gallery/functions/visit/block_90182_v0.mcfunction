tp @s 16.5 64.88 951.0 0 14.03624
tellraw @s {"text": "Резная каменная база с широким верхом · секция | ID 90182 | bloodborne_dw:source_addon_quartz_pillar_side | вариант 0 | new", "color": "gold"}
