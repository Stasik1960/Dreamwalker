tp @s 41.5 64.01 487.5 0 22.1589
tellraw @s {"text": "Напольная панель · вариант 4 | ID 90134 | bloodborne_dw:source_addon_floor_panels_3 | вариант 0 | new", "color": "gold"}
