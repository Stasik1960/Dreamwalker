tp @s 61.5 64.01 507.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · внешний угол | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 0 | new", "color": "gold"}
