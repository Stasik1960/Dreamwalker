tp @s 107.5 64.88 462.5 0 14.03624
tellraw @s {"text": "Настенный орнамент · вариант 5 | ID 90248 | bloodborne_dw:source_addon_wall_deco_4 | вариант 0 | new", "color": "gold"}
