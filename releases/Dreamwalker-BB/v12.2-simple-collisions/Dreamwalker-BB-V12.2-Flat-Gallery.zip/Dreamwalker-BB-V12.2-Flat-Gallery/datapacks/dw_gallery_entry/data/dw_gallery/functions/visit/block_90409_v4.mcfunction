tp @s 16.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · закреплённые UV 90° | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 4 | new", "color": "gold"}
