tp @s 61.5 64.01 482.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 2 | ID 90100 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_1 | вариант 0 | new", "color": "gold"}
