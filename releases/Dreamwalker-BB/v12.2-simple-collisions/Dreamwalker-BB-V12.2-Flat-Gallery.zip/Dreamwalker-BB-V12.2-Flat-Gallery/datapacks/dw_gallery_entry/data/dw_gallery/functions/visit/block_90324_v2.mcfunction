tp @s 71.5 64.01 507.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · внешний угол · наклон 180° | ID 90324 | bloodborne_dw:source_brick_stairs_outer | вариант 2 | new", "color": "gold"}
