tp @s 14.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь | ID 90271 | bloodborne_dw:source_azure_bluet | вариант 0 | new", "color": "gold"}
