tp @s 32.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 6 | ID 90338 | bloodborne_dw:source_bricks_bricks_r_5 | вариант 0 | new", "color": "gold"}
