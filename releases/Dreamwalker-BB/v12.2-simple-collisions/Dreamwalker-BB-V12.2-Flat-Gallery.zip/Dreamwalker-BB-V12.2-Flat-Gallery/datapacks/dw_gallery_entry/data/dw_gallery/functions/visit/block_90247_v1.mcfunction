tp @s 86.5 64.01 903.0 0 21.39897
tellraw @s {"text": "Настенный орнамент · вариант 4 · наклон 90° | ID 90247 | bloodborne_dw:source_addon_wall_deco_3 | вариант 1 | new", "color": "gold"}
