tp @s 23.5 64.53625 951.0 0 14.03624
tellraw @s {"text": "Секция ворот · открытая, вариант 2 | ID 90222 | bloodborne_dw:source_addon_spruce_fence_gate_open_1 | вариант 0 | new", "color": "gold"}
