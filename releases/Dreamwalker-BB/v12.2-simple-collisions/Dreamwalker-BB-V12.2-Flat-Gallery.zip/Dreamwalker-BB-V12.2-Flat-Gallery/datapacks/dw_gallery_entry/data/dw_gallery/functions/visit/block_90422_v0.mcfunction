tp @s 56.5 64.01 527.5 0 19.03443
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90422 | bloodborne_dw:source_cobbled_deepslate_slab_top | вариант 0 | new", "color": "gold"}
