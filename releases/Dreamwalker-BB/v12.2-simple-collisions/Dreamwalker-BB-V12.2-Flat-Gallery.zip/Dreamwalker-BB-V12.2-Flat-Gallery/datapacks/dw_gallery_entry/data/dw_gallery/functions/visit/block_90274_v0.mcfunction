tp @s 32.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь · вариант 4 | ID 90274 | bloodborne_dw:source_azure_bluet_3 | вариант 0 | new", "color": "gold"}
