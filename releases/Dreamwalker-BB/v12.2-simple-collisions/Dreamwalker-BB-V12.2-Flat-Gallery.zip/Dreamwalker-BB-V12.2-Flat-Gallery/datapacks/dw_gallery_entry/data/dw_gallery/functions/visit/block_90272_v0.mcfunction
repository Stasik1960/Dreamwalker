tp @s 20.0 64.88 397.0 0 14.03624
tellraw @s {"text": "Объёмная декоративная деталь · вариант 2 | ID 90272 | bloodborne_dw:source_azure_bluet_1 | вариант 0 | new", "color": "gold"}
