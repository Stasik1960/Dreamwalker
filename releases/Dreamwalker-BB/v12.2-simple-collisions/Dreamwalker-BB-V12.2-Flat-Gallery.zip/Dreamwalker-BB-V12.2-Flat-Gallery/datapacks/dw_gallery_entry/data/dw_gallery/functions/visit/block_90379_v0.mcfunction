tp @s 11.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90379 | bloodborne_dw:source_bricks_stonebrick_0 | вариант 0 | new", "color": "gold"}
