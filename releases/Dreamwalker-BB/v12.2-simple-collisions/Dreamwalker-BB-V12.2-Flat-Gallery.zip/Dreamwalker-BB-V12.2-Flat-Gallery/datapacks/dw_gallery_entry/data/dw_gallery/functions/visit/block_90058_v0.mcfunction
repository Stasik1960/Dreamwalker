tp @s 2.5 64.01 945.0 0 21.24359
tellraw @s {"text": "Книги · вариант 2 | ID 90058 | bloodborne_dw:source_addon_books_1 | вариант 0 | new", "color": "gold"}
