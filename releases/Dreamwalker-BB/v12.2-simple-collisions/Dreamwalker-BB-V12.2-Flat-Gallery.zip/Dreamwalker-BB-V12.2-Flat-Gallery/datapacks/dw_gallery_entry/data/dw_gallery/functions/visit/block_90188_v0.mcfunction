tp @s 44.5 64.01 903.0 0 22.1589
tellraw @s {"text": "Осколки стекла · вариант 3 | ID 90188 | bloodborne_dw:source_addon_shattered_glass_2 | вариант 0 | new", "color": "gold"}
