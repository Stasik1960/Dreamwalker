tp @s 6.5 64.16125 373.0 0 14.03624
tellraw @s {"text": "Настенный орнамент · верхняя | ID 90025 | bloodborne_dw:source__wall_dec_top | вариант 0 | new", "color": "gold"}
