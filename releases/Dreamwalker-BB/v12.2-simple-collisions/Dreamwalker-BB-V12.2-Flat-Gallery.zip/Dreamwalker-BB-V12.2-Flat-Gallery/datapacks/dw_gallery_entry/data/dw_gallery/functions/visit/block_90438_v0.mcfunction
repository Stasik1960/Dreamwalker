tp @s 6.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внутренний угол | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 0 | new", "color": "gold"}
