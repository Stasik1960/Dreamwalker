tp @s 41.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90363 | bloodborne_dw:source_bricks_purpur_block_3 | вариант 0 | new", "color": "gold"}
