tp @s 2.0 64.255 955.0 0 14.03624
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 5 | ID 90097 | bloodborne_dw:source_addon_crimson_button_4 | вариант 0 | new", "color": "gold"}
