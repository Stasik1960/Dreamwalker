tp @s 21.5 64.01 487.5 0 15.77499
tellraw @s {"text": "Тёмная кладка из вытянутых камней · вариант 10 | ID 90108 | bloodborne_dw:source_addon_cyan_terracotta_cyan_terracotta_9 | вариант 0 | new", "color": "gold"}
