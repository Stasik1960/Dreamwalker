tp @s 92.0 64.01 391.0 0 21.39897
tellraw @s {"text": "Архитектурная плита · вариант 11 | ID 90198 | bloodborne_dw:source_addon_slabs_1_10 | вариант 0 | new", "color": "gold"}
