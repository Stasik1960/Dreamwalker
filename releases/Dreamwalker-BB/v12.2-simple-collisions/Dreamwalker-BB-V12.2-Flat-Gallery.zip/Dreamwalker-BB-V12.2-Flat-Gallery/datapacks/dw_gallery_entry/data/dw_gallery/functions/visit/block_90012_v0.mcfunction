tp @s 11.5 64.01 2.5 0 15.77499
tellraw @s {"text": "Ограда · исходный материал 1 | ID 90012 | bloodborne_dw:prototype_wall_skin_1 | вариант 0 | v12", "color": "gold"}
