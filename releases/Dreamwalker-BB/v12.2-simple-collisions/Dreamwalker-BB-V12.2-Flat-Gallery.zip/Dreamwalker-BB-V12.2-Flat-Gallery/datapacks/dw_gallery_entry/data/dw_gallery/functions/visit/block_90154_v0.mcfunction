tp @s 44.0 64.01 817.5 0 15.3596
tellraw @s {"text": "Кирпичный парапет с зубцами · вариант 2 | ID 90154 | bloodborne_dw:source_addon_green_glazed_1 | вариант 0 | new", "color": "gold"}
