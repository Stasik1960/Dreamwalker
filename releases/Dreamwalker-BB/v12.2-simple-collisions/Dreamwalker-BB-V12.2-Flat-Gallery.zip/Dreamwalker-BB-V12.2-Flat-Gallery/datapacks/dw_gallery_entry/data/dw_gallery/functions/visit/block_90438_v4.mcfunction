tp @s 26.5 64.01 542.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · внутренний угол · закреплённые UV 180° | ID 90438 | bloodborne_dw:source_cobblestone_stairs_inner | вариант 4 | new", "color": "gold"}
