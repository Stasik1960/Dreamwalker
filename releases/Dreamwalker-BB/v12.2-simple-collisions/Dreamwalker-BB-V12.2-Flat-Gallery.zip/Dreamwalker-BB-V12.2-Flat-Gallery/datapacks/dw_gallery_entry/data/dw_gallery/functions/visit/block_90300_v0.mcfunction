tp @s 21.5 64.88 1153.5 0 14.03624
tellraw @s {"text": "Высокий ажурный шпиль | ID 90300 | bloodborne_dw:source_blackstone | вариант 0 | absent", "color": "gold"}
