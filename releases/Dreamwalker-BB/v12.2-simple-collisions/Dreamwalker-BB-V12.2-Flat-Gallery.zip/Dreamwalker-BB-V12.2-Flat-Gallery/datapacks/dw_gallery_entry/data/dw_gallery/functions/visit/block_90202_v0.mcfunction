tp @s 11.0 64.01 982.0 0 18.23059
tellraw @s {"text": "Архитектурная плита · вариант 6 | ID 90202 | bloodborne_dw:source_addon_slabs_1_5 | вариант 0 | new", "color": "gold"}
