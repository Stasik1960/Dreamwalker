tp @s 20.0 64.01 1164.0 0 15.77499
tellraw @s {"text": "Пилястра · вариант 3 | ID 90180 | bloodborne_dw:source_addon_pilaster_2 | вариант 0 | absent", "color": "gold"}
