tp @s 37.5 64.88 467.5 0 14.03624
tellraw @s {"text": "Тонкое кольцевое обрамление окна | ID 90390 | bloodborne_dw:source_brown_concrete | вариант 0 | new", "color": "gold"}
