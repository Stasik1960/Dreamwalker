tp @s 2.5 64.38 1135.5 0 14.03624
tellraw @s {"text": "Светильник · вариант 2 | ID 90021 | bloodborne_dw:source_1_spirelamp_001 | вариант 0 | absent", "color": "gold"}
