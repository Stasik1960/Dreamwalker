tp @s 74.0 64.01 391.0 0 18.63346
tellraw @s {"text": "Шляпа охотника | ID 90155 | bloodborne_dw:source_addon_hat | вариант 0 | new", "color": "gold"}
