tp @s 2.0 64.25734 1164.0 0 14.03619
tellraw @s {"text": "Бочка · вариант 7 | ID 90051 | bloodborne_dw:source_addon_barrel_6 | вариант 0 | absent", "color": "gold"}
