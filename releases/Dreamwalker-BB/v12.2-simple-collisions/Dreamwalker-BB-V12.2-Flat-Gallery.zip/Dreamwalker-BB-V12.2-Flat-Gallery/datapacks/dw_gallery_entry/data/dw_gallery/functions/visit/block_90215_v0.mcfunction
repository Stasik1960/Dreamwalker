tp @s 58.5 64.01 903.0 0 21.78597
tellraw @s {"text": "Архитектурная плита · вариант 8 | ID 90215 | bloodborne_dw:source_addon_slabs_7 | вариант 0 | new", "color": "gold"}
