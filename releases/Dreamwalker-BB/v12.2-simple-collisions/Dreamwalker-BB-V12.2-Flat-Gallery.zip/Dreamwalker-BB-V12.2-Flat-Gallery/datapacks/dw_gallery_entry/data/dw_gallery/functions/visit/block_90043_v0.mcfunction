tp @s 16.5 64.01 1148.5 0 14.41767
tellraw @s {"text": "Мешок · вариант 6 | ID 90043 | bloodborne_dw:source_addon_bag_5 | вариант 0 | absent", "color": "gold"}
