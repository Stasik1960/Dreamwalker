tp @s 1.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90409 | bloodborne_dw:source_cherry_stairs | вариант 1 | new", "color": "gold"}
