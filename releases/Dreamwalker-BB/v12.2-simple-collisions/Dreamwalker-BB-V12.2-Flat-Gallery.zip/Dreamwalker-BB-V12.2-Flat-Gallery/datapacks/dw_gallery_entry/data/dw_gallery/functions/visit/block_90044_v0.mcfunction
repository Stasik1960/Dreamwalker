tp @s 31.5 64.03625 482.5 0 14.03624
tellraw @s {"text": "Бочка · вариант 1 | ID 90044 | bloodborne_dw:source_addon_barrel_0 | вариант 0 | new", "color": "gold"}
