tp @s 16.5 64.01 903.0 0 22.1589
tellraw @s {"text": "Напольная декоративная пластина · вариант 13 | ID 90067 | bloodborne_dw:source_addon_button_12 | вариант 0 | new", "color": "gold"}
