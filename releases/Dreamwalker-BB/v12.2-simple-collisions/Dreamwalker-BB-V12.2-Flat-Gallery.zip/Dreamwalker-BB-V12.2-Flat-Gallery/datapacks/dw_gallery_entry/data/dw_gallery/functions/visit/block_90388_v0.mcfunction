tp @s 56.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90388 | bloodborne_dw:source_bricks_wallbrick_1 | вариант 0 | new", "color": "gold"}
