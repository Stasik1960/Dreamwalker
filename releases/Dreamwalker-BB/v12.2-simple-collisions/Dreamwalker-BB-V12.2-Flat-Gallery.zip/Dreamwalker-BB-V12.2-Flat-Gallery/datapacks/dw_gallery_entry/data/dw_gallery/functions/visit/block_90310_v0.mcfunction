tp @s 80.0 64.01 817.5 0 15.45809
tellraw @s {"text": "Составное декоративное украшение · вариант 3 | ID 90310 | bloodborne_dw:source_blue_orchid_2 | вариант 0 | new", "color": "gold"}
