tp @s 46.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 8 | ID 90386 | bloodborne_dw:source_bricks_stonebrick_7 | вариант 0 | new", "color": "gold"}
