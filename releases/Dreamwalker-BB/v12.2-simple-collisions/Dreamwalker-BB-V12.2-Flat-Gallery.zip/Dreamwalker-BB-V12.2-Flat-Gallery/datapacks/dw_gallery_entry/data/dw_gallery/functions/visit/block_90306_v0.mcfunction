tp @s 9.5 64.01 1202.5 0 15.77499
tellraw @s {"text": "Декоративная панель | ID 90306 | bloodborne_dw:source_blue_glazed_terracotta | вариант 0 | absent", "color": "gold"}
