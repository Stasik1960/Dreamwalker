tp @s 51.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90343 | bloodborne_dw:source_bricks_cracked_bricks_1 | вариант 0 | new", "color": "gold"}
