tp @s 46.5 64.01 482.5 0 15.77499
tellraw @s {"text": "Цепь · вариант 1 | ID 90084 | bloodborne_dw:source_addon_chain_0 | вариант 0 | new", "color": "gold"}
