tp @s 16.5 64.03625 492.5 0 14.03624
tellraw @s {"text": "Пучок травы · вариант 4 | ID 90147 | bloodborne_dw:source_addon_grass_3 | вариант 0 | new", "color": "gold"}
