tp @s 11.0 64.38 1185.0 0 14.03624
tellraw @s {"text": "Книги | ID 90319 | bloodborne_dw:source_bookshelf | вариант 0 | absent", "color": "gold"}
