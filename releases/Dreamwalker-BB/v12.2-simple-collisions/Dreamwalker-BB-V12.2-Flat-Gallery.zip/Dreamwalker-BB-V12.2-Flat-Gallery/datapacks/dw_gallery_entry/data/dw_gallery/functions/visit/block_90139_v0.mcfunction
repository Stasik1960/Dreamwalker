tp @s 66.5 64.01 487.5 0 21.00991
tellraw @s {"text": "Напольная панель · вариант 9 | ID 90139 | bloodborne_dw:source_addon_floor_panels_8 | вариант 0 | new", "color": "gold"}
