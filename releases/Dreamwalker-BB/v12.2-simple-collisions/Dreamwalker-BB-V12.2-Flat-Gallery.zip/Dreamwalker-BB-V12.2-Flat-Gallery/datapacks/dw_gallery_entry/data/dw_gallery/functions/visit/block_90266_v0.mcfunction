tp @s 2.5 64.88 1202.5 0 14.03624
tellraw @s {"text": "Декоративная панель | ID 90266 | bloodborne_dw:source_allium | вариант 0 | absent", "color": "gold"}
