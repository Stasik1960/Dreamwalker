tp @s 21.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · секция | ID 90327 | bloodborne_dw:source_brick_wall_side_tall | вариант 0 | new", "color": "gold"}
