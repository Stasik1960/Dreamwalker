tp @s 11.0 64.01 974.5 0 15.77499
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90210 | bloodborne_dw:source_addon_slabs_3_top | вариант 0 | new", "color": "gold"}
