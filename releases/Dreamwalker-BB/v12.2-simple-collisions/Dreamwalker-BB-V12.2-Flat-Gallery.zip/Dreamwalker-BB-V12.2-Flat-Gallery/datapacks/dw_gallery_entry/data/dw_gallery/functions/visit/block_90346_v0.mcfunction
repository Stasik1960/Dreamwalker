tp @s 66.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90346 | bloodborne_dw:source_bricks_cracked_bricks_4 | вариант 0 | new", "color": "gold"}
