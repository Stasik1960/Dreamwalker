tp @s 11.5 64.03625 492.5 0 14.03624
tellraw @s {"text": "Пучок травы · вариант 3 | ID 90146 | bloodborne_dw:source_addon_grass_2 | вариант 0 | new", "color": "gold"}
