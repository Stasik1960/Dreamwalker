tp @s 41.5 64.01 482.5 0 14.52389
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 3 | ID 90070 | bloodborne_dw:source_addon_button_2 | вариант 0 | new", "color": "gold"}
