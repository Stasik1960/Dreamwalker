tp @s 2.5 64.01 868.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 2 | ID 90340 | bloodborne_dw:source_bricks_bricks_rl_1 | вариант 0 | new", "color": "gold"}
