tp @s 76.5 64.01 492.5 0 22.1589
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90207 | bloodborne_dw:source_addon_slabs_1_top | вариант 0 | new", "color": "gold"}
