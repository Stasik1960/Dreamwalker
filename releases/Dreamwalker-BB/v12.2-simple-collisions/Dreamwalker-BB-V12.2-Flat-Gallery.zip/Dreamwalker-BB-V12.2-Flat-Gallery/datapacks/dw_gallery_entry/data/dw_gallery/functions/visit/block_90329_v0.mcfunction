tp @s 31.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 1 | ID 90329 | bloodborne_dw:source_bricks_bricks_0 | вариант 0 | new", "color": "gold"}
