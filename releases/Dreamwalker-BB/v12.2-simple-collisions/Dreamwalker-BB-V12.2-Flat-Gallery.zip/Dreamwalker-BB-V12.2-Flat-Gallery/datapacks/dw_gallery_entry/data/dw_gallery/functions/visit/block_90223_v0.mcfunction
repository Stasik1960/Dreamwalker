tp @s 8.0 64.38 397.0 0 14.03624
tellraw @s {"text": "Статуя · вариант 1 | ID 90223 | bloodborne_dw:source_addon_statue_0 | вариант 0 | new", "color": "gold"}
