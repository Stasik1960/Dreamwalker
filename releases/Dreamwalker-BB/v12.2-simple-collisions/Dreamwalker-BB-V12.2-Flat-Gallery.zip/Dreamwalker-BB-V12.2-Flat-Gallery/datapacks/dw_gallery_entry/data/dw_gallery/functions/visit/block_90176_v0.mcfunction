tp @s 6.5 64.88 833.5 0 14.03624
tellraw @s {"text": "Секция ворот · открытая, вариант 2 | ID 90176 | bloodborne_dw:source_addon_oak_fence_gate_open_1 | вариант 0 | new", "color": "gold"}
