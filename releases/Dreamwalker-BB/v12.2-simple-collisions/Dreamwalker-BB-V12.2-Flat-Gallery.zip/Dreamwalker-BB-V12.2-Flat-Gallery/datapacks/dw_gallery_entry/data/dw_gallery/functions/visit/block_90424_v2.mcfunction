tp @s 71.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль · наклон 180° | ID 90424 | bloodborne_dw:source_cobbled_deepslate_stairs_e | вариант 2 | new", "color": "gold"}
