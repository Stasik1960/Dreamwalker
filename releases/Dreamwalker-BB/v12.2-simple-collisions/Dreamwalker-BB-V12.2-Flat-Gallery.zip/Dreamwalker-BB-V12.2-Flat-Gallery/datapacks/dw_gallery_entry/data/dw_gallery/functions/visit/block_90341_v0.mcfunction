tp @s 9.5 64.01 868.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 3 | ID 90341 | bloodborne_dw:source_bricks_bricks_rl_2 | вариант 0 | new", "color": "gold"}
