tp @s 36.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 6 | ID 90384 | bloodborne_dw:source_bricks_stonebrick_5 | вариант 0 | new", "color": "gold"}
