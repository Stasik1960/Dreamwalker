tp @s 2.5 65.38 -3.3 0 11.76829
tellraw @s {"text": "Входная дверь | ID 90001 | bloodborne_dw:prototype_double_door | вариант 0 | v12", "color": "gold"}
