tp @s 14.0 64.88 817.5 0 14.03624
tellraw @s {"text": "Ажурная секция ограды с завитками · вариант 1 | ID 90093 | bloodborne_dw:source_addon_crimson_button_0 | вариант 0 | new", "color": "gold"}
