tp @s 1.5 64.28625 373.0 0 14.03624
tellraw @s {"text": "Настенный орнамент · нижняя | ID 90023 | bloodborne_dw:source__wall_dec_bottom | вариант 0 | new", "color": "gold"}
