tp @s 58.5 64.38978 462.5 0 14.03631
tellraw @s {"text": "Секция ворот · открытая, вариант 1 | ID 90156 | bloodborne_dw:source_addon_jungle_fence_gate_open_0 | вариант 0 | new", "color": "gold"}
