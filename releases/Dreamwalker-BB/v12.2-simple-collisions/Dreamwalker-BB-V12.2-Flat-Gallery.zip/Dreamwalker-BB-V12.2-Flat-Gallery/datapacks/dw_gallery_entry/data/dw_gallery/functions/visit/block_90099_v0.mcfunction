tp @s 23.5 64.01 903.0 0 14.94256
tellraw @s {"text": "Секция ворот · открытая | ID 90099 | bloodborne_dw:source_addon_crimson_fence_gate_open | вариант 0 | new", "color": "gold"}
