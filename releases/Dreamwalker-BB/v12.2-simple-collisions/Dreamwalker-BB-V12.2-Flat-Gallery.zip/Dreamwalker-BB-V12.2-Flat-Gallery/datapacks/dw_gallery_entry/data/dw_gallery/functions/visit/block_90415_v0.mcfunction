tp @s 36.5 64.38 527.5 0 14.03624
tellraw @s {"text": "Каменная панель со стрельчатой нишей | ID 90415 | bloodborne_dw:source_chiseled_sandstone | вариант 0 | new", "color": "gold"}
