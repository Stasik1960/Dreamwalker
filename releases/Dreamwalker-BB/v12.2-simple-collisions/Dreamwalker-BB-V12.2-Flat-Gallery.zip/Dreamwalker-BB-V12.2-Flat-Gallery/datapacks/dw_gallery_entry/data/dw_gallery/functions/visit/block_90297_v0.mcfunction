tp @s 62.0 64.01 397.0 0 15.77499
tellraw @s {"text": "Мелкая серая кладка · вариант 1 | ID 90297 | bloodborne_dw:source_black_terracotta_0 | вариант 0 | new", "color": "gold"}
