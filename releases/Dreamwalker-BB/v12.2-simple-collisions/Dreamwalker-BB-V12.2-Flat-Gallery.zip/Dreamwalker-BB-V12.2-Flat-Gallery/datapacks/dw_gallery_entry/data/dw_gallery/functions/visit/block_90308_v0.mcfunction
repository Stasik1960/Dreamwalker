tp @s 74.0 64.01 817.5 0 15.45809
tellraw @s {"text": "Составное декоративное украшение | ID 90308 | bloodborne_dw:source_blue_orchid | вариант 0 | new", "color": "gold"}
