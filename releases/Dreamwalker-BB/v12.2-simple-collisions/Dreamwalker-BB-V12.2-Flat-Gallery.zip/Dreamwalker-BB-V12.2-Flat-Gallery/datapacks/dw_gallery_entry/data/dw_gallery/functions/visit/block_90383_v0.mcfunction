tp @s 31.5 64.01 522.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 5 | ID 90383 | bloodborne_dw:source_bricks_stonebrick_4 | вариант 0 | new", "color": "gold"}
