tp @s 16.5 64.01 1135.5 0 21.78597
tellraw @s {"text": "Архитектурная плита · вариант 9 | ID 90217 | bloodborne_dw:source_addon_slabs_8 | вариант 0 | absent", "color": "gold"}
