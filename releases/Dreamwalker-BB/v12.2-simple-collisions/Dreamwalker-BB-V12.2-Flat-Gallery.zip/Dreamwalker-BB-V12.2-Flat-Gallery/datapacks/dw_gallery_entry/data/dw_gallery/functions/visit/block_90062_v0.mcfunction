tp @s 8.0 64.84872 817.5 0 14.03628
tellraw @s {"text": "Свечи · вариант 2 | ID 90062 | bloodborne_dw:source_addon_brown_candel_1 | вариант 0 | new", "color": "gold"}
