tp @s 26.5 64.01 487.5 0 22.1589
tellraw @s {"text": "Напольная панель · вариант 1 | ID 90130 | bloodborne_dw:source_addon_floor_panels_0 | вариант 0 | new", "color": "gold"}
