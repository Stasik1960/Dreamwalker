tp @s 71.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90375 | bloodborne_dw:source_bricks_stone_3 | вариант 0 | new", "color": "gold"}
