tp @s 1.5 64.01 517.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 8 | ID 90349 | bloodborne_dw:source_bricks_cracked_bricks_7 | вариант 0 | new", "color": "gold"}
