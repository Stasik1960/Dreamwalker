tp @s 51.5 64.01 502.5 0 19.03443
tellraw @s {"text": "Кирпичная деталь | ID 90320 | bloodborne_dw:source_brick_slab | вариант 0 | new", "color": "gold"}
