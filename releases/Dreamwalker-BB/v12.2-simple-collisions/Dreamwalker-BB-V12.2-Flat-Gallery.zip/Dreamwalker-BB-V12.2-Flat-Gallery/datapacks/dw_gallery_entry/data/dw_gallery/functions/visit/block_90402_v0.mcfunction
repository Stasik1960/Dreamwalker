tp @s 93.5 64.01 903.0 0 14.12943
tellraw @s {"text": "Составное декоративное украшение | ID 90402 | bloodborne_dw:source_buttons_birch_birch_button | вариант 0 | new", "color": "gold"}
