tp @s 107.5 64.01 854.5 0 21.78597
tellraw @s {"text": "Архитектурная плита · верхняя | ID 90212 | bloodborne_dw:source_addon_slabs_5_top | вариант 0 | new", "color": "gold"}
