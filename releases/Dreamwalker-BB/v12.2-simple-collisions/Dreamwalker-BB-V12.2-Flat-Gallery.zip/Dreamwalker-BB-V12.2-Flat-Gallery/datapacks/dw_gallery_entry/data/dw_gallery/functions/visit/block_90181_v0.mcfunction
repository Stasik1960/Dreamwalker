tp @s 11.5 64.01 1153.5 0 15.77499
tellraw @s {"text": "Объёмная декоративная деталь · вариант 1 | ID 90181 | bloodborne_dw:source_addon_pink_glazed_terracotta_0 | вариант 0 | absent", "color": "gold"}
