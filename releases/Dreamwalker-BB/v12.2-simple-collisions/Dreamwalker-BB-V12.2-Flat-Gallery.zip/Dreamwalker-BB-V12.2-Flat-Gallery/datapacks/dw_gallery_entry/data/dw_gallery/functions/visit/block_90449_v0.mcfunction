tp @s 16.5 64.88 547.5 0 14.03624
tellraw @s {"text": "Кирпичная кладка | ID 90449 | bloodborne_dw:source_cracked_polished_blackstone_bricks | вариант 0 | new", "color": "gold"}
