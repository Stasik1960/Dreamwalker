tp @s 51.5 64.01 903.0 0 22.1421
tellraw @s {"text": "Архитектурная плита · вариант 3 | ID 90200 | bloodborne_dw:source_addon_slabs_1_2 | вариант 0 | new", "color": "gold"}
