tp @s 3.0 64.01 982.0 0 22.08447
tellraw @s {"text": "Архитектурная плита · вариант 13 | ID 90196 | bloodborne_dw:source_addon_slabs_12 | вариант 0 | new", "color": "gold"}
