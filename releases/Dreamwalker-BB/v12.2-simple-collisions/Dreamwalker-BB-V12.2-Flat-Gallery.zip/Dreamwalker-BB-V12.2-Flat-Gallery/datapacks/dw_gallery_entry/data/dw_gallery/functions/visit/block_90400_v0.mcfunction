tp @s 16.5 64.88 868.5 0 14.03624
tellraw @s {"text": "Каменный мемориал со свечами | ID 90400 | bloodborne_dw:source_brown_terracotta | вариант 0 | new", "color": "gold"}
