tp @s 21.5 64.03625 492.5 0 14.03624
tellraw @s {"text": "Пучок травы · вариант 5 | ID 90148 | bloodborne_dw:source_addon_grass_4 | вариант 0 | new", "color": "gold"}
