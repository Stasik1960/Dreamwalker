tp @s 41.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Плотная тёмная кирпичная кладка | ID 90419 | bloodborne_dw:source_coarse_dirt | вариант 0 | new", "color": "gold"}
