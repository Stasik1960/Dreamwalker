tp @s 61.5 64.01 512.5 0 15.77499
tellraw @s {"text": "Кирпичная кладка · вариант 4 | ID 90345 | bloodborne_dw:source_bricks_cracked_bricks_3 | вариант 0 | new", "color": "gold"}
