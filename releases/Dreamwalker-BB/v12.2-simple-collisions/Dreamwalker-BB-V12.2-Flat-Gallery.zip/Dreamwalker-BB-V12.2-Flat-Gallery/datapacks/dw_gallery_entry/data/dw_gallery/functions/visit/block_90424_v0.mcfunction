tp @s 61.5 64.01 527.5 0 15.77499
tellraw @s {"text": "Ступенчатый модуль | ID 90424 | bloodborne_dw:source_cobbled_deepslate_stairs_e | вариант 0 | new", "color": "gold"}
