tp @s 66.5 64.01 502.5 0 15.77499
tellraw @s {"text": "Кирпичная деталь · наклон 180° | ID 90322 | bloodborne_dw:source_brick_stairs | вариант 1 | new", "color": "gold"}
