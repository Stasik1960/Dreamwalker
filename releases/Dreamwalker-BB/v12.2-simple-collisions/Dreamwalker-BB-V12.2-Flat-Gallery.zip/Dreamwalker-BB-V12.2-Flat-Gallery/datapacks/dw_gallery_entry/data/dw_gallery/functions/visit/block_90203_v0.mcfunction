tp @s 66.5 64.01 492.5 0 21.39897
tellraw @s {"text": "Архитектурная плита · вариант 7 | ID 90203 | bloodborne_dw:source_addon_slabs_1_6 | вариант 0 | new", "color": "gold"}
