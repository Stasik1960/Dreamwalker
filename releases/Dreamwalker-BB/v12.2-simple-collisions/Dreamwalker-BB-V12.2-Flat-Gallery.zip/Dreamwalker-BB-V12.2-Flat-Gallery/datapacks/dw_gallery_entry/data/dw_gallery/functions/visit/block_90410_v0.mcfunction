tp @s 56.0 64.01 403.0 0 15.77499
tellraw @s {"text": "Широкий ступенчатый каменный карниз | ID 90410 | bloodborne_dw:source_chiseled_deepslate | вариант 0 | new", "color": "gold"}
