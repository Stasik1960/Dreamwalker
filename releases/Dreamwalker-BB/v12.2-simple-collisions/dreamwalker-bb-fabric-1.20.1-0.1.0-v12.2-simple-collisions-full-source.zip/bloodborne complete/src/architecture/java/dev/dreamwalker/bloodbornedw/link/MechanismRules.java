package dev.dreamwalker.bloodbornedw.link;

import dev.dreamwalker.bloodbornedw.DreamwalkerBb;
import dev.dreamwalker.bloodbornerp.object.RpObjectEntity;
import java.util.*;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.*;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.world.PersistentState;

/** Stable creation order, shared persistent source flags, and ordered per-target delivery. */
public final class MechanismRules extends PersistentState {
    public enum Condition { ANY, ALL }
    public enum Effect { TOGGLE, OPEN, CLOSE, PULSE }
    public static final int LIMIT=4096,MEMBERS=64;
    public static final class Rule {
        public final UUID id;public final long order;public String name;public Condition condition=Condition.ANY;public Effect effect=Effect.TOGGLE;
        public final LinkedHashMap<UUID,MechanismLinks.TargetRef> sources=new LinkedHashMap<>();
        public final LinkedHashMap<String,MechanismLinks.TargetRef> targets=new LinkedHashMap<>();
        public boolean satisfied,incomplete;
        Rule(UUID id,long order,String name){this.id=id;this.order=order;this.name=name;}
    }
    private record Pending(long number,MechanismLinks.TargetRef target,Effect effect,ObjectPolicies.Initiator initiator,UUID rule){}
    private final LinkedHashMap<UUID,Rule> rules=new LinkedHashMap<>();
    private final Map<UUID,Boolean> flags=new LinkedHashMap<>();
    private final Map<UUID,ObjectPolicies.Initiator> initiators=new LinkedHashMap<>();
    private final Set<UUID> imported=new LinkedHashSet<>();
    private final Set<String> importedPending=new LinkedHashSet<>();
    private final ArrayDeque<Pending> queue=new ArrayDeque<>();
    private long sequence,creation;private boolean delivering;
    public static MechanismRules get(MinecraftServer server){var s=server.getOverworld().getPersistentStateManager().getOrCreate(MechanismRules::fromNbt,MechanismRules::new,"bloodborne_dw_mechanism_rules");s.importLegacy(MechanismState.get(server));return s;}
    private void importLegacy(MechanismState old){
        for(var lever:old.levers.values())if(!imported.contains(lever.id)&&rules.size()<LIMIT){imported.add(lever.id);if(!lever.targets.isEmpty()){Rule r=new Rule(lever.id,++creation,"Связи V9");r.sources.put(lever.id,new MechanismLinks.TargetRef(MechanismLinks.Kind.RP,lever.dimension,lever.id,lever.pos,lever.asset));for(String key:lever.targets){var t=old.targets.get(key);if(t!=null)r.targets.put(key,t.ref);}rules.put(r.id,r);flags.putIfAbsent(lever.id,false);}markDirty();}
        for(var target:old.targets.values())if(target.pending&&importedPending.add(target.ref.key())){int count=target.pulseOnly?(int)Math.min(target.pendingPulses,MEMBERS):1;for(int i=0;i<count;i++)enqueue(target.ref,target.pulseOnly?Effect.PULSE:target.unresolvedFlip?Effect.TOGGLE:target.desired?Effect.OPEN:Effect.CLOSE,null,new UUID(0,0));target.pending=false;target.pendingPulses=0;old.markDirty();markDirty();}
    }
    public static void noteInitiator(RpObjectEntity source,ServerPlayerEntity player){var s=get(player.getServer());if((s.initiators.size()<LIMIT||s.initiators.containsKey(source.getUuid()))&&(s.flags.size()<LIMIT||s.flags.containsKey(source.getUuid()))){s.flags.putIfAbsent(source.getUuid(),false);s.initiators.put(source.getUuid(),new ObjectPolicies.Initiator(player.getUuid(),player.getGameProfile().getName()));s.markDirty();}}
    public static void legacyLinked(RpObjectEntity source,MechanismLinks.TargetRef ref){var s=get(((ServerWorld)source.getWorld()).getServer());Rule r=s.rules.get(source.getUuid());if(r==null&&s.rules.size()<LIMIT){r=new Rule(source.getUuid(),++s.creation,"Простая связь");r.sources.put(source.getUuid(),MechanismLinks.TargetRef.rp(source));s.rules.put(r.id,r);}if(r!=null&&r.targets.size()<MEMBERS)r.targets.put(ref.key(),ref);s.flags.putIfAbsent(source.getUuid(),false);s.imported.add(source.getUuid());s.markDirty();}
    public static void legacyUnlinked(RpObjectEntity source,String key){var s=get(((ServerWorld)source.getWorld()).getServer());Rule r=s.rules.get(source.getUuid());if(r!=null){r.targets.remove(key);if(r.targets.isEmpty())s.rules.remove(r.id);s.markDirty();}}
    public static Rule create(ServerPlayerEntity player,String name){var s=get(player.getServer());if(s.rules.size()>=LIMIT)return null;Rule r=new Rule(UUID.randomUUID(),++s.creation,name.isBlank()?"Правило "+s.creation:name.substring(0,Math.min(80,name.length())));s.rules.put(r.id,r);s.markDirty();return r;}
    /** A builder form is never a persistent rule until its complete composition is saved. */
    public static Rule draft(String name){return new Rule(UUID.randomUUID(),0,name.isBlank()?"Новое правило":name.substring(0,Math.min(80,name.length())));}
    public static Rule copy(Rule original){Rule r=new Rule(original.id,original.order,original.name);r.condition=original.condition;r.effect=original.effect;r.sources.putAll(original.sources);r.targets.putAll(original.targets);r.satisfied=original.satisfied;r.incomplete=original.incomplete;return r;}
    public static String version(Rule r){if(r==null)return "none";String data=r.name+"|"+r.condition+"|"+r.effect+"|"+r.sources.values().stream().map(t->t.key()+"|"+t.registryId()).toList()+"|"+r.targets.values().stream().map(t->t.key()+"|"+t.registryId()).toList()+"|"+r.incomplete;try{return HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(data.getBytes(java.nio.charset.StandardCharsets.UTF_8)));}catch(java.security.NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}}
    public static boolean draftAdd(ServerPlayerEntity p,Rule r,MechanismLinks.TargetRef ref,boolean source){
        if(r==null||!validMember(p,ref,source))return false;
        if(source){if(r.sources.size()>=MEMBERS&&!r.sources.containsKey(ref.instance()))return false;r.sources.put(ref.instance(),ref);}
        else{if(r.targets.size()>=MEMBERS&&!r.targets.containsKey(ref.key()))return false;r.targets.put(ref.key(),ref);}
        r.incomplete=false;return true;
    }
    private static boolean validMember(ServerPlayerEntity p,MechanismLinks.TargetRef ref,boolean source){
        var w=world(p.getServer(),ref.dimension());if(w==null||!builder(p))return false;var entity=ref.kind()==MechanismLinks.Kind.RP?w.getEntity(ref.instance()):null;
        var pos=entity==null?net.minecraft.util.math.BlockPos.fromLong(ref.root()):entity.getBlockPos();if(!w.isChunkLoaded(pos)||!dev.dreamwalker.bloodbornedw.architecture.BuildPermissions.canEdit(w,p,pos))return false;
        return source?entity instanceof RpObjectEntity rp&&!rp.isRemoved()&&rp.assetId().equals(ref.registryId())&&rp.isMechanism():MechanismLinks.inspect(p.getServer(),ref).availability()==MechanismLinks.Availability.LOADED;
    }
    public static List<String> conflicts(MinecraftServer server,Rule draft){return list(server).stream().filter(r->!r.id.equals(draft.id)&&r.targets.keySet().stream().anyMatch(draft.targets::containsKey)).map(r->"№"+r.order+" "+r.name+" ("+r.effect+")").toList();}
    public static boolean saveDraft(ServerPlayerEntity p,Rule draft,boolean confirmConflicts){
        var s=get(p.getServer());if(!builder(p)||draft==null||draft.sources.isEmpty()||draft.targets.isEmpty()||draft.sources.size()>MEMBERS||draft.targets.size()>MEMBERS||draft.sources.values().stream().anyMatch(t->!validMember(p,t,true))||draft.targets.values().stream().anyMatch(t->!validMember(p,t,false)))return false;
        if(draft.effect==Effect.PULSE&&draft.targets.values().stream().anyMatch(t->!MechanismLinks.inspect(p.getServer(),t).pulseOnly()))return false;
        if(!confirmConflicts&&!conflicts(p.getServer(),draft).isEmpty())return false;
        Rule old=s.rules.get(draft.id);if(old==null&&(draft.order!=0||s.rules.size()>=LIMIT))return false;
        long missing=draft.sources.keySet().stream().filter(id->!s.flags.containsKey(id)).count();if(s.flags.size()+missing>LIMIT)return false;
        Rule saved=new Rule(draft.id,old==null?++s.creation:old.order,draft.name.substring(0,Math.min(80,draft.name.length())));saved.condition=draft.condition;saved.effect=draft.effect;saved.sources.putAll(draft.sources);saved.targets.putAll(draft.targets);saved.sources.keySet().forEach(id->s.flags.putIfAbsent(id,false));saved.satisfied=s.all(saved);removeLegacyMembers(p,old,saved.targets.keySet());s.queue.removeIf(pending->pending.rule().equals(saved.id)&&!saved.targets.containsKey(pending.target().key()));s.rules.put(saved.id,saved);s.markDirty();return true;
    }
    /** Keep old lever/entity lists from resurrecting removed members on a later load. */
    private static void removeLegacyMembers(ServerPlayerEntity p,Rule old,Set<String> retained){if(old==null)return;var legacy=MechanismState.get(p.getServer()).levers.get(old.id);if(legacy==null)return;var w=world(p.getServer(),legacy.dimension);var entity=w==null?null:w.getEntity(old.id);if(entity instanceof RpObjectEntity source)for(var ref:List.copyOf(old.targets.values()))if(!retained.contains(ref.key())){if(ref.kind()==MechanismLinks.Kind.RP)source.removeLink(ref.instance());else MechanismLinks.unlink(source,ref.key());}legacy.targets.removeIf(key->!retained.contains(key));MechanismState.get(p.getServer()).markDirty();}
    public static List<Rule> list(MinecraftServer server){return List.copyOf(get(server).rules.values());}
    static void expandMembers(MinecraftServer server,Set<UUID> members){for(Rule rule:get(server).rules.values())if(rule.sources.keySet().stream().anyMatch(members::contains)||rule.targets.values().stream().anyMatch(t->members.contains(t.instance()))){members.addAll(rule.sources.keySet());rule.targets.values().forEach(t->members.add(t.instance()));}}
    static boolean removeMembers(MinecraftServer server,Set<UUID> members){var state=get(server);List<Rule> removed=state.rules.values().stream().filter(r->r.sources.keySet().stream().anyMatch(members::contains)||r.targets.values().stream().anyMatch(t->members.contains(t.instance()))).toList();if(removed.isEmpty())return false;Set<UUID> ids=new HashSet<>();for(Rule rule:removed){state.rules.remove(rule.id);ids.add(rule.id);}state.queue.removeIf(p->ids.contains(p.rule()));members.forEach(id->{state.flags.remove(id);state.initiators.remove(id);});for(Rule rule:removed)for(var source:rule.sources.values())for(String key:rule.targets.keySet())MechanismLinks.forgetLegacyPair(server,source,key);state.markDirty();return true;}
    public static Rule rule(MinecraftServer server,UUID id){return get(server).rules.get(id);}
    public static boolean flag(MinecraftServer server,UUID id){return get(server).flags.getOrDefault(id,false);}
    public static boolean configure(ServerPlayerEntity player,UUID id,String name,Condition condition,Effect effect){var s=get(player.getServer());Rule r=s.rules.get(id);if(r==null||!builder(player)||r.incomplete&&!player.hasPermissionLevel(2))return false;if(effect==Effect.PULSE&&r.targets.values().stream().anyMatch(t->!MechanismLinks.inspect(player.getServer(),t).pulseOnly()))return false;r.name=name.substring(0,Math.min(80,name.length()));r.condition=condition;r.effect=effect;r.satisfied=s.all(r);s.markDirty();return true;}
    public static boolean add(ServerPlayerEntity player,UUID id,MechanismLinks.TargetRef ref,boolean source){var s=get(player.getServer());Rule r=s.rules.get(id);if(r==null||!builder(player)||r.incomplete&&!player.hasPermissionLevel(2))return false;if(source&&!s.flags.containsKey(ref.instance())&&s.flags.size()>=LIMIT)return false;var status=MechanismLinks.inspect(player.getServer(),ref);if(source){var world=world(player.getServer(),ref.dimension());if(world==null||!(world.getEntity(ref.instance()) instanceof RpObjectEntity rp)||!rp.isMechanism()||r.sources.size()>=MEMBERS)return false;r.sources.put(ref.instance(),ref);s.flags.putIfAbsent(ref.instance(),false);}else{if(status.availability()!=MechanismLinks.Availability.LOADED||r.targets.size()>=MEMBERS)return false;if(!status.pulseOnly()&&r.effect==Effect.PULSE)return false;r.targets.put(ref.key(),ref);}r.incomplete=false;r.satisfied=s.all(r);s.markDirty();return true;}
    public static boolean removeMember(ServerPlayerEntity player,UUID id,String key,boolean source){
        var s=get(player.getServer());Rule r=s.rules.get(id);if(r==null||!builder(player)||r.incomplete&&!player.hasPermissionLevel(2))return false;
        var oldSources=List.copyOf(r.sources.values());var oldTargets=List.copyOf(r.targets.values());
        boolean changed=source?r.sources.entrySet().removeIf(e->e.getValue().key().equals(key)):r.targets.remove(key)!=null;
        if(!changed)return false;
        for(var a:oldSources)for(var b:oldTargets)if(!r.sources.containsKey(a.instance())||!r.targets.containsKey(b.key()))MechanismLinks.forgetLegacyPair(player.getServer(),a,b.key());
        s.queue.removeIf(p->p.rule().equals(id)&&(r.sources.isEmpty()||!r.targets.containsKey(p.target().key())));
        if(r.sources.isEmpty()||r.targets.isEmpty())s.rules.remove(id);else{r.incomplete=false;r.satisfied=s.all(r);}
        s.markDirty();return true;
    }
    public static boolean delete(ServerPlayerEntity player,UUID id){
        if(!builder(player))return false;var s=get(player.getServer());Rule r=s.rules.remove(id);if(r==null)return false;
        for(var source:r.sources.values())for(String key:r.targets.keySet())MechanismLinks.forgetLegacyPair(player.getServer(),source,key);
        s.queue.removeIf(p->p.rule().equals(id));s.markDirty();return true;
    }
    public static List<UUID> affected(MinecraftServer server,UUID rule){var s=get(server);Rule r=s.rules.get(rule);return r==null?List.of():s.rules.values().stream().filter(q->q.condition==Condition.ALL&&q.sources.keySet().stream().anyMatch(r.sources::containsKey)).map(q->q.id).toList();}
    public static boolean reset(ServerPlayerEntity player,UUID id){var s=get(player.getServer());Rule r=s.rules.get(id);if(!builder(player)||r==null)return false;for(UUID source:r.sources.keySet())s.flags.put(source,false);var initiator=new ObjectPolicies.Initiator(player.getUuid(),player.getGameProfile().getName());for(Rule q:s.rules.values())if(q.condition==Condition.ALL&&q.sources.keySet().stream().anyMatch(r.sources::containsKey))s.evaluate(q,initiator);s.markDirty();retry(player.getServer(),256);return true;}
    public static void pulse(RpObjectEntity source){if(!(source.getWorld() instanceof ServerWorld world))return;var s=get(world.getServer());UUID id=source.getUuid();if(s.flags.size()<LIMIT||s.flags.containsKey(id))s.flags.put(id,!s.flags.getOrDefault(id,false));ObjectPolicies.Initiator initiator=s.initiators.remove(id);
        for(Rule r:s.rules.values())if(r.sources.containsKey(id)){if(r.incomplete||r.targets.isEmpty())continue;if(r.condition==Condition.ANY){for(var ref:r.targets.values())s.enqueue(ref,r.effect,initiator,r.id);}else s.evaluate(r,initiator);}s.markDirty();retry(world.getServer(),256);
        }
    private boolean all(Rule r){return !r.incomplete&&!r.sources.isEmpty()&&r.sources.keySet().stream().allMatch(id->flags.getOrDefault(id,false));}
    private void evaluate(Rule r,ObjectPolicies.Initiator initiator){boolean value=all(r);if(value==r.satisfied)return;r.satisfied=value;if(r.incomplete)return;Effect action=r.effect==Effect.TOGGLE?(value?Effect.OPEN:Effect.CLOSE):r.effect;if(value||r.effect==Effect.TOGGLE)for(var ref:r.targets.values()){boolean pulse=MechanismLinks.Kind.RP==ref.kind()&&ref.registryId().equals("wood_gate");if(pulse&&!value)continue;enqueue(ref,pulse?Effect.PULSE:action,initiator,r.id);}}
    private void enqueue(MechanismLinks.TargetRef target,Effect effect,ObjectPolicies.Initiator initiator,UUID rule){if(queue.size()>=LIMIT){DreamwalkerBb.LOG.warn("Mechanism effect queue is full; refusing target {}", target.instance());return;}if(target.kind()==MechanismLinks.Kind.RP&&target.registryId().equals("wood_gate"))effect=Effect.PULSE;queue.addLast(new Pending(++sequence,target,effect,initiator,rule));markDirty();}
    public static int retry(MinecraftServer server,int limit){var s=get(server);if(s.delivering||limit<=0)return 0;s.delivering=true;Set<String> blocked=new HashSet<>();int count=0;
        try{for(Pending p:List.copyOf(s.queue)){if(count>=limit)break;if(!s.queue.contains(p)||blocked.contains(p.target().key()))continue;count++;var status=MechanismLinks.inspect(server,p.target());if(status.availability()==MechanismLinks.Availability.STALE){s.queue.remove(p);s.markDirty();continue;}if(status.availability()!=MechanismLinks.Availability.LOADED||status.locked()){blocked.add(p.target().key());continue;}ServerWorld world=world(server,p.target().dimension());boolean open=p.effect()==Effect.OPEN||p.effect()==Effect.TOGGLE&&!status.open();
            if(p.target().kind()==MechanismLinks.Kind.RP&&world.getEntity(p.target().instance()) instanceof RpObjectEntity rp&&rp.animationBusy()){
                if(p.effect()==Effect.CLOSE){s.queue.removeIf(other->other!=p&&other.target().key().equals(p.target().key()));blocked.add(p.target().key());}
                else{s.queue.remove(p);}
                s.markDirty();continue;
            }
            ObjectPolicies.context(world,p.target(),p.initiator());boolean accepted=false;
            try{accepted=MechanismLinks.applyEffect(server,p.target(),open,p.effect()==Effect.PULSE);}catch(RuntimeException failure){DreamwalkerBb.LOG.error("Mechanism effect failed for {}; pending operation retained", p.target().instance(), failure);}finally{ObjectPolicies.context(world,p.target(),null);}

            if(accepted){s.queue.remove(p);s.markDirty();}else blocked.add(p.target().key());}
        }finally{s.delivering=false;}return count;
    }
    public static boolean pending(MinecraftServer server,MechanismLinks.TargetRef ref){return get(server).queue.stream().anyMatch(p->p.target().key().equals(ref.key()));}
    public static void removed(MinecraftServer server,MechanismLinks.TargetRef ref){var s=get(server);for(Rule r:s.rules.values()){boolean source=r.sources.remove(ref.instance())!=null;boolean target=r.targets.remove(ref.key())!=null;if(source&&r.condition==Condition.ALL)r.incomplete=true;if(target&&r.condition==Condition.ALL)r.incomplete=true;if(source||target)r.satisfied=s.all(r);}Set<UUID> pruned=new HashSet<>();s.rules.values().removeIf(r->{boolean remove=r.condition==Condition.ANY&&(r.sources.isEmpty()||r.targets.isEmpty());if(remove)pruned.add(r.id);return remove;});s.queue.removeIf(p->p.target().key().equals(ref.key())||pruned.contains(p.rule()));s.flags.remove(ref.instance());s.initiators.remove(ref.instance());s.markDirty();ObjectPolicies.removed(server,ref);}
    public static Map<String,Object> view(MinecraftServer server,Rule r){return view(server,r,0);}
    public static Map<String,Object> view(MinecraftServer server,Rule r,int affectedPage){var s=get(server);Map<String,Object> out=new LinkedHashMap<>();out.put("id",r.id.toString());out.put("order",r.order);out.put("name",r.name);out.put("condition",r.condition.name());out.put("effect",r.effect.name());out.put("incomplete",r.incomplete);out.put("satisfied",r.satisfied);out.put("active",r.sources.keySet().stream().filter(i->s.flags.getOrDefault(i,false)).count());out.put("total",r.sources.size());out.put("sources",r.sources.values().stream().map(t->member(server,t,true)).toList());out.put("targets",r.targets.values().stream().map(t->member(server,t,false)).toList());var related=affected(server,r.id);int pages=Math.max(1,(related.size()+63)/64),page=Math.max(0,Math.min(pages-1,affectedPage));var displayed=related.stream().skip(page*64L).limit(64).toList();out.put("affectedReset",displayed.stream().map(UUID::toString).toList());out.put("affectedResetNames",displayed.stream().map(id->s.rules.get(id).name).toList());out.put("affectedResetTotal",related.size());out.put("affectedResetPage",page);out.put("affectedResetPages",pages);return out;}
    private static Map<String,Object> member(MinecraftServer server,MechanismLinks.TargetRef ref,boolean source){var status=MechanismLinks.inspect(server,ref);if(source){var w=world(server,ref.dimension());var e=w==null?null:w.getEntity(ref.instance());status=new MechanismLinks.Status(e instanceof RpObjectEntity rp&&rp.isMechanism()?MechanismLinks.Availability.LOADED:MechanismLinks.Availability.UNLOADED,false,false);}var id=new Identifier(ref.kind()==MechanismLinks.Kind.RP?"bloodborne_rp:"+ref.registryId():ref.registryId());var entry=dev.dreamwalker.bloodbornedw.debug.DebugCatalogue.entry(id);var out=new LinkedHashMap<String,Object>();out.put("name",entry==null?ref.registryId():entry.name());out.put("key",ref.key());out.put("instance",ref.instance().toString());out.put("type",ObjectPolicies.type(ref));out.put("registry",ref.registryId());out.put("position",net.minecraft.util.math.BlockPos.fromLong(ref.root()).toShortString());out.put("active",source&&flag(server,ref.instance()));out.put("availability",status.availability().name());out.put("pending",pending(server,ref));out.put("pulseOnly",status.pulseOnly());out.put("supportedAction",status.pulseOnly()?"Одиночная анимация":"Открыть / закрыть");out.put("conflictingRules",list(server).stream().filter(r->r.targets.containsKey(ref.key())).count());return out;}
    private static boolean builder(ServerPlayerEntity p){return dev.dreamwalker.bloodbornedw.architecture.BuildPermissions.canEdit(p);}
    private static ServerWorld world(MinecraftServer server,String dimension){return server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(dimension)));}
    public static MechanismRules fromNbt(NbtCompound n){MechanismRules s=new MechanismRules();s.sequence=Math.max(0,n.getLong("Sequence"));s.creation=Math.max(0,n.getLong("Creation"));try{for(NbtElement raw:n.getList("Imported",11)){if(s.imported.size()>=LIMIT)break;var tag=new NbtCompound();tag.put("Id",raw);s.imported.add(tag.getUuid("Id"));}for(NbtElement raw:n.getList("Flags",10)){if(s.flags.size()>=LIMIT)break;var t=(NbtCompound)raw;s.flags.put(t.getUuid("Id"),t.getBoolean("Active"));if(t.contains("Initiator",10)){var i=ObjectPolicies.Initiator.read(t.getCompound("Initiator"));if(i!=null)s.initiators.put(t.getUuid("Id"),i);}}
            for(NbtElement raw:n.getList("Rules",10)){if(s.rules.size()>=LIMIT)break;var t=(NbtCompound)raw;Rule r=new Rule(t.getUuid("Id"),t.getLong("Order"),t.getString("Name"));r.condition=Condition.valueOf(t.getString("Condition"));r.effect=Effect.valueOf(t.getString("Effect"));r.satisfied=t.getBoolean("Satisfied");r.incomplete=t.getBoolean("Incomplete");for(NbtElement v:t.getList("Sources",10)){if(r.sources.size()>=MEMBERS)break;var ref=MechanismLinks.TargetRef.read((NbtCompound)v);r.sources.put(ref.instance(),ref);}for(NbtElement v:t.getList("Targets",10)){if(r.targets.size()>=MEMBERS)break;var ref=MechanismLinks.TargetRef.read((NbtCompound)v);r.targets.put(ref.key(),ref);}s.rules.put(r.id,r);}
            for(NbtElement raw:n.getList("Queue",10)){if(s.queue.size()>=LIMIT)break;var t=(NbtCompound)raw;s.queue.add(new Pending(t.getLong("Number"),MechanismLinks.TargetRef.read(t.getCompound("Target")),Effect.valueOf(t.getString("Effect")),ObjectPolicies.Initiator.read(t.getCompound("Initiator")),t.getUuid("Rule")));}
        }catch(RuntimeException failure){DreamwalkerBb.LOG.warn("Malformed saved mechanism rule; valid preceding entries retained", failure);}var sorted=s.rules.values().stream().sorted(Comparator.comparingLong(r->r.order)).toList();s.rules.clear();sorted.forEach(r->s.rules.put(r.id,r));return s;}
    @Override public NbtCompound writeNbt(NbtCompound n){n.putInt("Schema",1);n.putLong("Sequence",sequence);n.putLong("Creation",creation);NbtList a=new NbtList(),b=new NbtList(),c=new NbtList(),d=new NbtList();for(UUID id:imported){var t=new NbtCompound();t.putUuid("Id",id);a.add(t.get("Id"));}flags.forEach((id,value)->{var t=new NbtCompound();t.putUuid("Id",id);t.putBoolean("Active",value);if(initiators.containsKey(id))t.put("Initiator",initiators.get(id).write());b.add(t);});for(Rule r:rules.values()){var t=new NbtCompound();t.putUuid("Id",r.id);t.putLong("Order",r.order);t.putString("Name",r.name);t.putString("Condition",r.condition.name());t.putString("Effect",r.effect.name());t.putBoolean("Satisfied",r.satisfied);t.putBoolean("Incomplete",r.incomplete);NbtList src=new NbtList(),dst=new NbtList();r.sources.values().forEach(v->src.add(v.write()));r.targets.values().forEach(v->dst.add(v.write()));t.put("Sources",src);t.put("Targets",dst);c.add(t);}for(Pending p:queue){var t=new NbtCompound();t.putLong("Number",p.number());t.put("Target",p.target().write());t.putString("Effect",p.effect().name());t.putUuid("Rule",p.rule());if(p.initiator()!=null)t.put("Initiator",p.initiator().write());d.add(t);}n.put("Imported",a);n.put("Flags",b);n.put("Rules",c);n.put("Queue",d);return n;}
}
