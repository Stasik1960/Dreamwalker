V11.3 native QA evidence, bound to production6a45 and QA5d5e.
All244 capture PNG hashes/signatures/dimensions were verified; native dog4 and a bounded activity/B selection are included.
Full240 native activity states and per-PNG metadata are included; four contact sheets are lossy navigation previews.
Dog rear/west prove static presence; east/north are occluded. No hiding/restore animation claim.
Native profiler: 659.50s / 13191ticks / 20.00TPS with actual119 saved catalogue objects, additional QA fixtures and two real clients.
The separately delivered fresh row gallery contains120; the activity scene is a saved manual QA world.
No accounts, profiles, complete logs, QA mods/worlds or production changes are included.
