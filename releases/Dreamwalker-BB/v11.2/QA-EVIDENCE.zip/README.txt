Dreamwalker BB V11.2 compact QA evidence.
Bound production C285 / QA5d5e. All listed native PNG signatures, dimensions, sizes and SHA256 were rechecked.
Raw PNGs remain in isolated local build runs. This bundle includes their per-frame hashes, native state output, inputs, reviewed findings, exact F8 events and small lossy navigation contacts.
Contact JPGs are derived previews; original review reports distinguish raw-frame and contact-sheet review.
480 BASE/ALT stills cover120 exhibits per profile. 18 close stills resolve selected detail limits; dog91007 remains obscured/unconfirmed, not a proved missing asset.
Door cycle240 and closed-rejoin120 are discrete frame/state evidence, not continuous video. First closed-rejoin action was about28.435s after advancements; <=2s was not tested.
Manual held90006 climb and save/rejoin acceptance remain pending. Vanilla95s/1901ticks/20.01TPS describes119 remaining catalogue exhibits plus ladder/support fixtures and two real clients; export had ended.
No user profiles, accounts, complete logs, QA worlds, QA mods or production changes are included.
