execute as @a[tag=!dw_gallery_entered] run gamemode creative @s
execute as @a[tag=!dw_gallery_entered] run give @s bloodborne_dw:composite_builder
execute as @a[tag=!dw_gallery_entered] run tp @s 0.5 64 -5.5 0 0
tag @a[tag=!dw_gallery_entered] add dw_gallery_entered
