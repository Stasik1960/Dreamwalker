# Dreamwalker diagnostics session

Session UUID: 8911e9c3-da6a-4121-ae9e-9787943bfd3b
Capture: STOPPED / NO ACTIVE RECORDING; reason: AUTO_DURATION_EXPIRED
Started: 2026-10-09T23:12:18.407029800Z; requested duration: 60 seconds
Observed duration: 60.036 seconds

Events: 2 observed, 2 retained, 0 dropped.
Distinct error keys: 0; repeated occurrences are counted in errors.json.
Object snapshots: 0 retained; full NBT is never captured.

Server ticks: 1201 observed; ticks over 50 ms: 1.
Tick mean / p95 / p99: 2.964 ms / 11.264 ms / 15.333 ms.
Mean/count cover observed ticks; p95/p99 use only the retained window. Tick intervals include Fabric END callbacks. Own hook timings can overlap; they are not unique process CPU cost.

Client telemetry: NOT_MEASURED_NO_CLIENT_BATCHES. Graphics settings and frame intervals are in client-batches.json and the separate local client ZIP with the same UUID.
GPU timing: NOT_MEASURED. CPU render submission and FPS do not determine a block's GPU time or exact load percentage.
All-mod / vanilla chunk / DataTracker / TCP traffic: NOT_MEASURED. Network counters include only instrumented custom-channel payload bytes.
JFR reports actual observed GC pauses when available; MXBean collection time is not an STW pause measurement. Client and integrated server may share one PID: do not add their heap/GC values.

Production version: 0.1.0-90009-fix.1; SHA256: 5066ed3b334b4103120932f9be8810d2548230ddbd94984e62780311fbb1793a.
Minecraft/Java/Fabric/mod versions are in environment.json; detailed measurements, retention and unavailable data are in measurements.json. Normal placement refusals are events, not errors. This capture is not manual visual acceptance.
