# Dreamwalker diagnostics session

Session UUID: f8c54a95-5989-4b68-8d5f-d3aca17fb401
Capture: STOPPED / NO ACTIVE RECORDING; reason: AUTO_DURATION_EXPIRED
Started: 2026-10-09T23:31:41.636591600Z; requested duration: 60 seconds
Observed duration: 60.012 seconds

Events: 2 observed, 2 retained, 0 dropped.
Distinct error keys: 0; repeated occurrences are counted in errors.json.
Object snapshots: 0 retained; full NBT is never captured.

Server ticks: 1203 observed; ticks over 50 ms: 2.
Tick mean / p95 / p99: 2.965 ms / 10.293 ms / 31.101 ms.
Mean/count cover observed ticks; p95/p99 use only the retained window. Tick intervals include Fabric END callbacks. Own hook timings can overlap; they are not unique process CPU cost.

Client telemetry: NOT_MEASURED_NO_CLIENT_BATCHES. Graphics settings and frame intervals are in client-batches.json and the separate local client ZIP with the same UUID.
GPU timing: NOT_MEASURED. CPU render submission and FPS do not determine a block's GPU time or exact load percentage.
All-mod / vanilla chunk / DataTracker / TCP traffic: NOT_MEASURED. Network counters include only instrumented custom-channel payload bytes.
JFR reports actual observed GC pauses when available; MXBean collection time is not an STW pause measurement. Client and integrated server may share one PID: do not add their heap/GC values.

Production version: 0.1.0-90009-fix.1; SHA256: 61b206c7bd2d253fbf1387b8d95c7e3663f192759ce4673c808798246e90a4fa.
Minecraft/Java/Fabric/mod versions are in environment.json; detailed measurements, retention and unavailable data are in measurements.json. Normal placement refusals are events, not errors. This capture is not manual visual acceptance.
