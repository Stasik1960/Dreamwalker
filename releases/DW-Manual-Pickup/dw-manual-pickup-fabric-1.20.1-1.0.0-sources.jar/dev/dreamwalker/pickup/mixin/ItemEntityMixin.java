package dev.dreamwalker.pickup.mixin;

import dev.dreamwalker.pickup.PickupService;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin {
    @Inject(method = "onPlayerCollision", at = @At("HEAD"), cancellable = true)
    private void dwManualPickup$blockAutomaticPickup(class_1657 player, CallbackInfo ci) {
        class_1542 item = (class_1542) (Object) this;
        if (!item.method_37908().field_9236 && !PickupService.isPermitted(item, player)) ci.cancel();
    }
}
