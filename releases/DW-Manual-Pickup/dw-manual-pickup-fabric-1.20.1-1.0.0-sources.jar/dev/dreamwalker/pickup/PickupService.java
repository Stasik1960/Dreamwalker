package dev.dreamwalker.pickup;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_238;

public final class PickupService {
    private record Permission(class_1542 item, class_1657 player) {}
    private static final ThreadLocal<Permission> PERMISSION = new ThreadLocal<>();
    private static final Map<class_1657, RequestWindow> REQUESTS = new WeakHashMap<>();
    private static final class RequestWindow { long tick; int count; }

    private PickupService() {}

    /** Server-thread-only burst limit. Allows fast legitimate taps, bounds packet spam. */
    public static boolean acceptRequest(class_1657 player) {
        long tick = player.method_37908().method_8503().method_3780();
        RequestWindow window = REQUESTS.computeIfAbsent(player, ignored -> new RequestWindow());
        if (window.tick != tick) { window.tick = tick; window.count = 0; }
        return ++window.count <= 4;
    }

    public static boolean isPermitted(class_1542 item, class_1657 player) {
        Permission permission = PERMISSION.get();
        return permission != null && permission.item == item && permission.player == player;
    }

    /** Matches the search box in vanilla PlayerEntity.tickMovement, including riding. */
    public static class_238 pickupBox(class_1657 player) {
        class_1297 vehicle = player.method_5854();
        return vehicle != null && !vehicle.method_31481()
                ? player.method_5829().method_991(vehicle.method_5829()).method_1009(1.0, 0.0, 1.0)
                : player.method_5829().method_1009(1.0, 0.5, 1.0);
    }

    public static boolean pickUpNearest(class_1657 player) {
        if (player.method_37908().field_9236 || !player.method_5805() || player.method_7325()) return false;
        var items = player.method_37908().method_8390(class_1542.class, pickupBox(player),
                item -> item.method_5805() && !item.method_6977() && !item.method_6983().method_7960());
        items.sort(Comparator.comparingDouble((class_1542 item) -> item.method_5858(player))
                .thenComparingInt(class_1297::method_5628));
        for (class_1542 item : items) {
            int before = item.method_6983().method_7947();
            Permission previous = PERMISSION.get();
            PERMISSION.set(new Permission(item, player));
            try {
                // Vanilla handles ownership, inventory space, partial stacks, stats and animations.
                item.method_5694(player);
            } finally {
                if (previous == null) PERMISSION.remove(); else PERMISSION.set(previous);
            }
            if (item.method_31481() || item.method_6983().method_7947() < before) return true;
        }
        return false;
    }
}
