package dev.dreamwalker.pickup.client;

import dev.dreamwalker.pickup.ManualPickup;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public final class PickupInput {
    private PickupInput() {}

    public static void onKeyboard(long window, int key, int scanCode, int action) {
        class_310 client = class_310.method_1551();
        if (action == GLFW.GLFW_PRESS && client.field_1690.field_1832.method_1417(key, scanCode)) {
            send(client, window);
        }
    }

    public static void onMouse(long window, int button, int action) {
        class_310 client = class_310.method_1551();
        if (action == GLFW.GLFW_PRESS && client.field_1690.field_1832.method_1433(button)) {
            send(client, window);
        }
    }

    private static void send(class_310 client, long window) {
        if (window != client.method_22683().method_4490() || !client.method_1569()
                || client.field_1755 != null || client.field_1724 == null || client.field_1687 == null
                || !client.field_1724.method_5805() || client.field_1724.method_7325()
                || !ClientPlayNetworking.canSend(ManualPickup.REQUEST)) return;
        ClientPlayNetworking.send(ManualPickup.REQUEST, PacketByteBufs.empty());
    }
}
