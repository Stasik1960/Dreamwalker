# Bloodborne logical ALT visual starter

Use this as a Minecraft 1.20.1 resource pack (`pack_format: 15`). Install the ZIP above the mod's bundled resources.

Every exported ALT model contains editable `bloodborne_polygons`; vertices are `[x, y, z, u, v]` in block coordinates and UV 0..16. Texture slot names (`#t0`, `#t1`, …) map to copied PNGs under `textures/block/logical_alt/`.

To use standard vanilla model elements instead, remove `bloodborne_polygons` and add normal vanilla `elements` to the model JSON. Normal vanilla elements override the custom polygon extension when present. Do not add BASE model paths: this pack intentionally contains ALT-only models.
