Synthetic NightmareRunning gallery: 286 visible logical families, 1160 specimens.
Each root is fixed at Y=64; independent minecraft:white_concrete light pads sit at Y=63.
Pads are separated by at least 12 blocks of void, not a continuous floor; use gallery-positions.json /tp commands.
Oak-sign family markers name each visible family; gallery-markers.json records their readable text.
Use debug-family-map.json with /bloodborne debug target. alt-proof-positions.json contains three physical BASE/ALT pairs.
No city/original world data was read or changed.
