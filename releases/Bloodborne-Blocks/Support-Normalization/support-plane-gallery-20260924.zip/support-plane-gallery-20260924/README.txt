Synthetic NightmareRunning gallery (contract_v2): 47 logical families, 746 specimens.
Hidden compatibility families: 12 (o_c001_a, o_c001_b, o_c008, o_c009_a, o_c009_b, o_c1491, o_c1962, o_c1979, o_c282, o_c471, o_c654, o_dead_tree_planter).
Each root is fixed at Y=64; independent minecraft:white_concrete light pads sit at Y=63.
Pads are separated by at least 12 blocks of void, not a continuous floor; use gallery-positions.json /tp commands.
Oak-sign family markers name each scoped family; hidden compatibility families are explicitly labelled.
Use debug-family-map.json with /bloodborne debug target. alt-proof-positions.json contains three physical BASE/ALT pairs.
No city/original world data was read or changed.
