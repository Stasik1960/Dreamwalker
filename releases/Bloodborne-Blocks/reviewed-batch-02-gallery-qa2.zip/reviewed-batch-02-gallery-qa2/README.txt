Synthetic creative world, 21 active families, 104 specimens; all tree variants x four facings.
Gallery platform: minecraft:white_concrete; source carriers are deliberately excluded.
Install the checkpoint Fabric 1.20.1 JAR. Copy this folder into saves.
Use gallery-positions.json for /tp and /give; compare fresh manual placement with each specimen.
Aim at an object and run /bloodborne debug target (alias: /bloodborne debug). Click the report to copy.
No city data, original source world is never modified.
