"""Recover face UV conventions from retained source quads, with exact signed UVs."""
import json,struct,zipfile
import numpy as np
from prepare_workspace import BASE,RUN,write
from discover_native_windows import rotation,normal,PIVOT,FACE
from analyze_native_geometry import decode


def main():
    preflight=json.loads((RUN/'task09-native-window-preflight.json').read_text(encoding='utf-8'))
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as jar:
        catalog=json.loads(jar.read('assets/bloodborne_dw/native_grid/catalog.json'));raw=jar.read('assets/bloodborne_dw/native_grid/meshes.bin')
        model=json.loads(jar.read('assets/bloodborne_dw/models/remaining/source/minecraft/block/spruce_trapdoor_open.json'))
    offsets=[];cursor=8
    for mesh in catalog['meshes']:
        count=struct.unpack_from('>I',raw,cursor)[0];offsets.append(cursor+4);cursor+=4+139*count
    element=model['elements'][2];lo=np.array(element['from']);hi=np.array(element['to']);conventions={};samples={}
    for window in preflight['windows']:
        effective=np.array(window['root']);r=rotation(-45*window['rotation'])
        for cell in window['cells']:
            start=offsets[cell['mesh']]
            for i,ei in enumerate(cell['matched']):
                if ei!=2:continue
                encoded=raw[start+139*i:start+139*(i+1)];q=decode(encoded);v=np.array(q['vertices'])
                source=((v[:,:3]+np.array(cell['pos'])-effective-PIVOT)@r+PIVOT)*16-np.array([0,16,0]);n=normal(source)
                face=max(FACE,key=lambda f:n[FACE[f][0]]*FACE[f][2]);axis=FACE[face][0];axes=[j for j in range(3) if j!=axis]
                f=element['faces'][face];uv=np.array(f['uv']).reshape(2,2);centre=np.mean(uv,axis=0)
                recovered=centre+(v[:,3:5]-centre)*512/511
                normalized=(recovered-uv[0])/(uv[1]-uv[0]);points=(source[:,axes]-lo[axes])/(hi[axes]-lo[axes])
                coefficients,_,rank,_=np.linalg.lstsq(np.column_stack((points,np.ones(4))),normalized,rcond=None)
                if rank!=3:continue
                snapped=np.rint(coefficients).astype(int)
                assert np.max(abs(coefficients-snapped))<.003,(face,coefficients)
                assert face not in conventions or conventions[face]==snapped.tolist()
                conventions[face]=snapped.tolist();samples[face]=dict(root=window['root'],rotation=window['rotation'],pos=cell['pos'],quad=i,
                    header=struct.unpack_from('>ibbIB',encoded),vertexTail=struct.unpack_from('>III',encoded,31))
        if len(conventions)==6:break
    assert len(conventions)==6,conventions
    document=dict(schemaVersion=1,shrink=511/512,faces=conventions,samples=samples)
    write(RUN/'native-uv-conventions.json',document)
    out=__import__('pathlib').Path(__file__).resolve().parent/'data/native-uv-conventions.json';out.parent.mkdir(exist_ok=True);write(out,document)
    print(json.dumps(document,indent=2))


if __name__=='__main__':main()
