"""Plan the complete lamp migration in memory; write only after ownership and placement gates."""
import argparse,collections,copy,json,math,shutil,subprocess,zipfile
import numpy as np
from world_editor import *
from prefab_template import instantiate,install_empty,shifted_lamp_template
from lantern_owner_edit import remove_owners,physical_state
from owner_shard_edit import Shards,key as owner_uuid
from fix_single_lamp_shards import read as read_shard
from prepare_workspace import RUN,BASE,WORKSPACE,write
D='assets/bloodborne_dw/native_grid/'
DIRS={'overworld':'region','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}
AIR={'minecraft:air','minecraft:cave_air','minecraft:void_air'}

def load(name):return json.loads((RUN/name).read_text(encoding='utf-8'))
def json_boxes(row,key):return [[v.value for v in b.value] for b in row[key].value]
def source_centre(be,owner,archive):
    rows=compound(decode_nbt(be['OwnerDataV1'].value).root)['owners'].value;row=next(compound(r) for r in rows if compound(compound(r)['owner'])['uuid'].value==owner['uuid']);rd=compound(row['rootData']);props={k:v.value for k,v in compound(rd['properties']).items()};spec=json.loads(archive.read('bloodborne_dw/composite/'+owner['registryId'].split(':')[1]+'.json'));v=int(props.get('variant',0))+16*int(props.get('art_bank',0));pose=spec['variants'][v]['poses']['closed'];boxes=pose['selection'];lo=np.min([b['from'] for b in boxes],axis=0)/16;hi=np.max([b['to'] for b in boxes],axis=0)/16;centre=(lo+hi)/2;angle=int(props.get('rotation',0))*math.pi/4;co,si=math.cos(angle),math.sin(angle);rotation=np.array([[co,0,-si],[0,1,0],[si,0,co]]);payload=compound(be['payload']);shift=np.array([v.value for v in payload['SourceShift'].value] if 'SourceShift' in payload else [0,0,0]);centre=rotation@(centre-np.array([.5,0,.5])+shift)+np.array([.5,0,.5]);centre[1]+=sum(payload[k].value for k in ['MountY','VerticalOffset'] if k in payload);centre+=np.array(owner['root']);return list(map(float,centre))

def foreign_physics(editor,pos):
    chunk=pos[0]>>4,pos[2]>>4
    if chunk not in editor.binding_cache:
        file=editor.world/(editor.directory[:-6]+f'data/bloodborne_dw_owner_shards/owners-{chunk[0]}.{chunk[1]}.nbt');bindings={}
        if file.exists():
            n=compound(read_shard(file).root);assert n['Dictionary'].value==1
            for raw in n['cells'].value:
                row=compound(raw);owners=set()
                for raw_ref in row['refs'].value:
                    own,data,shape=raw_ref.value
                    if compound(n['shapeTable'].value[shape])['collision'].value:owners.add(owner_uuid(n['ownerTable'].value[own]))
                bindings[tuple(row['pos'].value)]=owners
        editor.binding_cache[chunk]=bindings
    return bool(editor.binding_cache[chunk].get(tuple(pos),set())-editor.ignored_owners)

def free(editor,pos,mask):
    for offset in mask:
        p=tuple(pos[i]+offset[i] for i in range(3))
        if (editor.dimension,*p) in editor.protected_dynamic or foreign_physics(editor,p):return False
        if editor.chunk(p[0],p[2]) is None or editor.state(*p) not in AIR or editor.entity(*p) is not None or editor.visual(*p) is not None:return False
    return True

def install_new(editor,cells):
    for row in cells:
        p=row['pos'];assert (editor.dimension,*p) not in editor.protected_dynamic and not foreign_physics(editor,p),('Foreign physical/dynamic layer',p)
    install_empty(editor,cells)


def pick_position(editor,desired,*,attached=False):
    mask=[(0,0,0),(0,1,0)]
    offsets=[(x,y,z) for x in range(-2,3) for y in range(-1,2) for z in range(-2,3)];offsets.sort(key=lambda p:(p[0]*p[0]+p[2]*p[2]+2*p[1]*p[1],abs(p[1]),p))
    for offset in offsets:
        if attached and offset!=(0,0,0):continue
        pos=[desired[i]+offset[i] for i in range(3)]
        if free(editor,pos,mask):return pos,offset
    return None,None

_FLOOR_SPECS={}
def grounded(editor,root):
    state=editor.state(root[0],root[1]-1,root[2]);kind,_,raw=state.partition('[')
    if kind in ['minecraft:stone','minecraft:cobblestone','minecraft:stone_bricks']:return True
    if not kind.startswith(('bloodborne_dw:source_bricks','bloodborne_dw:source_andesite','bloodborne_dw:source_polished_andesite','bloodborne_dw:source_snow_height12')):return False
    props=dict(x.split('=') for x in raw[:-1].split(',')) if raw else {};variant=int(props.get('variant',0))+16*int(props.get('art_bank',0))
    if kind not in _FLOOR_SPECS:
        with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:_FLOOR_SPECS[kind]=json.loads(z.read('bloodborne_dw/composite/'+kind.split(':')[1]+'.json'))
    spec=_FLOOR_SPECS[kind]
    if variant>=len(spec['variants']):return False
    return any(b['from'][0]<=8<=b['to'][0] and b['from'][2]<=8<=b['to'][2] and b['from'][1]<16<=b['to'][1] for b in spec['variants'][variant]['poses']['closed']['collision'])

def invalidate_caches(editor):
    changed=set(editor.before);halo={(x+dx,z+dz) for x,z in changed for dx in [-1,0,1] for dz in [-1,0,1]};count=0
    for cx,cz in sorted(halo):
        if editor.chunk(cx*16,cz*16) is None:continue
        root=editor.touch(cx*16,cz*16);root['isLightOn']=Tag(TAG_BYTE,0);count+=1
        if (cx,cz) in changed:root['Heightmaps']=Tag(TAG_COMPOUND,{})
        for section in root['sections'].value:
            for key in ['BlockLight','SkyLight']:compound(section).pop(key,None)
    return dict(lightChunks=count,heightmapChunks=len(changed),engineRebuildRequired=True)

def semantic_gate(editor):
    editor.flush()
    for (cx,cz),before in editor.before.items():
        after=editor.chunks[cx,cz];ignored={'sections','block_entities','DreamwalkerVisuals','Heightmaps','isLightOn'}
        assert {k:v for k,v in before.items() if k not in ignored}=={k:v for k,v in after.items() if k not in ignored}
        oldbe={tuple(compound(b)[k].value for k in 'xyz'):b for b in before['block_entities'].value};newbe={tuple(compound(b)[k].value for k in 'xyz'):b for b in after['block_entities'].value}
        for pos in oldbe.keys()|newbe.keys():
            if pos not in editor.allowed:assert oldbe.get(pos)==newbe.get(pos)
        def native(root):
            result={}
            if 'DreamwalkerVisuals' in root:
                for raw in compound(root['DreamwalkerVisuals'])['Sections'].value:
                    f=compound(raw);sy=f['Y'].value
                    for entry in f['Entries'].value:
                        local=entry&4095;result[(cx*16+(local&15),sy*16+(local>>8),cz*16+((local>>4)&15))]=(entry&0xffffffff)>>12
            return result
        a,b=native(before),native(after)
        for pos in a.keys()|b.keys():
            if pos not in editor.native_changed:assert a.get(pos)==b.get(pos)
        oldsections={compound(s)['Y'].value:s for s in before['sections'].value};newsections={compound(s)['Y'].value:s for s in after['sections'].value}
        for sy in oldsections.keys()|newsections.keys():
            a=oldsections.get(sy);b=newsections.get(sy);aa=compound(a) if a else {};bb=compound(b) if b else {};skip={'block_states','BlockLight','SkyLight'};assert {k:v for k,v in aa.items() if k not in skip}=={k:v for k,v in bb.items() if k not in skip}
            if aa.get('block_states')==bb.get('block_states'):continue
            ap,ai=section_blocks(a) if a is not None and section_blocks(a) else ([Tag(TAG_COMPOUND,{'Name':Tag(TAG_STRING,'minecraft:air')})],[0]*4096);bp,bi=section_blocks(b) if b is not None and section_blocks(b) else ([Tag(TAG_COMPOUND,{'Name':Tag(TAG_STRING,'minecraft:air')})],[0]*4096);names_a=[block_state_key(p) for p in ap];names_b=[block_state_key(p) for p in bp]
            for i in range(4096):
                pos=(cx*16+(i&15),sy*16+(i>>8),cz*16+((i>>4)&15))
                if pos not in editor.allowed:assert names_a[ai[i]]==names_b[bi[i]],pos
    return dict(status='ALL_UNRELATED_BLOCKS_ENTITIES_NATIVE_ENTRIES_AND_CHUNK_DATA_IDENTICAL',chunks=len(editor.before),allowedCells=len(editor.allowed))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output');args=parser.parse_args();source=RUN/'lamps-single-stage1-fixed-v2/bloodborne';editors={dim:Editor(source,directory) for dim,directory in DIRS.items()};layout=json.loads((RUN/'native-overlay'/D/'visual_physics.json').read_text(encoding='utf-8'));catalog_sha=layout['catalogSha256'];owner_index=load('task11-lantern-owner-preflight.json');native_plan=load('task11-native-lantern-removal-plan.json');post_plan=load('task11-post-cleanup-plan.json');static_plan=load('task11-static-removal-plan.json');native_pre=load('task11-native-lantern-preflight.json');post_template=load('task11-post-template.json');lamp_template=load('task11-lamp-template.json');hanging=shifted_lamp_template(lamp_template,1/16);targets={k for k,o in owner_index['owners'].items() if o['registryId']!='bloodborne_dw:source_lantern'};targets.update(k for c in owner_index['cells'] if c['nativeBase']>=0 for k in c['targets']);assert len(targets)==33
    protected={(r['dimension'],*r['pos']) for r in load('task09-native-window-map-plan.json')['cells']}
    bench=json.loads((Path(__file__).resolve().parent/'src/main/resources/bloodborne_dw/repair/native-benches.json').read_text(encoding='utf-8'));bench_templates={t['id']:t for t in bench['templates']}
    for b in load('bench-plan.json')['benchProbes']:
        dim='overworld' if b['dimension']=='minecraft:overworld' else 'bloodborne_old'
        for dx,dy,dz,visual in bench_templates[b['template']]['cells']:protected.add((dim,b['root'][0]+dx,b['root'][1]+dy,b['root'][2]+dz))
    for dim,e in editors.items():e.dimension=dim;e.protected_dynamic=protected;e.ignored_owners={tuple(owner_index['owners'][k]['uuid']) for k in targets};e.binding_cache={}
    singles=[o.copy() for o in static_plan['objects'] if not o['post']]
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        for key in targets:
            owner=owner_index['owners'][key]
            if owner['registryId']=='bloodborne_dw:source_dead_fire_coral_block':continue
            be=editors[owner['dimension']].entity(*owner['root']);centre=source_centre(be,owner,archive);singles.append(dict(dimension=owner['dimension'],registryId=owner['registryId'],root=owner['root'],centre=centre,desiredLamp=[round(centre[i]-[.5,.96875,.5][i]) for i in range(3)]))
    singles += [dict(dimension='overworld' if o['dimension']==0 else 'bloodborne_old',registryId=o['registryId'],root=o['root'],desiredLamp=o['root']) for o in native_pre['groups']];assert len(singles)==560
    for row in post_plan['cells']:
        editor=editors[row['dimension']];p=row['pos'];expected=f"bloodborne_dw:static_architecture_{row['old']//128}";assert editor.state(*p).startswith(expected+'[');assert editor.entity(*p) is None and editor.visual(*p) is None;wet='waterlogged=true' in editor.state(*p);next_index=row['next'];editor.set_state(p,('minecraft:water[level=0]' if wet else 'minecraft:air') if next_index<0 else f"bloodborne_dw:static_architecture_{next_index//128}[part={next_index%128},waterlogged={str(wet).lower()}]")
    for row in post_plan['direct']:
        editor=editors[row['dimension']];p=row['pos'];assert editor.state(*p)==row['state'] and editor.entity(*p) is None and editor.visual(*p) is None;editor.set_state(p,'minecraft:air')
    removal=[]
    for dim,editor in editors.items():
        positions=[tuple(c['pos']) for c in owner_index['cells'] if c['dimension']==dim and targets.intersection(c['targets'])];removal.append(dict(dimension=dim,**remove_owners(editor,positions,targets,layout,catalog_sha)))
    for row in native_plan['cells']:
        editor=editors[row['dimension']];p=row['pos'];assert editor.visual(*p)==row['old'] and editor.entity(*p) is None;index=row['next'];editor.set_state(p,'minecraft:air' if index<0 else physical_state(layout,index));editor.set_visual(p,index,catalog_sha)
    obsolete_lights=[]
    for post in post_plan['posts']:
        editor=editors[post['dimension']];base=post['base']
        for x in range(-1,2):
            for z in range(-1,2):
                for y in range(4,9):
                    p=[base[0]+x,base[1]+y,base[2]+z];state=editor.state(*p)
                    if state.startswith('minecraft:light['):
                        assert editor.entity(*p) is None and editor.visual(*p) is None
                        obsolete_lights.append(dict(dimension=post['dimension'],pos=p,state=state));editor.set_state(p,'minecraft:air')
    installed_posts=[];new_lamps=[];conflicts=[]
    for post in post_plan['posts']:
        dim=post['dimension'];editor=editors[dim];base=post['base'];cut=post['cut'];root=[base[0],base[1]+cut,base[2]];cells=instantiate(post_template,root,dim,cut=cut)
        rotation=0;original_base=list(base)
        try:install_new(editor,cells)
        except AssertionError as error:
            if cut:conflicts.append(dict(kind='post',post=post,error=str(error)));continue
            # A single foliage obstruction may use the same standard on adjacent matching paving.
            below=editor.state(base[0],base[1]-1,base[2]);found=False
            offsets=sorted([(x,y,z) for x in range(-3,4) for y in range(-2,2) for z in range(-3,4) if x or y or z],key=lambda p:(p[0]*p[0]+p[2]*p[2]+2*p[1]*p[1],p))
            for dx,dy,dz in offsets:
                candidate=[original_base[0]+dx,original_base[1]+dy,original_base[2]+dz]
                if not grounded(editor,candidate):continue
                if not all(free(editor,[candidate[0]+side,candidate[1]+5,candidate[2]],[(0,0,0),(0,1,0)]) for side in [-1,1]):continue
                attempt=instantiate(post_template,candidate,dim)
                try:install_new(editor,attempt)
                except AssertionError:continue
                base=candidate;root=candidate;cells=attempt;found=True;break
            if not found:conflicts.append(dict(kind='post',post=post,error=str(error),support=below));continue
        installed_posts.append(dict(post,base=base,sourceBase=original_base,root=root,cells=len(cells),rotation=rotation))
        for side in [-1,1]:
            desired=[base[0]+side,base[1]+5,base[2]] if rotation==0 else [base[0],base[1]+5,base[2]+side];p,offset=pick_position(editor,desired,attached=True)
            if p is None:conflicts.append(dict(kind='attached-lamp',dimension=dim,desired=desired,states=[editor.state(*desired),editor.state(desired[0],desired[1]+1,desired[2])]));continue
            install_new(editor,instantiate(hanging,p,dim));new_lamps.append(dict(dimension=dim,root=p,attached=True,postBase=base))
    for obj in sorted(singles,key=lambda o:(o['dimension'],o['root'])):
        editor=editors[obj['dimension']];p,offset=pick_position(editor,obj['desiredLamp'])
        if p is None:conflicts.append(dict(kind='single-lamp',source=obj));continue
        install_new(editor,instantiate(lamp_template,p,obj['dimension']));new_lamps.append(dict(dimension=obj['dimension'],root=p,attached=False,sourceRoot=obj['root'],offset=offset,registryId=obj['registryId']))
    shard_edits={};shard_gates={}
    if not conflicts:
        removed_uuids={tuple(owner_index['owners'][k]['uuid']) for k in targets};membership_proof=load('task11-managed-shard-membership-proof.json')
        for dim,editor in editors.items():
            store=Shards(source,dim);positions={tuple(c['pos']) for c in owner_index['cells'] if c['dimension']==dim and targets.intersection(c['targets'])};positions.update(tuple(c['pos']) for c in membership_proof['foreignCarrierBindings'] if c['dimension']==dim);store.prune(removed_uuids,positions)
            for pos in positions:
                if editor.state(*pos).startswith('minecraft:light[') and not store.logical(pos):
                    assert editor.entity(*pos) is None and editor.visual(*pos) is None
                    obsolete_lights.append(dict(dimension=dim,pos=pos,state=editor.state(*pos),reason='Retired authoritative lamp binding'));editor.set_state(pos,'minecraft:air')
            actors={}
            for actor in installed_posts+new_lamps:
                if actor['dimension']!=dim:continue
                owner=editor.entity(*actor['root'])['resident'];actors[owner_uuid(owner)]=owner
            members=store.mirror(editor,actors,removed_uuids);shard_edits[dim]=store.prepare(removed_uuids,actors);shard_gates[dim]=dict(status='FOREIGN_AUTHORITATIVE_DATA_IDENTICAL_NEW_MEMBERSHIPS_COMPLETE',newOwners=len(actors),newMemberCells=members,files=len(shard_edits[dim]))
    cache_gates={dim:invalidate_caches(e) for dim,e in editors.items()} if not conflicts else {}
    report=dict(cacheInvalidation=cache_gates,status='CONFLICTS_REQUIRE_REPAIR' if conflicts else 'PLACEMENT_PLAN_PASS_PENDING_SAVED_REGION_GATE',managedRemoval=removal,obsoleteLights=obsolete_lights,posts=len(installed_posts),newLamps=len(new_lamps),retainedExistingCanonicalLamps=559,conflicts=conflicts,installedPosts=installed_posts,lamps=new_lamps,catalogSha256=catalog_sha)
    if not conflicts:report['ownerShardGates']=shard_gates
    if not conflicts:report['semanticGates']={dim:semantic_gate(e) for dim,e in editors.items()}
    write(RUN/'task11-stage2-placement-report.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['installedPosts','lamps','conflicts','obsoleteLights']},indent=2));print('CONFLICTS',len(conflicts));print(json.dumps(conflicts[:8],ensure_ascii=False))
    if args.output:
        assert not conflicts,'No world is written while any placement is unresolved';target=Path(args.output).resolve();assert target.is_relative_to(RUN.resolve()) and not target.exists();subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True);shutil.copytree(source,target)
        for dim,editor in editors.items():editor.save(target)
        saved_gate=[]
        for dim,editor in editors.items():
            changed_regions={(cx>>5,cz>>5) for cx,cz in editor.before}
            for rx,rz in sorted(changed_regions):
                subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)
                relative=editor.directory+f'/r.{rx}.{rz}.mca';old=RegionFile.open(source/relative);new=RegionFile.open(target/relative)
                for chunk in old.chunks():
                    cx,cz=rx*32+chunk.x,rz*32+chunk.z;after=new.get_chunk(chunk.x,chunk.z)
                    if (cx,cz) in editor.before:assert compound(after.nbt().root)==editor.chunks[cx,cz]
                    else:assert chunk.compressed_payload==after.compressed_payload and chunk.timestamp==after.timestamp
                saved_gate.append(relative)
        report['savedRegionGate']=dict(status='PASS',regions=saved_gate,allChangedChunksExact=True,allUnchangedChunkPayloadsAndTimestampsIdentical=True)
        for edits in shard_edits.values():
            for relative,raw in edits:
                file=target/relative;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
        report['status']='SAVED_REGION_AND_OWNER_SCOPE_PASS_GAMEPLAY_PENDING'
        write(target.parent/'migration-receipt.json',report)

if __name__=='__main__':main()
