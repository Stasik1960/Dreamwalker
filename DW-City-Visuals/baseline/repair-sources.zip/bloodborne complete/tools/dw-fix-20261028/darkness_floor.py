"""Write only Y=-63, inside each city's independently measured convex footprint."""
from __future__ import annotations

import copy
import collections
import json
import math
from pathlib import Path
import sys

from prepare_workspace import RUN, write
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from world_io import (Tag, TAG_BYTE, TAG_STRING, TAG_COMPOUND, TAG_LIST, TAG_LONG_ARRAY,
                      TAG_INT_ARRAY, RegionFile, compound, section_blocks, block_state_key,
                      pack_palette_indices, unpack_palette_indices, invalidate_chunk_lighting)

Y = -63
STATE = 'bloodborne_dw:city_darkness'


def footprint(polygon):
    """Integer columns on or inside the convex hull; includes air between city structures."""
    grouped = collections.defaultdict(list)
    for z in range(min(p[1] for p in polygon), max(p[1] for p in polygon)+1):
        hits = []
        for a,b in zip(polygon, polygon[1:]+polygon[:1]):
            if a[1] == b[1]:
                if z == a[1]:
                    hits.extend([a[0], b[0]])
            elif min(a[1],b[1]) <= z <= max(a[1],b[1]):
                hits.append(a[0]+(z-a[1])*(b[0]-a[0])/(b[1]-a[1]))
        if hits:
            for x in range(math.ceil(min(hits)-1e-8), math.floor(max(hits)+1e-8)+1):
                grouped[x>>4,z>>4].append((x,z))
    return grouped


def clear_visuals(root, positions):
    table = root.get('DreamwalkerVisuals')
    if table is None:
        return 0
    fields = compound(table)
    rows = fields.get('Sections')
    removed = 0
    if rows:
        keep = []
        for row in rows.value:
            data = compound(row)
            if data['Y'].value == Y>>4:
                entries = data['Entries'].value
                after = [v for v in entries if (v&4095) not in positions]
                removed += len(entries)-len(after)
                if not after:
                    continue
                data['Entries'] = Tag(TAG_INT_ARRAY, after)
            keep.append(row)
        rows.value = keep
    water = fields.get('ForcedWater')
    if water:
        # Packed BlockPos: lowest 12 bits contain the signed Y coordinate.
        water.value = [v for v in water.value if not (v&4095 == (Y&4095)
            and (((v>>38)&15)|(((v>>12)&15)<<4)|((Y&15)<<8)) in positions)]
    return removed


def main():
    world = RUN / 'world/bloodborne'
    receipt = RUN / 'darkness-floor.json'
    assert not receipt.exists(), 'Floor already applied; use its audit receipt'
    census = json.loads((RUN/'census.json').read_text(encoding='utf-8'))
    reports, pending = {}, []
    for directory, city in census.items():
        targets = footprint(city['hull'])
        by_region = collections.defaultdict(dict)
        for (x,z), positions in targets.items():
            by_region[x>>5,z>>5][x,z] = positions
        replaced = collections.Counter()
        changed_chunks, cleared, removed_entities, total = 0, 0, 0, 0
        for (rx,rz), chunks in sorted(by_region.items()):
            path = world / directory / f'r.{rx}.{rz}.mca'
            assert path.is_file(), f'City interior has no generated region: {path}'
            region = RegionFile.open(path)
            for (cx,cz), positions in sorted(chunks.items()):
                chunk = region.get_chunk(cx&31,cz&31)
                assert chunk, f'City interior has no generated chunk: {cx},{cz}'
                nbt = chunk.nbt()
                root = compound(nbt.root)
                sections = root['sections'].value
                section = next((s for s in sections if compound(s)['Y'].value == Y>>4), None)
                if section is None:
                    # Copy only the biome palette, never another section's blocks or light.
                    reference = next((compound(s)['biomes'] for s in sections if 'biomes' in compound(s)), None)
                    assert reference is not None
                    section = Tag(TAG_COMPOUND, {'Y':Tag(TAG_BYTE,Y>>4), 'biomes':copy.deepcopy(reference)})
                    sections.append(section)
                fields = compound(section)
                data = section_blocks(section)
                if data:
                    palette, indices = data
                else:
                    palette, indices = [Tag(TAG_COMPOUND, {'Name':Tag(TAG_STRING,'minecraft:air')})], [0]*4096
                old_states = [block_state_key(p) for p in palette]
                before = indices.copy()
                selected = {((Y&15)<<8)|((z&15)<<4)|(x&15) for x,z in positions}
                new_index = len(palette)
                palette.append(Tag(TAG_COMPOUND, {'Name':Tag(TAG_STRING,STATE)}))
                for index in selected:
                    replaced[old_states[before[index]]] += 1
                    indices[index] = new_index
                assert all(indices[i] == before[i] for i in range(4096) if i not in selected)
                fields['block_states'] = Tag(TAG_COMPOUND, {
                    'palette':Tag(TAG_LIST,palette,TAG_COMPOUND),
                    'data':Tag(TAG_LONG_ARRAY,pack_palette_indices(indices,len(palette)))})
                cleared += clear_visuals(root,selected)
                block_entities = root.get('block_entities')
                if block_entities:
                    keep = []
                    for entity in block_entities.value:
                        be = compound(entity)
                        pos = (be.get('x',Tag(3,0)).value,be.get('z',Tag(3,0)).value)
                        if be.get('y',Tag(3,0)).value == Y and pos in positions:
                            assert not any(k in be for k in ['Owner','Resident','Contributions']), 'Owned architecture intersects floor'
                            removed_entities += 1
                        else:
                            keep.append(entity)
                    block_entities.value = keep
                maps = root.get('Heightmaps')
                if maps:
                    for key,array in compound(maps).items():
                        if key in ['WORLD_SURFACE','WORLD_SURFACE_WG']:
                            values = unpack_palette_indices(array.value,512,256)
                            for x,z in positions:
                                i=(z&15)*16+(x&15)
                                values[i]=max(values[i],2)
                            array.value=pack_palette_indices(values,512)
                invalidate_chunk_lighting(root)
                region.set_chunk(cx&31,cz&31,nbt,timestamp=chunk.timestamp)
                changed_chunks += 1
                total += len(positions)
            pending.append((path,region))
        reports[directory] = dict(y=Y, block=STATE, hull=city['hull'], columns=total,
                                  changedChunks=changed_chunks, replaced=dict(replaced),
                                  clearedVisualEntries=cleared, removedBlockEntities=removed_entities)
    # Commit to the disposable candidate only after every dimension passed preflight.
    for path,region in pending:
        region.save(path)
    write(receipt,dict(status='APPLIED_REQUIRES_GAME_RELIGHT_AND_VERIFICATION',dimensions=reports,
                       originalWorldModified=False, blockEntitiesAdded=0, onlyBlockYChanged=Y))
    print(json.dumps(reports,ensure_ascii=False,indent=2),flush=True)


if __name__ == '__main__':
    main()
