"""Conservative exterior-only trim; generate a preview function for the disposable QA world."""
import collections
import json
from pathlib import Path
from prepare_workspace import RUN,write
from map_reader import MapReader

FILLERS={'bloodborne_dw:source_snow_height12','bloodborne_dw:source_andesite',
         'bloodborne_dw:source_bricks_stone_1','bloodborne_dw:source_bricks_stone_2','bloodborne_dw:source_bricks'}


def own(x,z):
    # The measured roof/facade L, including two cells for cornices and shared members.
    return ((-178<=x<=-82 and -936<=z<=-866) or
            (-174<=x<=-126 and -956<=z<=-932) or
            (-134<=x<=-86 and -870<=z<=-844))


def exterior(x,z):
    # East facade is clear. Keep the neighbouring northern and southern city masses.
    return ((-190<=x<=-177 and -960<=z<=-840) or
            (-128<=x<=-80 and -968<=z<=-934) or
            (-190<=x<=-134 and -870<=z<=-840) or
            (-153<=x<=-105 and -844<=z<=-820)) and not own(x,z)


def main():
    reader=MapReader(RUN/'world/bloodborne');selected=[];heights=collections.Counter();types=collections.Counter()
    for z in range(-968,-819):
        for x in range(-190,-79):
            if not exterior(x,z):continue
            for y in range(-62,27):
                state=reader.state(x,y,z);name=state.split('[')[0]
                allowed=state=='minecraft:stone' or (name in FILLERS and 'compact=true' in state)
                allowed|=(name=='bloodborne_dw:static_architecture_15' and any(f'part={p},' in state for p in [46,47,48,49])
                          and 'waterlogged=false' in state)
                if not allowed:continue
                assert reader.entity(x,y,z) is None,'Trim must not remove any owned block'
                assert reader.visual(x,y,z) is None,'Trim must not remove native artwork'
                selected.append([x,y,z,state]);heights[y]+=1;types[name]+=1
    write(RUN/'task01-trim-plan.json',dict(status='PREVIEW_ONLY_REQUIRES_VISUAL_REVIEW',cells=selected,
          ownLIsProtected=True,nativeArtworkAndOwnedObjectsExcluded=True,dimensions=['minecraft:overworld'],
          heights=dict(sorted(heights.items())),types=dict(types)))
    preview=RUN/'runs/scene01-detail/client/saves/city/datapacks/dwfix-preview'
    assert not preview.exists(),'Do not replace a loaded preview pack'
    write(preview/'pack.mcmeta',{'pack':{'pack_format':15,'description':'Disposable DW task01 trim review'}})
    directory=preview/'data/dwfix/functions/trim';directory.mkdir(parents=True)
    batches=[selected[i:i+200] for i in range(0,len(selected),200)]
    for i,batch in enumerate(batches):
        lines=[f'execute if block {x} {y} {z} {state} run setblock {x} {y} {z} minecraft:air' for x,y,z,state in batch]
        lines.append(f'schedule function dwfix:trim/part_{i+1:04d} 1t replace' if i+1<len(batches) else
                     'tellraw @a {"text":"DW QA trim preview finished","color":"green"}')
        (directory/f'part_{i:04d}.mcfunction').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (directory/'start.mcfunction').write_text('function dwfix:trim/part_0000\n',encoding='utf-8')
    print(json.dumps(dict(cells=len(selected),types=dict(types),heights=dict(sorted(heights.items())),
                         previewPack=str(preview)),indent=2))


if __name__=='__main__':main()
