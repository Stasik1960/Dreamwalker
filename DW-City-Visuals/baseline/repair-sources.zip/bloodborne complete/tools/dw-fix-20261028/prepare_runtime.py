"""Fetch the pinned vanilla/Fabric runtime to D:, outside the user's launcher."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import urllib.request
import zipfile

from prepare_workspace import RUN, write

ROOT=RUN/'runtime'


def fetch(url,path,digest=None):
    path=Path(path)
    if path.is_file() and (digest is None or hashlib.sha1(path.read_bytes()).hexdigest()==digest):
        return path
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.download')
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Dreamwalker-local-QA'}),timeout=60) as source,temp.open('wb') as dest:
                shutil.copyfileobj(source,dest)
            if digest:
                assert hashlib.sha1(temp.read_bytes()).hexdigest()==digest,(url,'SHA1 mismatch')
            temp.replace(path)
            return path
        except Exception:
            if attempt==2: raise


def read(url,path):
    return json.loads(fetch(url,path).read_text(encoding='utf-8'))


def allowed(library):
    rules=library.get('rules')
    result=not rules
    for rule in rules or []:
        os=rule.get('os',{})
        if os.get('name','windows')!='windows': continue
        if os.get('arch','x86_64') not in ['x86_64','amd64']: continue
        if rule.get('features'): continue
        result=rule['action']=='allow'
    return result


def main():
    ROOT.mkdir(exist_ok=True)
    manifest=read('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json',ROOT/'version-manifest.json')
    url=next(v['url'] for v in manifest['versions'] if v['id']=='1.20.1')
    version=read(url,ROOT/'1.20.1.json')
    fabric=read('https://meta.fabricmc.net/v2/versions/loader/1.20.1/0.19.3/profile/json',ROOT/'fabric-0.19.3.json')
    client=version['downloads']['client']
    jobs=[(client['url'],ROOT/'1.20.1.jar',client['sha1'])]
    classpath=[]
    natives=[]
    for lib in version['libraries']:
        if not allowed(lib):continue
        artifact=lib.get('downloads',{}).get('artifact')
        if artifact:
            path=ROOT/'libraries'/artifact['path'];classpath.append(str(path))
            jobs.append((artifact['url'],path,artifact.get('sha1')))
        classifier=lib.get('natives',{}).get('windows')
        if classifier:
            classifier=classifier.replace('${arch}','64')
            native=lib['downloads']['classifiers'][classifier]
            path=ROOT/'libraries'/native['path'];natives.append(path)
            jobs.append((native['url'],path,native.get('sha1')))
    for lib in fabric['libraries']:
        group,artifact,version_id=lib['name'].split(':')
        relative=f'{group.replace(".","/")}/{artifact}/{version_id}/{artifact}-{version_id}.jar'
        path=ROOT/'libraries'/relative;classpath.append(str(path))
        jobs.append((lib.get('url','https://maven.fabricmc.net/')+relative,path,None))
    print('Runtime downloads',len(jobs),flush=True)
    with ThreadPoolExecutor(max_workers=6) as pool:
        list(pool.map(lambda args:fetch(*args),jobs))
    native_root=ROOT/'natives';native_root.mkdir(exist_ok=True)
    for path in natives:
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if name.endswith('.dll'):
                    (native_root/Path(name).name).write_bytes(z.read(name))
    index=version['assetIndex']
    assets=ROOT/'assets'
    asset_index=read(index['url'],assets/'indexes'/f'{index["id"]}.json')
    objects=set(v['hash'] for v in asset_index['objects'].values())
    print('Asset objects',len(objects),flush=True)
    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(lambda h:fetch(f'https://resources.download.minecraft.net/{h[:2]}/{h}',assets/'objects'/h[:2]/h,h),objects))
    write(ROOT/'runtime.json',dict(javaMain=fabric['mainClass'],classpath=classpath+[str(ROOT/'1.20.1.jar')],
          natives=str(native_root),assets=str(assets),assetIndex=index['id'],loader='0.19.3',minecraft='1.20.1'))
    print('Runtime and assets ready',flush=True)


if __name__=='__main__':main()
