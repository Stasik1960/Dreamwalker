"""Task04: copy the good front artwork onto the back, then cap its real silhouette."""
import copy
import json
from pathlib import Path
import zipfile

from prepare_workspace import BASE,RUN,write
from repair_door_90986 import silhouette_edges
from door_surfaces import rebuild,mirrored


def main():
    output=Path(__file__).resolve().parent/'src/main/resources'
    prefix='assets/bloodborne_dw/models/v126/doors/90458/'
    source='assets/bloodborne_dw/models/remaining/source/minecraft/block/crimson_top.json'
    changes={};receipt={}
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        model=json.loads(archive.read(source));assert len(model['elements'])==2
        caps=[]
        for element in model['elements']:
            assert element['to'][2]-element['from'][2]==2
            element['faces']['south']=mirrored(element['faces']['north'])
            caps.extend(silhouette_edges(model,element,archive))
            element['faces']={k:v for k,v in element['faces'].items() if k in ['north','south']}
        model['elements'].extend(caps);changes[source]=model
        receipt[source]=dict(newSilhouetteEdgeFaces=len(caps),copiedBackFaces=2)
        descriptor=json.loads(archive.read('bloodborne_dw/composite/source_crimson_top.json'))
        used={part['model'] for variant in descriptor['variants']
              for part in variant['poses']['open']['parts']}
        for reference in sorted(used):
            name='assets/'+reference.replace(':','/models/',1)+'.json'
            assert name.startswith(prefix)
            model=json.loads(archive.read(name))
            receipt[name]=rebuild(model,{-3.0:2,-1.0:2},mirror_back=True)
            changes[name]=model
    assert len(changes)==5
    for name,model in changes.items():write(output/name,model)
    write(RUN/'task04-resource-repair.json',dict(status='DRAFT_REQUIRES_GAME_AND_PERFORMANCE_VALIDATION',
          models=receipt,originalFrontArtUnchanged=True,sourceTexturePixelsUnchanged=True,
          descriptorAndCollisionUnchanged=True,allRegisteredInstancesUseTheSameModels=True))
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
