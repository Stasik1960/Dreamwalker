"""Append board support physics; retain every original mesh, layer, owner and catalog index."""
import copy,hashlib,json,math,shutil,struct,subprocess
from pathlib import Path
import numpy as np
from prepare_workspace import RUN,WORKSPACE,write,sha
from compile_native_windows import canonical,DIRECTORY
from discover_native_benches import surface
from world_editor import Editor,MapReader,Tag,TAG_BYTE
from lantern_owner_edit import physical_state
from migrate_lanterns_stage2 import semantic_gate

DIRS={'overworld':'region','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}
RESOURCE=Path(__file__).resolve().parent/'src/main/resources'

def guard():subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)

def overlaps(poly,x,z):
    square=np.array([[x,z],[x+1/16,z],[x+1/16,z+1/16],[x,z+1/16]])
    axes=[np.array([1,0]),np.array([0,1])]+[np.array([-(b-a)[1],(b-a)[0]]) for a,b in zip(poly,np.roll(poly,-1,axis=0))]
    for axis in axes:
        if np.linalg.norm(axis)<1e-9:continue
        a,b=poly@axis,square@axis
        if min(a.max(),b.max())-max(a.min(),b.min())<=1e-9:return False
    return True

def boxes(polygons,top):
    mask={(x,z) for x in range(16) for z in range(16) if any(overlaps(p,x/16,z/16) for p in polygons)}
    rows={}
    for z in range(16):
        x=0
        while x<16:
            if (x,z) not in mask:x+=1;continue
            start=x
            while x<16 and (x,z) in mask:x+=1
            rows.setdefault((start,x),[]).append(z)
    result=[]
    for (lo,hi),zs in sorted(rows.items()):
        start=last=zs[0]
        for z in zs[1:]+[99]:
            if z!=last+1:result.append([lo/16,round(top-.125,8),start/16,hi/16,round(top,8),(last+1)/16]);start=z
            last=z
    assert result and all(0<=b[1]<b[4]<=1.000001 for b in result)
    return result

def main():
    guard();output=RUN/'native-overlay';backup=RUN/'native-overlay-stage20'
    if not backup.exists():shutil.copytree(output,backup)
    manifest=json.loads((backup/'manifest.json').read_text(encoding='utf-8'));assert manifest['catalogSha256']=='1423a49c3758b534ab3ec469cc2b84c170bde31cb03af1776f9acd4efbcb91ef'
    original_bytes=(backup/DIRECTORY/'catalog.json').read_bytes();catalog=json.loads(original_bytes);original=copy.deepcopy(catalog)
    layout=json.loads((backup/DIRECTORY/'visual_physics.json').read_text(encoding='utf-8'));old_layout=copy.deepcopy(layout)
    coverage=json.loads((RUN/'task08-native-bench-coverage.json').read_text(encoding='utf-8'))['benches'];assert len(coverage)==42
    definitions=json.loads((RESOURCE/'bloodborne_dw/repair/native-benches.json').read_text(encoding='utf-8'));old_defs=copy.deepcopy(definitions);templates={t['id']:t for t in definitions['templates']}
    analysis=json.loads((RUN/'native-geometry-analysis.json').read_text(encoding='utf-8'))['benchTopMeshes']
    world=RUN/'prelit-stage4-v18/bloodborne';editors={d:Editor(world,path) for d,path in DIRS.items()};changes={};template_changes={};scene_ids={};shape_ids={canonical(v):i for i,v in enumerate(catalog['shapes'])}
    semantics=lambda cell:{k:v for k,v in cell.items() if k not in ['key','mesh','displayName']}
    physics_ids={(canonical(semantics(catalog['cells'][v])),layout['physicsLayers'][i],layout['physicsAmbient'][i]):i for i,v in enumerate(layout['representatives'])}
    bounds=(backup/DIRECTORY/'selection-bounds.bin').read_bytes();length=struct.unpack_from('>H',bounds,4)[0];at=6+length;count=struct.unpack_from('>I',bounds,at)[0];bound_rows={struct.unpack_from('>i',bounds,at+4+i*28)[0]:bounds[at+4+i*28:at+4+(i+1)*28] for i in range(count)};added_bounds=[]
    for bench in coverage:
        dim=bench['dimension'];editor=editors[dim];root=bench['root'];template=templates[bench['template']]
        for dx,dy,dz,old in old_defs['templates'][next(i for i,t in enumerate(old_defs['templates']) if t['id']==bench['template'])]['cells']:
            pos=(root[0]+dx,root[1]+dy,root[2]+dz);assert editor.visual(*pos)==old and editor.entity(*pos) is None
            cell=original['cells'][old];quads=analysis[str(cell['mesh'])];polygons=[];top=None
            for q in quads:
                s=surface(q)
                if s is None or abs(s['centre'][1]+pos[1]-bench['centre'][1])>1e-4:continue
                y=float(s['centre'][1]);assert top is None or abs(top-y)<1e-5;top=y;polygons.append(s['polygon'])
            assert polygons and top is not None
            support=boxes(polygons,top);merged=copy.deepcopy(original['shapes'][cell['collision']])
            for b in support:
                if b not in merged:merged.append(b)
            shape=canonical(merged)
            if shape not in shape_ids:shape_ids[shape]=len(catalog['shapes']);catalog['shapes'].append(merged)
            key=(old,shape_ids[shape])
            if key not in scene_ids:
                new=copy.deepcopy(cell);new['collision']=shape_ids[shape];new.pop('key');new['key']=hashlib.sha256(('dwfix-bench-support-v1/'+canonical(new)).encode()).hexdigest();index=len(catalog['cells']);catalog['cells'].append(new);scene_ids[key]=index
                old_phys=old_layout['cellToPhysics'][old];layer=old_layout['physicsLayers'][old_phys];ambient=old_layout['physicsAmbient'][old_phys];pk=(canonical(semantics(new)),layer,ambient)
                if pk not in physics_ids:physics_ids[pk]=len(layout['representatives']);layout['representatives'].append(index);layout['physicsLayers'].append(layer);layout['physicsAmbient'].append(ambient)
                layout['cellToPhysics'].append(physics_ids[pk])
                if old in bound_rows:added_bounds.append(struct.pack('>i',index)+bound_rows[old][4:])
                assert {k:v for k,v in new.items() if k not in ['key','collision']}=={k:v for k,v in cell.items() if k not in ['key','collision']}
            new=scene_ids[key];previous=changes.setdefault((dim,*pos),(old,new));assert previous==(old,new)
            tc=template_changes.setdefault(bench['template'],{});assert (dx,dy,dz) not in tc or tc[dx,dy,dz]==(old,new);tc[dx,dy,dz]=(old,new)
    protected={(r['dimension'],*r['pos']) for r in json.loads((RUN/'task09-native-window-map-plan.json').read_text(encoding='utf-8'))['cells']};assert not protected.intersection(changes)
    for identity,updates in template_changes.items():
        t=templates[identity]
        for field in ['cells','triggers']:
            for row in t[field]:
                pair=updates.get(tuple(row[:3]))
                if pair is not None:assert row[3]==pair[0];row[3]=pair[1]
    for name in ['cells','shapes','materials','meshes','optics','wholeObjects']:assert catalog[name][:len(original[name])]==original[name]
    for name in ['cellToPhysics','representatives','physicsLayers','physicsAmbient']:assert layout[name][:len(old_layout[name])]==old_layout[name]
    data=canonical(catalog).encode();header=hashlib.sha256(data).hexdigest();layout['catalogSha256']=header;layout.setdefault('compatibleCatalogs',[]).append(manifest['catalogSha256']);layout['compatibleCatalogs']=sorted(set(layout['compatibleCatalogs']));definitions['catalogSha256']=header
    repairs=json.loads((backup/DIRECTORY/'visual-repairs.json').read_text(encoding='utf-8'));repairs['catalogSha256']=header
    windows=json.loads((backup/'bloodborne_dw/repair/native-windows.json').read_text(encoding='utf-8'));windows['catalogSha256']=header
    new_bounds=bounds[:4]+struct.pack('>H',64)+header.encode()+struct.pack('>I',count+len(added_bounds))+bounds[at+4:]+b''.join(added_bounds)
    files={DIRECTORY+'catalog.json':data,DIRECTORY+'visual_physics.json':canonical(layout).encode(),DIRECTORY+'visual-repairs.json':canonical(repairs).encode(),DIRECTORY+'selection-bounds.bin':new_bounds,'bloodborne_dw/repair/native-windows.json':canonical(windows).encode(),'bloodborne_dw/repair/native-benches.json':canonical(definitions).encode()}
    guard()
    for name,blob in files.items():p=output/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(blob);manifest['entries'][name]=dict(sha256=sha(p),bytes=len(blob))
    p=RESOURCE/'bloodborne_dw/repair/native-benches.json';p.write_bytes(files['bloodborne_dw/repair/native-benches.json'])
    if 'bloodborne_dw/repair/native-benches.json' in manifest['sources']:manifest['sources']['bloodborne_dw/repair/native-benches.json']=sha(p)
    manifest['catalogSha256']=header;manifest.setdefault('stages',{})['benchWalkingSurface']=header;write(output/'manifest.json',manifest)
    target=RUN/'bench-surfaces-v21/bloodborne';assert not target.exists();guard();shutil.copytree(world,target,ignore=shutil.ignore_patterns('session.lock'));chunks=[];reports=[]
    for (dim,x,y,z),(old,new) in sorted(changes.items()):
        editor=editors[dim];assert editor.state(x,y,z)==physical_state(old_layout,old);editor.set_state((x,y,z),physical_state(layout,new));editor.set_visual((x,y,z),new,header)
    for dim,editor in editors.items():
        reports.append(semantic_gate(editor))
        for (cx,cz) in editor.before:
            editor.chunks[cx,cz]['isLightOn']=Tag(TAG_BYTE,0);chunks.append(dict(dimension='minecraft:overworld' if dim=='overworld' else 'bloodborne_dw:bloodborne_old',x=cx,z=cz))
        editor.save(target);reader=MapReader(target,DIRS[dim])
        for (d,x,y,z),(old,new) in changes.items():
            if d==dim:assert reader.state(x,y,z)==physical_state(layout,new) and reader.visual(x,y,z)==new and reader.entity(x,y,z) is None
    receipt=dict(status='PERSISTED_BENCH_SUPPORT_SCOPE_PASS_GAMEPLAY_PENDING',benches=len(coverage),mapCells=len(changes),addedScenes=len(scene_ids),addedPhysics=len(layout['representatives'])-len(old_layout['representatives']),meshBytesUnchanged=True,originalCatalogPrefixUnchanged=True,foreignPhysicsRetained=True,blockEntitiesAdded=0,sourceWorld=str(world),outputWorld=str(target),catalogSha256=header,semanticGates=reports)
    write(RUN/'bench-support-scope.json',receipt);write(RUN/'prelight-targets-bench-v21.json',dict(world=str(target),prelightChunks=chunks));write(RUN/'bench-support-map-plan.json',dict(catalogSha256=header,cells=[dict(dimension=dim,pos=[x,y,z],old=a,next=b) for (dim,x,y,z),(a,b) in sorted(changes.items())]));print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
