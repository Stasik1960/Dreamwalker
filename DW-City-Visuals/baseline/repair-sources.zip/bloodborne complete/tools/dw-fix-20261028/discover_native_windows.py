"""Recover retained window poses and prove component geometry before any migration."""
import collections,itertools,json,math,struct,sys,zipfile
from pathlib import Path
import numpy as np
from analyze_native_geometry import decode
from map_reader import MapReader
from prepare_workspace import BASE,RUN,write
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile,compound
DIMS={'overworld':'region','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}
PIVOT=np.array([.5,0,.5]);FACE={'west':(0,0,-1),'east':(0,1,1),'down':(1,0,-1),'up':(1,1,1),'north':(2,0,-1),'south':(2,1,1)}


def rotation(degrees):
    c,s=math.cos(math.radians(degrees)),math.sin(math.radians(degrees))
    return np.array([[c,0,s],[0,1,0],[-s,0,c]])


def normal(v):
    candidates=[np.cross(v[a]-v[0],v[b]-v[0]) for a,b in [(1,2),(2,3),(1,3)]]
    n=max(candidates,key=np.linalg.norm);return n/np.linalg.norm(n) if np.linalg.norm(n)>1e-9 else None


def main():
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        catalog=json.loads(z.read('assets/bloodborne_dw/native_grid/catalog.json'))
        raw=z.read('assets/bloodborne_dw/native_grid/meshes.bin')
        model=json.loads(z.read('assets/bloodborne_dw/models/remaining/source/minecraft/block/spruce_trapdoor_open.json'))
    offsets=[];cursor=8
    for m in catalog['meshes']:
        count=struct.unpack_from('>I',raw,cursor)[0];assert count==m['quadCount'];offsets.append((cursor+4,count));cursor+=4+139*count
    pane_materials={i for i,m in enumerate(catalog['materials']) if m['sprite'].endswith('/roof_3')}
    decoded={};panes={}
    def mesh(mid):
        if mid not in decoded:
            start,count=offsets[mid];decoded[mid]=[decode(raw[start+139*i:start+139*(i+1)]) for i in range(count)]
        return decoded[mid]
    for mid,(start,count) in enumerate(offsets):
        materials=np.ndarray((count,),dtype='>u4',buffer=raw,offset=start,strides=(139,))
        if not any(np.any(materials==m) for m in pane_materials):continue
        for q in mesh(mid):
            if q['material'] not in pane_materials:continue
            v=np.array(q['vertices']);uv=v[:,3:5]
            if uv[:,0].min()<13.37 or uv[:,0].max()>15.38 or uv[:,1].min()<5.12 or uv[:,1].max()>8.88:continue
            coef,_,rank,_=np.linalg.lstsq(np.column_stack((uv,np.ones(4))),v[:,:3],rcond=None)
            if rank!=3 or np.max(abs(np.column_stack((uv,np.ones(4)))@coef-v[:,:3]))>1e-5:continue
            u,w=coef[:2]
            if abs(np.linalg.norm(u)-256/511)>.001 or np.max(abs(w-np.array([0,-256/511,0])))>.001:continue
            yaw=max(range(8),key=lambda k:np.dot(u/np.linalg.norm(u),rotation(-45*k)@np.array([-1,0,0])))
            if np.dot(u/np.linalg.norm(u),rotation(-45*yaw)@np.array([-1,0,0]))<.99999:continue
            centre=np.array([14.375,7.,1.])@coef
            local=(np.array([.5,23/16,6/16])-PIVOT)@rotation(-45*yaw).T+PIVOT
            area=sum(np.linalg.norm(np.cross(v[a,:3]-v[0,:3],v[b,:3]-v[0,:3]))*.5 for a,b in [(1,2),(2,3)])
            panes.setdefault(mid,[]).append(dict(root=centre-local,yaw=yaw,area=float(area)))
    visuals={i:panes[c['mesh']] for i,c in enumerate(catalog['cells']) if c['mesh'] in panes}
    groups={}
    for dimension,directory in DIMS.items():
        for path in sorted((RUN/'world/bloodborne'/directory).glob('r.*.*.mca')):
            _,rx,rz,_=path.name.split('.');rx,rz=int(rx),int(rz)
            for chunk in RegionFile.open(path).chunks():
                root=compound(chunk.nbt().root)
                if 'DreamwalkerVisuals' not in root:continue
                for section in compound(root['DreamwalkerVisuals'])['Sections'].value:
                    sec=compound(section);sy=sec['Y'].value
                    for entry in sec['Entries'].value:
                        visual=(entry&0xffffffff)>>12
                        if visual not in visuals:continue
                        local=entry&4095;p=np.array([rx*512+16*chunk.x+(local&15),sy*16+(local>>8),rz*512+16*chunk.z+((local>>4)&15)])
                        for pane in visuals[visual]:
                            effective=pane['root']+p;key=(dimension,*(round(float(x),2) for x in effective),pane['yaw'])
                            group=groups.setdefault(key,dict(area=0,best=None));group['area']+=pane['area']
                            if group['best'] is None or pane['area']>group['best']['area']:group['best']={**pane,'root':effective}
    readers={d:MapReader(RUN/'world/bloodborne',directory) for d,directory in DIMS.items()};tables={};class_cache={}
    def visual_at(d,p):
        key=d,p[0]>>4,p[2]>>4
        if key not in tables:
            chunk=readers[d].chunk(p[0],p[2]);table={}
            if chunk and 'DreamwalkerVisuals' in chunk:
                for section in compound(chunk['DreamwalkerVisuals'])['Sections'].value:
                    s=compound(section)
                    for e in s['Entries'].value:table[s['Y'].value,e&4095]=(e&0xffffffff)>>12
            tables[key]=table
        return tables[key].get((p[1]>>4,((p[1]&15)<<8)|((p[2]&15)<<4)|(p[0]&15)))
    def classify(visual,cell,effective,yaw):
        key=(visual,yaw,*(round(float(x),5) for x in np.array(cell)-effective))
        if key in class_cache:return class_cache[key]
        result=[];r=rotation(-yaw*45)
        for q in mesh(catalog['cells'][visual]['mesh']):
            v=np.array(q['vertices']);source=((v[:,:3]+np.array(cell)-effective-PIVOT)@r+PIVOT)*16-np.array([0,16,0])
            n=normal(source);found=None
            if n is not None:
                for ei,e in enumerate(model['elements']):
                    rr=e.get('rotation',{});a=rotation(rr.get('angle',0));origin=np.array(rr.get('origin',[0,0,0]))
                    point=(source-origin)@a+origin;nn=n@a;lo=np.array(e['from']);hi=np.array(e['to'])
                    if np.any(point<lo-.003) or np.any(point>hi+.003):continue
                    for face,f in e['faces'].items():
                        sprite=model['textures'][f['texture'].lstrip('#')]
                        if catalog['materials'][q['material']]['sprite']!=sprite:continue
                        axis,side,sign=FACE[face];expected=np.zeros(3);expected[axis]=sign
                        if np.dot(nn,expected)<.999 or np.max(abs(point[:,axis]-(hi if side else lo)[axis]))>.003:continue
                        axes=[j for j in range(3) if j!=axis]
                        design=np.column_stack((point[:,axes],np.ones(4)));coef,_,rank,_=np.linalg.lstsq(design,v[:,3:5],rcond=None)
                        if rank!=3:continue
                        corners=np.array([[lo[axes[0]],lo[axes[1]],1],[lo[axes[0]],hi[axes[1]],1],[hi[axes[0]],lo[axes[1]],1],[hi[axes[0]],hi[axes[1]],1]])@coef
                        uv=np.array(f['uv']).reshape(2,2);centre=np.mean(uv,axis=0);uv=centre+(uv-centre)*511/512
                        if np.max(abs(np.min(corners,axis=0)-np.min(uv,axis=0)))>.007 or np.max(abs(np.max(corners,axis=0)-np.max(uv,axis=0)))>.007:continue
                        found=ei;break
                    if found is not None:break
            result.append(found)
        class_cache[key]=result;return result
    windows=[];mixed=[];incomplete=[];sample=None
    for key,g in sorted(groups.items()):
        dimension=key[0];best=g['best'];effective=best['root'];yaw=best['yaw'];cells=[];elements=collections.Counter()
        if abs(g['area']-1.875)>.02:incomplete.append(dict(pose=key,area=g['area']))
        for x in range(math.floor(effective[0])-3,math.ceil(effective[0])+4):
            for y in range(math.floor(effective[1])-1,math.ceil(effective[1])+4):
                for z in range(math.floor(effective[2])-3,math.ceil(effective[2])+4):
                    p=x,y,z;visual=visual_at(dimension,p)
                    if visual is None:continue
                    matched=classify(visual,p,effective,yaw)
                    if not any(e is not None for e in matched):continue
                    elements.update(e for e in matched if e is not None)
                    row=dict(pos=p,visual=visual,mesh=catalog['cells'][visual]['mesh'],matched=matched,
                             collision=catalog['cells'][visual]['collision'],baseState=catalog['cells'][visual].get('baseState'),hasBlockEntity=readers[dimension].entity(*p) is not None)
                    cells.append(row)
                    if any(e is None for e in matched):mixed.append(dict(dimension=dimension,root=effective.tolist(),**row))
                    if dimension=='overworld' and p==(190,102,-1130):sample=row
        windows.append(dict(dimension=dimension,root=[round(float(x),5) for x in effective],rotation=yaw,area=g['area'],elements=dict(elements),cells=cells))
    write(RUN/'task09-native-window-preflight.json',dict(windows=windows,mixed=mixed,incomplete=incomplete,sample=sample))
    assert sample is not None and all(e is not None for e in sample['matched']),sample
    print(json.dumps(dict(windows=len(windows),dimensions=dict(collections.Counter(w['dimension'] for w in windows)),mixedCells=len(mixed),incomplete=incomplete,sample=sample,protectedCells=sum(c['hasBlockEntity'] or c['baseState'] is not None for w in windows for c in w['cells'])),indent=2))


if __name__=='__main__':main()
