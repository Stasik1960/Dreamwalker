package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;

public final class LanternQa {
    private static final BlockPos ROOT=new BlockPos(830,250,-1300);
    public static JsonObject prepare(MinecraftServer server,ServerPlayerEntity player){
        var world=server.getOverworld();for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)world.getChunk((ROOT.getX()>>4)+x,(ROOT.getZ()>>4)+z);
        world.setBlockState(ROOT.down(),Blocks.STONE.getDefaultState(),Block.NOTIFY_ALL);player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.teleport(world,ROOT.getX()+3,ROOT.getY()+1,ROOT.getZ()-3,0,0);
        var block=(CompositeRootBlock)Registries.BLOCK.get(new Identifier("bloodborne_dw:source_standard_lantern"));var stack=new ItemStack(block.asItem());player.setStackInHand(Hand.MAIN_HAND,stack);
        var result=((BlockItem)stack.getItem()).place(new ItemPlacementContext(world,player,Hand.MAIN_HAND,stack,new BlockHitResult(Vec3d.ofBottomCenter(ROOT),Direction.UP,ROOT.down(),false)));
        if(!result.isAccepted()||!world.getBlockState(ROOT).isOf(block))throw new IllegalStateException("Canonical lantern normal placement "+result);
        for(int x:new int[]{842,854,878,890}){
            var p=new BlockPos(x,250,-1300);world.getChunk(x>>4,p.getZ()>>4);world.setBlockState(p.down(),Blocks.STONE.getDefaultState(),Block.NOTIFY_ALL);
            var fixture=Registries.BLOCK.get(new Identifier("bloodborne_dw",x==842?"source_standard_lantern":(x==854||x==890)?"source_street_lamp_post":"source_warped_trapdoor_open_2"));var item=new ItemStack(fixture.asItem());if(x==890){item.getOrCreateSubNbt("BlockStateTag").putString("variant","3");item.getOrCreateSubNbt("BlockStateTag").putString("art_bank","2");}player.setStackInHand(Hand.MAIN_HAND,item);player.teleport(world,x+4,251,-1304,0,0);
            var placed=((BlockItem)item.getItem()).place(new ItemPlacementContext(world,player,Hand.MAIN_HAND,item,new BlockHitResult(Vec3d.ofBottomCenter(p),Direction.UP,p.down(),false)));
            if(!placed.isAccepted()||!world.getBlockState(p).isOf(fixture))throw new IllegalStateException("Plain lamp/post fixture "+x+" / "+placed);
        }
        var upperState=world.getBlockState(new BlockPos(890,250,-1300));if(ImportedArtworkBlock.variant(upperState)!=35)throw new IllegalStateException("Upper canonical post pose was not placed normally");
        var row=new JsonObject();row.addProperty("ordinaryPlacement",true);row.addProperty("upperPostNormalPlacement",true);return row;
    }
    public static JsonObject run(MinecraftServer server,ServerPlayerEntity player){
        var w=server.getOverworld();
        for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)w.getChunk((ROOT.getX()>>4)+x,(ROOT.getZ()>>4)+z);
        var owner=((CompositeBlockEntity)w.getBlockEntity(ROOT)).resident();var before=w.getBlockState(ROOT);if(before.getLuminance()!=15||before.get(CompositeRootBlock.OPEN))throw new IllegalStateException("Lit lamp emission");
        player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);player.setSneaking(false);
        var footprint=CompositeRuntime.contributions(w,ROOT).stream().filter(v->v.owner().equals(owner)).findFirst().orElseThrow();var bounds=CompositeRuntime.shape(footprint.shape().collision()).getBoundingBox();var original=(CompositeRootBlock)Registries.BLOCK.get(new Identifier("bloodborne_dw:source_lantern"));var reference=CompositeRuntime.instance(ROOT,original.getDefaultState(),owner.instanceId(),((CompositeBlockEntity)w.getBlockEntity(ROOT)).payload());
        var sourceShape=reference.cells().get(new dev.dreamwalker.bloodbornedw.runtime.ObjectGeometry.Cell(0,0,0));
        if(!footprint.shape().collision().equals(sourceShape.collision())||!bounds.equals(CompositeRuntime.shape(sourceShape.collision()).getBoundingBox()))throw new IllegalStateException("Canonical lamp differs from original source fitted physics "+bounds);
        var first=Door90001Qa.click(w,ROOT,owner,player);var off=w.getBlockState(ROOT);if(!first.isAccepted()||!off.get(CompositeRootBlock.OPEN)||off.getLuminance()!=0)throw new IllegalStateException("Lamp did not extinguish "+first);
        if(!((CompositeRootBlock)off.getBlock()).spec.pose(off).parts().get(0).model().toString().equals("bloodborne_dw:interactions/mod_lantern_empty"))throw new IllegalStateException("Lamp does not use the hollow frame");
        var second=Door90001Qa.click(w,ROOT,owner,player);var on=w.getBlockState(ROOT);if(!second.isAccepted()||on.get(CompositeRootBlock.OPEN)||on.getLuminance()!=15)throw new IllegalStateException("Lamp did not relight "+second);
        if(!owner.equals(((CompositeBlockEntity)w.getBlockEntity(ROOT)).resident()))throw new IllegalStateException("Lamp owner changed");
        var row=new JsonObject();row.addProperty("status","PASS");row.addProperty("ordinaryPlacement",true);row.addProperty("originalSourcePhysicalFootprintAndVoxelShape",true);row.addProperty("customModModel",true);row.addProperty("originalAnimatedFlame",true);row.addProperty("ordinaryUseOffOn",true);row.addProperty("litEmission",15);row.addProperty("unlitEmission",0);row.addProperty("hollowOffModel",true);row.addProperty("ownerPreserved",true);return row;
    }
    public static void togglePlain(MinecraftServer server,ServerPlayerEntity player,boolean lit){
        var w=server.getOverworld();var pos=new BlockPos(842,250,-1300);for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)w.getChunk((pos.getX()>>4)+x,(pos.getZ()>>4)+z);
        player.changeGameMode(GameMode.CREATIVE);player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);player.setSneaking(false);
        var owner=((CompositeBlockEntity)w.getBlockEntity(pos)).resident();var result=Door90001Qa.click(w,pos,owner,player);
        if(!result.isAccepted()||w.getBlockState(pos).get(CompositeRootBlock.OPEN)==lit)throw new IllegalStateException("Custom mod lamp phase toggle: "+result+" / "+w.getBlockState(pos)+" / "+CompositeRuntime.lastResult());
    }
    public static JsonObject archedModels(net.minecraft.client.MinecraftClient client){
        int poses=0,parts=0;for(var pose:StaticArchitectureCatalog.poses())if(pose.block().spec.id.toString().equals("bloodborne_dw:source_warped_trapdoor_open_2")){
            poses++;for(int i=0;i<pose.parts().size();i++){var full=client.getBakedModelManager().getModel(pose.parts().get(i).model());var actual=StaticArchitectureGeometry.visible(pose,i,client.world,new BlockPos(290,73,-1012));if(actual!=full)throw new IllegalStateException("Frozen arch does not use its complete source model");parts++;}
        }
        if(poses==0)throw new IllegalStateException("No frozen arched tops audited");var row=new JsonObject();row.addProperty("status","PASS");row.addProperty("poses",poses);row.addProperty("parts",parts);return row;
    }
}
