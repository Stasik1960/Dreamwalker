package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.composite.*;
import dev.dreamwalker.bloodbornedw.runtime.TransactionCore;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;

/** Fixed review fixtures on the disposable world, outside both city footprints. */
public final class GalleryQa {
    public static JsonArray install(MinecraftServer server,ServerPlayerEntity player) {
        String[] types={"source_stairs_dark_prismarine_stairs_inner_right","source_crimson_top",
                "source_acacia_pressure_plate","source_birch_grille_door","source_dark_arch_door"};
        var world=server.getOverworld();var results=new JsonArray();
        player.changeGameMode(GameMode.CREATIVE);
        player.teleport(world,610,258,-1340,0,0);player.setNoGravity(true);
        for(int i=0;i<types.length;i++) for(int pose=0;pose<2;pose++) {
            var p=new BlockPos(620+i*15,250,-1300-pose*20);
            for(int x=-1;x<=1;x++) for(int z=-1;z<=1;z++) world.getChunk((p.getX()>>4)+x,(p.getZ()>>4)+z);
            for(int x=-5;x<=8;x++) for(int z=-5;z<=5;z++)
                world.setBlockState(p.add(x,-1,z),Blocks.STONE.getDefaultState(),Block.NOTIFY_ALL);
            var block=(CompositeRootBlock)Registries.BLOCK.get(new Identifier("bloodborne_dw",types[i]));
            int variant=ImportedAssemblyV126.installationPose(types[i]);
            var state=block.getDefaultState().with(CompositeRootBlock.VARIANT,variant)
                    .with(CompositeRootBlock.OPEN,pose==1).with(CompositeRootBlock.ROTATION,0);
            var payload=ImportedTypeAliases.markPayload(new NbtCompound());
            var result=CompositeRuntime.place(world,p,state,UUID.randomUUID(),player,payload);
            var row=new JsonObject();row.addProperty("registry",types[i]);row.addProperty("open",pose==1);
            row.addProperty("position",p.toString());row.addProperty("variant",variant);
            row.addProperty("status",result.outcome()==TransactionCore.Outcome.COMMITTED?"PASS":"FAIL");
            row.addProperty("result",result.toString());results.add(row);
        }
        return results;
    }
}
