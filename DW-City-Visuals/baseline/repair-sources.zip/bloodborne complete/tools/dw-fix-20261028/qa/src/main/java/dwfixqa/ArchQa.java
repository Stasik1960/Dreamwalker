package dwfixqa;

import com.google.gson.JsonObject;
import dev.dreamwalker.bloodbornedw.composite.*;
import dev.dreamwalker.bloodbornedw.runtime.TransactionCore;
import java.util.UUID;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;

/** Controlled comparison: same source, same root, same source shift, ordinary owned rendering. */
public final class ArchQa {
    public static JsonObject materialize(MinecraftServer server,ServerPlayerEntity player){
        var world=server.getOverworld();var root=new BlockPos(290,73,-1012);
        for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)world.getChunk((root.getX()>>4)+x,(root.getZ()>>4)+z);
        var pose=StaticArchitectureCatalog.poses().stream().filter(p->p.key().equals("pc6484e462ceacd92b1bd")).findFirst().orElseThrow();
        player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);
        var removed=StaticArchitectureRuntime.remove(world,root,pose);if(removed.outcome()!=TransactionCore.Outcome.COMMITTED)throw new IllegalStateException("Arch controlled removal "+removed);
        var payload=new NbtCompound();payload.putInt("ImportedTypeVersion",1);payload.putInt("DecorativePlacementOptics",1);var shift=new NbtList();shift.add(NbtDouble.of(pose.shift().x()));shift.add(NbtDouble.of(pose.shift().y()));shift.add(NbtDouble.of(pose.shift().z()));payload.put("SourceShift",shift);if(pose.mountY()!=0)payload.putDouble("MountY",pose.mountY());
        var uuid=UUID.randomUUID();var result=CompositeRuntime.place(world,root,pose.state(),uuid,player,payload);if(result.outcome()!=TransactionCore.Outcome.COMMITTED)throw new IllegalStateException("Arch controlled ordinary placement "+result);
        var entity=(CompositeBlockEntity)world.getBlockEntity(root);var actual=CompositeSourceShift.local(entity.payload());if(actual.x()!=pose.shift().x()||actual.y()!=pose.shift().y()||actual.z()!=pose.shift().z())throw new IllegalStateException("Arch source shift changed");
        var row=new JsonObject();row.addProperty("status","CONTROLLED_OWNED_INSTANCE_PLACED");row.addProperty("sameRoot",root.toShortString());row.addProperty("sameSourceShift",actual.toString());row.addProperty("memberCells",CompositeRuntime.instance(world,root,world.getBlockState(root),uuid,entity.payload()).cells().size());return row;
    }
}
