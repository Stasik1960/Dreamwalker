package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.architecture.NoCollidePlacement;
import dev.dreamwalker.bloodbornedw.composite.*;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;

/** Real native callback use, whole-map coverage and ordinary prefab placement. */
public final class WindowQa {
    private static final List<BlockPos> FIXTURES=new ArrayList<>();
    private static BlockPos root(JsonObject p){var r=p.getAsJsonArray("root");return new BlockPos(r.get(0).getAsInt(),r.get(1).getAsInt(),r.get(2).getAsInt());}
    private static ServerWorld world(MinecraftServer server,JsonObject p){return server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(p.get("dimension").getAsString())));}
    private static void load(ServerWorld w,BlockPos p){for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)w.getChunk((p.getX()>>4)+x,(p.getZ()>>4)+z);}
    private static <T extends Comparable<T>> BlockState property(BlockState s,Property<T> p,String value){return s.with(p,p.parse(value).orElseThrow());}
    private static JsonObject place(MinecraftServer server,ServerPlayerEntity player,int index,int variant,int type){
        var w=server.getOverworld();var floor=new BlockPos(740+12*index,249,-1300);load(w,floor);
        BlockState support=switch(type){case 0->Blocks.STONE.getDefaultState();case 1->Registries.BLOCK.get(new Identifier("bloodborne_dw:source_bricks_stone_1")).getDefaultState();default->Blocks.SMOOTH_STONE_SLAB.getDefaultState();};
        if(type==1){var compact=support.getBlock().getStateManager().getProperty("compact");if(compact==null)throw new IllegalStateException("Compact floor absent");support=property(support,compact,"true");}
        for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)w.setBlockState(floor.add(x,0,z),support,Block.NOTIFY_ALL);
        double top=floor.getY()+(type==2?.5:1);player.stopRiding();player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.teleport(w,floor.getX()+.5,top+.1,floor.getZ()-3,0,0);
        if(NoCollidePlacement.armed(player))throw new IllegalStateException("No-collide is armed");
        var block=(CompositeRootBlock)Registries.BLOCK.get(new Identifier("bloodborne_dw:source_shutter_window"));var stack=new ItemStack(block.asItem());stack.getOrCreateSubNbt("BlockStateTag").putString("variant",String.valueOf(variant));player.setStackInHand(Hand.MAIN_HAND,stack);
        var context=new ItemPlacementContext(w,player,Hand.MAIN_HAND,stack,new BlockHitResult(new Vec3d(floor.getX()+.5,top,floor.getZ()+.5),Direction.UP,floor,false));
        var outcome=((BlockItem)stack.getItem()).place(context);var pos=new BlockPos(floor.getX(),(int)Math.ceil(top-1e-7),floor.getZ());
        if(!outcome.isAccepted()||!(w.getBlockEntity(pos) instanceof CompositeBlockEntity entity)||entity.resident()==null)throw new IllegalStateException("Normal window placement: "+outcome+" / "+CompositeRuntime.lastResult());
        var state=w.getBlockState(pos);var shift=CompositeSourceShift.local(entity.payload());var bounds=block.spec.variant(state).visible();double bottom=bounds==null?block.spec.pose(state).selection().stream().mapToDouble(b->b.from().y()/16).min().orElseThrow():bounds.from().y()/16;
        if(Math.abs(pos.getY()+shift.y()+bottom-top-1./1024)>1e-5)throw new IllegalStateException("Window floor alignment");
        if(!w.getBlockState(floor).equals(support))throw new IllegalStateException("Window replaced its floor");
        FIXTURES.add(pos);var row=new JsonObject();row.addProperty("variant",variant);row.addProperty("floorType",type);row.addProperty("root",pos.toShortString());row.addProperty("status","PASS");return row;
    }
    public static JsonObject prepare(MinecraftServer server,ServerPlayerEntity player,JsonArray probes){
        FIXTURES.clear();var report=new JsonObject();var audit=new JsonArray();var placements=new JsonArray();
        for(var value:probes){var p=value.getAsJsonObject();var row=p.deepCopy();try{var w=world(server,p);var root=root(p);load(w,root);int rotation=p.get("rotation").getAsInt();
            if(NativeShutterWindows.state(w,root,rotation)!=1||!NativeShutterWindows.complete(w,root,rotation))throw new IllegalStateException("Native window is incomplete or wrong state");
            var anchor=root.up();var stack=w.getBlockState(anchor).getBlock().getPickStack(w,anchor,w.getBlockState(anchor));
            if(stack.getItem()!=Registries.ITEM.get(new Identifier("bloodborne_dw:source_shutter_window"))||!stack.getSubNbt("BlockStateTag").getString("variant").equals("1"))throw new IllegalStateException("Native window pick is not the working prefab");
            row.addProperty("status","PASS");}catch(Throwable error){row.addProperty("status","FAIL");row.addProperty("error",error.toString());}audit.add(row);}
        for(int type=0;type<3;type++)for(int variant=0;variant<2;variant++)try{placements.add(place(server,player,type*2+variant,variant,type));}catch(Throwable error){var row=new JsonObject();row.addProperty("variant",variant);row.addProperty("floorType",type);row.addProperty("status","FAIL");row.addProperty("error",error.toString());placements.add(row);}
        report.add("nativeAudit",audit);report.add("ordinaryPlacements",placements);report.add("actions",new JsonArray());return report;
    }
    public static void nativeUse(MinecraftServer server,ServerPlayerEntity player,JsonObject probe,int expected,JsonObject report){
        var w=world(server,probe);var root=root(probe);load(w,root);int k=probe.get("rotation").getAsInt();
        int before=NativeShutterWindows.state(w,root,k);if(before!=expected)throw new IllegalStateException("Native window before mode "+before+" != "+expected);
        double a=Math.toRadians(-k*45);var n=new Vec3d(-Math.sin(a),0,-Math.cos(a));var centre=new Vec3d(root.getX()+.5-.125*Math.sin(a),root.getY()+23./16,root.getZ()+.5-.125*Math.cos(a));
        player.stopRiding();player.setNoGravity(true);player.setSneaking(false);player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);
        var eye=centre.add(n.multiply(2.5)).add(0,.3,0);var aim=centre.subtract(eye);float yaw=(float)(Math.toDegrees(Math.atan2(aim.z,aim.x))-90),pitch=(float)-Math.toDegrees(Math.atan2(aim.y,Math.hypot(aim.x,aim.z)));
        double height=player.getEyeY()-player.getY();player.teleport(w,eye.x,eye.y-height,eye.z,yaw,pitch);player.setHeadYaw(yaw);
        var result=player.interactionManager.interactBlock(player,w,ItemStack.EMPTY,Hand.MAIN_HAND,new BlockHitResult(centre,Direction.getFacing((float)n.x,0,(float)n.z),root.up(),false));
        int after=NativeShutterWindows.state(w,root,k);if(!result.isAccepted()||after!=1-before||!NativeShutterWindows.complete(w,root,k))throw new IllegalStateException("Native callback failed: "+result+" / "+before+" -> "+after);
        var row=probe.deepCopy();row.addProperty("kind","native");row.addProperty("before",before);row.addProperty("after",after);row.addProperty("status","PASS");report.getAsJsonArray("actions").add(row);
    }
    public static void prefabUse(MinecraftServer server,ServerPlayerEntity player,int index,boolean expected,JsonObject report){
        var w=server.getOverworld();var root=FIXTURES.get(index);load(w,root);player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.setSneaking(false);player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);
        if(w.getBlockState(root).get(CompositeRootBlock.OPEN)!=expected)throw new IllegalStateException("Prefab before mode");
        var owner=((CompositeBlockEntity)w.getBlockEntity(root)).resident();boolean used=false;
        outer:for(int y=0;y<4;y++)for(int x=-3;x<=3;x++)for(int z=-2;z<=2;z++){
            var cell=root.add(x,y,z);
            for(var contribution:CompositeRuntime.contributions(w,cell))if(contribution.owner().equals(owner))for(var box:CompositeRuntime.shape(contribution.shape().collision()).getBoundingBoxes()){
                var point=box.getCenter().add(cell.getX(),cell.getY(),cell.getZ());double height=player.getEyeY()-player.getY();player.teleport(w,point.x,point.y-height,point.z-3,0,0);
                var aim=point.subtract(player.getEyePos());float yaw=(float)(Math.toDegrees(Math.atan2(aim.z,aim.x))-90),pitch=(float)-Math.toDegrees(Math.atan2(aim.y,Math.hypot(aim.x,aim.z)));player.setYaw(yaw);player.setPitch(pitch);player.setHeadYaw(yaw);
                if(!owner.equals(CompositeRuntime.target(w,cell,player)))continue;
                var result=player.interactionManager.interactBlock(player,w,ItemStack.EMPTY,Hand.MAIN_HAND,new BlockHitResult(point,Direction.NORTH,cell,false));
                if(!result.isAccepted())throw new IllegalStateException("Prefab interaction "+result);used=true;break outer;
            }
        }
        if(!used||w.getBlockState(root).get(CompositeRootBlock.OPEN)==expected)throw new IllegalStateException("Prefab did not toggle");
        var row=new JsonObject();row.addProperty("kind","prefab");row.addProperty("fixture",index);row.addProperty("before",expected);row.addProperty("after",!expected);row.addProperty("status","PASS");report.getAsJsonArray("actions").add(row);
    }
    public static void finish(JsonObject report,int expectedActions){
        boolean ok=report.getAsJsonArray("actions").size()==expectedActions;
        for(String key:List.of("nativeAudit","ordinaryPlacements","actions"))for(var row:report.getAsJsonArray(key))ok&=row.getAsJsonObject().get("status").getAsString().equals("PASS");report.addProperty("status",ok?"PASS":"FAIL");
    }
}
