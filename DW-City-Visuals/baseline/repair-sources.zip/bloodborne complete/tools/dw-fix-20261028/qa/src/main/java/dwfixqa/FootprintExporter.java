package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.composite.*;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.api.ModInitializer;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

/** Worldless validation of exact runtime footprints, executed only with an explicit QA property. */
public final class FootprintExporter implements ModInitializer {
    private static <T extends Comparable<T>> BlockState property(BlockState state,Property<T> property,String value){return state.with(property,property.parse(value).orElseThrow());}
    @Override public void onInitialize(){
        String path=System.getProperty("dwfix.exportFootprints");if(path==null)return;
        try{
            var request=JsonParser.parseString(Files.readString(Path.of(path))).getAsJsonObject();var results=new JsonArray();
            for(var raw:request.getAsJsonArray("actors")){
                var row=raw.getAsJsonObject();var block=(CompositeRootBlock)Registries.BLOCK.get(new Identifier(row.get("id").getAsString()));var state=block.getDefaultState();
                for(var entry:row.getAsJsonObject("properties").entrySet()){var prop=block.getStateManager().getProperty(entry.getKey());if(prop==null)throw new IllegalStateException("Unsupported property "+entry.getKey());state=property(state,prop,entry.getValue().getAsString());}
                var xyz=row.getAsJsonArray("root");var root=new BlockPos(xyz.get(0).getAsInt(),xyz.get(1).getAsInt(),xyz.get(2).getAsInt());var payload=CompositeData.nbt(HexFormat.of().parseHex(row.get("payloadNbtHex").getAsString()));
                var result=new JsonObject();result.addProperty("key",row.get("key").getAsString());result.addProperty("simplePhysicalCollision",block.spec.simplePhysicalCollision);
                for(boolean open:new boolean[]{false,true}){
                    var instance=CompositeRuntime.instance(root,state.with(CompositeRootBlock.OPEN,open),new UUID(0,1),payload);var cells=new JsonArray();
                    for(var entry:instance.cells().entrySet()){
                        var c=new JsonObject();c.add("offset",new Gson().toJsonTree(new int[]{entry.getKey().x(),entry.getKey().y(),entry.getKey().z()}));
                        for(String name:new String[]{"collision","selection"}){
                            var boxes=new JsonArray();var list=name.equals("collision")?entry.getValue().collision():entry.getValue().selection();for(var b:list)boxes.add(new Gson().toJsonTree(new double[]{b.minX(),b.minY(),b.minZ(),b.maxX(),b.maxY(),b.maxZ()}));c.add(name,boxes);
                        }
                        cells.add(c);
                    }
                    result.add(open?"open":"closed",cells);
                }
                results.add(result);
            }
            var result=new JsonObject();result.addProperty("status","RUNTIME_WORLDLESS_FOOTPRINT_EXPORT_PASS");result.add("actors",results);Files.writeString(Path.of(request.get("output").getAsString()),new GsonBuilder().setPrettyPrinting().create().toJson(result));System.out.println("DW_FOOTPRINT_EXPORT_PASS "+results.size());System.exit(0);
        }catch(Throwable error){error.printStackTrace();System.exit(2);}
    }
}
