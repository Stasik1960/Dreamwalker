package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.composite.NativeVisuals;
import net.minecraft.block.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;

public final class NativeWallQa {
    public static void set(MinecraftServer server,JsonArray cells,boolean repaired){
        var w=server.getOverworld();for(var value:cells){var row=value.getAsJsonObject();var p=row.getAsJsonArray("pos");var pos=new BlockPos(p.get(0).getAsInt(),p.get(1).getAsInt(),p.get(2).getAsInt());w.getChunk(pos.getX()>>4,pos.getZ()>>4);int visual=row.get(repaired?"next":"old").getAsInt();
            if(w.getBlockEntity(pos)!=null)throw new IllegalStateException("Wall repair intersects a block entity");
            if(visual>=0)NativeVisuals.write(w,pos,visual,Block.NOTIFY_ALL);
            else{NativeVisuals.stage(w,pos,-1);if(!w.setBlockState(pos,Blocks.AIR.getDefaultState(),Block.NOTIFY_ALL))throw new IllegalStateException("Wall baseline clear");NativeVisuals.publish(w,pos);}
            if(NativeVisuals.index(w,pos)!=visual)throw new IllegalStateException("Wall visual update did not publish");
        }
    }
    public static JsonObject finish(MinecraftServer server,JsonArray cells){
        var w=server.getOverworld();for(var value:cells){var row=value.getAsJsonObject();var p=row.getAsJsonArray("pos");var pos=new BlockPos(p.get(0).getAsInt(),p.get(1).getAsInt(),p.get(2).getAsInt());w.getChunk(pos.getX()>>4,pos.getZ()>>4);if(NativeVisuals.index(w,pos)!=row.get("next").getAsInt()||w.getBlockEntity(pos)!=null)throw new IllegalStateException("Wall final state");}
        var result=new JsonObject();result.addProperty("status","PASS");result.addProperty("cells",cells.size());result.addProperty("noBlockEntities",true);return result;
    }
}
