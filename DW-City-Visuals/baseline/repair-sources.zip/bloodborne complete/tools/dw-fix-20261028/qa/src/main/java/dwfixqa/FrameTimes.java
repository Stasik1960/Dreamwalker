package dwfixqa;

import com.google.gson.JsonObject;
import java.util.Arrays;

/** Fixed-size, render-thread-only samples. No allocation or I/O while recording a frame. */
public final class FrameTimes {
    private static final long[] SAMPLES=new long[20000];
    private static int size,limit;
    private static long previous;
    private static boolean active;
    public static void start(int frames){size=0;previous=0;limit=Math.max(1,Math.min(frames,SAMPLES.length));active=true;}
    public static void rendered(){
        if(!active)return;
        long now=System.nanoTime();
        if(previous!=0&&size<limit)SAMPLES[size++]=now-previous;
        previous=now;
    }
    public static boolean complete(){return size>=limit;}
    public static JsonObject stop(){
        active=false;var out=new JsonObject();out.addProperty("frames",size);
        if(size==0)return out;
        long[] sorted=Arrays.copyOf(SAMPLES,size);Arrays.sort(sorted);double total=0;
        for(int i=0;i<size;i++)total+=SAMPLES[i];
        out.addProperty("meanMs",total/size/1e6);out.addProperty("meanFps",1e9/(total/size));
        out.addProperty("p50Ms",sorted[(int)Math.floor((size-1)*.50)]/1e6);
        out.addProperty("p95Ms",sorted[(int)Math.floor((size-1)*.95)]/1e6);
        out.addProperty("p99Ms",sorted[(int)Math.floor((size-1)*.99)]/1e6);
        out.addProperty("maximumMs",sorted[size-1]/1e6);return out;
    }
}
