package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.architecture.NoCollidePlacement;
import dev.dreamwalker.bloodbornedw.composite.*;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.*;

/** Integrated-world checks against real registered items, callback use and retained cells. */
public final class BenchQa {
    private static final List<BlockPos> fixtures=new ArrayList<>();
    private static ServerWorld brokenWorld;private static BlockPos brokenRoot;
    private static String brokenIdentity;private static BenchSeatEntity brokenSeat;
    private static ServerWorld world(MinecraftServer server,JsonObject probe){
        var key=RegistryKey.of(RegistryKeys.WORLD,new Identifier(probe.get("dimension").getAsString()));
        var result=server.getWorld(key);if(result==null)throw new IllegalStateException("Missing bench dimension");return result;
    }
    private static BlockPos root(JsonObject probe){var p=probe.getAsJsonArray("root");return new BlockPos(p.get(0).getAsInt(),p.get(1).getAsInt(),p.get(2).getAsInt());}
    private static void load(ServerWorld world,BlockPos pos){for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)world.getChunk((pos.getX()>>4)+x,(pos.getZ()>>4)+z);}
    private static BenchSeating.Target target(ServerWorld world,BlockPos root,String identity){
        return BenchSeating.targets(world,root).stream().filter(t->t.root().equals(root)&&(identity==null||t.identity().equals(identity))).findFirst().orElseThrow(()->new IllegalStateException("No bench target "+root+" / "+identity));
    }
    public static BenchSeatEntity sit(ServerWorld world,ServerPlayerEntity player,BenchSeating.Target target){
        player.stopRiding();player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.setSneaking(false);
        player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);
        var contact=target.seats().get(0).contact();
        player.teleport(world,contact.x,contact.y+.3,contact.z-2.5,0,0);
        var cell=BlockPos.ofFloored(contact.add(0,-1e-4,0));
        var result=player.interactionManager.interactBlock(player,world,ItemStack.EMPTY,Hand.MAIN_HAND,new BlockHitResult(contact,Direction.UP,cell,false));
        if(!result.isAccepted()||!(player.getVehicle() instanceof BenchSeatEntity seat)||!seat.rootPos().equals(target.root())||!seat.identity().equals(target.identity()))throw new IllegalStateException("Ordinary bench use failed: "+result+" / "+cell);
        if(Math.abs(seat.getMountedHeightOffset()+.25)>1e-6)throw new IllegalStateException("Seat height was not raised");
        return seat;
    }
    public static void reviewProbe(MinecraftServer server,ServerPlayerEntity player,JsonObject probe){
        var world=world(server,probe);var root=root(probe);load(world,root);
        sit(world,player,target(world,root,"native-bench/"+probe.get("template").getAsString()));
    }
    public static void reviewFixture(MinecraftServer server,ServerPlayerEntity player,int index){
        if(index<0||index>=fixtures.size())throw new IllegalArgumentException("Bench fixture index");
        var world=server.getOverworld();var root=fixtures.get(index);load(world,root);sit(world,player,target(world,root,null));
    }
    private static <T extends Comparable<T>> BlockState property(BlockState state,Property<T> property,String value){return state.with(property,property.parse(value).orElseThrow());}
    private static JsonObject place(MinecraftServer server,ServerPlayerEntity player,int index,int variant,int floorType){
        var world=server.getOverworld();var floor=new BlockPos(650+index*8,249,-1300);load(world,floor);
        BlockState support=switch(floorType){case 0->Blocks.STONE.getDefaultState();case 1->Registries.BLOCK.get(new Identifier("bloodborne_dw:source_bricks_stone_1")).getDefaultState();default->Blocks.SMOOTH_STONE_SLAB.getDefaultState();};
        if(floorType==1){var compact=support.getBlock().getStateManager().getProperty("compact");if(compact==null)throw new IllegalStateException("Missing compact floor property");support=property(support,compact,"true");}
        for(int x=-2;x<=2;x++)for(int z=-2;z<=2;z++)world.setBlockState(floor.add(x,0,z),support,Block.NOTIFY_ALL);
        double top=floor.getY()+(floorType==2?.5:1);
        player.stopRiding();player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.teleport(world,floor.getX()+.5,top+.1,floor.getZ()-2.5,0,0);
        if(NoCollidePlacement.armed(player))throw new IllegalStateException("No-collide must be disabled for normal bench placement");
        var block=Registries.BLOCK.get(new Identifier("bloodborne_dw:source_hold_bench"));var stack=new ItemStack(block.asItem());stack.getOrCreateSubNbt("BlockStateTag").putString("variant",String.valueOf(variant));player.setStackInHand(Hand.MAIN_HAND,stack);
        var context=new ItemPlacementContext(world,player,Hand.MAIN_HAND,stack,new BlockHitResult(new Vec3d(floor.getX()+.5,top,floor.getZ()+.5),Direction.UP,floor,false));
        var before=context.getBlockPos();var result=((BlockItem)stack.getItem()).place(context);
        var expected=new BlockPos(floor.getX(),(int)Math.ceil(top-1e-7),floor.getZ());
        if(!result.isAccepted()||!(world.getBlockEntity(expected) instanceof CompositeBlockEntity entity)||entity.resident()==null)throw new IllegalStateException("Bench placement failed: "+result+" / "+CompositeRuntime.lastResult()+" / context="+before+" / expected="+expected);
        var target=target(world,expected,null);
        for(var point:target.seats())if(Math.abs(point.contact().y-(top+1))>1e-4)throw new IllegalStateException("Bench sinks above floor "+floorType+": "+point.contact().y+" expected "+(top+1));
        if(!world.getBlockState(floor).equals(support))throw new IllegalStateException("Bench replaced the support floor");
        fixtures.add(expected);sit(world,player,target);player.stopRiding();
        var row=new JsonObject();row.addProperty("variant",variant);row.addProperty("floorType",floorType);row.addProperty("initialContext",before.toShortString());row.addProperty("root",expected.toShortString());row.addProperty("contactY",target.seats().get(0).contact().y);row.addProperty("floorTop",top);row.addProperty("status","PASS");return row;
    }
    public static JsonArray surfaceFixtures(MinecraftServer server,ServerPlayerEntity player){
        fixtures.clear();var rows=new JsonArray();for(int floor=0;floor<3;floor++)for(int variant=0;variant<2;variant++)rows.add(place(server,player,floor*2+variant,variant,floor));return rows;
    }
    public static BenchSeating.Target surfaceFixture(MinecraftServer server,int index){var w=server.getOverworld();var p=fixtures.get(index);load(w,p);return target(w,p,null);}
    public static JsonObject run(MinecraftServer server,ServerPlayerEntity player,JsonArray probes){
        var report=new JsonObject();var nativeRows=new JsonArray();var placement=new JsonArray();fixtures.clear();
        var rideExamples=new LinkedHashMap<String,JsonObject>();
        for(var raw:probes){var probe=raw.getAsJsonObject();var row=probe.deepCopy();
            try{var world=world(server,probe);var root=root(probe);load(world,root);var identity="native-bench/"+probe.get("template").getAsString();var target=target(world,root,identity);
                if(!BenchSeating.valid(world,root,identity)||target.seats().size()!=probe.get("seats").getAsInt())throw new IllegalStateException("Native bench identity/seat count");
                for(var point:target.seats())if(Math.abs(point.contact().y-probe.getAsJsonArray("centre").get(1).getAsDouble())>1e-4)throw new IllegalStateException("Native contact height mismatch");
                row.addProperty("status","PASS");rideExamples.putIfAbsent(probe.get("dimension").getAsString(),probe);
                if(target.seats().size()==2)rideExamples.put("partial/"+root,probe);
            }catch(Throwable error){row.addProperty("status","FAIL");row.addProperty("error",error.toString());}nativeRows.add(row);
        }
        var rides=new JsonArray();
        for(var probe:rideExamples.values()){var row=probe.deepCopy();try{reviewProbe(server,player,probe);player.stopRiding();row.addProperty("status","PASS");}catch(Throwable error){row.addProperty("status","FAIL");row.addProperty("error",error.toString());}rides.add(row);}
        for(int floor=0;floor<3;floor++)for(int variant=0;variant<2;variant++)try{placement.add(place(server,player,floor*2+variant,variant,floor));}catch(Throwable error){var row=new JsonObject();row.addProperty("floorType",floor);row.addProperty("variant",variant);row.addProperty("status","FAIL");row.addProperty("error",error.toString());placement.add(row);}
        try{var probe=probes.get(probes.size()-1).getAsJsonObject();brokenWorld=world(server,probe);brokenRoot=root(probe);brokenIdentity="native-bench/"+probe.get("template").getAsString();brokenSeat=sit(brokenWorld,player,target(brokenWorld,brokenRoot,brokenIdentity));
            if(!player.interactionManager.tryBreakBlock(brokenRoot))throw new IllegalStateException("Creative bench fragment break rejected");report.addProperty("fragmentBroken",true);
        }catch(Throwable error){report.addProperty("breakError",error.toString());}
        report.add("nativeAudit",nativeRows);report.add("ordinaryNativeRides",rides);report.add("ordinaryPlacements",placement);return report;
    }
    public static void finish(JsonObject report){
        if(brokenWorld!=null)load(brokenWorld,brokenRoot);
        boolean invalid=brokenWorld!=null&&!BenchSeating.valid(brokenWorld,brokenRoot,brokenIdentity);
        report.addProperty("brokenBenchInvalidated",invalid);report.addProperty("occupiedSeatRemovedAfterBreak",brokenSeat!=null&&brokenSeat.isRemoved());
        boolean ok=invalid&&brokenSeat!=null&&brokenSeat.isRemoved()&&report.has("fragmentBroken")&&!report.has("breakError");
        for(String key:List.of("nativeAudit","ordinaryNativeRides","ordinaryPlacements"))for(var row:report.getAsJsonArray(key))ok&=row.getAsJsonObject().get("status").getAsString().equals("PASS");
        report.addProperty("status",ok?"PASS":"FAIL");
    }
}
