package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;

public final class CanonicalLampQa {
    public static JsonObject run(MinecraftServer server,ServerPlayerEntity player,JsonArray probes){
        int count=0,used=0;
        for(int i=0;i<probes.size();i++){
            var row=probes.get(i).getAsJsonObject();var xyz=row.getAsJsonArray("root");var p=new BlockPos(xyz.get(0).getAsInt(),xyz.get(1).getAsInt(),xyz.get(2).getAsInt());
            var w=server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(row.get("dimension").getAsString())));for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)w.getChunk((p.getX()>>4)+x,(p.getZ()>>4)+z);
            var state=w.getBlockState(p);if(!state.isOf(Registries.BLOCK.get(new Identifier("bloodborne_dw:source_standard_lantern")))||state.getLuminance()!=15||state.get(CompositeRootBlock.OPEN))throw new IllegalStateException("Migrated lamp state "+p);
            if(!(w.getBlockEntity(p) instanceof CompositeBlockEntity entity)||entity.resident()==null||!entity.resident().registryId().equals("bloodborne_dw:source_standard_lantern"))throw new IllegalStateException("Migrated lamp ownership "+p);count++;

        }
        var result=new JsonObject();result.addProperty("status","PASS");result.addProperty("audited",count);result.addProperty("ordinaryUseCycles",used);return result;
    }
    public static JsonObject cycle(MinecraftServer server,ServerPlayerEntity player,JsonObject row){
        var a=row.getAsJsonArray("root");var p=new BlockPos(a.get(0).getAsInt(),a.get(1).getAsInt(),a.get(2).getAsInt());
        var w=server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(row.get("dimension").getAsString())));
        var entity=(CompositeBlockEntity)w.getBlockEntity(p);var owner=entity.resident();
        player.changeGameMode(GameMode.CREATIVE);player.setNoGravity(true);player.setSneaking(false);player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);
        var off=Door90001Qa.click(w,p,owner,player);if(!off.isAccepted()||!w.getBlockState(p).get(CompositeRootBlock.OPEN)||w.getBlockState(p).getLuminance()!=0){
            var diagnostic=row.deepCopy();diagnostic.addProperty("status","FAIL_ORDINARY_USE");diagnostic.add("click",Door90001Qa.recentClick.deepCopy());
            diagnostic.addProperty("rootState",w.getBlockState(p).toString());diagnostic.addProperty("payload",entity.payload().toString());
            diagnostic.addProperty("directRuntimeUse",CompositeRuntime.use(w,p,player).toString());diagnostic.addProperty("lastTransaction",String.valueOf(CompositeRuntime.lastResult()));
            diagnostic.addProperty("afterDirectState",w.getBlockState(p).toString());
            if(w.getBlockState(p).get(CompositeRootBlock.OPEN))CompositeRuntime.use(w,p,player);return diagnostic;
        }
        var on=Door90001Qa.click(w,p,owner,player);if(!on.isAccepted()||w.getBlockState(p).get(CompositeRootBlock.OPEN)||w.getBlockState(p).getLuminance()!=15)throw new IllegalStateException("Migrated lamp on "+p+" / "+on);
        var result=row.deepCopy();result.addProperty("status","PASS");result.addProperty("ordinaryUseCycle",true);return result;
    }

}
