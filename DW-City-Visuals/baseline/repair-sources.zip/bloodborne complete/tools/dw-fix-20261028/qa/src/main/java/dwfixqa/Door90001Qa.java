package dwfixqa;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.composite.*;
import dev.dreamwalker.bloodbornedw.runtime.TransactionCore;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;

/** Real registered item and owner transactions, including the shifted map door. */
public final class Door90001Qa {
    private static final BlockPos ROOT=new BlockPos(600,250,-1300);
    private static dev.dreamwalker.bloodbornedw.runtime.ObjectInstance.Owner preparedOwner;

    public static JsonObject prepare(MinecraftServer server, ServerPlayerEntity player) {
        var output=new JsonObject();
        var world=server.getOverworld();
        player.changeGameMode(GameMode.CREATIVE);
        var block=(CompositeRootBlock)Registries.BLOCK.get(new Identifier("bloodborne_dw:prototype_double_door"));
        if (block.spec.requiredSupport) throw new IllegalStateException("90001 retains obsolete center support");
        var p=ROOT;
        for(int x=-1;x<=1;x++) for(int z=-1;z<=1;z++) world.getChunk((p.getX()>>4)+x,(p.getZ()>>4)+z);
        player.teleport(world,p.getX()+6,p.getY()+1,p.getZ()+6,0,0);
        player.setNoGravity(true);
        world.setBlockState(p.down(),Blocks.STONE.getDefaultState(),Block.NOTIFY_ALL);
        ItemStack stack=new ItemStack(block.asItem());
        player.setStackInHand(Hand.MAIN_HAND,stack);
        var context=new ItemPlacementContext(world,player,Hand.MAIN_HAND,stack,
                new BlockHitResult(new Vec3d(p.getX()+.5,p.getY(),p.getZ()+.5),Direction.UP,p.down(),false));
        var placed=((BlockItem)stack.getItem()).place(context);
        if(!placed.isAccepted() || !world.getBlockState(p).isOf(block))
            throw new IllegalStateException("90001 normal placement failed: "+placed+" / "+CompositeRuntime.lastResult());
        if(!(world.getBlockEntity(p) instanceof CompositeBlockEntity entity) || entity.resident()==null)
            throw new IllegalStateException("90001 placed without owner");
        preparedOwner=entity.resident();
        output.addProperty("ordinaryPlacementWithoutNoCollide",true);
        output.addProperty("preparedAtServerTick",server.getTicks());
        return output;
    }

    public static JsonObject run(MinecraftServer server, ServerPlayerEntity player) {
        var output=new JsonObject();
        var world=server.getOverworld();
        var p=ROOT;
        var owner=preparedOwner;
        if(owner==null || !(world.getBlockEntity(p) instanceof CompositeBlockEntity entity)
                || !owner.equals(entity.resident()))throw new IllegalStateException("Prepared door owner is missing");
        player.changeGameMode(GameMode.CREATIVE);
        player.setSneaking(false);
        player.setNoGravity(true);
        player.setStackInHand(Hand.MAIN_HAND,ItemStack.EMPTY);
        var opened=click(world,p,owner,player);
        if(!opened.isAccepted() || !world.getBlockState(p).get(CompositeRootBlock.OPEN))
            throw new IllegalStateException("90001 opening failed: "+opened);
        var shut=click(world,p,owner,player);
        if(!shut.isAccepted() || world.getBlockState(p).get(CompositeRootBlock.OPEN))
            throw new IllegalStateException("90001 closing failed: "+shut);
        output.addProperty("ordinaryPlacementWithoutNoCollide",true);
        if(!(world.getBlockEntity(p) instanceof CompositeBlockEntity finalEntity)||finalEntity.resident()==null
                ||!owner.equals(finalEntity.resident()))throw new IllegalStateException("Door owner changed after use");
        output.addProperty("ordinaryBlockUseOpenClose",true);
        output.addProperty("serverOpenClose",true);
        output.addProperty("ownerPreserved",true);
        output.addProperty("requiredSupport",false);
        return output;
    }

    static JsonObject recentClick=new JsonObject();
    static ActionResult click(net.minecraft.server.world.ServerWorld world,BlockPos root,
            dev.dreamwalker.bloodbornedw.runtime.ObjectInstance.Owner owner,ServerPlayerEntity player) {
        // Runtime selection uses the server player's actual ray, not the supplied hit vector.
        // Click an allocated member after aiming at its real outline, including after it moves.
        int memberCells=0, aimedBoxes=0;
        JsonObject lastRay=new JsonObject();
        double eye=player.getEyeY()-player.getY();
        for(int y=0;y<5;y++)for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++) {
            var p=root.add(x,y,z);
            for(var contribution:CompositeRuntime.contributions(world,p)) {
                if(!contribution.owner().equals(owner))continue;
                memberCells++;
                var boxes=contribution.shape().collision().isEmpty()
                        ? contribution.shape().selection():contribution.shape().collision();
                for(var box:CompositeRuntime.shape(boxes).getBoundingBoxes()) {
                    aimedBoxes++;
                    var point=box.getCenter().add(p.getX(),p.getY(),p.getZ());
                    player.teleport(world,point.x,point.y-eye,point.z-3,0,0);
                    var aim=point.subtract(player.getEyePos());
                    float yaw=(float)(Math.toDegrees(Math.atan2(aim.z,aim.x))-90);
                    float pitch=(float)-Math.toDegrees(Math.atan2(aim.y,Math.hypot(aim.x,aim.z)));
                    player.setYaw(yaw);player.setPitch(pitch);player.setHeadYaw(yaw);
                    var selected=CompositeRuntime.target(world,p,player);
                    lastRay.addProperty("cell",p.toShortString());
                    lastRay.addProperty("eye",player.getEyePos().toString());
                    lastRay.addProperty("direction",player.getRotationVec(1).toString());
                    lastRay.addProperty("point",point.toString());
                    lastRay.addProperty("selected",String.valueOf(selected));
                    if(!owner.equals(selected))continue;
                    lastRay.addProperty("blockState",world.getBlockState(p).toString());
                    lastRay.addProperty("blockClass",world.getBlockState(p).getBlock().getClass().getName());
                    lastRay.addProperty("mode",player.interactionManager.getGameMode().getName());
                    lastRay.addProperty("sneaking",player.isSneaking());
                    recentClick=lastRay;
                    var result=player.interactionManager.interactBlock(player,world,ItemStack.EMPTY,Hand.MAIN_HAND,
                            new BlockHitResult(point,Direction.NORTH,p,false));
                    recentClick.addProperty("actionResult",result.toString());return result;
                }
            }
        }
        throw new IllegalStateException("No aimed door member could be selected: members="+memberCells
                +", boxes="+aimedBoxes+", last="+lastRay);
    }
}
