package dwfixqa;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.registry.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.*;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.WorldChunk;

/** Bounded lighting work in the disposable QA world. Only cache fields are later imported. */
public final class PrelightQa {
    private record Task(ServerWorld world,ChunkPos pos){}
    private record Loaded(Task task,WorldChunk chunk){}
    private static final ChunkTicketType<Long> TICKET=ChunkTicketType.create("dwfix_prelight",Long::compare);
    private static PrelightQa active;
    private static boolean registered;
    private final MinecraftServer server;
    private final List<Task> tasks=new ArrayList<>();
    private final List<Loaded> batch=new ArrayList<>();
    private final Path output;
    private final Consumer<JsonObject> completed;
    private final Consumer<Throwable> failed;
    private final long start=System.nanoTime();
    private CompletableFuture<Void> pending;
    private int next,done;
    private PrelightQa(MinecraftServer server,JsonArray rows,Path output,Consumer<JsonObject> completed,Consumer<Throwable> failed){
        this.server=server;this.output=output;this.completed=completed;this.failed=failed;
        for(var raw:rows){var row=raw.getAsJsonObject();var world=server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(row.get("dimension").getAsString())));if(world==null)throw new IllegalArgumentException("Missing prelight dimension");tasks.add(new Task(world,new ChunkPos(row.get("x").getAsInt(),row.get("z").getAsInt())));}
    }
    public static void start(MinecraftServer server,JsonArray chunks,Path output,Consumer<JsonObject> completed,Consumer<Throwable> failed){
        if(active!=null||!server.isOnThread())throw new IllegalStateException("Prelight ownership/thread");
        if(!registered){registered=true;ServerTickEvents.END_SERVER_TICK.register(s->{if(active!=null&&active.server==s)active.tick();});}
        active=new PrelightQa(server,chunks,output,completed,failed);active.progress("RUNNING");
    }
    private JsonObject progress(String status){
        var row=new JsonObject();row.addProperty("status",status);row.addProperty("completedChunks",done);row.addProperty("totalChunks",tasks.size());row.addProperty("seconds",(System.nanoTime()-start)/1e9);
        try{Files.writeString(output.resolve("prelight-progress.json"),new GsonBuilder().setPrettyPrinting().create().toJson(row));}catch(Exception e){throw new RuntimeException(e);}return row;
    }
    private void release(){for(var value:batch)value.task.world.getChunkManager().removeTicket(TICKET,value.task.pos,2,value.task.pos.toLong());batch.clear();}
    private void tick(){
        try{
            if(pending!=null){
                if(!pending.isDone())return;pending.join();
                for(var value:batch){if(!value.chunk.isLightOn())throw new IllegalStateException("Lighting future finished without lit chunk "+value.task.pos);value.chunk.setNeedsSaving(true);}
                done+=batch.size();release();pending=null;
                if(done%32==0||done==tasks.size()){for(var w:server.getWorlds())w.getChunkManager().save(false);progress("RUNNING");}
            }
            if(next==tasks.size()){var result=progress("PASS");active=null;completed.accept(result);return;}
            var futures=new ArrayList<CompletableFuture<?>>();
            for(int i=0;i<4&&next<tasks.size();i++){
                var task=tasks.get(next++);var manager=task.world.getChunkManager();manager.addTicket(TICKET,task.pos,2,task.pos.toLong());var chunk=task.world.getChunk(task.pos.x,task.pos.z);batch.add(new Loaded(task,chunk));
                Heightmap.populateHeightmaps(chunk,EnumSet.allOf(Heightmap.Type.class));chunk.setLightOn(false);futures.add(manager.getLightingProvider().light(chunk,false));
            }
            pending=CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new));
        }catch(Throwable error){release();active=null;progress("FAIL");failed.accept(error);}
    }
}
