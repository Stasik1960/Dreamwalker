package dwfixqa;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

/** A disposable integrated-client driver; it never installs into the user's launcher. */
public final class RepairQa implements ClientModInitializer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private JsonObject plan;
    private final JsonObject report = new JsonObject();
    private JsonArray phases = new JsonArray();
    private Path output;
    private int phase, settled, ticks;
    private CompletableFuture<Void> serverJob;
    private volatile boolean screenshotSaved;
    private boolean waiting, stopping;
    private long started;
    private boolean startupCaptured;
    private boolean holding;
    private boolean inspectionFailure;
    private boolean measuring;
    private long phaseStarted;
    private JsonObject loadingTiming;

    @Override public void onInitializeClient() {
        try {
            plan = JsonParser.parseString(Files.readString(Path.of(System.getProperty("dwfix.qa")))).getAsJsonObject();
            output = Path.of(plan.get("output").getAsString());
            Files.createDirectories(output);
            report.addProperty("status", "STARTING");
            report.add("phases", phases);
            started = System.nanoTime();
            save();
            ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        } catch (Exception error) { throw new RuntimeException(error); }
    }

    private void tick(MinecraftClient client) {
        if (stopping) return;
        if (++ticks > 20*1800) { fail(new IllegalStateException("QA timeout")); return; }
        if (client.world == null || client.player == null || client.getServer() == null) {
            if (ticks%100==0) {
                report.addProperty("startupScreen",client.currentScreen==null ? "none" : client.currentScreen.getClass().getName());
                report.addProperty("startupOverlay",client.getOverlay()==null ? "none" : client.getOverlay().getClass().getName());
                save();
            }
            if (!startupCaptured && ticks>100 && client.getOverlay()==null && client.currentScreen!=null) {
                startupCaptured=true;
                ScreenshotRecorder.saveScreenshot(client.runDirectory,"startup.png",client.getFramebuffer(),message -> {});
            }
            return;
        }
        try {
            if (holding) {
                Path instruction=output.resolve("next.json");
                if(!Files.exists(instruction))return;
                var command=JsonParser.parseString(Files.readString(instruction)).getAsJsonObject();
                Files.move(instruction,output.resolve("processed-"+System.nanoTime()+".json"));
                if(command.get("action").getAsString().equals("finish")) {finish(client);return;}
                if(command.get("action").getAsString().equals("retry")){
                    if(!inspectionFailure||!report.has("benchSurfacePreparation"))throw new IllegalStateException("Retry needs completed support preparation and an inspected client failure");
                    if(!report.has("priorClientFailures"))report.add("priorClientFailures",new JsonArray());
                    var previous=new JsonObject();previous.add("error",report.get("error"));if(report.has("benchSurfaceClientState"))previous.add("state",report.get("benchSurfaceClientState"));report.getAsJsonArray("priorClientFailures").add(previous);
                    phases=new JsonArray();report.add("phases",phases);report.remove("benchSurfaceTests");report.remove("error");report.addProperty("status","RETRYING_ALL_BENCH_PHASES");phase=0;serverJob=null;waiting=false;holding=false;inspectionFailure=false;save();return;
                }
                if(!command.get("action").getAsString().equals("capture"))throw new IllegalArgumentException("Unknown review command");
                var row=command.getAsJsonObject("phase");
                if(!row.get("name").getAsString().matches("[a-z0-9-]{1,80}")
                        ||Math.abs(row.get("x").getAsDouble())>2000||Math.abs(row.get("z").getAsDouble())>2000)
                    throw new IllegalArgumentException("Review camera is out of bounds");
                plan.getAsJsonArray("phases").add(row);holding=false;
            }
            if (serverJob == null) {
                JsonObject row = plan.getAsJsonArray("phases").get(phase).getAsJsonObject();
                measuring=false;loadingTiming=null;phaseStarted=System.nanoTime();
                if(row.has("measureFrames"))FrameTimes.start(20000);
                client.options.setPerspective(row.has("seatProbe")||row.has("placedBenchReview")||row.has("benchSurface")
                        ?net.minecraft.client.option.Perspective.THIRD_PERSON_FRONT:net.minecraft.client.option.Perspective.FIRST_PERSON);
                client.options.hudHidden = true;
                client.options.pauseOnLostFocus = false;
                if (plan.has("disableFogForVisualReview") && plan.get("disableFogForVisualReview").getAsBoolean()) {
                    var type=Class.forName("dev.imb11.fog.config.FogConfig");
                    var config=type.getMethod("getInstance").invoke(null);
                    type.getField("disableMod").setBoolean(config,true);
                    report.addProperty("fogDisabledOnlyInDisposableVisualReview",true);
                }
                client.setScreen(null);
                serverJob = new CompletableFuture<>();
                client.getServer().execute(() -> {
                    try {
                        var server = client.getServer();
                        var player = server.getPlayerManager().getPlayer(client.player.getUuid());
                        if(phase==0&&plan.has("benchSurfaceProbes")&&!report.has("benchSurfacePreparation"))report.add("benchSurfacePreparation",BenchSurfaceQa.prepare(server,player,plan.getAsJsonArray("benchSurfaceProbes")));
                        if(phase==0&&plan.has("frozenArchFixtureCells")) {
                            var w=server.getOverworld();
                            for(var value:plan.getAsJsonArray("frozenArchFixtureCells")) {
                                var cell=value.getAsJsonObject();var p=new BlockPos(cell.get("x").getAsInt(),cell.get("y").getAsInt(),cell.get("z").getAsInt());w.getChunk(p.getX()>>4,p.getZ()>>4);
                                var b=net.minecraft.registry.Registries.BLOCK.get(new Identifier("bloodborne_dw:static_architecture_"+cell.get("bank").getAsInt()));var property=(net.minecraft.state.property.IntProperty)b.getStateManager().getProperty("part");w.setBlockState(p,b.getDefaultState().with(property,cell.get("part").getAsInt()),Block.NOTIFY_ALL);
                            }
                        }
                        if (phase==0 && plan.has("canonicalLampProbes"))report.add("canonicalLampTests",CanonicalLampQa.run(server,player,plan.getAsJsonArray("canonicalLampProbes")));
                        if (phase==0 && plan.has("testLantern"))report.add("lanternPreparation",LanternQa.prepare(server,player));
                        if (phase==0 && plan.has("windowProbes"))
                            report.add("windowTests",WindowQa.prepare(server,player,plan.getAsJsonArray("windowProbes")));
                        if (phase==0 && plan.has("benchProbes"))
                            report.add("benchTests",BenchQa.run(server,player,plan.getAsJsonArray("benchProbes")));
                        if (phase==0 && plan.has("testDoor90001") && plan.get("testDoor90001").getAsBoolean())
                            report.add("door90001Placement",Door90001Qa.prepare(server,player));
                        if (phase==0 && plan.has("testDarkness") && plan.get("testDarkness").getAsBoolean())
                            report.add("darknessCreativeTests",testDarkness(server,player));
                        if (phase==0 && plan.has("testGallery") && plan.get("testGallery").getAsBoolean())
                            report.add("galleryFixtures",GalleryQa.install(server,player));
                        if (phase==0 && plan.has("inertProbes")) {
                            var probes=new JsonArray();
                            for(var raw:plan.getAsJsonArray("inertProbes")) {
                                var probe=raw.getAsJsonObject();
                                var probeWorld=server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(probe.get("dimension").getAsString())));
                                var p=new BlockPos(probe.get("x").getAsInt(),probe.get("y").getAsInt(),probe.get("z").getAsInt());
                                var chunk=probeWorld.getWorldChunk(p);
                                if(!probeWorld.getBlockState(p).isAir()||probeWorld.getBlockEntity(p)!=null
                                        ||dev.dreamwalker.bloodbornedw.composite.NativeVisuals.index(chunk,p)>=0)
                                    throw new IllegalStateException("Inert cell reappeared at "+p);
                                var result=probe.deepCopy();result.addProperty("status","PASS");probes.add(result);
                            }
                            report.add("inertRemovalTests",probes);
                        }
                        if(row.has("materializeArch")&&row.get("materializeArch").getAsBoolean())report.add("controlledArchPlacement",ArchQa.materialize(server,player));
                        if(row.has("canonicalLampCycle")) {
                            if(!report.has("canonicalLampCycles"))report.add("canonicalLampCycles",new JsonArray());
                            report.getAsJsonArray("canonicalLampCycles").add(CanonicalLampQa.cycle(server,player,row.getAsJsonObject("canonicalLampCycle")));
                        }
                        if (row.has("respawnFromVoid") && row.get("respawnFromVoid").getAsBoolean()) {
                            player.getWorld().getGameRules().get(net.minecraft.world.GameRules.DO_IMMEDIATE_RESPAWN).set(true,server);
                            player.kill();
                            serverJob.complete(null);
                            return;
                        }
                        if(row.has("benchSurface")){BenchSurfaceQa.begin(server,player,row.getAsJsonObject("benchSurface"));serverJob.complete(null);return;}
                        player.stopRiding();
                        var key = RegistryKey.of(RegistryKeys.WORLD, new Identifier(row.has("dimension")
                                ? row.get("dimension").getAsString() : "minecraft:overworld"));
                        var world = server.getWorld(key);
                        if (world == null) throw new IllegalStateException("Missing QA dimension " + key);
                        if(plan.has("fixedTime")) {
                            world.setTimeOfDay(plan.get("fixedTime").getAsLong());
                            world.getGameRules().get(net.minecraft.world.GameRules.DO_DAYLIGHT_CYCLE).set(false,server);
                            world.getGameRules().get(net.minecraft.world.GameRules.DO_WEATHER_CYCLE).set(false,server);
                            world.setWeather(0,0,false,false);
                        }
                        world.getGameRules().get(net.minecraft.world.GameRules.SPECTATORS_GENERATE_CHUNKS).set(true,server);
                        player.changeGameMode(GameMode.byName(row.has("mode") ? row.get("mode").getAsString() : "spectator"));
                        player.setNoGravity(true);
                        if(row.has("nativeWallState"))NativeWallQa.set(server,plan.getAsJsonArray("nativeWallCells"),row.get("nativeWallState").getAsString().equals("repaired"));
                        if(row.has("plainLampToggle"))LanternQa.togglePlain(server,player,row.get("plainLampToggle").getAsBoolean());
                        if(row.has("nativeWindow"))WindowQa.nativeUse(server,player,row.getAsJsonObject("nativeWindow"),row.get("expectedWindowMode").getAsInt(),report.getAsJsonObject("windowTests"));
                        else if(row.has("prefabWindow"))WindowQa.prefabUse(server,player,row.get("prefabWindow").getAsInt(),row.get("expectedWindowOpen").getAsBoolean(),report.getAsJsonObject("windowTests"));
                        else if(row.has("seatProbe")||row.has("placedBenchReview")||row.has("benchSurface")) {
                            if(row.has("seatProbe"))BenchQa.reviewProbe(server,player,row.getAsJsonObject("seatProbe"));
                            else BenchQa.reviewFixture(server,player,row.get("placedBenchReview").getAsInt());
                            player.setYaw(player.getYaw()+row.get("yaw").getAsFloat());player.setPitch(row.get("pitch").getAsFloat());
                        } else player.teleport(world, row.get("x").getAsDouble(), row.get("y").getAsDouble(), row.get("z").getAsDouble(),
                                row.get("yaw").getAsFloat(), row.get("pitch").getAsFloat());
                        player.setVelocity(0,0,0);
                        serverJob.complete(null);
                    } catch (Throwable error) { serverJob.completeExceptionally(error); }
                });
                settled=0;
                return;
            }
            if (!serverJob.isDone()) return;
            serverJob.join();
            var cameraRow=plan.getAsJsonArray("phases").get(phase).getAsJsonObject();
            if(cameraRow.has("lockCamera")&&cameraRow.get("lockCamera").getAsBoolean()){
                client.player.setYaw(cameraRow.get("yaw").getAsFloat());client.player.setPitch(cameraRow.get("pitch").getAsFloat());
            }
            if(cameraRow.has("benchSurface"))BenchSurfaceQa.client(client);
            if (waiting) {
                if (!screenshotSaved) return;
                waiting=false;
                phase++;
                serverJob=null;
                save();
                if (phase==plan.getAsJsonArray("phases").size()) {
                    if(plan.has("holdForReview")&&plan.get("holdForReview").getAsBoolean()) {
                        holding=true;report.addProperty("status","HOLDING_FOR_REVIEW");save();
                    } else finish(client);
                }
                return;
            }
            var row=plan.getAsJsonArray("phases").get(phase).getAsJsonObject();
            if (row.has("respawnFromVoid") && !client.player.isAlive()) return;
            if (!client.world.getRegistryKey().getValue().toString().equals(row.has("dimension")
                    ? row.get("dimension").getAsString() : "minecraft:overworld")) return;
            if (++settled < (row.has("settleTicks") ? row.get("settleTicks").getAsInt() : 160)) return;
            // Readiness is a phase boundary, not part of the steady-frame workload.
            // The measured camera is locked; final terrain/position are still recorded.
            if (!measuring) {
                if ((!row.has("mode") || row.has("seatProbe") || row.has("placedBenchReview") || row.has("requireTerrain")) && !client.worldRenderer.isTerrainRenderComplete() && settled<2400) return;
                boolean delivered=viewChunksDelivered(client);
                if(!delivered) {
                    if(settled>2400) throw new IllegalStateException("Camera chunks were not fully delivered");
                    return;
                }
                if(row.has("measureFrames")) {
                    if(!client.worldRenderer.isTerrainRenderComplete())throw new IllegalStateException("Performance camera terrain is incomplete");
                    loadingTiming=FrameTimes.stop();loadingTiming.addProperty("readyAndSettleSeconds",(System.nanoTime()-phaseStarted)/1e9);
                    measuring=true;FrameTimes.start(row.get("measureFrames").getAsInt());return;
                }
            }
            if(row.has("measureFrames")) {
                if(!FrameTimes.complete())return;
                // The sample is full, but the final readiness evidence must still be true.
                if(!client.worldRenderer.isTerrainRenderComplete()||!viewChunksDelivered(client)) {
                    if(settled>2400)throw new IllegalStateException("Final camera terrain/chunks did not become ready");
                    return;
                }
            }
            if(row.has("benchSurface")){report.add("benchSurfaceClientState",BenchSurfaceQa.diagnostics(client));if(!report.has("benchSurfaceTests"))report.add("benchSurfaceTests",new JsonArray());report.getAsJsonArray("benchSurfaceTests").add(BenchSurfaceQa.finish(client,row.getAsJsonObject("benchSurface")));}
            var evidence=row.deepCopy();
            if(row.has("measureFrames")) {evidence.add("loadingFrames",loadingTiming);evidence.add("steadyFrames",FrameTimes.stop());}
            evidence.addProperty("actualPosition",client.player.getPos().toString());
            evidence.addProperty("actualYaw",client.player.getYaw());evidence.addProperty("actualPitch",client.player.getPitch());
            evidence.addProperty("windowFocused",client.isWindowFocused());evidence.addProperty("configuredMaxFps",client.options.getMaxFps().getValue());
            int simulation=client.options.getSimulationDistance().getValue();
            evidence.addProperty("configuredSimulationDistance",simulation);
            if(plan.has("simulationDistance")&&simulation!=plan.get("simulationDistance").getAsInt())
                throw new IllegalStateException("Simulation distance differs from the launch plan");
            evidence.addProperty("terrainComplete",client.worldRenderer.isTerrainRenderComplete());
            evidence.addProperty("allViewChunksDelivered",true);
            evidence.addProperty("bottomY",client.world.getBottomY());
            evidence.addProperty("actualMode",client.interactionManager.getCurrentGameMode().getName());
            evidence.addProperty("alive",client.player.isAlive());
            evidence.addProperty("screenshot",row.get("name").getAsString()+".png");
            phases.add(evidence);
            waiting=true;screenshotSaved=false;
            ScreenshotRecorder.saveScreenshot(client.runDirectory,row.get("name").getAsString()+".png",client.getFramebuffer(),message -> screenshotSaved=true);
        } catch (Throwable error) { fail(error); }
    }

    private static boolean viewChunksDelivered(MinecraftClient client) {
        int cx=client.player.getBlockX()>>4,cz=client.player.getBlockZ()>>4;
        int distance=client.options.getViewDistance().getValue();
        for(int x=cx-distance-2;x<=cx+distance+2;x++) for(int z=cz-distance-2;z<=cz+distance+2;z++)
            if(net.minecraft.server.world.ThreadedAnvilChunkStorage.isWithinDistance(x,z,cx,cz,distance)
                    && client.world.getChunkManager().getChunk(x,z,net.minecraft.world.chunk.ChunkStatus.FULL,false)==null)
                return false;
        return true;
    }

    private void finish(MinecraftClient client) {
        if(inspectionFailure){stopping=true;report.addProperty("status","FAIL");save();client.scheduleStop();return;}
        stopping=true;
        client.getServer().execute(() -> {
            try {
                if(plan.has("testDoor90001")&&plan.get("testDoor90001").getAsBoolean()) {
                    try {
                        var result=Door90001Qa.run(client.getServer(),client.getServer().getPlayerManager().getPlayer(client.player.getUuid()));
                        result.addProperty("status","PASS");report.add("door90001Tests",result);
                    } catch(Throwable testError) {
                        var result=new JsonObject();result.addProperty("status","FAIL");result.addProperty("error",testError.toString());
                        report.add("door90001Tests",result);
                    }
                }
                if(plan.has("nativeWallCells"))report.add("nativeWallTests",NativeWallQa.finish(client.getServer(),plan.getAsJsonArray("nativeWallCells")));
                if(plan.has("testArchedModels"))report.add("archedModelTests",LanternQa.archedModels(client));
                if(plan.has("testLantern")) {
                    try {report.add("lanternTests",LanternQa.run(client.getServer(),client.getServer().getPlayerManager().getPlayer(client.player.getUuid())));}
                    catch(Throwable testError){var result=new JsonObject();result.addProperty("status","FAIL");result.addProperty("error",testError.toString());report.add("lanternTests",result);}
                }
                if(report.has("windowTests")) {
                    int expected=0;for(var value:plan.getAsJsonArray("phases")){var row=value.getAsJsonObject();if(row.has("nativeWindow")||row.has("prefabWindow"))expected++;}
                    WindowQa.finish(report.getAsJsonObject("windowTests"),expected);
                }
                if(report.has("benchTests"))BenchQa.finish(report.getAsJsonObject("benchTests"));
                if(plan.has("prelightChunks")) {
                    report.addProperty("status","PRELIGHTING");save();
                    for(var world:client.getServer().getWorlds())world.getGameRules().get(net.minecraft.world.GameRules.DO_DAYLIGHT_CYCLE).set(false,client.getServer());
                    PrelightQa.start(client.getServer(),plan.getAsJsonArray("prelightChunks"),output,result->{report.add("prelight",result);finishSave(client);},error->client.execute(()->fail(error)));
                } else finishSave(client);
            } catch(Throwable error) {fail(error);}
        });
    }

    private void finishSave(MinecraftClient client) {
        client.getServer().save(false,true,true);report.addProperty("status","PASS");report.addProperty("saved",true);
        report.addProperty("seconds",(System.nanoTime()-started)/1e9);save();client.execute(client::scheduleStop);
    }

    private synchronized void save() {
        try { Files.writeString(output.resolve("qa.json"),GSON.toJson(report)); }
        catch (Exception error) { throw new RuntimeException(error); }
    }

    private JsonArray testDarkness(MinecraftServer server, ServerPlayerEntity player) {
        var results = new JsonArray();
        for (String dimension : List.of("minecraft:overworld","bloodborne_dw:bloodborne_old")) {
            var world = server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(dimension)));
            if (world==null) throw new IllegalStateException("Missing test dimension");
            var p = new BlockPos(dimension.equals("minecraft:overworld") ? -100 : 0,
                    world.getBottomY()+1,dimension.equals("minecraft:overworld") ? -900 : 0);
            for (int x=-1;x<=1;x++) for (int z=-1;z<=1;z++) world.getChunk((p.getX()>>4)+x,(p.getZ()>>4)+z);
            player.changeGameMode(GameMode.CREATIVE);
            player.teleport(world,p.getX()+2,p.getY()+2,p.getZ()+2,0,0);
            player.setNoGravity(true);
            BlockState state=world.getBlockState(p);
            if (!Registries.BLOCK.getId(state.getBlock()).toString().equals("bloodborne_dw:city_darkness"))
                throw new IllegalStateException("Missing city darkness at "+dimension+" "+p+": "+state);
            if (state.getBlock() instanceof BlockEntityProvider || !state.getBlock().getStateManager().getProperties().isEmpty()
                    || !state.getCollisionShape(world,p,ShapeContext.of(player)).isEmpty() || state.hasRandomTicks())
                throw new IllegalStateException("Floor allocated data, ticking or collision");
            if(plan.has("requireOpaqueDarkness") && (!state.isOpaque() || !state.isOpaqueFullCube(world,p)))
                throw new IllegalStateException("Darkness is not opaque to the terrain renderer");
            if (state.getOutlineShape(world,p,ShapeContext.of(player)).isEmpty())
                throw new IllegalStateException("Creative floor selection is empty");
            if(!world.getBlockState(p.east()).isOf(state.getBlock())
                    ||Block.shouldDrawSide(state,world,p,Direction.EAST,p.east()))
                throw new IllegalStateException("Internal darkness layer faces are rendered");
            ItemStack picked=state.getBlock().getPickStack(world,p,state);
            if (!(picked.getItem() instanceof BlockItem item) || item.getBlock()!=state.getBlock())
                throw new IllegalStateException("Middle pick returned the wrong floor item");
            var support=world.getBlockState(p.down());
            world.setBlockState(p.down(),Blocks.STONE.getDefaultState(),Block.NOTIFY_ALL);
            for (int attempt=0;attempt<2;attempt++) {
                if (!player.interactionManager.tryBreakBlock(p) || !world.getBlockState(p).isAir())
                    throw new IllegalStateException("Creative break failed at "+dimension+" "+p);
                player.setStackInHand(Hand.MAIN_HAND,picked.copy());
                var context=new ItemPlacementContext(world,player,Hand.MAIN_HAND,player.getMainHandStack(),
                        new BlockHitResult(new Vec3d(p.getX()+.5,p.getY(),p.getZ()+.5),Direction.UP,p.down(),false));
                var placed=((BlockItem)picked.getItem()).place(context);
                if (!placed.isAccepted() || !world.getBlockState(p).equals(state) || world.getBlockEntity(p)!=null)
                    throw new IllegalStateException("Creative place failed: "+placed+" "+world.getBlockState(p));
            }
            world.setBlockState(p.down(),support,Block.NOTIFY_ALL);
            var result=new JsonObject();
            result.addProperty("dimension",dimension);
            result.addProperty("position",p.toString());
            result.addProperty("middlePick",true);
            result.addProperty("placeBreakCycles",2);
            result.addProperty("noBlockEntityOrPropertiesOrTicks",true);
            result.addProperty("emptyPlayerCollision",true);
            result.addProperty("opaqueForTerrainOcclusion",state.isOpaque() && state.isOpaqueFullCube(world,p));
            results.add(result);
        }
        return results;
    }

    private void fail(Throwable error) {
        if(plan.has("holdOnFailure")&&plan.get("holdOnFailure").getAsBoolean()&&MinecraftClient.getInstance().world!=null){
            error.printStackTrace();inspectionFailure=true;holding=true;waiting=false;serverJob=null;phase=plan.getAsJsonArray("phases").size();report.addProperty("status","FAIL_HOLD_FOR_INSPECTION");report.addProperty("error",error.toString());save();return;
        }
        stopping=true;
        error.printStackTrace();
        report.addProperty("status","FAIL");
        report.addProperty("error",error.toString());
        save();
        MinecraftClient.getInstance().scheduleStop();
    }
}
