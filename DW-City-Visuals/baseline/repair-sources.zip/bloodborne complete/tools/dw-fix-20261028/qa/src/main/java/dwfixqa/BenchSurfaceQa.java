package dwfixqa;
import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.*;
import net.minecraft.server.*;
import net.minecraft.server.network.*;
import net.minecraft.server.world.*;
import net.minecraft.registry.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.*;

/** Real collision movement and Crawl; no mount or RMB is used by surface probes. */
public final class BenchSurfaceQa {
    private static volatile double expected;
    private static volatile String mode;
    private static volatile int jumpStage;
    private static volatile double jumpPeak;
    private static volatile double expectedX,expectedZ;
    private static volatile String expectedDimension;
    @SuppressWarnings("unchecked")
    private static net.minecraft.entity.data.TrackedData<Boolean> request(){try{return (net.minecraft.entity.data.TrackedData<Boolean>)Class.forName("ru.fewizz.crawl.Crawl$Shared").getField("CRAWL_REQUEST").get(null);}catch(ReflectiveOperationException e){throw new IllegalStateException("Installed Crawl API",e);}}
    private static void crawl(Entity player,boolean value){player.getDataTracker().set(request(),value);}
    private static boolean crawling(Entity player){return player.getDataTracker().get(request());}
    private static ServerWorld world(MinecraftServer server,JsonObject p){var w=server.getWorld(RegistryKey.of(RegistryKeys.WORLD,new Identifier(p.get("dimension").getAsString())));if(w==null)throw new IllegalStateException("Missing bench world");return w;}
    private static BenchSeating.Target target(ServerWorld w,JsonObject p){var a=p.getAsJsonArray("root");var root=new BlockPos(a.get(0).getAsInt(),a.get(1).getAsInt(),a.get(2).getAsInt());for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)w.getChunk((root.getX()>>4)+x,(root.getZ()>>4)+z);return BenchSeating.targets(w,root).stream().filter(t->t.root().equals(root)&&t.identity().equals("native-bench/"+p.get("template").getAsString())).findFirst().orElseThrow();}
    private static void reset(ServerPlayerEntity p){p.stopRiding();p.changeGameMode(GameMode.CREATIVE);p.getAbilities().flying=false;p.sendAbilitiesUpdate();p.noClip=false;p.setSneaking(false);p.setSprinting(false);crawl(p,false);p.setPose(EntityPose.STANDING);p.setVelocity(0,0,0);}
    private record Contact(BenchSeating.Point point,int seat,double forward){}
    private static final java.util.Map<String,Contact> clearContacts=new java.util.HashMap<>();
    private static volatile int actualSeat;
    private static volatile double actualForward;
    private static String key(JsonObject p){return p.get("dimension").getAsString()+p.get("root")+p.get("template");}
    private static JsonObject drop(ServerWorld w,ServerPlayerEntity p,BenchSeating.Point seat){
        reset(p);var at=seat.contact();p.teleport(w,at.x,at.y+2,at.z,seat.yaw(),0);p.setNoGravity(true);p.move(MovementType.SELF,new Vec3d(0,-4,0));
        if(p.getY()<at.y-.063||p.hasVehicle())throw new IllegalStateException("Missing plank support: feet="+p.getY()+" board="+at.y+" at "+at);
        var r=new JsonObject();r.addProperty("x",at.x);r.addProperty("z",at.z);r.addProperty("boardY",at.y);r.addProperty("feetY",p.getY());r.addProperty("standingOnPlank",Math.abs(p.getY()-at.y)<=.063);r.addProperty("obstacleAbovePlank",p.getY()>at.y+.063);r.addProperty("withoutMountOrRmb",true);return r;
    }
    private static JsonObject inspect(ServerWorld w,ServerPlayerEntity player,BenchSeating.Target target,String identity){
        var row=new JsonObject();var drops=new JsonArray();Contact best=null;double score=Double.POSITIVE_INFINITY;
        for(int j=0;j<target.seats().size();j++)for(double forward:new double[]{0,.125,.25}){
            var original=target.seats().get(j);double angle=Math.toRadians(original.yaw());var at=original.contact().add(-Math.sin(angle)*forward,0,Math.cos(angle)*forward);var point=new BenchSeating.Point(at,original.yaw());
            var result=drop(w,player,point);result.addProperty("seat",j);result.addProperty("forwardOffset",forward);drops.add(result);
            double candidateScore=forward*10+Math.abs(j-(target.seats().size()-1)/2.0);
            if(result.get("standingOnPlank").getAsBoolean()&&candidateScore<score){best=new Contact(point,j,forward);score=candidateScore;}
        }
        row.add("surfaceDrops",drops);if(best==null)throw new IllegalStateException("No free supported plank contact: "+identity+" / "+drops);
        clearContacts.put(identity,best);row.addProperty("selectedSeat",best.seat());row.addProperty("selectedForwardOffset",best.forward());row.addProperty("status","PASS");return row;
    }
    public static JsonObject prepare(MinecraftServer server,ServerPlayerEntity player,JsonArray probes){
        clearContacts.clear();var report=new JsonObject();report.add("placements",BenchQa.surfaceFixtures(server,player));var nativeTests=new JsonArray();
        for(var value:probes){var p=value.getAsJsonObject();var w=world(server,p);var row=inspect(w,player,target(w,p),key(p));row.add("probe",p);nativeTests.add(row);}
        report.add("nativeBenches",nativeTests);var fresh=new JsonArray();for(int i=0;i<6;i++){var row=inspect(server.getOverworld(),player,BenchQa.surfaceFixture(server,i),"fixture/"+i);row.addProperty("fixture",i);fresh.add(row);}
        report.add("freshStanding",fresh);report.addProperty("nativeCount",nativeTests.size());report.addProperty("status","PASS");return report;
    }
    public static void begin(MinecraftServer server,ServerPlayerEntity player,JsonObject row){
        ServerWorld w;String identity;if(row.has("fixture")){w=server.getOverworld();identity="fixture/"+row.get("fixture").getAsInt();}else{var probe=row.getAsJsonObject("probe");w=world(server,probe);identity=key(probe);}
        var selected=clearContacts.get(identity);if(selected==null)throw new IllegalStateException("Missing tested contact "+identity);var seat=selected.point();actualSeat=selected.seat();actualForward=selected.forward();
        w.setTimeOfDay(6000);w.getGameRules().get(GameRules.DO_DAYLIGHT_CYCLE).set(false,server);reset(player);expected=seat.contact().y;mode=row.get("pose").getAsString();var at=seat.contact();expectedX=at.x;expectedZ=at.z;expectedDimension=w.getRegistryKey().getValue().toString();player.teleport(w,at.x,at.y+.05,at.z,seat.yaw()+90,5);player.setNoGravity(false);player.setVelocity(0,0,0);jumpStage=0;jumpPeak=0;
    }
    @SuppressWarnings("unchecked")
    public static void client(MinecraftClient c){if(c.player==null)return;try{
        var api=Class.forName("ru.fewizz.crawl.CrawlClient");
        ((net.minecraft.client.option.SimpleOption<Boolean>)api.getField("crawlToggled").get(null)).setValue(false);
        if(c.player.getAbilities().flying){c.player.getAbilities().flying=false;c.player.sendAbilitiesUpdate();}
        c.player.noClip=false;c.player.setNoGravity(false);
        var key=(net.minecraft.client.option.KeyBinding)api.getField("key").get(null);
        if(!c.world.getRegistryKey().getValue().toString().equals(expectedDimension)||Math.abs(c.player.getX()-expectedX)>.1||Math.abs(c.player.getZ()-expectedZ)>.1||Math.abs(c.player.getY()-expected)>1.6){c.options.jumpKey.setPressed(false);key.setPressed(false);return;}
        jumpPeak=Math.max(jumpPeak,c.player.getY()-expected);
        if(jumpStage==0&&c.player.isOnGround()){c.options.jumpKey.setPressed(true);jumpStage=1;}
        else if(jumpStage==1){c.options.jumpKey.setPressed(false);jumpStage=2;}
        ((net.minecraft.client.option.KeyBinding)api.getField("key").get(null)).setPressed(mode.equals("crawl")&&jumpStage==2);
    }catch(ReflectiveOperationException e){throw new IllegalStateException("Real Crawl key",e);}}
    public static JsonObject diagnostics(MinecraftClient c){var r=new JsonObject();var p=c.player;r.addProperty("flying",p.getAbilities().flying);r.addProperty("noClip",p.noClip);r.addProperty("noGravity",p.hasNoGravity());r.addProperty("onGround",p.isOnGround());r.addProperty("feetY",p.getY());r.addProperty("velocity",p.getVelocity().toString());r.addProperty("pose",p.getPose().name());r.addProperty("jumpStage",jumpStage);r.addProperty("jumpPeak",jumpPeak);r.addProperty("gameMode",c.interactionManager.getCurrentGameMode().name());return r;}
    public static JsonObject finish(MinecraftClient c,JsonObject row){var p=c.player;if(p.hasVehicle()||Math.abs(p.getY()-expected)>.063||!p.isOnGround()||jumpPeak<.2||jumpPeak>1.6)throw new IllegalStateException("Jump landing/crawl does not rest on board: feet="+p.getY()+" expected="+expected+" pose="+p.getPose()+" ground="+p.isOnGround());if(mode.equals("crawl")&&(!crawling(p)||!p.getPose().name().equals("CRAWLING")))throw new IllegalStateException("Real Crawl pose not active: "+p.getPose());var r=row.deepCopy();r.addProperty("status","PASS");r.addProperty("actualFeetY",p.getY());r.addProperty("normalJumpPeakAboveBoard",jumpPeak);r.addProperty("normalJumpKeyUsed",jumpStage==2);r.addProperty("selectedSeat",actualSeat);r.addProperty("selectedForwardOffset",actualForward);r.addProperty("visibleBoardY",expected);r.addProperty("actualPose",p.getPose().name());r.addProperty("realCrawlState",crawling(p));r.addProperty("withoutMountOrRmb",true);return r;}
}
