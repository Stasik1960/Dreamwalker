package dwfixqa.mixin;

import dwfixqa.FrameTimes;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value=GameRenderer.class,priority=50)
public abstract class FrameTimesMixin {
    @Inject(method="render",at=@At("TAIL"))
    private void dw$frame(float tickDelta,long startTime,boolean tick,CallbackInfo callback){FrameTimes.rendered();}
}
