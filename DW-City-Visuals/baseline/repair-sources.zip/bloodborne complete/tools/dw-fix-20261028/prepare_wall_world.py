"""Apply the three proved wall repairs to a separate copy and verify saved NBT scope."""
import collections,copy,json,shutil,sys
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write,sha
from remove_inert_cells import entries,block_table
from prepare_native_window_world import tag,state,metadata
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import *

def main():
    source=RUN/'native-window-world-8e38b14da7b5-r1/bloodborne';plan=json.loads((RUN/'task12-wall-native-map-plan.json').read_text(encoding='utf-8'));header=plan['catalogSha256'];output=RUN/('wall-world-'+header[:12])/'bloodborne';assert output.resolve().is_relative_to(WORKSPACE)
    if output.exists():assert not (output.parent/'receipt.json').exists()
    layout=json.loads((RUN/'native-overlay/assets/bloodborne_dw/native_grid/visual_physics.json').read_text(encoding='utf-8'))
    if not output.exists():shutil.copytree(source,output,ignore=shutil.ignore_patterns('session.lock'))
    groups=collections.defaultdict(list)
    for row in plan['cells']:
        x,y,z=row['pos'];directory='region' if row['dimension']=='overworld' else 'dimensions/bloodborne_dw/bloodborne_old/region';groups[directory+f'/r.{x>>9}.{z>>9}.mca'].append(row)
    receipts=[]
    for relative,rows in groups.items():
        assert sha(source/relative)==sha(output/relative),'Candidate is no longer pristine'
        region=RegionFile.open(source/relative);expected={};before={}
        for row in rows:
            x,y,z=row['pos'];key=(x>>4)&31,(z>>4)&31
            if key not in expected:
                nbt=region.get_chunk(*key).nbt();expected[key]=nbt;before[key]=copy.deepcopy(compound(nbt.root))
            root=compound(expected[key].root);section=next(s for s in root['sections'].value if compound(s)['Y'].value==y>>4);fields=compound(section);palette,indices=section_blocks(section);names=[block_state_key(p) for p in palette];local=((y&15)<<8)|((z&15)<<4)|(x&15);new=state(layout['cellToPhysics'][row['next']])
            if new not in names:names.append(new);palette.append(tag(layout['cellToPhysics'][row['next']]))
            indices[local]=names.index(new);fields['block_states']=Tag(TAG_COMPOUND,{'palette':Tag(TAG_LIST,palette,TAG_COMPOUND),'data':Tag(TAG_LONG_ARRAY,pack_palette_indices(indices,len(palette)))})
            native=compound(root['DreamwalkerVisuals']);native['Catalog']=Tag(TAG_STRING,header);s=next(s for s in native['Sections'].value if compound(s)['Y'].value==y>>4);fields=compound(s);values={v&4095:(v&0xffffffff)>>12 for v in fields['Entries'].value};values[local]=row['next'];fields['Entries']=Tag(TAG_INT_ARRAY,[(v<<12)|k for k,v in sorted(values.items())])
            height=root['yPos'].value*16
            for key_h in ['WORLD_SURFACE','WORLD_SURFACE_WG']:
                if key_h in compound(root['Heightmaps']):
                    values=unpack_palette_indices(compound(root['Heightmaps'])[key_h].value,512,256);column=((z&15)<<4)|(x&15);values[column]=max(values[column],y+1-height);compound(root['Heightmaps'])[key_h]=Tag(TAG_LONG_ARRAY,pack_palette_indices(values,512))
        for key,nbt in expected.items():region.set_chunk(*key,nbt,timestamp=region.get_chunk(*key).timestamp)
        region.save(output/relative);saved=RegionFile.open(output/relative);original=RegionFile.open(source/relative)
        for chunk in original.chunks():
            key=chunk.x,chunk.z;other=saved.get_chunk(*key)
            if key not in before:assert chunk.compressed_payload==other.compressed_payload and chunk.timestamp==other.timestamp;continue
            a,b=before[key],compound(other.nbt().root);ma,mb=metadata(a),metadata(b)
            for h in ['WORLD_SURFACE','WORLD_SURFACE_WG']:
                compound(ma['Heightmaps']).pop(h,None);compound(mb['Heightmaps']).pop(h,None)
            assert ma==mb,'Unrelated NBT or light data changed'
            allowed={((r['pos'][1]>>4),((r['pos'][1]&15)<<8)|((r['pos'][2]&15)<<4)|(r['pos'][0]&15)):r['next'] for r in rows if (((r['pos'][0]>>4)&31),((r['pos'][2]>>4)&31))==key}
            expected_native=entries(a);expected_native.update(allowed);assert entries(b)==expected_native
            aa,bb=block_table(a),block_table(b);changes=set()
            for sy,(pa,ia) in aa.items():
                pb,ib=bb[sy]
                for i in range(4096):
                    if pa[ia[i]]!=pb[ib[i]]:assert (sy,i) in allowed;assert pb[ib[i]]==state(layout['cellToPhysics'][allowed[sy,i]]);changes.add((sy,i))
            old_entries=entries(a);expected_changes={k for k,v in allowed.items() if k not in old_entries or layout['cellToPhysics'][old_entries[k]]!=layout['cellToPhysics'][v]}
            assert changes==expected_changes;assert compound(b['DreamwalkerVisuals'])['Catalog'].value==header
            for h in ['WORLD_SURFACE','WORLD_SURFACE_WG']:
                if h not in compound(a['Heightmaps']):continue
                values=unpack_palette_indices(compound(a['Heightmaps'])[h].value,512,256)
                for row in rows:
                    x,y,z=row['pos'];col=((z&15)<<4)|(x&15);values[col]=max(values[col],y+1-a['yPos'].value*16)
                assert unpack_palette_indices(compound(b['Heightmaps'])[h].value,512,256)==values
        receipts.append(dict(path=relative,before=sha(source/relative),after=sha(output/relative)))
    result=dict(status='SAVED_REGION_SCOPE_PASS_GAMEPLAY_PENDING',world=str(output),catalogSha256=header,cells=len(plan['cells']),regions=receipts,unrelatedBlocksAndNbtUnchanged=True,lightingUnchanged=True,heightmapsOnlyRepairedColumns=True,originalWorldModified=False)
    write(output.parent/'receipt.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':main()
