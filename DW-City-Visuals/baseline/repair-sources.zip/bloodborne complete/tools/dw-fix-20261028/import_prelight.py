"""Import only verified engine lighting into an immutable copy of the prepared city."""
import argparse,collections,copy,json,shutil,subprocess
from pathlib import Path
from import_lighting import ROOT_LIGHT,SECTION_LIGHT,normalized
from fast_block_compare import same_blocks
from map_reader import MapReader
from prepare_workspace import RUN,WORKSPACE,write,sha
from world_io import RegionFile,compound,Tag,TAG_BYTE,TAG_COMPOUND,lighting_cache_errors

PREFIX={'minecraft:overworld':'region','bloodborne_dw:bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}

def guard():
    subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)

def visuals(root):
    table=root.get('DreamwalkerVisuals')
    if table is None:return {}
    return {compound(s)['Y'].value:tuple(sorted(compound(s)['Entries'].value)) for s in compound(table)['Sections'].value if compound(s)['Entries'].value}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('run');parser.add_argument('--world',type=Path,required=True);parser.add_argument('--targets',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    guard();assert args.run.replace('-','').isalnum();world=args.world.resolve();output=args.output.resolve()
    assert world.is_relative_to(RUN.resolve()) and output.is_relative_to(RUN.resolve()) and (not output.exists() or args.resume) and output!=world and not world.is_relative_to(output)
    scope=json.loads(args.targets.read_text(encoding='utf-8'));qa=RUN/'runs'/args.run/'client';report=json.loads((qa/'evidence/qa.json').read_text(encoding='utf-8'))
    assert report['status']=='PASS' and report['prelight']['status']=='PASS' and report['prelight']['completedChunks']==len(scope['prelightChunks'])
    assert Path(scope['world']).resolve()==world
    groups=collections.defaultdict(list)
    for row in scope['prelightChunks']:
        directory=PREFIX[row['dimension']];cx,cz=row['x'],row['z'];groups[directory,cx>>5,cz>>5].append((cx,cz))
    if not output.exists():shutil.copytree(world,output,ignore=shutil.ignore_patterns('session.lock'))
    readers={directory:MapReader(qa/'saves/city',directory) for directory in PREFIX.values()};results=[];total=0
    for (directory,rx,rz),positions in sorted(groups.items()):
        guard();path=output/directory/f'r.{rx}.{rz}.mca';source_path=world/directory/path.name;region=RegionFile.open(source_path);original_region=RegionFile(source_path.read_bytes());allowed=set()
        for cx,cz in sorted(positions):
            chunk=region.get_chunk(cx&31,cz&31);assert chunk is not None;nbt=chunk.nbt();target=compound(nbt.root);original=copy.deepcopy(target);saved=readers[directory].chunk(cx*16,cz*16)
            assert saved and same_blocks(target,saved),f'Lighting source changed blocks: {directory}/{cx},{cz}'
            assert visuals(target)==visuals(saved),f'Lighting source changed native geometry: {directory}/{cx},{cz}'
            assert saved.get('isLightOn') and saved['isLightOn'].value==1 and not lighting_cache_errors(saved)
            assert saved.get('Heightmaps') and all(k in compound(saved['Heightmaps']) for k in ['WORLD_SURFACE','MOTION_BLOCKING'])
            for key in ROOT_LIGHT:
                target.pop(key,None)
                if key in saved:target[key]=copy.deepcopy(saved[key])
            target['Heightmaps']=copy.deepcopy(saved['Heightmaps']);sections={compound(s)['Y'].value:s for s in target['sections'].value}
            for tag in target['sections'].value:
                for key in SECTION_LIGHT:compound(tag).pop(key,None)
            for tag in saved['sections'].value:
                data=compound(tag);y=data['Y'].value
                if not any(key in data for key in SECTION_LIGHT):continue
                if y not in sections:sections[y]=Tag(TAG_COMPOUND,{'Y':Tag(TAG_BYTE,y)});target['sections'].value.append(sections[y])
                for key in SECTION_LIGHT:
                    if key in data:compound(sections[y])[key]=copy.deepcopy(data[key])
            assert normalized(original)==normalized(target) and same_blocks(original,target) and not lighting_cache_errors(target)
            region.set_chunk(cx&31,cz&31,nbt,timestamp=chunk.timestamp);allowed.add((cx&31,cz&31));total+=1
        region.save(path);persisted=RegionFile.open(path)
        for old in original_region.chunks():
            new=persisted.get_chunk(old.x,old.z);assert new is not None
            if (old.x,old.z) in allowed:
                a,b=compound(old.nbt().root),compound(new.nbt().root);assert normalized(a)==normalized(b) and same_blocks(a,b) and not lighting_cache_errors(b)
            else:assert old.compressed_payload==new.compressed_payload and old.timestamp==new.timestamp
        results.append(dict(path=str(path.relative_to(output)),chunks=len(positions),sha256=sha(path)))
        write(output.parent/'prelight-import-progress.json',dict(status='RUNNING',completedChunks=total,totalChunks=len(scope['prelightChunks']),completedRegions=len(results)))
    receipt=dict(status='PERSISTED_LIGHTING_ONLY_GATE_PASS',chunks=total,sourceRun=args.run,inputWorld=str(world),outputWorld=str(output),regions=results,blocksOwnershipAndNativeGeometryUnchanged=True)
    write(output.parent/'prelight-import-receipt.json',receipt);print(json.dumps({k:v for k,v in receipt.items() if k!='regions'},indent=2))

if __name__=='__main__':main()
