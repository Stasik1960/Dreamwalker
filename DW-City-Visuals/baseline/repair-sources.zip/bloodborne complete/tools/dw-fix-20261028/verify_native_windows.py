"""Independent saved-data gates: immutable prefix, retained geometry and every round trip."""
import collections,hashlib,json,struct,zipfile
from prepare_workspace import BASE,RUN,write

D='assets/bloodborne_dw/native_grid/'
FIELDS=['collision','outline','culling','climbing','optics','fluid','localFunction']


def mesh_table(data):
    magic,count=struct.unpack_from('>II',data);assert magic==0x4e475131
    cursor=8;result=[]
    for _ in range(count):
        n=struct.unpack_from('>I',data,cursor)[0];result.append(data[cursor+4:cursor+4+n*139]);cursor+=4+n*139
    assert cursor==len(data);return result


def main():
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        old=json.loads(z.read(D+'catalog.json'));old_layout=json.loads(z.read(D+'visual_physics.json'));old_meshes=mesh_table(z.read(D+'meshes.bin'))
    out=RUN/'native-overlay';catalog=json.loads((out/(D+'catalog.json')).read_text(encoding='utf-8'));layout=json.loads((out/(D+'visual_physics.json')).read_text(encoding='utf-8'));meshes=mesh_table((out/(D+'meshes.bin')).read_bytes())
    for key in ['cells','meshes','materials','shapes','optics','wholeObjects']:assert catalog[key][:len(old[key])]==old[key],key
    assert meshes[:len(old_meshes)]==old_meshes
    assert len({c['key'] for c in catalog['cells']})==len(catalog['cells'])
    for key in ['cellToPhysics','representatives','physicsLayers','physicsAmbient']:assert layout[key][:len(old_layout[key])]==old_layout[key],key
    for visual in range(len(old['cells']),len(catalog['cells'])):
        physics=layout['cellToPhysics'][visual];rep=catalog['cells'][layout['representatives'][physics]];cell=catalog['cells'][visual]
        assert all(cell.get(k)==rep.get(k) for k in FIELDS),(visual,'physical representative differs')
    scenes=json.loads((__import__('pathlib').Path(__file__).resolve().parent/'data/native-window-scenes.json').read_text(encoding='utf-8'))['scenes'];receipt=json.loads((RUN/'task09-native-window-compile.json').read_text(encoding='utf-8'));initial={r['scene']:r['initial'] for r in receipt['sceneReceipts']}
    retained=0
    for sid,scene in scenes.items():
        before=old['cells'][scene['old']];after=catalog['cells'][initial[sid]]
        assert all(before.get(k)==after.get(k) for k in FIELDS),(sid,'initial physics changed')
        removed={i for c in scene['components'] for i in c['remove']};source=old_meshes[before['mesh']];base=b''.join(source[i:i+139] for i in range(0,len(source),139) if i//139 not in removed)
        assert meshes[after['mesh']].startswith(base),'Unrelated quad bytes changed';retained+=len(base)//139
    functions=json.loads((out/'bloodborne_dw/repair/native-windows.json').read_text(encoding='utf-8'));profiles={p['rotation']:p for p in functions['profiles']};modes={tuple(r[:5]):r[5] for r in functions['modes']};transitions={tuple(r[:6]):r[6] for r in functions['transitions']}
    plan=json.loads((RUN/'task09-native-window-map-plan.json').read_text(encoding='utf-8'));current={(c['dimension'],tuple(c['pos'])):c['next'] for c in plan['cells']};checked=0;air_transitions=0
    for window in plan['windows']:
        root=window['root'];rotation=window['rotation'];profile=profiles[rotation];dimension=window['dimension'];saved={}
        for off in profile['cells']:
            p=tuple(a+b for a,b in zip(root,off));saved[p]=current[dimension,p]
        def mode():
            a=tuple(x+y for x,y in zip(root,profile['anchor']));return modes[(current[dimension,a],*[-x for x in profile['anchor']],rotation)]
        assert mode()==1
        for expected in [1,0]:
            changes=[]
            for p,previous in saved.items():
                before=current[dimension,p];key=(before,*[a-b for a,b in zip(root,p)],rotation,expected);assert key in transitions,(window,p,before)
                after=transitions[key];changes.append((p,after))
                if after<0:
                    cell=catalog['cells'][before];opt=catalog['optics'][cell['optics']]
                    assert not any(catalog['shapes'][cell[k]] for k in ['collision','culling','climbing']) and opt['opacity']==0 and opt['luminance']==0 and cell.get('fluid') is None
                    air_transitions+=1
            for p,after in changes:current[dimension,p]=after
            assert mode()==1-expected
        assert all(current[dimension,p]==index for p,index in saved.items()),'Round trip changed a neighbouring component'
        checked+=1
    header=hashlib.sha256((out/(D+'catalog.json')).read_bytes()).hexdigest();assert layout['catalogSha256']==functions['catalogSha256']==header
    result=dict(status='PASS',windowsRoundTripped=checked,prefixCellsUnchanged=len(old['cells']),prefixMeshesUnchanged=len(old_meshes),retainedUnrelatedQuadsInUniqueScenes=retained,initialCollisionOpticsAndBehaviourUnchanged=True,emptyOpenLeafCellsSafelyCleared=air_transitions,blockEntitiesAdded=0)
    write(RUN/'task09-native-window-data-verification.json',result);print(json.dumps(result,indent=2))


if __name__=='__main__':main()
