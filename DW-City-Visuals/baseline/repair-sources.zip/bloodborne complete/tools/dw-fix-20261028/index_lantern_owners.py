"""Find every saved cell of retired managed lamp owners, preserving foreign contributions."""
import hashlib,json,subprocess,sys
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write,sha
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile,compound,decode_nbt

def owner_key(tag):return ','.join(map(str,compound(tag)['uuid'].value))

def main():
    world=RUN/'wall-world-62d4794366ab/bloodborne';retired=set(json.loads((RUN/'task11-static-lantern-preflight.json').read_text(encoding='utf-8'))['types']);cells=[];owners={};residents={};regions=[]
    for dim,directory in [('overworld','region'),('bloodborne_old','dimensions/bloodborne_dw/bloodborne_old/region')]:
        for path in sorted((world/directory).glob('r.*.*.mca')):
            subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)
            for chunk in RegionFile.open(path).chunks():
                root=compound(chunk.nbt().root)
                for raw_be in root['block_entities'].value:
                    be=compound(raw_be);packed=be.get('OwnerDataV1')
                    if packed is None:continue
                    payload=compound(decode_nbt(packed.value).root);target=[];foreign=0
                    for entry in payload['owners'].value:
                        fields=compound(entry);owner=compound(fields['owner']);kind=owner['id'].value
                        if kind not in retired:foreign+=1;continue
                        key=owner_key(fields['owner']);target.append(key);row=dict(dimension=dim,root=owner['root'].value,registryId=kind,uuid=owner['uuid'].value)
                        assert key not in owners or owners[key]==row;owners[key]=row
                    if not target:continue
                    resident=be.get('resident');resident_key=owner_key(resident) if resident is not None else None
                    if resident_key in target:residents[resident_key]=[be['x'].value,be['y'].value,be['z'].value]
                    cells.append(dict(dimension=dim,pos=[be[k].value for k in 'xyz'],targets=target,foreignOwners=foreign,resident=resident_key,nativeBase=be.get('NativeGridBase').value if be.get('NativeGridBase') is not None else -1,packedSha256=hashlib.sha256(packed.value).hexdigest()))
            regions.append(dict(dimension=dim,path=directory+'/'+path.name,sha256=sha(path)));write(RUN/'task11-lantern-owner-progress.json',dict(regions=len(regions),owners=len(owners),cells=len(cells)))
    for key,row in owners.items():row['residentPresent']=residents.get(key)==row['root']
    result=dict(status='SAVED_OWNER_CLOSURE_IDENTIFIED_NO_WRITES',owners=owners,cells=cells,regions=regions,residentRoots=len(residents),orphanOwners=sum(not r['residentPresent'] for r in owners.values()),mixedCells=sum(r['foreignOwners']>0 for r in cells))
    write(RUN/'task11-lantern-owner-preflight.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['owners','cells','regions']},indent=2));print('owners',len(owners),'cells',len(cells))

if __name__=='__main__':main()
