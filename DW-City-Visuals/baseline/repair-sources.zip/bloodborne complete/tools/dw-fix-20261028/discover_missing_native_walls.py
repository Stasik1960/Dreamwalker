"""Prove retained wall roots by all source caps; no inference from collision boxes."""
import collections,json,struct,zipfile
import numpy as np
from native_model_baker import bake,cell_quads
from prepare_workspace import BASE,RUN,write

D='assets/bloodborne_dw/native_grid/'

def signature(q,materials):
    mat,_,face,_,flags=struct.unpack_from('>ibbIB',q)
    vertices=tuple(sorted(tuple(round(v,5) for v in struct.unpack_from('>5f',q,11+i*32)) for i in range(4)))
    return materials[mat]['sprite'],face,flags,vertices

def main():
    overlay=RUN/'native-overlay';c=json.loads((overlay/D/'catalog.json').read_text(encoding='utf-8'));raw=(overlay/D/'meshes.bin').read_bytes();materials=c['materials'];templates=[]
    def material(sprite,layer):return next(i for i,m in enumerate(materials) if m['sprite']==sprite and m['layer']=='solid')
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        for name in ['diorite','prismarine_bricks']:
            asset='assets/bloodborne_dw/models/remaining/source/minecraft/block/'+name+'.json';model=json.loads(z.read(asset))
            for rotation in [0,2,4,6]:
                cells=cell_quads(bake(model,offset=(0,0,0),yaw=rotation,layer='solid'),material);caps=[q for q in cells[0,0,0] if q[5] in (0,1)]
                assert len(caps)==(2 if name=='diorite' else 4)
                templates.append(dict(model=name,rotation=rotation,required={signature(q,materials) for q in caps},cells=cells))
    wanted=set().union(*(t['required'] for t in templates));first=collections.defaultdict(set)
    for ti,t in enumerate(templates):
        for q in t['required']:first[q].add(ti)
    matches={};cursor=8;proofs=[]
    for mid in range(len(c['meshes'])):
        count=struct.unpack_from('>I',raw,cursor)[0];start=cursor+4;cursor=start+139*count;found=set()
        for i in range(count):
            q=raw[start+i*139:start+(i+1)*139]
            if q[5] not in (0,1) or not materials[struct.unpack_from('>I',q)[0]]['sprite'].endswith('/spirelamp_0018'):continue
            s=signature(q,materials)
            if s in wanted:found.add(s)
        candidates={ti for q in found for ti in first[q]};valid=[ti for ti in candidates if templates[ti]['required']<=found]
        if valid:
            assert len(valid)==1,('Ambiguous root',mid,valid);matches[mid]=valid[0]
    assert cursor==len(raw)
    by_visual={i:matches[cell['mesh']] for i,cell in enumerate(c['cells']) if cell['mesh'] in matches}
    assert 115235 in by_visual and templates[by_visual[115235]]['model']=='prismarine_bricks'
    summary=dict(status='SOURCE_CAP_IDENTITIES_PROVED_MAP_COVERAGE_PENDING',matchingMeshes=len(matches),matchingVisuals=len(by_visual),models=dict(collections.Counter(templates[ti]['model'] for ti in by_visual.values())),sample=dict(visual=115235,model=templates[by_visual[115235]]['model'],rotation=templates[by_visual[115235]]['rotation']),byVisual=by_visual)
    write(RUN/'task12-wall-source-identities.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='byVisual'},indent=2))

if __name__=='__main__':main()
