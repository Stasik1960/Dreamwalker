"""Atomically enqueue one instruction for an owned, paused disposable QA run."""
import argparse,json,os,uuid
from pathlib import Path
from prepare_workspace import RUN

def main():
    p=argparse.ArgumentParser();p.add_argument('run');g=p.add_mutually_exclusive_group(required=True);g.add_argument('--phase',type=Path);g.add_argument('--finish',action='store_true');args=p.parse_args()
    assert args.run.replace('-','').isalnum();folder=RUN/'runs'/args.run/'client/evidence';report=json.loads((folder/'qa.json').read_text(encoding='utf-8'));assert report['status']=='HOLDING_FOR_REVIEW';target=folder/'next.json';assert not target.exists()
    command={'action':'finish'} if args.finish else {'action':'capture','phase':json.loads(args.phase.read_text(encoding='utf-8'))}
    temp=folder/f'.next-{uuid.uuid4().hex}.tmp'
    with temp.open('x',encoding='utf-8') as stream:json.dump(command,stream);stream.flush();os.fsync(stream.fileno())
    temp.replace(target);print('Queued',command['action'],'for',args.run)

if __name__=='__main__':main()
