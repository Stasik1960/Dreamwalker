"""Derive reusable seating layouts from complete retained bench plank surfaces.

Runtime definitions contain relative native identities and plank contacts only.
World coordinates stay in the offline coverage report. No world file is edited.
"""
import collections
import hashlib
import json
import math
from pathlib import Path
import sys
import struct
import zipfile
import numpy as np
from prepare_workspace import BASE,RUN,write
from map_reader import MapReader
from analyze_native_geometry import decode
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile,compound

AREA=46*14/256
CENTRE=np.array([2.875,5.75,1.])
DIMS={'overworld':'region','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}


def surface(q):
    v=np.array(q['vertices']);design=np.column_stack((v[:,3:5],np.ones(4)))
    coefficients,_,rank,_=np.linalg.lstsq(design,v[:,[0,2]],rcond=None)
    if rank!=3:return None
    u,w=coefficients[:2]
    if max(abs(np.linalg.norm(a)-.50097847358) for a in [u,w])>.003:return None
    if abs(np.dot(u,w))>1e-4:return None
    if np.max(abs(design@coefficients-v[:,[0,2]]))>1e-4:return None
    centre=CENTRE@coefficients
    area=abs(np.dot(v[:,0],np.roll(v[:,2],1))-np.dot(v[:,2],np.roll(v[:,0],1)))*.5
    if area<1e-7:return None
    forward=-w/np.linalg.norm(w)
    yaw=math.degrees(math.atan2(-forward[0],forward[1]))%360
    assert abs(yaw/45-round(yaw/45))<.001,(yaw,q)
    return dict(centre=np.array([centre[0],np.mean(v[:,1]),centre[1]]),
                axis=np.array([u[0],0,u[1]])/np.linalg.norm(u),yaw=round(yaw/45)*45%360,area=area,polygon=v[:,[0,2]])


def main():
    analysis=json.loads((RUN/'native-geometry-analysis.json').read_text(encoding='utf-8'))
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as jar:
        catalog_bytes=jar.read('assets/bloodborne_dw/native_grid/catalog.json')
        catalog=json.loads(catalog_bytes)
        raw=jar.read('assets/bloodborne_dw/native_grid/meshes.bin')
        sprites=set()
        for model in ['bench','bench_1','bench_rotate']:
            n=json.loads(jar.read('assets/bloodborne_dw/models/remaining/source/minecraft/block/hold/'+model+'.json'))
            sprites.update(v for v in n['textures'].values() if not v.startswith('#'))
    offsets=[];cursor=8
    for mesh in catalog['meshes']:
        count=struct.unpack_from('>I',raw,cursor)[0];assert count==mesh['quadCount']
        offsets.append((cursor+4,count));cursor+=4+count*139
    wood={i for i,m in enumerate(catalog['materials']) if m['sprite'] in sprites}
    mesh_cache={}
    readers={d:MapReader(RUN/'world/bloodborne',directory) for d,directory in DIMS.items()}
    def mesh_quads(mid):
        if mid not in mesh_cache:
            start,count=offsets[mid]
            mesh_cache[mid]=[q for i in range(count) if (q:=decode(raw[start+i*139:start+(i+1)*139]))['material'] in wood]
        return mesh_cache[mid]
    def facing(dimension,centre,axis):
        short=np.array([-axis[2],0,axis[0]]);weighted=total=0;members={}
        r=readers[dimension]
        for x in range(math.floor(centre[0])-3,math.floor(centre[0])+4):
            for y in range(math.floor(centre[1])-1,math.floor(centre[1])+3):
                for z in range(math.floor(centre[2])-3,math.floor(centre[2])+4):
                    visual=r.visual(x,y,z)
                    if visual is None:continue
                    for q in mesh_quads(catalog['cells'][visual]['mesh']):
                        v=np.array(q['vertices'])[:,:3]+np.array([x,y,z]);delta=np.mean(v,axis=0)-centre
                        if not (-1.05<delta[1]<1.55 and abs(delta@axis)<1.48 and abs(delta@short)<1.1):continue
                        members[x,y,z]=visual
                        if delta[1]<=.05:continue
                        area=sum(np.linalg.norm(np.cross(v[a]-v[0],v[b]-v[0]))*.5 for a,b in [(1,2),(2,3)])
                        total+=area;weighted+=area*float(delta@short)
        assert total>.05 and abs(weighted/total)>.08,('No unambiguous wooden backrest',dimension,centre,total,weighted)
        forward=-math.copysign(1,weighted)*short
        return round(math.degrees(math.atan2(-forward[0],forward[2]))%360,3),round(weighted/total,5),members
    def contains(point,polygon):
        signs=[]
        for i in range(len(polygon)):
            a,b=polygon[i],polygon[(i+1)%len(polygon)]
            signs.append((b[0]-a[0])*(point[1]-a[1])-(b[1]-a[1])*(point[0]-a[0]))
        return min(signs)>=-1e-4 or max(signs)<=1e-4

    top={int(k):[s for q in quads if (s:=surface(q))] for k,quads in analysis['benchTopMeshes'].items()}
    by_visual={i:top[cell['mesh']] for i,cell in enumerate(catalog['cells']) if cell['mesh'] in top}
    body=set(analysis['benchBodyMeshes'])
    body_visuals=[i for i,c in enumerate(catalog['cells']) if c['mesh'] in body]
    groups={};native_candidates=0
    for dimension,directory in DIMS.items():
        for path in sorted((RUN/'world/bloodborne'/directory).glob('r.*.*.mca')):
            _,rx,rz,_=path.name.split('.');rx,rz=int(rx),int(rz)
            for chunk in RegionFile.open(path).chunks():
                root=compound(chunk.nbt().root)
                if 'DreamwalkerVisuals' not in root:continue
                for row in compound(root['DreamwalkerVisuals'])['Sections'].value:
                    section=compound(row);sy=section['Y'].value
                    for entry in section['Entries'].value:
                        visual=(entry&0xffffffff)>>12
                        if visual not in by_visual:continue
                        local=entry&4095
                        position=np.array([rx*512+chunk.x*16+(local&15),sy*16+(local>>8),rz*512+chunk.z*16+((local>>4)&15)])
                        native_candidates+=1
                        for s in by_visual[visual]:
                            centre=s['centre']+position
                            key=(dimension,*(round(float(v),2) for v in centre),s['yaw'])
                            group=groups.setdefault(key,dict(area=0,cells={},best=None,polygons=[]))
                            group['area']+=s['area'];group['cells'][tuple(map(int,position))]=visual
                            group['polygons'].append(s['polygon']+position[[0,2]])
                            if group['best'] is None or s['area']>group['best']['area']:
                                group['best']={**s,'centre':centre}
    templates={};coverage=[];incomplete=[];partial=[]
    for key,g in sorted(groups.items()):
        if g['area']<AREA*.5 or g['area']>AREA+.02:

            incomplete.append(dict(key=key,area=g['area'],cells=len(g['cells'])));continue
        root=min(g['cells']);basis=g['best'];centre=basis['centre']-np.array(root)
        cells=[[*[p[i]-root[i] for i in range(3)],visual] for p,visual in sorted(g['cells'].items())]
        yaw,backrest,members=facing(key[0],basis['centre'],basis['axis'])
        members.update(g['cells'])
        seats=[]
        for distance in [-.95,0,.95]:
            contact=basis['centre']+distance*basis['axis']
            if any(contains(contact[[0,2]],p) for p in g['polygons']):
                seats.append([*[round(float(v),5) for v in contact-np.array(root)],yaw])
        assert seats,(key,g['area'])
        if abs(g['area']-AREA)>.02:partial.append(dict(key=key,area=g['area'],seats=len(seats)))
        definition=dict(cells=cells,seats=seats,triggers=[[*[p[i]-root[i] for i in range(3)],visual] for p,visual in sorted(members.items())])
        identifier=hashlib.sha256(json.dumps(definition,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:16]
        assert identifier not in templates or templates[identifier]==definition
        templates[identifier]=definition
        coverage.append(dict(dimension=key[0],root=root,centre=basis['centre'].tolist(),template=identifier,
                             area=g['area'],memberCells=len(cells),seats=len(seats),backrestProjection=backrest,yaw=yaw))
    resource=dict(schemaVersion=1,catalogSha256=hashlib.sha256(catalog_bytes).hexdigest(),
                  templates=[dict(id=k,**v) for k,v in sorted(templates.items())])
    write(RUN/'native-bench-definitions.json',resource)
    report=dict(nativeCandidateCells=native_candidates,supportedBenches=len(coverage),completeBenches=len(coverage)-len(partial),partialBenches=partial,templates=len(templates),
                bodyVisuals=len(body_visuals),dimensions=dict(collections.Counter(p['dimension'] for p in coverage)),
                incomplete=incomplete,benches=coverage)
    write(RUN/'task08-native-bench-coverage.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='benches'},indent=2))


if __name__=='__main__':main()
