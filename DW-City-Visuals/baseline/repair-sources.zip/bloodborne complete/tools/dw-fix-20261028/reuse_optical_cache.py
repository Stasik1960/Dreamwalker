"""Keep accepted light arrays after collision-only edits; regenerate motion heightmaps on load."""
import collections,copy,json,shutil,subprocess
from prepare_workspace import RUN,WORKSPACE,write,sha
from import_lighting import ROOT_LIGHT,SECTION_LIGHT,normalized
from fast_block_compare import same_blocks
from world_io import RegionFile,compound,Tag,TAG_BYTE,lighting_cache_errors

def guard():subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)

def cache(root):
    return ({k:v for k,v in root.items() if k in ROOT_LIGHT and k!='isLightOn'},
        {compound(s)['Y'].value:{k:v for k,v in compound(s).items() if k in SECTION_LIGHT} for s in root['sections'].value})

def main():
    guard();world=RUN/'bench-surfaces-v21/bloodborne';base=RUN/'prelit-stage4-v18/bloodborne';output=RUN/'prelit-bench-v22/bloodborne';assert not output.exists()
    proof=json.loads((RUN/'v22-byte-bound-change.json').read_text(encoding='utf-8'));support=json.loads((RUN/'bench-support-scope.json').read_text(encoding='utf-8'))
    assert proof['status']=='BENCH_SURFACE_ONLY_CHANGE_SCOPE_PASS' and proof['benchAimAndGeometryUnchanged'] and proof['allExistingRuntimeClassesAndPngByteIdentical']
    assert proof['candidateSha256']==sha(RUN/'candidates/dreamwalker-bb-visual4-rc3-dwfix.22.jar')
    assert sha(RUN/'native-overlay/assets/bloodborne_dw/native_grid/catalog.json')==support['catalogSha256']
    scope=json.loads((RUN/'prelight-targets-bench-v21.json').read_text(encoding='utf-8'));prefix={'minecraft:overworld':'region','bloodborne_dw:bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'};groups=collections.defaultdict(list)
    for row in scope['prelightChunks']:groups[prefix[row['dimension']],row['x']>>5,row['z']>>5].append((row['x'],row['z']))
    shutil.copytree(world,output,ignore=shutil.ignore_patterns('session.lock'));results=[];total=0
    for (directory,rx,rz),positions in sorted(groups.items()):
        guard();relative=f'{directory}/r.{rx}.{rz}.mca';original=RegionFile.open(world/relative);reference=RegionFile.open(base/relative);edited=RegionFile((world/relative).read_bytes());allowed=set()
        for cx,cz in positions:
            chunk=original.get_chunk(cx&31,cz&31);oldchunk=reference.get_chunk(cx&31,cz&31);nbt=chunk.nbt();root=compound(nbt.root);before=copy.deepcopy(root);cached=compound(oldchunk.nbt().root)
            assert cached['isLightOn'].value==1 and cache(root)==cache(cached)
            assert root.get('Heightmaps')==cached.get('Heightmaps')
            root['isLightOn']=Tag(TAG_BYTE,1);assert not lighting_cache_errors(root)
            # These maps may depend on collision. Vanilla recomputes missing maps using the new states.
            maps=compound(root['Heightmaps'])
            for key in list(maps):
                if key not in ['WORLD_SURFACE','WORLD_SURFACE_WG']:maps.pop(key)
            assert normalized(before)==normalized(root) and same_blocks(before,root)
            edited.set_chunk(cx&31,cz&31,nbt,timestamp=chunk.timestamp);allowed.add((cx&31,cz&31));total+=1
        edited.save(output/relative);persisted=RegionFile.open(output/relative)
        for chunk in original.chunks():
            check=persisted.get_chunk(chunk.x,chunk.z)
            if (chunk.x,chunk.z) in allowed:
                a,b=compound(chunk.nbt().root),compound(check.nbt().root);assert normalized(a)==normalized(b) and same_blocks(a,b) and b['isLightOn'].value==1 and cache(a)==cache(b)
            else:assert chunk.compressed_payload==check.compressed_payload and chunk.timestamp==check.timestamp
        results.append(dict(path=relative,chunks=len(positions),sha256=sha(output/relative)))
    receipt=dict(status='PERSISTED_LIGHTING_ONLY_GATE_PASS',chunks=total,inputWorld=str(world),outputWorld=str(output),referenceLightingWorld=str(base),method='Accepted cached sky/block light retained after proven optics/culling/fluid/emission equivalence; collision-dependent heightmaps invalidated for vanilla regeneration on load.',allChangedCellOpticsIdentical=True,blocksOwnershipAndNativeGeometryUnchanged=True,regions=results)
    write(output.parent/'prelight-import-receipt.json',receipt);print({k:v for k,v in receipt.items() if k!='regions'})

if __name__=='__main__':main()
