"""Identify only plain terrain remnants revealed by the first trim preview."""
import json
import re
import struct
import zipfile
from prepare_workspace import BASE,RUN,write
from map_reader import MapReader,compound
from plan_scene01_trim import exterior,FILLERS


def split(state):
    name,*tail=state.split('[',1)
    return name,dict(p.split('=',1) for p in tail[0][:-1].split(',')) if tail else {}


def main():
    first=json.loads((RUN/'task01-trim-plan.json').read_text(encoding='utf-8'));old={tuple(c[:3]) for c in first['cells']}
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        catalogue=json.loads(archive.read('assets/bloodborne_dw/native_grid/catalog.json'))
        static=json.loads(archive.read('bloodborne_dw/static-architecture-v1274.json'));poses={p['key']:p for p in static['poses']}
        models={};materials={'minecraft:block/stone'}
        def model_materials(ref):
            if ref in models:return models[ref]
            name='assets/'+ref.replace(':','/models/',1)+'.json'
            if name not in archive.namelist():return set()
            d=json.loads(archive.read(name));tex=d.get('textures',{});result=set()
            if d.get('parent'):result.update(model_materials(d['parent']))
            for key,value in tex.items():
                if key!='particle' and not value.startswith('#'):result.add(value)
            models[ref]=result;return result
        for state in {c[3] for c in first['cells']}:
            name,props=split(state)
            if name in FILLERS:
                d=json.loads(archive.read('bloodborne_dw/composite/'+name.split(':')[1]+'.json'))
                variant=int(props.get('variant','0'))+16*int(props.get('art_bank','0'))
                for p in d['variants'][variant]['poses']['closed']['parts']:materials.update(model_materials(p['model']))
        d=json.loads(archive.read('bloodborne_dw/composite/source_bricks_bricks_r_0.json'))
        for v in d['variants'][:4]:
            for p in v['poses']['closed']['parts']:materials.update(model_materials(p['model']))
        permitted={i for i,m in enumerate(catalogue['materials']) if m['sprite'] in materials}
        terrain_meshes=set()
        with archive.open('assets/bloodborne_dw/native_grid/meshes.bin') as stream:
            assert struct.unpack('>II',stream.read(8))==(0x4e475131,len(catalogue['meshes']))
            for i,m in enumerate(catalogue['meshes']):
                count=struct.unpack('>I',stream.read(4))[0];data=stream.read(count*139)
                if count and all(struct.unpack_from('>I',data,j*139)[0] in permitted for j in range(count)):
                    terrain_meshes.add(i)
    members={m['cell'] for o in catalogue['wholeObjects'] for m in o['cells']}
    natives={i for i,c in enumerate(catalogue['cells']) if c['mesh'] in terrain_meshes and not c.get('localFunction')
             and c.get('fluid') is None and not catalogue['optics'][c['optics']]['luminance'] and i not in members}
    terrain_types=FILLERS|{'bloodborne_dw:source_bricks_bricks_r_0'}
    recipes={i for i,r in enumerate(static['recipes']) if r['fragments'] and
             all(poses[f['pose']]['registryId'] in terrain_types for f in r['fragments'])}
    reader=MapReader(RUN/'world/bloodborne');delta=[];native_visuals={};counts={}
    for z in range(-968,-819):
        for x in range(-190,-79):
            if not exterior(x,z):continue
            for y in range(-64,27):
                if (x,y,z) in old:continue
                state=reader.state(x,y,z);name,props=split(state);visual=reader.visual(x,y,z)
                allowed=state=='minecraft:stone' or (name in FILLERS and props.get('compact')=='true')
                if name.startswith('bloodborne_dw:static_architecture_'):
                    allowed=int(name.rsplit('_',1)[1])*128+int(props['part']) in recipes and props.get('waterlogged')=='false'
                if name.startswith('bloodborne_dw:native_physics_'):
                    allowed=visual in natives
                if not allowed:continue
                if reader.entity(x,y,z) is not None:continue
                fields=compound(reader.chunk(x,z)['DreamwalkerVisuals']) if 'DreamwalkerVisuals' in reader.chunk(x,z) else {}
                if fields.get('ForcedWater') and (((x&0x3ffffff)<<38)|((z&0x3ffffff)<<12)|(y&4095)) in fields['ForcedWater'].value:continue
                delta.append([x,y,z,state]);counts[name]=counts.get(name,0)+1
                if visual is not None:native_visuals[f'{x},{y},{z}']=visual
    write(RUN/'task01-trim-plan-v2.json',dict(status='SECOND_PREVIEW_REQUIRES_REVIEW',cells=first['cells']+delta,
          delta=delta,nativeVisuals=native_visuals,permittedMaterialSprites=sorted(materials),types=counts))
    directory=RUN/'runs/scene01-detail/client/saves/city/datapacks/dwfix-preview/data/dwfix/functions/trim2'
    directory.mkdir(parents=True,exist_ok=False)
    batches=[delta[i:i+200] for i in range(0,len(delta),200)]
    for i,batch in enumerate(batches):
        lines=[f'execute if block {x} {y} {z} {state} run setblock {x} {y} {z} minecraft:air' for x,y,z,state in batch]
        lines.append(f'schedule function dwfix:trim2/part_{i+1:04d} 1t replace' if i+1<len(batches) else
                     'tellraw @a {"text":"DW QA trim second preview finished","color":"green"}')
        (directory/f'part_{i:04d}.mcfunction').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (directory/'start.mcfunction').write_text('function dwfix:trim2/part_0000\n',encoding='utf-8')
    print(json.dumps(dict(delta=len(delta),nativeCells=len(native_visuals),types=counts,materials=sorted(materials)),indent=2))


if __name__=='__main__':main()
