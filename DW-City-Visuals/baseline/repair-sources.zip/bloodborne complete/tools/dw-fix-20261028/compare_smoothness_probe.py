"""One fixed six-phase diagnostic pair; never replaces the accepted full route."""
import argparse
import json
from prepare_workspace import RUN, sha, write
from compare_performance import BASELINE_SHA


def load(label):
    assert label.replace('-', '').isalnum()
    folder = RUN/'runs'/label
    plan, report, receipt = [json.loads((folder/name).read_text(encoding='utf8'))
        for name in ['plan.json', 'client/evidence/qa.json', 'receipt.json']]
    assert report['status'] == 'PASS' and report['saved'] and receipt['exitCode'] == 0
    assert plan['simulationDistance'] == 12 and plan['renderDistance'] == 12
    assert receipt['profile'] is True
    assert plan['heapGb'] == 8 and plan['maxFps'] == 260
    assert len(plan['phases']) == len(report['phases']) == 6
    for planned, actual in zip(plan['phases'], report['phases']):
        assert planned['name'] == actual['name']
        assert actual['configuredSimulationDistance'] == 12 and actual['configuredMaxFps'] == 260
        assert actual['windowFocused'] and actual['allViewChunksDelivered']
        assert actual['steadyFrames']['frames'] >= 1800
        assert abs((actual['actualYaw']-actual['yaw']+180)%360-180) < .1
        assert abs(actual['actualPitch']-actual['pitch']) < .1
    return plan, report, receipt


def compare(baseline, candidate):
    a, ar, ac = load(baseline)
    b, br, bc = load(candidate)
    assert ac['candidateSha256'] == BASELINE_SHA and ac['qaSha256'] == bc['qaSha256']
    assert a['phases'] == b['phases']
    assert all(a.get(k) == b.get(k) for k in
        ['maxFps', 'renderDistance', 'simulationDistance', 'heapGb', 'fixedTime'])
    assert [x['name'] for x in a['phases']] == [
        f'perf-{camera}-visit{visit}' for visit in [1, 2]
        for camera in ['bench-courtyard', 'upper-street', 'arched-facade']]
    visits = []
    for index, (old, new) in enumerate(zip(ar['phases'], br['phases'])):
        assert old['actualPosition'] == new['actualPosition']
        so, sn = old['steadyFrames'], new['steadyFrames']
        lo, ln = old['loadingFrames'], new['loadingFrames']
        checks = dict(finalTerrainComplete=old['terrainComplete'] and new['terrainComplete'],
            meanFpsWithinTenPercent=sn['meanFps'] >= so['meanFps']*.9,
            steadyP99WithinTenPercent=sn['p99Ms'] <= so['p99Ms']*1.1,
            noNewSteadyStallAbove250ms=sn['maximumMs'] <= max(250, so['maximumMs']*1.1))
        if index:
            checks.update(travelP99WithinTenPercent=ln['p99Ms'] <= lo['p99Ms']*1.1,
                readyAndSettleWithinTenPercent=ln['readyAndSettleSeconds'] <= lo['readyAndSettleSeconds']*1.1,
                noNewTravelStallAbove250ms=ln['maximumMs'] <= max(250, lo['maximumMs']*1.1))
        visits.append(dict(phase=old['name'], steady=dict(baseline=so,candidate=sn),
            loading=dict(baseline=lo,candidate=ln),checks=checks,
            firstWorldEntry=index == 0, violations=[k for k,v in checks.items() if not v]))
    return dict(status='PASS' if not any(x['violations'] for x in visits) else 'REVIEW_REQUIRED',
        diagnosticOnly=True, invalidVisits=[x['phase'] for x in visits if not x['checks']['finalTerrainComplete']],
        baseline=baseline, candidate=candidate, qaSha256=ac['qaSha256'],
        candidateSha256=bc['candidateSha256'],visits=visits,
        limitation='One targeted pair with corrected QA and explicit simulation distance; does not replace the full-route record or establish the causal effect of the QA change.',
        evidence={label:{name:sha(RUN/'runs'/label/name) for name in
            ['plan.json','receipt.json','client/evidence/qa.json']} for label in [baseline,candidate]})


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('baseline');parser.add_argument('candidate');args=parser.parse_args()
    result=compare(args.baseline,args.candidate)
    write(RUN/'microstutter-20261029/probe-comparison.json',result)
    print(json.dumps({k:result[k] for k in ['status','baseline','candidate']},indent=2))
    for row in result['visits']:print(row['phase'],row['violations'])
