"""Inspect native bench surfaces and look for exact retained supersets of the reported broken mesh."""
import collections
import json
import struct
import zipfile
import numpy as np
from prepare_workspace import BASE,RUN,write


def quads(data,start,count):
    return [data[start+i*139:start+(i+1)*139] for i in range(count)]


def decode(raw):
    material,cull,face,tint,flags=struct.unpack_from('>ibbIB',raw)
    vertices=[struct.unpack_from('>5f',raw,11+i*32) for i in range(4)]
    return dict(material=material,cull=cull,face=face,vertices=vertices)


def main():
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        catalog=json.loads(archive.read('assets/bloodborne_dw/native_grid/catalog.json'))
        raw=archive.read('assets/bloodborne_dw/native_grid/meshes.bin')
    assert struct.unpack_from('>II',raw)==(0x4e475131,len(catalog['meshes']))
    offsets=[];pos=8
    for mesh in catalog['meshes']:
        count=struct.unpack_from('>I',raw,pos)[0];assert count==mesh['quadCount']
        offsets.append((pos+4,count));pos+=4+count*139
    assert pos==len(raw)
    target=set(quads(raw,*offsets[107175]));needle=next(iter(target));supersets=[];common=None
    bench_materials={i for i,m in enumerate(catalog['materials']) if m['sprite'].endswith('/spirelamp_0022')}
    bench={};body=[]
    for mesh,(start,count) in enumerate(offsets):
        if count>len(target) and raw.find(needle,start,start+count*139)>=0:
            other=set(quads(raw,start,count))
            if target<=other:
                extra=other-target;common=extra if common is None else common&extra
                supersets.append(dict(mesh=mesh,extra=len(extra)))
        materials=np.ndarray((count,),dtype='>u4',buffer=raw,offset=start,strides=(139,))
        if not any(np.any(materials==i) for i in bench_materials):continue
        body.append(mesh)
        top=[]
        for encoded in quads(raw,start,count):
            q=decode(encoded)
            if q['material'] not in bench_materials or q['face']!=1:continue
            v=np.asarray(q['vertices'])
            if np.ptp(v[:,1])>1e-5:continue
            if v[:,3].min()>=-.01 and v[:,3].max()<=5.76 and v[:,4].min()>=4.86 and v[:,4].max()<=6.64:
                top.append(q)
        if top:bench[str(mesh)]=top
    write(RUN/'native-geometry-analysis.json',dict(targetMesh=107175,exactSupersets=supersets,
           commonExtraQuads=[decode(q) for q in sorted(common or [])],benchTopMeshes=bench,benchBodyMeshes=body))
    print(json.dumps(dict(exactSupersets=supersets,commonExtraFaces=[decode(q)['face'] for q in sorted(common or [])],
                          benchTopMeshes=len(bench)),indent=2))


if __name__=='__main__':main()
