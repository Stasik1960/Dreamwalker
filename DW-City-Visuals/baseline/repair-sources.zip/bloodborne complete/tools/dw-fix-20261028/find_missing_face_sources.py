"""Find retained source faces whose UV domains contain the reported clipped native cap."""
import json,zipfile
from prepare_workspace import BASE,RUN,write

def main():
    target=[12.375,13.25,14.375,15.25];matches=[]
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        for name in z.namelist():
            if not name.startswith('assets/bloodborne_dw/models/') or not name.endswith('.json'):continue
            data=json.loads(z.read(name));textures=data.get('textures',{})
            for index,e in enumerate(data.get('elements',[])):
                for side,face in e.get('faces',{}).items():
                    texture=face.get('texture','');seen=set()
                    while texture.startswith('#') and texture not in seen:seen.add(texture);texture=textures.get(texture[1:],'')
                    if not texture.endswith('/spirelamp_0018') or 'uv' not in face:continue
                    u,v,w,h=face['uv'];bounds=min(u,w),min(v,h),max(u,w),max(v,h)
                    if all(a>=b-1e-6 for a,b in zip(target[:2],bounds[:2])) and all(a<=b+1e-6 for a,b in zip(target[2:],bounds[2:])):
                        matches.append(dict(model=name,index=index,side=side,element=e,area=(bounds[2]-bounds[0])*(bounds[3]-bounds[1])))
    matches.sort(key=lambda x:x['area']);write(RUN/'task12-source-face-candidates.json',matches)
    print(json.dumps(dict(matches=len(matches),smallest=[{k:v for k,v in m.items() if k!='element'} for m in matches[:25]]),indent=2))

if __name__=='__main__':main()
