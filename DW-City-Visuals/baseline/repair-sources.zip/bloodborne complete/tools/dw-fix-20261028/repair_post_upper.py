"""Reuse byte-proven canonical feet in mixed native cells without destroying their neighbours."""
import copy,json,zipfile
from prepare_workspace import RUN,BASE,write
from pathlib import Path

def main():
    resource=Path(__file__).resolve().parent/'src/main/resources'
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        spec=json.loads(z.read('bloodborne_dw/composite/source_street_lamp_post.json'));before=copy.deepcopy(spec['variants']);assert len(before)==35
        variant=copy.deepcopy(before[0]);pose=variant['poses']['closed'];pose['parts']=pose['parts'][2:]
        for part in pose['parts']:part['offset'][1]-=32
        for key in ['collision','selection']:
            rows=[]
            for box in pose[key]:
                if box['to'][1]<=32:continue
                b=copy.deepcopy(box);b['from'][1]=max(32,b['from'][1])-32;b['to'][1]-=32;rows.append(b)
            pose[key]=rows
        pose.pop('simpleCollisionByRotation',None)
        variant['poses'].pop('open',None);spec['variants'].append(variant);assert spec['variants'][:-1]==before
        write(resource/'bloodborne_dw/composite/source_street_lamp_post.json',spec)
        cat=json.loads((resource/'bloodborne_dw/remaining-catalogue.json').read_text(encoding='utf-8'));row=next(x for x in cat['objects'] if x['path']=='source_street_lamp_post');assert len(row['variants'])==35;row['variants'].append(dict(variant=35,name='Фонарный столб · верх над сохранённым стандартным основанием'));write(resource/'bloodborne_dw/remaining-catalogue.json',cat)
        optics=json.loads(z.read('bloodborne_dw/street-lamp-post-optics.json'));assert len(optics['variants'])==35
        upper=[]
        for value in optics['variants'][0]:
            if value['offset'][1]<2:continue
            value=copy.deepcopy(value);value['offset'][1]-=2;upper.append(value)
        optics['variants'].append(upper);write(resource/'bloodborne_dw/street-lamp-post-optics.json',optics)
    write(RUN/'task11-upper-post-resource.json',dict(status='RESOURCE_PREPARED_GAMEPLAY_PENDING',variant=35,canonicalPartsRetainedExactly=True,retainedSourceNativeFeetProof='task11-native-post-base-proof.json',exposedInCreativeCatalogue=False))
    print('Canonical upper assembly prepared; existing 35 post poses unchanged')

if __name__=='__main__':main()
