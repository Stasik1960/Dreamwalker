import jdk.jfr.consumer.*;
import java.nio.file.*;
import java.util.*;
public class JfrLoadSummary {
  static final Map<String,Map<String,Long>> counts=new TreeMap<>();
  static void add(String group,String key,long n){counts.computeIfAbsent(group,k->new HashMap<>()).merge(key,n,Long::sum);}
  // Startup recordings can retain Minecraft's original "main" thread label.
  // Bound the analysis to gameplay; CPU group labels remain verbatim.
  static boolean renderThread(RecordedThread thread){return thread!=null&&("Render thread".equals(thread.getJavaName())||"main".equals(thread.getJavaName()));}
  public static void main(String[] args)throws Exception {
    var from=args.length>1?java.time.Instant.parse(args[1]):java.time.Instant.EPOCH;
    var until=args.length>2?java.time.Instant.parse(args[2]):java.time.Instant.MAX;
    long events=0;try(var file=new RecordingFile(Path.of(args[0]))){while(file.hasMoreEvents()){
      var e=file.readEvent();
      if(e.getStartTime().isBefore(from)||!e.getStartTime().isBefore(until))continue;
      events++;String type=e.getEventType().getName();
      if(e.getDuration().toMillis()>150&&renderThread(e.getThread())){
        System.out.println("SLOW_RENDER_EVENT\t"+e.getStartTime()+"\t"+e.getDuration().toNanos()/1e6+"\t"+type);
        if(e.getStackTrace()!=null)for(var f:e.getStackTrace().getFrames().subList(0,Math.min(12,e.getStackTrace().getFrames().size())))System.out.println("EVENT_STACK\t"+f.getMethod().getType().getName()+"."+f.getMethod().getName());
      }
      if(type.equals("jdk.FileRead")&&e.getDuration().toMillis()>200&&renderThread(e.getThread())){
        System.out.println("RENDER_SLOW_READ\t"+e.getStartTime()+"\t"+e.getLong("bytesRead")+"\t"+e.getString("path"));
        if(e.getStackTrace()!=null)for(var f:e.getStackTrace().getFrames())System.out.println("READ_STACK\t"+f.getMethod().getType().getName()+"."+f.getMethod().getName());
      }
      if(type.equals("jdk.ExecutionSample")||type.equals("jdk.NativeMethodSample")){
        var t=e.getThread("sampledThread");String thread=t==null?"unknown":t.getJavaName();var trace=e.getStackTrace();if(trace==null)continue;boolean first=true;var seen=new HashSet<String>();
        for(var f:trace.getFrames()){var m=f.getMethod();String method=m.getType().getName()+"."+m.getName();if(first){add("LEAF/"+thread,method,1);first=false;}if(seen.add(method)){add("STACK/"+thread,method,1);if(method.contains("dwfix$")||method.contains(".repair.")||method.startsWith("dwfixqa."))add("REPAIR_OR_QA/"+thread,method,1);}}
      }else if(type.equals("jdk.GCPhasePause")){System.out.println("GC_PAUSE\t"+e.getStartTime()+"\t"+e.getDuration().toNanos()/1e6);}
      else if(type.equals("jdk.FileRead")||type.equals("jdk.FileWrite")){add(type+"_NANOS",e.getString("path"),e.getDuration().toNanos());if(e.getDuration().toMillis()>=50)System.out.println("SLOW_IO\t"+e.getStartTime()+"\t"+e.getDuration().toNanos()/1e6+"\t"+type+"\t"+e.getThread().getJavaName()+"\t"+e.getString("path"));}
      else if(type.equals("jdk.ObjectAllocationSample")){
        String object=e.getClass("objectClass").getName();long weight=e.getLong("weight");
        add("ALLOC_WEIGHT",object,weight);
        if(renderThread(e.getThread())){
          add("RENDER_ALLOC_WEIGHT",object,weight);
          if(e.getStackTrace()!=null)for(var f:e.getStackTrace().getFrames()){
            var m=f.getMethod();String method=m.getType().getName()+"."+m.getName();
            if(method.startsWith("dev.dreamwalker.")||method.startsWith("dwfixqa.")){
              add("RENDER_ALLOC_CALLER_WEIGHT",method,weight);break;
            }
          }
        }
      }
    }}
    System.out.println("EVENTS\t"+events);
    for(var g:counts.entrySet()){var values=new ArrayList<>(g.getValue().entrySet());values.sort(Map.Entry.<String,Long>comparingByValue().reversed());int n=0;for(var v:values){if(n++>=35)break;System.out.println(g.getKey()+"\t"+v.getValue()+"\t"+v.getKey());}}
  }
}
