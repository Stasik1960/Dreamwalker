"""Compare every proven source wall with the saved native geometry; write a reviewable plan only."""
import collections,hashlib,io,json,struct,zipfile
import numpy as np
from PIL import Image
from native_model_baker import bake,cell_quads
from discover_missing_native_walls import signature,D
from prepare_workspace import BASE,RUN,write
from map_reader import MapReader

def main():
    overlay=RUN/'native-overlay';c=json.loads((overlay/D/'catalog.json').read_text(encoding='utf-8'));raw=(overlay/D/'meshes.bin').read_bytes();materials=c['materials'];mesh_cache={};offsets=[];cursor=8
    for m in c['meshes']:n=struct.unpack_from('>I',raw,cursor)[0];offsets.append((cursor+4,n));cursor+=4+139*n
    by_visual={int(k):v for k,v in json.loads((RUN/'task12-wall-source-identities.json').read_text(encoding='utf-8'))['byVisual'].items()}
    index=np.load(RUN/'world-repair-index.npz')['native'];lookup={tuple(map(int,row[:4])):int(row[4]) for row in index};assert len(lookup)==len(index)
    roots=index[np.isin(index[:,4],list(by_visual))];templates=[]
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        alpha=np.asarray(Image.open(io.BytesIO(z.read('assets/bloodborne_dw/textures/block/remaining/source/minecraft/block/addon/spirelamp_0018.png'))).convert('RGBA'))[:,:,3]
        sprite='bloodborne_dw:block/remaining/source/minecraft/block/addon/spirelamp_0018';ids={m['layer']:i for i,m in enumerate(materials) if m['sprite']==sprite}
        def material(sprite,layer):return ids['solid']
        for name in ['diorite','prismarine_bricks']:
            model=json.loads(z.read('assets/bloodborne_dw/models/remaining/source/minecraft/block/'+name+'.json'))
            for rotation in [0,2,4,6]:templates.append(cell_quads(bake(model,offset=(0,0,0),yaw=rotation,layer='solid'),material))
    def quads(visual):
        mid=c['cells'][visual]['mesh']
        if mid not in mesh_cache:
            start,count=offsets[mid];mesh_cache[mid]=set(signature(raw[start+139*i:start+139*(i+1)],materials) for i in range(count))
        return mesh_cache[mid]
    def layer(q):
        uv=np.array([struct.unpack_from('>2f',q,11+32*i+12) for i in range(4)]);h,w=alpha.shape
        lo=np.maximum(0,np.floor(uv.min(axis=0)*[w/16,h/16]).astype(int));hi=np.minimum([w,h],np.ceil(uv.max(axis=0)*[w/16,h/16]).astype(int))
        opaque=bool(np.all(alpha[lo[1]:hi[1],lo[0]:hi[0]]==255));return struct.pack('>I',ids['solid' if opaque else 'cutout'])+q[4:]
    additions=collections.defaultdict(dict);contributions=collections.defaultdict(set);present=0
    for dim,x,y,z,visual in roots:
        ti=by_visual[int(visual)]
        for offset,qs in templates[ti].items():
            key=int(dim),int(x)+offset[0],int(y)+offset[1],int(z)+offset[2];old=lookup.get(key);existing=quads(old) if old is not None else set()
            for q in qs:
                s=signature(q,materials)
                if s in existing:present+=1;continue
                additions[key][s]=layer(q);contributions[key].add((int(x),int(y),int(z),ti))
    meta=json.loads((RUN/'world-repair-index.json').read_text(encoding='utf-8'));world=meta['world'];readers=[MapReader(world),MapReader(world,'dimensions/bloodborne_dw/bloodborne_old/region')];scenes={};positions=[];skipped=collections.Counter();example=[]
    for key,extra in sorted(additions.items()):
        dim,x,y,z=key;old=lookup.get(key);state=None
        if old is None:
            state=readers[dim].state(x,y,z)
            if state!='minecraft:air':skipped[state.split('[')[0]]+=len(extra);continue
        else:
            cell=c['cells'][old];optics=c['optics'][cell['optics']]
            # Faces inside an occupied opaque physical cell cannot repair an external hole.
            # Leave their original suppression in place and retain all source geometry there.
            if cell['collision']==1 and optics['opacity']==15:skipped['opaqueFullPhysicalInterior']+=len(extra);continue
        blob=b''.join(extra.values());scene=dict(old=old,quads=blob.hex());sid=hashlib.sha256(json.dumps(scene,sort_keys=True).encode()).hexdigest()[:20];assert sid not in scenes or scenes[sid]==scene;scenes[sid]=scene
        positions.append(dict(dimension='overworld' if dim==0 else 'bloodborne_old',pos=[x,y,z],scene=sid))
        if dim==0 and abs(x-214)<=1 and y==65 and abs(z+1097)<=1:example.append(dict(pos=[x,y,z],old=old,quads=len(extra)))
    report=dict(status='SOURCE_GEOMETRY_PLAN_ONLY',rootCount=len(roots),sourceRoots=dict(collections.Counter('diorite' if by_visual[int(v)]<4 else 'prismarine_bricks' for v in roots[:,4])),alreadyPresentQuads=present,plannedCells=len(positions),newAirGeometryCells=sum(scenes[p['scene']]['old'] is None for p in positions),uniqueScenes=len(scenes),addedQuads=sum(len(scenes[p['scene']]['quads'])//278 for p in positions),suppressedOrOtherStorage=dict(skipped),example=example)
    write(RUN/'task12-wall-restoration-plan.json',dict(report=report,scenes=scenes,cells=positions));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
