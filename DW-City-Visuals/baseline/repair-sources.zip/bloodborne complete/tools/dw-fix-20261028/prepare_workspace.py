"""Freeze the supplied map and census its native city footprint before editing."""
from __future__ import annotations

import collections
import hashlib
import json
from pathlib import Path
import shutil
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile, Tag, TAG_LIST, TAG_COMPOUND, compound, section_blocks

WORKSPACE = Path(__file__).resolve().parents[3]
RUN = WORKSPACE / '.local/dw-fix-20261028'
BASE = WORKSPACE / '.local/bloodborne-visual4-rc3'


def sha(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path: Path, document: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2), encoding='utf-8')


def hull(points):
    points = sorted(set(points))
    def cross(o, a, b):
        return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lower, upper = [], []
    for p in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def census(world: Path):
    result = {}
    for directory in [world / 'region', world / 'dimensions/bloodborne_dw/bloodborne_old/region']:
        dim = directory.relative_to(world).as_posix()
        points, bounds, blocks = set(), None, collections.Counter()
        chunks, visuals, entities, missing_section = 0, 0, 0, 0
        for path in sorted(directory.glob('*.mca')):
            for chunk in RegionFile.open(path).chunks():
                root = compound(chunk.nbt().root)
                chunks += 1
                x, z = root['xPos'].value, root['zPos'].value
                entities += len(root.get('block_entities', Tag(TAG_LIST, [], TAG_COMPOUND)).value)
                for section in root.get('sections', Tag(TAG_LIST, [], TAG_COMPOUND)).value:
                    fields = compound(section)
                    data = section_blocks(section)
                    if data is None:
                        continue
                    palette, indices = data
                    names = [compound(p)['Name'].value for p in palette]
                    counts = collections.Counter(indices)
                    for i, count in counts.items():
                        blocks[names[i]] += count
                    if any(n.startswith(('bloodborne_dw:native_', 'bloodborne_dw:composite_')) for n in names):
                        # Use actual occupied native columns, not the generated chunk boundary.
                        for i, kind in enumerate(indices):
                            if names[kind].startswith(('bloodborne_dw:native_', 'bloodborne_dw:composite_')):
                                points.add((x*16+(i&15), z*16+((i>>4)&15)))
                table = root.get('DreamwalkerVisuals')
                if table:
                    for row in compound(table).get('Sections', Tag(TAG_LIST, [], TAG_COMPOUND)).value:
                        visuals += len(compound(row)['Entries'].value)
        if points:
            bounds = [min(x for x,z in points), min(z for x,z in points),
                      max(x for x,z in points), max(z for x,z in points)]
        result[dim] = dict(chunks=chunks, blockEntities=entities, nativeVisuals=visuals,
                          occupiedNativeColumns=len(points), bounds=bounds, hull=hull(points),
                          blocks=dict(blocks.most_common()))
        print(dim, {k:v for k,v in result[dim].items() if k not in ['blocks','hull']}, flush=True)
    return result


if __name__ == '__main__':
    RUN.mkdir(exist_ok=True)
    source = BASE / 'world/bloodborne'
    target = RUN / 'world/bloodborne'
    if not (RUN / 'baseline-map-manifest.json').exists():
        assert not target.exists(), 'Refusing to overwrite an existing candidate world'
        files = sorted(p for p in source.rglob('*') if p.is_file() and p.name != 'session.lock')
        assert all(not p.is_symlink() and not p.is_junction() for p in [source, *source.rglob('*')])
        manifest = {}
        for path in files:
            key = path.relative_to(source).as_posix()
            manifest[key] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
            output = target / key
            output.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, output)
            assert sha(output) == manifest[key]['sha256'], key
        write(RUN / 'baseline-map-manifest.json', manifest)
        jar = next(BASE.glob('*.jar'))
        write(RUN / 'baseline.json', dict(jar=str(jar), jarSha256=sha(jar), world=str(source),
              candidate=str(target), archiveSha256=sha(Path('C:/Users/vakir/Downloads/dw-fix.zip'))))
        print('Frozen map copied:', len(files), 'files', flush=True)
    write(RUN / 'census.json', census(source))
