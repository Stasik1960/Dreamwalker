"""Lossless removal of retired lamp owners from shared composite cells."""
import copy,json,sys
from pathlib import Path
from index_lantern_owners import owner_key
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import *

def physical_state(layout,index):
    physical=layout['cellToPhysics'][index];assert physical>=0
    return f'bloodborne_dw:native_physics_{physical//128}[part={physical%128}]'

def remove_owners(editor,positions,targets,layout,catalog_sha):
    touched=removed=0
    for pos in positions:
        before=editor.entity(*pos);assert before is not None and 'OwnerDataV1' in before
        be=copy.deepcopy(before);envelope=decode_nbt(be['OwnerDataV1'].value);root=compound(envelope.root);original=root['owners'].value
        kept=[row for row in original if owner_key(compound(row)['owner']) not in targets]
        if len(kept)==len(original):continue
        removed+=len(original)-len(kept);touched+=1;resident=be.get('resident');remove_resident=resident is not None and owner_key(resident) in targets
        if remove_resident:be.pop('resident');be['payload']=Tag(TAG_COMPOUND,{})
        if kept or 'resident' in be:
            root['owners']=Tag(TAG_LIST,kept,TAG_COMPOUND);be['OwnerDataV1']=Tag(TAG_BYTE_ARRAY,encode_nbt(envelope));editor.set_entity(pos,be)
            if remove_resident:editor.set_state(pos,'bloodborne_dw:composite_cell')
        else:
            base=be.get('NativeGridBase');editor.set_entity(pos,None)
            if base is not None:
                editor.set_state(pos,physical_state(layout,base.value));editor.set_visual(pos,base.value,catalog_sha)
            else:
                state=editor.state(*pos);wet='waterlogged=true' in state;editor.set_state(pos,'minecraft:water[level=0]' if wet else 'minecraft:air');editor.set_visual(pos,-1,catalog_sha)
        # Verify foreign rows byte-for-byte as typed NBT before any later object is installed.
        after=editor.entity(*pos);actual=[] if after is None else compound(decode_nbt(after['OwnerDataV1'].value).root)['owners'].value
        assert actual==kept
        if resident is not None and not remove_resident:assert after['resident']==resident and after['payload']==before['payload']
    return dict(cells=touched,contributions=removed)
