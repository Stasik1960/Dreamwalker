"""Read-only proof of frozen lanterns using complete source-model fingerprints."""
import collections,copy,hashlib,json,struct,zipfile
import numpy as np
from native_model_baker import bake,cell_quads
from prepare_workspace import BASE,RUN,write
D='assets/bloodborne_dw/native_grid/'

def sig(q,materials):
    mat,_,face=struct.unpack_from('>ibb',q);return materials[mat]['sprite'],face,tuple(sorted(tuple(round(v,4) for v in struct.unpack_from('>5f',q,11+i*32)) for i in range(4)))

def main():
    overlay=RUN/'native-overlay';c=json.loads((overlay/D/'catalog.json').read_text(encoding='utf-8'));raw=(overlay/D/'meshes.bin').read_bytes();materials=c['materials'];by_sprite=collections.defaultdict(list)
    for i,m in enumerate(materials):by_sprite[m['sprite']].append(i)
    retired=json.loads((RUN/'task11-static-lantern-preflight.json').read_text(encoding='utf-8'))['types'];templates=[];unsupported=[];seen=set()
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        def model(identifier):
            ns,path=identifier.split(':');d=json.loads(z.read('assets/'+ns+'/models/'+path+'.json'))
            if 'parent' in d:
                try:base=model(d['parent'])
                except (KeyError,AssertionError):base={}
                textures=base.get('textures',{}).copy();textures.update(d.get('textures',{}));base.update(d);base['textures']=textures;d=base
            return d
        for kind in retired:
            spec=json.loads(z.read('bloodborne_dw/composite/'+kind.split(':')[1]+'.json'))
            for vi,variant in enumerate(spec['variants']):
                parts=variant['poses']['closed']['parts'];family=hashlib.sha256(json.dumps(parts,sort_keys=True).encode()).hexdigest()[:16]
                for rotation in [0,2,4,6]:
                    try:
                        quads=[]
                        for p in parts:
                            assert not any(p.get(k,0) for k in ['yaw','pitch','extraYaw']),'Part transform'
                            quads+=bake(model(p['model']),offset=p.get('offset',[0,0,0]),yaw=rotation,layer='cutout')
                        for shift in [-1,0,1]:
                            moved=copy.deepcopy(quads)
                            for q in moved:q.vertices[:,1]+=shift
                            cells=cell_quads(moved,lambda sprite,layer:by_sprite[sprite][0]);root=cells.get((0,0,0),[])
                            if len(root)<3:continue
                            fingerprint=frozenset(sig(q,materials) for q in root)
                            key=family,rotation,shift
                            if key in seen:continue
                            seen.add(key);templates.append(dict(kind=kind,variant=vi,family=family,rotation=rotation,shift=shift,cells=cells,required=fingerprint))
                    except (AssertionError,KeyError,TypeError,IndexError,ValueError) as error:unsupported.append(dict(kind=kind,variant=vi,rotation=rotation,reason=str(error)))
    wanted=set().union(*(t['required'] for t in templates));sprites={s[0] for s in wanted};meshes=[];cursor=8;mesh_signatures={};root_matches={}
    for mid,m in enumerate(c['meshes']):
        n=struct.unpack_from('>I',raw,cursor)[0];blob=raw[cursor+4:cursor+4+n*139];cursor+=4+139*n;meshes.append(blob);found=set()
        for at in range(0,len(blob),139):
            if materials[struct.unpack_from('>I',blob,at)[0]]['sprite'] not in sprites:continue
            s=sig(blob[at:at+139],materials)
            if s in wanted:found.add(s)
        if found:
            candidates=[ti for ti,t in enumerate(templates) if t['required']<=found]
            if candidates:root_matches[mid]=candidates
    by_visual={i:root_matches[cell['mesh']] for i,cell in enumerate(c['cells']) if cell['mesh'] in root_matches};index=np.load(RUN/'world-repair-index.npz')['native'];lookup={tuple(map(int,row[:4])):int(row[4]) for row in index};groups={};rejected=0
    def actual(visual):
        mid=c['cells'][visual]['mesh']
        if mid not in mesh_signatures:
            blob=meshes[mid];mesh_signatures[mid]={sig(blob[at:at+139],materials):at//139 for at in range(0,len(blob),139)}
        return mesh_signatures[mid]
    for dim,x,y,z,visual in index[np.isin(index[:,4],list(by_visual))]:
        for ti in by_visual[int(visual)]:
            t=templates[ti];matches=[];total=matched=0;missing=[]
            for offset,qs in t['cells'].items():
                pos=int(dim),int(x)+offset[0],int(y)+offset[1],int(z)+offset[2];old=lookup.get(pos);existing=actual(old) if old is not None else {};remove=[]
                for q in qs:
                    total+=1;s=sig(q,materials)
                    if s in existing:matched+=1;remove.append(existing[s])
                    else:missing.append(dict(pos=pos,face=s[1]))
                if remove:matches.append(dict(pos=list(pos[1:]),visual=old,remove=sorted(set(remove))))
            if matched<total*.95 or matched<6:rejected+=1;continue
            key=int(dim),int(x),int(y)+t['shift'],int(z),t['family'],t['rotation']
            row=dict(dimension=int(dim),root=[int(x),int(y)+t['shift'],int(z)],registryId=t['kind'],variant=t['variant'],rotation=t['rotation'],sourceFamily=t['family'],matched=matched,expected=total,missing=missing,cells=matches)
            if key not in groups or row['matched']>groups[key]['matched']:groups[key]=row
    summary=dict(status='NATIVE_SOURCE_MODELS_PROVED_NO_MAP_WRITES',templates=len(templates),candidateNativeVisuals=len(by_visual),nativeLanterns=len(groups),byType=dict(collections.Counter(g['registryId'] for g in groups.values())),rejectedIncompleteOrOtherGeometry=rejected,unsupported=unsupported,groups=list(groups.values()))
    write(RUN/'task11-native-lantern-preflight.json',summary);print(json.dumps({k:v for k,v in summary.items() if k not in ['groups','unsupported']},indent=2));print('Unsupported source variants',len(unsupported))

if __name__=='__main__':main()
