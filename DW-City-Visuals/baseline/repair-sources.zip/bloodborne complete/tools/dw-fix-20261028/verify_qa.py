"""Accept actual pixels and gameplay results separately from test-driver completion."""
import argparse
import json
from PIL import Image
from prepare_workspace import RUN,write


def verify(label):
    folder=RUN/'runs'/label
    report=json.loads((folder/'client/evidence/qa.json').read_text(encoding='utf-8'))
    gates={}
    plan=json.loads((folder/'plan.json').read_text(encoding='utf-8'))
    if plan.get('testDarkness'):
        tests=report.get('darknessCreativeTests',[])
        gates['creativePlacePickBreakBothDimensions']=(len(tests)==2 and all(
            x['middlePick'] and x['placeBreakCycles']==2 and x['noBlockEntityOrPropertiesOrTicks']
            and x['emptyPlayerCollision'] for x in tests))
    if plan.get('requireOpaqueDarkness'):gates['darknessOpaqueWithoutPlayerCollision']=all(r.get('opaqueForTerrainOcclusion') and r['emptyPlayerCollision'] for r in report.get('darknessCreativeTests',[])) and len(report.get('darknessCreativeTests',[]))==2
    images={}
    for row in report['phases']:
        name=row['name']
        if '-void' in name or '-return' in name:
            path=folder/'client/screenshots'/row['screenshot']
            extrema=Image.open(path).convert('RGB').getextrema()
            black=all(v==(0,0) for v in extrema)
            images[name]={'rgbExtrema':extrema,'exactlyBlack':black}
            gates[name]=black if '-void' in name else not black
    gates['driverSavedAndCompleted']=report.get('status')=='PASS' and report.get('saved') is True
    if plan.get('testDoor90001'):
        gates['door90001']=report.get('door90001Tests',{}).get('status')=='PASS'
    plan=json.loads((folder/'plan.json').read_text(encoding='utf-8'))
    for flag,key in [('testLantern','lanternTests'),('testArchedModels','archedModelTests')]:
        if plan.get(flag):gates[key]=report.get(key,{}).get('status')=='PASS'
    if 'canonicalLampProbes' in plan:
        gates['canonicalLampTests']=report.get('canonicalLampTests',{}).get('status')=='PASS'
        planned=[r for r in plan['phases'] if 'canonicalLampCycle' in r]
        actual=report.get('canonicalLampCycles',[])
        gates['canonicalLampOrdinaryCycles']=len(actual)>=len(planned) and all(r.get('status')=='PASS' and r.get('ordinaryUseCycle') is True for r in actual)
    if 'prelightChunks' in plan:
        light=report.get('prelight',{});gates['allRequestedChunksPrelit']=light.get('status')=='PASS' and light.get('completedChunks')==len(plan['prelightChunks'])
    if 'nativeWallCells' in plan:gates['nativeWallTests']=report.get('nativeWallTests',{}).get('status')=='PASS'
    if 'windowProbes' in plan:
        gates['windowAllNativeInstancesAndOrdinaryUse']=report.get('windowTests',{}).get('status')=='PASS'
    if 'benchProbes' in plan:
        gates['benchPlacementAndAllNativeInstances']=report.get('benchTests',{}).get('status')=='PASS'
    if 'benchSurfaceProbes' in plan:
        preparation=report.get('benchSurfacePreparation',{});gates['allNativeBenchWalkingSurfaces']=preparation.get('status')=='PASS' and preparation.get('nativeCount')==len(plan['benchSurfaceProbes'])
        expected=sum('benchSurface' in row for row in plan['phases']);actual=report.get('benchSurfaceTests',[]);gates['realJumpAndCrawlWithoutMount']=len(actual)==expected and all(row.get('status')=='PASS' and row.get('withoutMountOrRmb') for row in actual)
        gates['normalJumpWasObserved']=len(actual)==expected and all(r.get('normalJumpKeyUsed') and .2<=r.get('normalJumpPeakAboveBoard',0)<=1.6 for r in actual)
        gates['benchSurfaceViewsComplete']=len(report['phases'])==len(plan['phases']) and all(r.get('terrainComplete') and r.get('allViewChunksDelivered') for r in report['phases'])
        gates['benchSurfacePosesAreReal']=len(actual)==expected and all(r.get('actualPose')==('CRAWLING' if r.get('pose')=='crawl' else 'STANDING') and r.get('realCrawlState')==(r.get('pose')=='crawl') for r in actual)
    if 'inertProbes' in plan:
        tests=report.get('inertRemovalTests',[])
        gates['removedInertCellsRemainAirWithoutMetadata']=(len(tests)==len(plan['inertProbes']) and all(t['status']=='PASS' for t in tests))
    accepted=all(gates.values())
    write(folder/'acceptance.json',dict(status='PASS' if accepted else 'FAIL',gates=gates,pixels=images,
          scope='Floor creative lifecycle and exact-black void frames; scene removal/performance/other archive tasks are separate gates.'))
    print(json.dumps({'status':'PASS' if accepted else 'FAIL','gates':gates,'pixels':images},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('label');verify(parser.parse_args().label)
