"""Remove exactly the retired structural pieces attached to paired lamp anchors."""
import collections,json,zipfile
import numpy as np
from map_reader import MapReader
from plan_static_lantern_removal import fragment_key
from prepare_workspace import RUN,BASE,write

def main():
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:catalog=json.loads(z.read('bloodborne_dw/static-architecture-v1274.json'))
    recipes=catalog['recipes'];poses={p['key']:p for p in catalog['poses']};anchors=json.loads((RUN/'task11-red-post-columns.json').read_text(encoding='utf-8'))['anchors'];proof=json.loads((RUN/'task11-native-post-base-proof.json').read_text(encoding='utf-8'));assert all(r['canonicalPartUnchanged'] for r in proof['cells'])
    target=set();direct=[];posts=[]
    for a in anchors:
        dim=0 if a['dimension']=='overworld' else 1;cut=2 if any(r['native'] is not None for r in a['column'] if r['dy'] in [-5,-4]) else 0;posts.append(dict(dimension=a['dimension'],base=[a['root'][0],a['root'][1]-5,a['root'][2]],cut=cut))
        for row in a['column']:
            dy=row['dy']
            if dy not in [-5,-4,-3,-2,-1,2,3] or (cut and dy in [-5,-4]):continue
            if 'recipe' in row:
                for f in row['fragments']:
                    kind=f['pose']['registryId'];expected={-3:'source_assembly_diorite_wall',-2:'source_assembly_orange_stained_glass_pane',-1:'source_assembly_orange_stained_glass_pane',2:'source_dead_bubble_coral_block',3:'source_dead_bubble_coral_block'}[dy]
                    if kind!='bloodborne_dw:'+expected:continue
                    root=tuple(row['pos'][i]+f['origin'][i] for i in range(3));target.add((dim,root,f['pose']['key']))
            elif row['state'].startswith('minecraft:air'):continue
            else:
                assert row['native'] is None,row
                expected={-5:'source_deepslate_tile_wall_side',-4:'source_andesite_slab_top',-2:'source_assembly_orange_stained_glass_pane',-1:'source_assembly_orange_stained_glass_pane'}[dy]
                assert row['state'].startswith('bloodborne_dw:'+expected+'[') and 'compact=true' in row['state'],row
                direct.append(dict(dimension=a['dimension'],pos=row['pos'],state=row['state']))
    # Existing lamp removals and structural removals are composed as exact recipe closures.
    removals={};lamp_pre=json.loads((RUN/'task11-static-lantern-preflight.json').read_text(encoding='utf-8'))
    for g in lamp_pre['groups']:
        for c in g['cells']:
            key=(g['dimension'],*c['pos']);f=recipes[c['recipe']]['fragments'][c['fragment']];row=removals.setdefault(key,dict(old=c['recipe'],remove=set()));assert row['old']==c['recipe'];row['remove'].add(fragment_key(f))
    relevant={i:[f for f in r['fragments'] if any(t[2]==f['pose'] for t in target)] for i,r in enumerate(recipes)};relevant={i:f for i,f in relevant.items() if f};index=np.load(RUN/'world-repair-index.npz')['static'];matched=set()
    for dim,x,y,z,old in index[np.isin(index[:,4],list(relevant))]:
        for f in relevant[int(old)]:
            root=(int(x)+f['origin'][0],int(y)+f['origin'][1],int(z)+f['origin'][2]);group=(int(dim),root,f['pose'])
            if group not in target:continue
            matched.add(group);key=tuple(map(int,[dim,x,y,z]));row=removals.setdefault(key,dict(old=int(old),remove=set()));assert row['old']==int(old);row['remove'].add(fragment_key(f))
    assert matched==target,(len(matched),len(target))
    changes=[]
    for key,row in sorted(removals.items()):
        at=row['old'];left=[f for f in recipes[at]['fragments'] if fragment_key(f) not in row['remove']]
        for wanted in sorted(row['remove']):
            r=recipes[at];which=next(i for i,f in enumerate(r['fragments']) if fragment_key(f)==wanted);at=r['remove'][which]
        assert ([] if at<0 else recipes[at]['fragments'])==left
        changes.append(dict(dimension='overworld' if key[0]==0 else 'bloodborne_old',pos=key[1:],old=row['old'],next=at))
    report=dict(status='EXACT_POST_AND_LAMP_CLOSURES_PASS_NO_MAP_WRITES',posts=len(posts),fullPosts=sum(p['cut']==0 for p in posts),retainedCanonicalFeetPosts=sum(p['cut']==2 for p in posts),staticCells=len(changes),compactCells=len(direct),structuralSourceObjects=len(target),mixedStaticCellsRetained=sum(c['next']>=0 for c in changes))
    write(RUN/'task11-post-cleanup-plan.json',dict(report=report,posts=posts,direct=direct,cells=changes));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
