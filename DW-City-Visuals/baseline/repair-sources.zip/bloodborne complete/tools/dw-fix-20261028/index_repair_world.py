"""Reusable read-only native/static coordinates, pinned to exact source region hashes."""
import collections,json,subprocess,sys,zipfile
from pathlib import Path
import numpy as np
from prepare_workspace import RUN,BASE,WORKSPACE,write,sha
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile,compound,section_blocks,block_state_key

DIMS={'overworld':'region','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}

def main():
    world=RUN/'native-window-world-8e38b14da7b5-r1/bloodborne';native=[];static=[];source=[];regions=[]
    for dimension,(name,directory) in enumerate(DIMS.items()):
        for path in sorted((world/directory).glob('r.*.*.mca')):
            subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)
            rx,rz=map(int,path.stem.split('.')[1:])
            for chunk in RegionFile.open(path).chunks():
                root=compound(chunk.nbt().root);cx,cz=rx*512+chunk.x*16,rz*512+chunk.z*16
                if 'DreamwalkerVisuals' in root:
                    for row in compound(root['DreamwalkerVisuals'])['Sections'].value:
                        s=compound(row);sy=s['Y'].value
                        for value in s['Entries'].value:
                            local=value&4095;native.append((dimension,cx+(local&15),sy*16+(local>>8),cz+((local>>4)&15),(value&0xffffffff)>>12))
                for section in root.get('sections',[]).value:
                    parsed=section_blocks(section)
                    if not parsed:continue
                    palette,indices=parsed;keys=[block_state_key(p) for p in palette]
                    if not any('static_architecture_' in key or 'soul_lantern' in key or 'street_lamp_post' in key for key in keys):continue
                    sy=compound(section)['Y'].value
                    for local,index in enumerate(indices):
                        key=keys[index]
                        if 'static_architecture_' in key:
                            bank=int(key.split('static_architecture_')[1].split('[')[0]);part=int(key.split('part=')[1].split(',')[0].split(']')[0]);static.append((dimension,cx+(local&15),sy*16+(local>>8),cz+((local>>4)&15),bank*128+part))
                        elif 'soul_lantern' in key or 'street_lamp_post' in key:source.append(dict(dimension=name,pos=[cx+(local&15),sy*16+(local>>8),cz+((local>>4)&15)],state=key))
            regions.append(dict(dimension=name,path=directory+'/'+path.name,sha256=sha(path)))
            write(RUN/'world-repair-index-progress.json',dict(regions=len(regions),native=len(native),static=len(static)))
    np.savez_compressed(RUN/'world-repair-index.npz',native=np.array(native,dtype=np.int32),static=np.array(static,dtype=np.int32))
    write(RUN/'world-repair-index.json',dict(world=str(world),regions=regions,sourceLanternAndPost=source,native=len(native),static=len(static)))
    print(json.dumps(dict(native=len(native),static=len(static),sourceLanternAndPost=len(source)),indent=2))

if __name__=='__main__':main()
