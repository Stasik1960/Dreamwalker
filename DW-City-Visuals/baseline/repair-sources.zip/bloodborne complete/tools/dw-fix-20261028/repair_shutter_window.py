"""Task09 working window edge caps and a retained-facade item variant. Texture bytes stay intact."""
import copy,json,zipfile
from pathlib import Path
from prepare_workspace import BASE,RUN,write
from repair_door_90986 import silhouette_edges


def main():
    output=Path(__file__).resolve().parent/'src/main/resources';counts={}
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as jar:
        for model_name in ['shutter_0','shutter_1']:
            path='assets/bloodborne_dw/models/interactions/'+model_name+'.json';model=json.loads(jar.read(path));before=copy.deepcopy(model)
            if model_name=='shutter_0':
                for index in [0,1]:
                    e=model['elements'][index];faces=e['faces'];front=faces['north'];u0,v0,u1,v1=front['uv']
                    existing='west' if 'west' in faces else 'east';opposite='east' if existing=='west' else 'west'
                    faces[opposite]=copy.deepcopy(faces[existing]);uv=faces[opposite]['uv'];uv[0],uv[2]=uv[2],uv[0]
                    for direction,a,b in [('up',v0,v0+.015625),('down',v1-.015625,v1)]:
                        faces[direction]={'texture':front['texture'],'uv':[u0,a,u1,b]}
            model['elements'][3]['to'][2]=7.25  # Separate both rim faces from the retained facade planes at Z=5/7.
            caps=silhouette_edges(model,model['elements'][3],jar);model['elements'].extend(caps)
            assert all(model['elements'][i]['faces']['north']==before['elements'][i]['faces']['north'] for i in [2,3])
            write(output/path,model);counts[model_name]=len(caps)
        path='assets/bloodborne_dw/models/interactions/shutter_glass.json';glass=json.loads(jar.read(path));glass['ambientocclusion']=False;write(output/path,glass)
        original=json.loads(jar.read('assets/bloodborne_dw/models/remaining/source/minecraft/block/spruce_trapdoor_open.json'))
        backdrop={k:copy.deepcopy(original[k]) for k in ['textures','ambientocclusion'] if k in original};backdrop['elements']=copy.deepcopy(original['elements'][4:8]);write(output/'assets/bloodborne_dw/models/interactions/shutter_backdrop.json',backdrop)
        path='bloodborne_dw/composite/source_shutter_window.json';spec=json.loads(jar.read(path));spec['layer']='cutout'
        legacy=copy.deepcopy(spec['variants'][0])
        for pose in legacy['poses'].values():
            pose['parts'].append({'model':'bloodborne_dw:interactions/shutter_backdrop','offset':[0,16,0]})
            # The retained facade and pane form the permanent barrier. The decorative shutters move visually.
            pose['collision']=[{'from':[-16,0,5],'to':[32,48,7]},{'from':[-5,2,0],'to':[21,8,8]}]
            pose['selection'].append({'from':[-16,0,5],'to':[32,48,7]});pose.pop('simpleCollisionByRotation',None)
        spec['variants'].append(legacy);write(output/path,spec)
    write(RUN/'task09-window-models.json',dict(silhouetteCaps=counts,pngBytesChanged=False,legacyVariant=1))
    print(json.dumps(counts))


if __name__=='__main__':main()
