"""Scoped Anvil editor for the offline, independently verified repair stages."""
import copy,json,sys
from pathlib import Path
from map_reader import MapReader
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import *


def state_tag(key):
    name,_,raw=key.partition('[');fields={'Name':Tag(TAG_STRING,name)}
    if raw:fields['Properties']=Tag(TAG_COMPOUND,{k:Tag(TAG_STRING,v) for k,v in (pair.split('=',1) for pair in raw[:-1].split(','))})
    return Tag(TAG_COMPOUND,fields)


class Editor(MapReader):
    def __init__(self,world,directory='region'):
        super().__init__(world,directory);self.before={};self.edited_sections=set();self.allowed=set();self.be_changed=set();self.native_changed=set()
    def touch(self,x,z):
        root=self.chunk(x,z);key=x>>4,z>>4
        if root is None:raise ValueError('Repair may not generate a new terrain chunk')
        if key not in self.before:self.before[key]=copy.deepcopy(root)
        return root
    def set_state(self,pos,key):
        x,y,z=pos;self.touch(x,z);palette,indices=self.section(x,y,z)
        if key not in palette:palette.append(key)
        indices[((y&15)<<8)|((z&15)<<4)|(x&15)]=palette.index(key);self.edited_sections.add((x>>4,y>>4,z>>4));self.allowed.add(tuple(pos))
    def set_entity(self,pos,value):
        x,y,z=pos;root=self.touch(x,z);rows=root['block_entities'].value
        found=next((i for i,r in enumerate(rows) if tuple(compound(r)[k].value for k in 'xyz')==tuple(pos)),None)
        if value is None:
            if found is not None:rows.pop(found)
        else:
            new=Tag(TAG_COMPOUND,value)
            if found is None:rows.append(new)
            else:rows[found]=new
            root['block_entities']=Tag(TAG_LIST,rows,TAG_COMPOUND)
        self.be_changed.add(tuple(pos));self.allowed.add(tuple(pos))
    def set_visual(self,pos,index,catalog_sha):
        x,y,z=pos;root=self.touch(x,z);self.native_changed.add(tuple(pos));self.allowed.add(tuple(pos))
        if 'DreamwalkerVisuals' not in root:
            assert index<0,'New native tables must come from a reviewed schema template';return
        native=compound(root['DreamwalkerVisuals']);native['Catalog']=Tag(TAG_STRING,catalog_sha);rows=native['Sections'].value
        row=next((s for s in rows if compound(s)['Y'].value==y>>4),None)
        if row is None:
            if index<0:return
            row=Tag(TAG_COMPOUND,{'Y':Tag(TAG_BYTE,y>>4),'Entries':Tag(TAG_INT_ARRAY,[])});rows.append(row)
        fields=compound(row);entries={v&4095:(v&0xffffffff)>>12 for v in fields['Entries'].value};local=((y&15)<<8)|((z&15)<<4)|(x&15)
        if index<0:entries.pop(local,None)
        else:entries[local]=index
        fields['Entries']=Tag(TAG_INT_ARRAY,[(v<<12)|k for k,v in sorted(entries.items())])
    def flush(self):
        for cx,sy,cz in self.edited_sections:
            root=self.chunks[cx,cz];section=next(s for s in root['sections'].value if compound(s)['Y'].value==sy);names,indices=self.sections[cx,sy,cz]
            compound(section)['block_states']=Tag(TAG_COMPOUND,{'palette':Tag(TAG_LIST,[state_tag(k) for k in names],TAG_COMPOUND),'data':Tag(TAG_LONG_ARRAY,pack_palette_indices(indices,len(names)))})
    def save(self,output):
        self.flush();changed_regions={}
        for (cx,cz),before in self.before.items():
            region=self.regions[cx>>5,cz>>5];chunk=region.get_chunk(cx&31,cz&31);region.set_chunk(cx&31,cz&31,NbtFile('',Tag(TAG_COMPOUND,self.chunks[cx,cz])),timestamp=chunk.timestamp);changed_regions[cx>>5,cz>>5]=region
        for (rx,rz),region in changed_regions.items():region.save(Path(output)/self.directory/f'r.{rx}.{rz}.mca')
        return len(changed_regions)
