"""Close the outer boundary of disjoint, alpha-clipped north-facing door rectangles."""
import copy

EPS=1e-6


def subtract(a,b,holes):
    spans=[(a,b)]
    for lo,hi in holes:
        result=[]
        for x,y in spans:
            if hi<=x+EPS or lo>=y-EPS:result.append((x,y))
            else:
                if lo>x+EPS:result.append((x,min(lo,y)))
                if hi<y-EPS:result.append((max(hi,x),y))
        spans=result
    return spans


def mirrored(face):
    out=copy.deepcopy(face);u0,v0,u1,v1=out['uv'];out['uv']=[u1,v0,u0,v1]
    return out


AXES={'north':(0,-1,1,-1,2),'south':(0,1,1,-1,2),
      'east':(2,-1,1,-1,0),'west':(2,1,1,-1,0),
      'up':(0,1,2,1,1),'down':(0,1,2,-1,1)}


def clip_face(element,direction,bounds):
    out=copy.deepcopy(element);face=out['faces'][direction]
    rotation=face.get('rotation',0)
    assert rotation in (0,90,180,270),'Unsupported UV rotation'
    ua,us,va,vs,_=AXES[direction];uv=face['uv'];new=[]
    for axis,sign,start,end in [(ua,us,uv[0],uv[2]),(va,vs,uv[1],uv[3])]:
        low,high=element['from'][axis],element['to'][axis]
        a,b=(bounds[0][axis],bounds[1][axis]) if sign>0 else (bounds[1][axis],bounds[0][axis])
        origin=low if sign>0 else high
        length=(high-low)*sign
        new.append(((a-origin)/length,(b-origin)/length))
    out['from'],out['to']=bounds
    sa,sb=new[0];ta,tb=new[1]
    ua,ub,va,vb={0:(sa,sb,ta,tb),90:(ta,tb,1-sb,1-sa),
                 180:(1-sb,1-sa,1-tb,1-ta),270:(1-tb,1-ta,sa,sb)}[rotation]
    face['uv']=[uv[0]+(uv[2]-uv[0])*ua,uv[1]+(uv[3]-uv[1])*va,
                uv[0]+(uv[2]-uv[0])*ub,uv[1]+(uv[3]-uv[1])*vb]
    return out


def old_side_remainders(elements,caps):
    """Keep original side artwork outside new caps, avoiding coplanar UV fighting."""
    kept=[]
    for element in elements:
        assert len(element['faces'])==1
        direction=next(iter(element['faces']))
        if direction in ['north','south']:continue
        ua,_,va,_,normal=AXES[direction];pieces=[element]
        for cap in caps:
            if direction not in cap['faces'] or abs(cap['from'][normal]-element['from'][normal])>EPS:continue
            next_pieces=[]
            for piece in pieces:
                lo=piece['from'];hi=piece['to'];a=max(lo[ua],cap['from'][ua]);b=min(hi[ua],cap['to'][ua]);c=max(lo[va],cap['from'][va]);d=min(hi[va],cap['to'][va])
                if b-a<=EPS or d-c<=EPS:next_pieces.append(piece);continue
                for x0,y0,x1,y1 in [(lo[ua],lo[va],a,hi[va]),(b,lo[va],hi[ua],hi[va]),(a,lo[va],b,c),(a,d,b,hi[va])]:
                    if x1-x0<=EPS or y1-y0<=EPS:continue
                    start=lo.copy();end=hi.copy();start[ua]=x0;end[ua]=x1;start[va]=y0;end[va]=y1
                    next_pieces.append(clip_face(piece,direction,[start,end]))
            pieces=next_pieces
        kept.extend(pieces)
    return kept


def rebuild(model,depths,mirror_back=True):
    before=copy.deepcopy(model)
    fronts=[e for e in before['elements'] if 'north' in e.get('faces',{})]
    assert fronts and all(len(e['faces'])==1 and abs(e['to'][2]-e['from'][2])<EPS for e in fronts)
    assert all(not e['faces']['north'].get('rotation',0) for e in fronts)
    result=copy.deepcopy(fronts) if mirror_back else [copy.deepcopy(e) for e in before['elements']
            if set(e.get('faces',{})) & {'north','south'}]
    caps=[]
    for e in fronts:
        x0,y0,z=e['from'];x1,y1,_=e['to'];face=e['faces']['north']
        depth=depths[round(z,6)]
        if mirror_back:
            back=copy.deepcopy(e);back['from'][2]+=depth;back['to'][2]+=depth
            back['faces']={'south':mirrored(face)};result.append(back)
        u0,v0,u1,v1=face['uv']
        def u(x):return u0+(u1-u0)*(x1-x)/(x1-x0)
        def v(y):return v0+(v1-v0)*(y1-y)/(y1-y0)
        neighbors=[q for q in fronts if q is not e and abs(q['from'][2]-z)<EPS]
        def emit(a,b,direction,uv):
            caps.append({'from':a,'to':b,'faces':{direction:{'texture':face['texture'],'uv':uv}}})
        for boundary,normal,other_side in [(x0,'west',1),(x1,'east',0)]:
            holes=[(q['from'][1],q['to'][1]) for q in neighbors
                   if abs((q['to'][0] if other_side else q['from'][0])-boundary)<EPS]
            inside=boundary+(1 if normal=='west' else -1)*min(.5,(x1-x0)/2)
            strip=abs((u1-u0)/(x1-x0))*min(.4,(x1-x0)*.4)
            for a,b in subtract(y0,y1,holes):
                emit([boundary,a,z],[boundary,b,z+depth],normal,[u(inside)-strip,v(b),u(inside)+strip,v(a)])
        for boundary,normal,other_side in [(y0,'down',1),(y1,'up',0)]:
            holes=[(q['from'][0],q['to'][0]) for q in neighbors
                   if abs((q['to'][1] if other_side else q['from'][1])-boundary)<EPS]
            inside=boundary+(1 if normal=='down' else -1)*min(.5,(y1-y0)/2)
            strip=abs((v1-v0)/(y1-y0))*min(.4,(y1-y0)*.4)
            for a,b in subtract(x0,x1,holes):
                emit([a,boundary,z],[b,boundary,z+depth],normal,[u(b),v(inside)-strip,u(a),v(inside)+strip])
    assert len(caps)<=512,'Refusing an unbounded model surface expansion'
    old_sides=old_side_remainders(before['elements'],caps)
    model['elements']=result+caps+old_sides
    # The original north geometry and UV rectangles stay exact and in order.
    assert [e for e in model['elements'] if 'north' in e['faces']]==fronts
    for e in model['elements']:
        assert all(a<=b+EPS for a,b in zip(e['from'],e['to']))
    return dict(fronts=len(fronts),newEdgeFaces=len(caps),
                beforeFaces=sum(len(e.get('faces',{})) for e in before['elements']),
                afterFaces=sum(len(e.get('faces',{})) for e in model['elements']))
