"""Package a verified local checkpoint; inventory mode needs no game or full world copy."""
import argparse
import datetime
import json
import shutil
import subprocess
import zipfile
from pathlib import Path
from prepare_workspace import RUN, WORKSPACE, BASE, write, sha
from compare_performance import accepted_performance

EXCLUDED_DIRS = {'.git', '.gradle', '.local', '__pycache__', 'build', 'logs'}
EXCLUDED_SUFFIXES = {'.pyc', '.class', '.lock', '.tmp', '.log'}
EXTRA_EVIDENCE = [
    'task10-material-acceptance.json', 'task10-v18-all-rotations-visual-acceptance.json',
    'v18-unchanged-accepted-runtime.json', 'runtime-shape-plan-lamp-post-v18.json',
    'door-gallery-visual-review.json', 'task13-example-proof.json',
    'pre-shadow-task-acceptance.json', 'performance-comparison.json', 'performance-acceptance.json',
    'task13-dead-wrapper-proof.json', 'v20-byte-bound-change.json', 'v22-byte-bound-change.json',
    'bench-support-scope.json', 'bench-owned-collision-source-proof.json',
    'bench-surface-visual-review.json', 'bench-native-static-collision-audit.json',
    'bench-source-static-collision-audit.json', 'darkness-flat-lighting-proof.json',
    'AUDIT-20261029.txt', 'PLAN-20261029.txt', 'offline-repair-verification.json',
    'cleanup-receipt.json', 'historical-run-status-notes.json', 'performance-pair-decision.json',
    'test-launch-fix-verification.json', 'microstutter-investigation.json',
    'MICROSTUTTER-REPORT-20261029.txt', 'SHADOWS-PLAN-20261029.txt',
]


def guard():
    subprocess.run(['pwsh', '-NoProfile', '-File',
        r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],
        cwd=WORKSPACE, check=True, stdout=subprocess.DEVNULL)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def source_files(source):
    # Prune excluded trees before traversal; never include a cache or follow a link.
    import os
    for directory, dirs, names in os.walk(source, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDED_DIRS
                         and not (Path(directory)/d).is_symlink())
        for name in sorted(names):
            path = Path(directory)/name
            if path.suffix not in EXCLUDED_SUFFIXES and not path.is_symlink():
                yield path


def evidence_files(tasks, qa_run, world):
    files = {}

    def add(path, target, expected=None):
        path = path.resolve()
        assert path.is_relative_to(RUN.resolve()) and path.is_file(), path
        if expected is not None:
            assert sha(path) == expected, path
        assert target not in files or files[target] == path, target
        files[target] = path

    def run_files(folder, prefix):
        for name in ['acceptance.json', 'receipt.json', 'plan.json', 'client/evidence/qa.json']:
            if (folder/name).is_file():
                add(folder/name, prefix+'/'+name)
        screenshots = folder/'client/screenshots'
        if screenshots.is_dir():
            for path in sorted(screenshots.glob('*.png')):
                add(path, prefix+'/screenshots/'+path.name)

    add(qa_run/'acceptance.json', 'game-acceptance.json')
    add(qa_run/'client/evidence/qa.json', 'qa.json')
    add(world.parent/'prelight-import-receipt.json', 'prelight-import-receipt.json')
    if (world.parent/'heightmap-import-receipt.json').is_file():
        heightmap_record = world.parent/'heightmap-import-receipt.json'
        add(heightmap_record, 'heightmap-import-receipt.json')
        heightmaps = read(heightmap_record)
        heightmap_run = RUN/'runs'/heightmaps['sourceRun']
        add(heightmap_run/'client/evidence/qa.json', 'heightmap-source/qa.json', heightmaps['sourceQaSha256'])
        add(heightmap_run/'receipt.json', 'heightmap-source/receipt.json', heightmaps['sourceReceiptSha256'])
        add(heightmap_run/'plan.json', 'heightmap-source/plan.json')
    for name in EXTRA_EVIDENCE:
        if (RUN/name).is_file():
            add(RUN/name, name)
    for item in tasks['evidence']:
        accepted = Path(item['path'])
        if accepted.parent.parent == RUN/'runs':
            prefix = 'accepted/'+accepted.parent.name
            add(accepted, prefix+'/'+accepted.name, item['sha256'])
            run_files(accepted.parent, prefix)
        else:
            add(accepted, accepted.name, item['sha256'])
    closure_path = RUN/'bench-scope-closure.json'
    if closure_path.is_file():
        closure = read(closure_path)
        add(closure_path, closure_path.name)
        bench = RUN/'runs'/closure['run']
        add(bench/'client/evidence/qa.json', 'bench-closed-scope/qa.json', closure['clientRecordSha256'])
        add(Path(closure['screenshot']), 'bench-closed-scope/'+Path(closure['screenshot']).name,
            closure['screenshotSha256'])
        run_files(bench, 'bench-closed-scope')
    contacts_path = RUN/'bench-server-contact-acceptance.json'
    if contacts_path.is_file():
        contacts = read(contacts_path)
        add(contacts_path, contacts_path.name)
        add(RUN/'runs'/contacts['run']/'client/evidence/qa.json',
            'all-bench-server-contact-qa.json', contacts['sourceQaSha256'])
    micro = RUN/'microstutter-investigation.json'
    if micro.is_file():
        investigation = read(micro)
        for item in investigation.get('evidence', []):
            add(Path(item['path']), 'microstutter/'+item['target'], item['sha256'])
        for label in investigation.get('probeRuns', []):
            assert label.replace('-', '').isalnum()
            run_files(RUN/'runs'/label, 'microstutter/probes/'+label)
    performance = read(RUN/'performance-comparison.json')
    for label in [performance['baseline'], performance['candidate']]:
        run_files(RUN/'runs'/label, 'performance/'+label)
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label')
    parser.add_argument('--qa', required=True)
    parser.add_argument('--world', required=True, type=Path)
    parser.add_argument('--candidate', required=True, type=Path)
    parser.add_argument('--inventory-only', action='store_true')
    args = parser.parse_args()
    guard()
    assert args.qa.replace('-', '').isalnum()
    world, candidate = args.world.resolve(), args.candidate.resolve()
    assert world.is_relative_to(RUN.resolve()) and candidate.is_relative_to(RUN.resolve())
    qa_run = RUN/'runs'/args.qa
    tasks = read(RUN/'pre-shadow-task-acceptance.json')
    source = Path(__file__).resolve().parent
    sources = list(source_files(source))
    common = source.parent/'world_io.py'
    assert common.is_file() and not common.is_symlink()
    sources.append(common)
    evidence = evidence_files(tasks, qa_run, world)
    inventory = dict(sources=[str(p.relative_to(WORKSPACE)) for p in sources],
        evidence=[dict(path=name, source=str(path), sha256=sha(path))
                  for name, path in sorted(evidence.items())])
    if args.inventory_only:
        write(RUN/'checkpoint-inventory.json', inventory)
        print('Inventory only:', len(sources), 'source files;', len(evidence), 'evidence files')
        return
    assert args.label and args.label.replace('-', '').isalnum()
    expected = sha(candidate)
    assert read(qa_run/'acceptance.json')['status'] == 'PASS'
    assert read(qa_run/'receipt.json')['candidateSha256'] == expected
    light = read(world.parent/'prelight-import-receipt.json')
    assert light['status'] == 'PERSISTED_LIGHTING_ONLY_GATE_PASS'
    assert Path(light['outputWorld']).resolve() == world
    assert accepted_performance(expected, world)
    assert tasks['status'] == 'PRE_SHADOW_TASKS_ACCEPTED' and tasks['candidateSha256'] == expected
    assert Path(tasks['world']).resolve() == world
    folder = RUN/'checkpoints'/args.label
    folder.mkdir(parents=True, exist_ok=False)
    shutil.copy2(candidate, folder/'mod.jar')
    baseline = next(BASE.glob('*.jar'))
    shutil.copy2(baseline, folder/'baseline-mod.jar')
    guard()
    shutil.copytree(world, folder/'world/bloodborne', ignore=shutil.ignore_patterns('session.lock'))
    shutil.copy2(RUN/'input/dw-fix.zip', folder/'request.zip')
    with zipfile.ZipFile(folder/'repair-sources.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sources:
            archive.write(path, path.relative_to(WORKSPACE).as_posix())
    guard()
    with zipfile.ZipFile(folder/'native-overlay.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        overlay = RUN/'native-overlay'
        for path in sorted(overlay.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(overlay).as_posix())
    for name, path in evidence.items():
        output = folder/'evidence'/name
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, output)
        assert sha(output) == sha(path)
    write(folder/'evidence-inventory.json', inventory)
    guard()
    for name in ['repair-sources.zip', 'native-overlay.zip', 'request.zip']:
        with zipfile.ZipFile(folder/name) as archive:
            assert archive.testzip() is None, name
    files = [dict(path=str(p.relative_to(folder)), size=p.stat().st_size, sha256=sha(p))
             for p in sorted(folder.rglob('*')) if p.is_file()]
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKSPACE, text=True).strip()
    write(folder/'checkpoint.json', dict(
        status='COMPLETE_LOCAL_CHECKPOINT_BEFORE_GLOBAL_ANGULAR_SHADOW_WORK',
        createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        repositoryBaseCommit=commit, modSha256=expected, baselineSha256=sha(baseline),
        preparedWorld=str(world), sourceRoot=str(source), githubModified=False, files=files))
    print('Complete local checkpoint:', folder)


if __name__ == '__main__':
    main()
