"""Copy only verified Minecraft lighting/heightmaps from a completed disposable run."""
import argparse
import collections
import copy
import json
from pathlib import Path
import shutil
from prepare_workspace import RUN,write,sha
from map_reader import MapReader
from remove_inert_cells import block_table
from world_io import RegionFile,compound,Tag,TAG_BYTE,TAG_COMPOUND,lighting_cache_errors

ROOT_LIGHT=('isLightOn','starlight.light_version')
SECTION_LIGHT=('BlockLight','SkyLight','starlight.blocklight_state','starlight.skylight_state')


def normalized(root):
    root=copy.deepcopy(root)
    for key in (*ROOT_LIGHT,'Heightmaps'):root.pop(key,None)
    sections=[]
    for tag in root['sections'].value:
        s=compound(tag)
        for key in SECTION_LIGHT:s.pop(key,None)
        if set(s)!={'Y'}:sections.append(tag)
    root['sections'].value=sections
    return root


def same_blocks(a,b):
    # Exact NBT equality already proves identical block palettes and packed indices.
    # The semantic fallback still handles Minecraft's palette compaction/reordering.
    raw=lambda root:{compound(section)['Y'].value:compound(section)['block_states'] for section in root['sections'].value if 'block_states' in compound(section)}
    if raw(a)==raw(b):return True
    aa,bb=block_table(a),block_table(b)
    for sy in aa.keys()|bb.keys():
        pa,ia=aa.get(sy,(['minecraft:air'],[0]*4096));pb,ib=bb.get(sy,(['minecraft:air'],[0]*4096))
        if any(pa[ia[i]]!=pb[ib[i]] for i in range(4096)):return False
    return True


def prepare_heightmaps(run_name, source_world, output_world):
    """Reuse engine heightmaps only where every block and native visual still matches."""
    from fast_block_compare import same_blocks as exact_blocks
    from world_io import TAG_LONG_ARRAY
    source_world, output_world = source_world.resolve(), output_world.resolve()
    assert source_world.is_relative_to(RUN.resolve()) and output_world.is_relative_to(RUN.resolve())
    assert not output_world.exists()
    run = RUN/'runs'/run_name
    receipt = json.loads((run/'receipt.json').read_text(encoding='utf-8'))
    report = json.loads((run/'client/evidence/qa.json').read_text(encoding='utf-8'))
    assert receipt['exitCode'] == 0 and report['status'] == 'PASS' and report['saved']
    assert sha(Path(receipt['candidate'])) == receipt['candidateSha256']
    assert Path(receipt['world']).resolve() == source_world
    scope = json.loads((RUN/'prelight-targets-bench-v21.json').read_text(encoding='utf-8'))
    directories = {'minecraft:overworld':'region',
        'bloodborne_dw:bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}
    groups = collections.defaultdict(list)
    for row in scope['prelightChunks']:
        relative = f"{directories[row['dimension']]}/r.{row['x']>>5}.{row['z']>>5}.mca"
        groups[relative].append((row['x'], row['z']))
    prepared, skipped, already_prepared = {}, [], []
    required = {'MOTION_BLOCKING', 'MOTION_BLOCKING_NO_LEAVES', 'OCEAN_FLOOR', 'WORLD_SURFACE'}
    for relative, positions in groups.items():
        before = RegionFile.open(source_world/relative)
        engine = RegionFile.open(run/'client/saves/city'/relative)
        changes = []
        for cx, cz in positions:
            original = before.get_chunk(cx&31,cz&31)
            target = compound(original.nbt().root)
            saved = compound(engine.get_chunk(cx&31,cz&31).nbt().root)
            maps = compound(saved['Heightmaps'])
            reason = None
            if not required.issubset(maps): reason = 'Engine did not load/rebuild this chunk'
            elif not exact_blocks(target,saved): reason = 'Runtime block states differ; do not transfer'
            elif target.get('DreamwalkerVisuals') != saved.get('DreamwalkerVisuals'):
                reason = 'Runtime native visuals differ; do not transfer'
            if reason:
                skipped.append(dict(region=relative,x=cx,z=cz,reason=reason))
                continue
            if target.get('Heightmaps') == saved['Heightmaps']:
                already_prepared.append(dict(region=relative,x=cx,z=cz))
                continue
            assert all(v.type == TAG_LONG_ARRAY and len(v.value) == 37 for v in maps.values())
            changes.append((cx,cz,copy.deepcopy(saved['Heightmaps']),original.timestamp))
        prepared[relative] = changes
    assert any(prepared.values()), 'No eligible engine heightmaps'
    shutil.copytree(source_world,output_world,ignore=shutil.ignore_patterns('session.lock'))
    results = []
    for relative, changes in prepared.items():
        if not changes: continue
        before = RegionFile.open(source_world/relative)
        edited = RegionFile.open(output_world/relative)
        allowed = set()
        for cx,cz,maps,timestamp in changes:
            nbt = edited.get_chunk(cx&31,cz&31).nbt()
            target = compound(nbt.root)
            original = copy.deepcopy(target)
            target['Heightmaps'] = maps
            assert {k:v for k,v in original.items() if k!='Heightmaps'} == {k:v for k,v in target.items() if k!='Heightmaps'}
            edited.set_chunk(cx&31,cz&31,nbt,timestamp=timestamp)
            allowed.add((cx&31,cz&31))
        edited.save(output_world/relative)
        persisted = RegionFile.open(output_world/relative)
        for chunk in before.chunks():
            saved = persisted.get_chunk(chunk.x,chunk.z)
            if (chunk.x,chunk.z) not in allowed:
                assert chunk.compressed_payload == saved.compressed_payload and chunk.timestamp == saved.timestamp
            else:
                a,b = compound(chunk.nbt().root),compound(saved.nbt().root)
                assert {k:v for k,v in a.items() if k!='Heightmaps'} == {k:v for k,v in b.items() if k!='Heightmaps'}
                assert required.issubset(compound(b['Heightmaps'])) and not lighting_cache_errors(b)
        results.append(dict(path=relative,chunks=len(changes),sha256=sha(output_world/relative)))
    result = dict(status='PERSISTED_HEIGHTMAP_ONLY_GATE_PASS', sourceRun=run_name,
        candidateSha256=receipt['candidateSha256'], inputWorld=str(source_world), outputWorld=str(output_world),
        chunks=sum(len(v) for v in prepared.values()), skipped=skipped, alreadyPrepared=already_prepared, regions=results,
        importedChunks=[dict(dimension='minecraft:overworld' if relative.startswith('region/') else 'bloodborne_dw:bloodborne_old',x=cx,z=cz)
            for relative,rows in prepared.items() for cx,cz,maps,timestamp in rows],
        sourceQaSha256=sha(run/'client/evidence/qa.json'), sourceReceiptSha256=sha(run/'receipt.json'),
        allOtherChunkFieldsAndUntouchedCompressedPayloadsIdentical=True)
    write(output_world.parent/'heightmap-import-receipt.json',result)
    light = json.loads((source_world.parent/'prelight-import-receipt.json').read_text(encoding='utf-8'))
    light.update(outputWorld=str(output_world),heightmapCacheSourceWorld=str(source_world),
        heightmapCacheReceipt='heightmap-import-receipt.json')
    for row in light['regions']:row['sha256']=sha(output_world/row['path'])
    write(output_world.parent/'prelight-import-receipt.json',light)
    print(json.dumps({k:result[k] for k in ['status','chunks','sourceRun']},indent=2))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('run');parser.add_argument('--scope',choices=['scene01','floor'],default='scene01')
    parser.add_argument('--apply',action='store_true')
    parser.add_argument('--heightmaps-only',action='store_true')
    parser.add_argument('--input-world',type=Path)
    parser.add_argument('--output-world',type=Path)
    args=parser.parse_args();assert args.run.replace('-','').isalnum()
    if args.heightmaps_only:
        assert args.input_world and args.output_world
        return prepare_heightmaps(args.run,args.input_world,args.output_world)
    selected={}
    if args.scope=='scene01':
        cells=json.loads((RUN/'task01-trim-plan-final.json').read_text(encoding='utf-8'))['cells']
        selected['region']={(x>>4,z>>4) for x,y,z,state in cells}
    else:
        from darkness_floor import footprint
        for directory,city in json.loads((RUN/'census.json').read_text(encoding='utf-8')).items():selected[directory]=set(footprint(city['hull']))
    report=RUN/f'lighting-import-{args.scope}-{args.run}.json';assert not report.exists()
    checkpoint=RUN/f'checkpoints/lighting-{args.scope}-{args.run}'
    if args.apply:checkpoint.mkdir(parents=True,exist_ok=False)
    results=[];total=0
    for directory,chunks in selected.items():
        source=MapReader(RUN/f'runs/{args.run}/client/saves/city',directory)
        groups=collections.defaultdict(list)
        for cx,cz in chunks:groups[cx>>5,cz>>5].append((cx,cz))
        for (rx,rz),positions in sorted(groups.items()):
            path=RUN/'world/bloodborne'/directory/f'r.{rx}.{rz}.mca';region=RegionFile.open(path)
            before_bytes=path.read_bytes();prepared=[]
            for cx,cz in sorted(positions):
                chunk=region.get_chunk(cx&31,cz&31);nbt=chunk.nbt();target=compound(nbt.root);original=copy.deepcopy(target)
                saved=source.chunk(cx*16,cz*16)
                assert saved and same_blocks(target,saved),f'Blocks differ at {directory}/{cx},{cz}'
                assert saved.get('isLightOn') and saved['isLightOn'].value==1 and not lighting_cache_errors(saved)
                assert saved.get('Heightmaps') and compound(saved['Heightmaps'])
                for key in ROOT_LIGHT:
                    target.pop(key,None)
                    if key in saved:target[key]=copy.deepcopy(saved[key])
                target['Heightmaps']=copy.deepcopy(saved['Heightmaps'])
                sections={compound(s)['Y'].value:s for s in target['sections'].value}
                for tag in target['sections'].value:
                    for key in SECTION_LIGHT:compound(tag).pop(key,None)
                for tag in saved['sections'].value:
                    data=compound(tag);y=data['Y'].value
                    if not any(key in data for key in SECTION_LIGHT):continue
                    if y not in sections:
                        sections[y]=Tag(TAG_COMPOUND,{'Y':Tag(TAG_BYTE,y)});target['sections'].value.append(sections[y])
                    for key in SECTION_LIGHT:
                        if key in data:compound(sections[y])[key]=copy.deepcopy(data[key])
                assert normalized(original)==normalized(target) and same_blocks(original,target)
                assert not lighting_cache_errors(target)
                prepared.append((cx,cz,nbt,chunk.timestamp))
            if args.apply:
                backup=checkpoint/directory/path.name;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(before_bytes)
                for cx,cz,nbt,timestamp in prepared:region.set_chunk(cx&31,cz&31,nbt,timestamp=timestamp)
                region.save(path);saved_region=RegionFile.open(path);old_region=RegionFile(before_bytes)
                allowed={(cx&31,cz&31) for cx,cz in positions}
                for old in old_region.chunks():
                    new=saved_region.get_chunk(old.x,old.z)
                    if (old.x,old.z) in allowed:
                        a,b=compound(old.nbt().root),compound(new.nbt().root)
                        assert normalized(a)==normalized(b) and same_blocks(a,b) and not lighting_cache_errors(b)
                    else:assert old.compressed_payload==new.compressed_payload and old.timestamp==new.timestamp
            total+=len(prepared);results.append(dict(path=str(path),chunks=len(prepared),sha256=sha(path)))
    result=dict(status='APPLIED_VERIFIED' if args.apply else 'PREFLIGHT_PASS',chunks=total,regions=results,
                sourceRun=args.run,blocksOrOwnershipChanged=False,scope=args.scope)
    if args.apply:write(report,result)
    print(json.dumps(dict(status=result['status'],chunks=total,regions=len(results)),indent=2))


if __name__=='__main__':main()
