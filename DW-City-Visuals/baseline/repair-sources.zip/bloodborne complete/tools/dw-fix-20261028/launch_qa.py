"""Launch the intermediary game and the unchanged current client mod set on a copy."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import uuid

from prepare_workspace import RUN, WORKSPACE, sha, write


def options_text(plan):
    # Minecraft 1.20.1 rejects 4; never rely on an implicit fallback.
    simulation = plan.get('simulationDistance', 12)
    if type(simulation) is not int or not 5 <= simulation <= 32:
        raise ValueError('simulationDistance must be an integer from 5 to 32')
    return (f'renderDistance:{int(plan.get("renderDistance",8))}\n'
            f'simulationDistance:{simulation}\n'
            f'maxFps:{int(plan.get("maxFps",60))}\n'
            'enableVsync:false\npauseOnLostFocus:false\nfullscreen:false\n'
            'gamma:0.5\nguiScale:2\nonboardAccessibility:false\n')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('label')
    parser.add_argument('--plan',required=True,type=Path)
    parser.add_argument('--candidate',type=Path,default=RUN/'candidates/dreamwalker-bb-visual4-rc3-dwfix.1.jar')
    parser.add_argument('--world',type=Path,default=RUN/'world/bloodborne')
    parser.add_argument('--timeout',type=int,default=1200)
    parser.add_argument('--qa',type=Path)
    parser.add_argument('--profile',action='store_true',help='Record bounded JFR diagnostics for this run')
    args=parser.parse_args()
    assert args.label.replace('-','').isalnum()
    plan=json.loads(args.plan.read_text(encoding='utf-8'))
    plan.setdefault('simulationDistance',12)
    options=options_text(plan)
    runtime=json.loads((RUN/'runtime/runtime.json').read_text(encoding='utf-8'))
    folder=RUN/'runs'/args.label
    folder.mkdir(parents=True,exist_ok=False)
    game=folder/'client'
    (game/'mods').mkdir(parents=True)
    (game/'saves').mkdir()
    for mod in (WORKSPACE/'.local/modpacks/client-server-20261028/client_mods').glob('*.jar'):
        if not mod.name.startswith('dreamwalker-bb-'):
            shutil.copy2(mod,game/'mods'/mod.name)
    shutil.copy2(args.candidate,game/'mods/dreamwalker-candidate.jar')
    qa=args.qa if args.qa else RUN/'qa-build/libs/dw-archive-repair-qa-1.jar'
    shutil.copy2(qa,game/'mods/dw-repair-qa.jar')
    shutil.copytree(args.world,game/'saves/city',ignore=shutil.ignore_patterns('session.lock'))
    plan['output']=str(game/'evidence')
    write(folder/'plan.json',plan)
    (game/'options.txt').write_text(options,encoding='utf-8')
    (game/'config').mkdir(exist_ok=True)
    (game/'config/iris.properties').write_text('enableShaders=false\ndisableUpdateMessage=true\n',encoding='utf-8')
    username='DWArchiveQA'
    identifier=uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+username).encode()).digest(),version=3)
    arguments=['-Xms128M',f'-Xmx{int(plan.get("heapGb",6))}G','-Dfabric.modsFolder='+str(game/'mods'),
        '-Ddwfix.qa='+str(folder/'plan.json'),'-Djava.library.path='+runtime['natives'],
        '-Dorg.lwjgl.librarypath='+runtime['natives'],'-cp',os.pathsep.join(runtime['classpath']),
        runtime['javaMain'],'--username',username,'--version','1.20.1','--gameDir',str(game),
        '--assetsDir',runtime['assets'],'--assetIndex',str(runtime['assetIndex']),
        '--uuid',identifier.hex,'--accessToken','0','--userType','legacy','--versionType','release',
        '--width','1280','--height','720','--quickPlayPath',str(game/'quickplay.json'),'--quickPlaySingleplayer','city']
    if args.profile:
        arguments.insert(0,'-XX:StartFlightRecording=name=Smoothness,settings=profile,disk=true,dumponexit=true,maxsize=128m,filename='+str(folder/'profile.jfr'))
    argfile=game/'launch.args'
    argfile.write_text('\n'.join('"'+a.replace('\\','\\\\').replace('"','\\"')+'"' for a in arguments),encoding='utf-8')
    receipt=dict(status='STARTING',candidate=str(args.candidate),candidateSha256=sha(args.candidate),
                 qaSha256=sha(qa),world=str(args.world),originalWorldModified=False,
                 simulationDistance=plan['simulationDistance'],profile=args.profile,
                 loader=runtime['loader'],clientMods='client-server-20261028/client_mods',
                 startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(folder/'receipt.json',receipt)
    java=WORKSPACE/'.local/tools/jdk-17/bin/java.exe'
    started=time.monotonic()
    proc=None
    try:
        with (game/'console.log').open('w',encoding='utf-8') as log:
            proc=subprocess.Popen([str(java),'@'+str(argfile)],cwd=game,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            write(folder/'process.json',dict(pid=proc.pid,owned=True))
            while proc.poll() is None:
                if time.monotonic()-started>args.timeout:
                    raise TimeoutError('QA process exceeded its deadline')
                time.sleep(2)
        report=json.loads((game/'evidence/qa.json').read_text(encoding='utf-8')) if (game/'evidence/qa.json').exists() else None
        receipt.update(exitCode=proc.returncode,seconds=time.monotonic()-started,
                       status='DRIVER_COMPLETED_REQUIRES_ACCEPTANCE' if proc.returncode==0 and report and report['status']=='PASS' else 'FAIL')
        print(json.dumps(receipt,indent=2),flush=True)
    except BaseException as error:
        receipt.update(status='TIMEOUT' if isinstance(error,TimeoutError) else 'INTERRUPTED_OR_ERROR',
                       error=repr(error),seconds=time.monotonic()-started)
        raise
    finally:
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=15)
            except subprocess.TimeoutExpired: proc.kill();proc.wait()
        receipt['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        if proc is not None:receipt['exitCode']=proc.returncode
        write(folder/'receipt.json',receipt)


if __name__=='__main__':main()
