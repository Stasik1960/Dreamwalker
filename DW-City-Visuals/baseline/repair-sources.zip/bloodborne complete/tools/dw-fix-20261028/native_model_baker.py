"""Bounded source JSON face baking and convex clipping for append-only native data.

UV orientation is recovered by learn_native_uv.py from the pinned real bake.
The vertex convention and rotation follow Minecraft 1.20.1 ModelElementTexture.
"""
from dataclasses import dataclass
import itertools,json,math,struct
from pathlib import Path
import numpy as np
from discover_native_windows import rotation,FACE,PIVOT

CONVENTIONS=json.loads((Path(__file__).resolve().parent/'data/native-uv-conventions.json').read_text(encoding='utf-8'))
SHRINK=CONVENTIONS['shrink']
NORMALS=[np.array(v) for v in [[0,-1,0],[0,1,0],[0,0,-1],[0,0,1],[-1,0,0],[1,0,0]]]


@dataclass
class Quad:
    sprite:str
    layer:str
    flags:int
    vertices:np.ndarray
    normal:np.ndarray
    element:int


def pack_normal(n):return sum((math.floor(float(v)*127+.5)&255)<<(8*i) for i,v in enumerate(n))


def default_uv(face,lo,hi):
    x,y,z=lo;X,Y,Z=hi
    return dict(down=[x,16-Z,X,16-z],up=[x,z,X,Z],north=[16-X,16-Y,16-x,16-y],south=[x,16-Y,X,16-y],west=[z,16-Y,Z,16-y],east=[16-Z,16-Y,16-z,16-y])[face]


def bake(model,offset=(0,16,0),yaw=0,layer='translucent',sprite_layers=None):
    result=[];root=rotation(-yaw*45);sprite_layers=sprite_layers or {}
    for ei,e in enumerate(model['elements']):
        lo=np.array(e['from'],float);hi=np.array(e['to'],float)
        er=e.get('rotation',{});angle=er.get('angle',0)
        axis=er.get('axis','y');local=rotation(angle)
        if angle and axis!='y':
            a=math.radians(angle);co,si=math.cos(a),math.sin(a)
            if axis=='x':local=np.array([[1,0,0],[0,co,-si],[0,si,co]])
            elif axis=='z':local=np.array([[co,-si,0],[si,co,0],[0,0,1]])
            else:raise AssertionError('Unknown element rotation axis')
        scale=np.ones(3)
        if angle and er.get('rescale',False):
            scale[:]=1/math.cos(math.radians(angle));scale['xyz'.index(axis)]=1
        origin=np.array(er.get('origin',[0,0,0]))
        for face,f in e.get('faces',{}).items():
            axis,side,sign=FACE[face];axes=[i for i in range(3) if i!=axis]
            if any(hi[a]-lo[a]<1e-10 for a in axes):continue
            points=[]
            for a,b in [(0,0),(1,0),(1,1),(0,1)]:
                point=lo.copy();point[axis]=(hi if side else lo)[axis]
                point[axes[0]]=(hi if a else lo)[axes[0]];point[axes[1]]=(hi if b else lo)[axes[1]];points.append(point)
            points=np.array(points);n=np.zeros(3);n[axis]=sign
            if np.dot(np.cross(points[1]-points[0],points[2]-points[0]),n)<0:points=points[[0,3,2,1]]
            relative=(points[:,axes]-lo[axes])/(hi[axes]-lo[axes])
            uv=np.column_stack((relative,np.ones(4)))@np.array(CONVENTIONS['faces'][face])
            for _ in range(f.get('rotation',0)//90):uv=np.column_stack((uv[:,1],1-uv[:,0]))
            corners=np.array(f.get('uv',default_uv(face,lo,hi))).reshape(2,2);uv=corners[0]+uv*(corners[1]-corners[0]);centre=np.mean(corners,axis=0);uv=centre+(uv-centre)*SHRINK
            position=(((points-origin)@local.T)*scale+origin+np.array(offset))/16
            position=(position-PIVOT)@root.T+PIVOT
            normal=root@local@n;normal=normal/np.linalg.norm(normal)
            sprite=f['texture']
            while sprite.startswith('#'):sprite=model['textures'][sprite[1:]]
            flags=(1 if e.get('shade',True) else 0)|(2 if model.get('ambientocclusion',True) else 0)
            result.append(Quad(sprite,sprite_layers.get(sprite,layer),flags,np.column_stack((position,uv)),normal,ei))
    return result


def clip(poly,axis,bound,greater):
    result=[]
    for a,b in zip(poly,np.roll(poly,-1,axis=0)):
        inside_a=a[axis]>=bound-1e-9 if greater else a[axis]<=bound+1e-9
        inside_b=b[axis]>=bound-1e-9 if greater else b[axis]<=bound+1e-9
        if inside_a:result.append(a)
        if inside_a!=inside_b:
            t=(bound-a[axis])/(b[axis]-a[axis]);v=a+t*(b-a);v[axis]=bound;result.append(v)
    if not result:return np.empty((0,5))
    cleaned=[]
    for value in result:
        if not cleaned or np.linalg.norm(value[:3]-cleaned[-1][:3])>1e-8:cleaned.append(value)
    if len(cleaned)>1 and np.linalg.norm(cleaned[-1][:3]-cleaned[0][:3])<1e-8:cleaned.pop()
    return np.array(cleaned)


def encode(quad,vertices,material):
    assert len(vertices)==4
    normal=quad.normal;face=max(range(6),key=lambda i:float(np.dot(normal,NORMALS[i])))
    data=bytearray(struct.pack('>ibbIB',material,-1,face,0xffffffff,quad.flags))
    packed=pack_normal(normal)
    for v in vertices:
        assert np.isfinite(v).all() and min(v[:3])>=-1e-6 and max(v[:3])<=1.000001
        data.extend(struct.pack('>5fIII',*[min(1,max(0,float(x))) for x in v[:3]],*map(float,v[3:]),0xffffffff,0,packed))
    assert len(data)==139;return bytes(data)


def cell_quads(quads,material_index):
    cells={}
    for q in quads:
        v=q.vertices;ranges=[]
        for axis in range(3):
            low,high=float(v[:,axis].min()),float(v[:,axis].max())
            if high-low<1e-8:
                value=(low+high)*.5;inside=value-(1e-7 if q.normal[axis]>0 else -1e-7);ranges.append(range(math.floor(inside),math.floor(inside)+1))
            else:ranges.append(range(math.floor(low+1e-8),math.ceil(high-1e-8)))
        material=material_index(q.sprite,q.layer)
        for cell in itertools.product(*ranges):
            polygon=v.copy()
            for axis in range(3):
                for greater,bound in [(True,cell[axis]),(False,cell[axis]+1)]:
                    if len(polygon)<3:break
                    polygon=clip(polygon,axis,bound,greater)
            if len(polygon)<3:continue
            area=sum(np.linalg.norm(np.cross(polygon[i,:3]-polygon[0,:3],polygon[i+1,:3]-polygon[0,:3]))*.5 for i in range(1,len(polygon)-1))
            if area<1e-10:continue
            polygon[:,:3]-=np.array(cell);bucket=cells.setdefault(cell,[]);i=1
            while i<len(polygon)-1:
                if i+2<len(polygon):vertices=polygon[[0,i,i+1,i+2]];i+=2
                else:vertices=polygon[[0,i,i+1,i+1]];i+=1
                bucket.append(encode(q,vertices,material))
    return cells
