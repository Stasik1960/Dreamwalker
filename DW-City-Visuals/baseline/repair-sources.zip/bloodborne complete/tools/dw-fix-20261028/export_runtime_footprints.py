"""Ask the actual registered mod runtime for every repaired lamp/post footprint; no world is opened."""
import argparse,collections,hashlib,json,os,shutil,subprocess,uuid
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write,sha
from map_reader import MapReader
from world_editor import compound,encode_nbt,NbtFile

DIRS={'overworld':'region','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--world',type=Path,required=True);args=p.parse_args();assert args.label.replace('-','').isalnum()
    source=args.world.resolve();assert source.is_relative_to(RUN.resolve());folder=RUN/'exports'/args.label;folder.mkdir(parents=True,exist_ok=False);game=folder/'client';(game/'mods').mkdir(parents=True)
    index=json.loads((RUN/'task11-lantern-owner-preflight.json').read_text(encoding='utf-8'));receipt=json.loads((source.parent/'migration-receipt.json').read_text(encoding='utf-8'));deferred={k for c in index['cells'] if c['nativeBase']>=0 for k in c['targets']}
    actors=[dict(dimension=o['dimension'],root=o['root']) for k,o in index['owners'].items() if o['registryId']=='bloodborne_dw:source_lantern' and k not in deferred];actors += [dict(dimension=o['dimension'],root=o['root']) for o in receipt['lamps']+receipt['installedPosts']];assert len(actors)==1287
    readers={d:MapReader(source,path) for d,path in DIRS.items()};rows=[]
    for actor in actors:
        dim=actor['dimension'];root=actor['root'];reader=readers[dim];be=reader.entity(*root);state=reader.state(*root);kind,_,props=state.partition('[');owner=compound(be['resident']);assert owner['id'].value==kind
        rows.append(dict(key=dim+'/'+','.join(map(str,root)),dimension=dim,root=root,id=kind,uuid=owner['uuid'].value,properties=dict(pair.split('=') for pair in props[:-1].split(',')),payloadNbtHex=encode_nbt(NbtFile('',be['payload'])).hex()))
    request=folder/'request.json';output=folder/'footprints.json';write(request,dict(world=str(source),candidateSha256=sha(args.candidate),output=str(output),actors=rows))
    for mod in (WORKSPACE/'.local/modpacks/client-server-20261028/client_mods').glob('*.jar'):
        if not mod.name.startswith('dreamwalker-bb-'):shutil.copy2(mod,game/'mods'/mod.name)
    shutil.copy2(args.candidate,game/'mods/dreamwalker-candidate.jar');qa=RUN/'qa-build/libs/dw-archive-repair-qa-1.jar';shutil.copy2(qa,game/'mods/dw-repair-qa.jar');runtime=json.loads((RUN/'runtime/runtime.json').read_text(encoding='utf-8'));username='DWArchiveQA';identity=uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+username).encode()).digest(),version=3)
    argv=['-Xms128M','-Xmx6G','-Dfabric.modsFolder='+str(game/'mods'),'-Ddwfix.exportFootprints='+str(request),'-Djava.library.path='+runtime['natives'],'-Dorg.lwjgl.librarypath='+runtime['natives'],'-cp',os.pathsep.join(runtime['classpath']),runtime['javaMain'],'--username',username,'--version','1.20.1','--gameDir',str(game),'--assetsDir',runtime['assets'],'--assetIndex',str(runtime['assetIndex']),'--uuid',identity.hex,'--accessToken','0','--userType','legacy','--versionType','release']
    argfile=game/'launch.args';argfile.write_text('\n'.join('"'+a.replace('\\','\\\\').replace('"','\\"')+'"' for a in argv),encoding='utf-8')
    with (game/'console.log').open('w',encoding='utf-8') as log:result=subprocess.run([str(WORKSPACE/'.local/tools/jdk-17/bin/java.exe'),'@'+str(argfile)],cwd=game,stdout=log,stderr=subprocess.STDOUT,timeout=780,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0,(result.returncode,game/'console.log');data=json.loads(output.read_text(encoding='utf-8'));assert data['status']=='RUNTIME_WORLDLESS_FOOTPRINT_EXPORT_PASS' and len(data['actors'])==len(rows)
    write(folder/'receipt.json',dict(status='PASS',world=str(source),candidateSha256=sha(args.candidate),qaSha256=sha(qa),actors=len(rows),worldOpened=False,outputSha256=sha(output)));print('Runtime footprint export PASS:',len(rows))

if __name__=='__main__':main()
