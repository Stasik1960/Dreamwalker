"""Probe every native support and photograph real jump landings and Crawl."""
import json
from prepare_workspace import RUN,write

def main():
    probes=json.loads((RUN/'bench-plan.json').read_text(encoding='utf-8'))['benchProbes']
    chosen={}
    for probe in probes:
        chosen.setdefault(probe['dimension'],probe)
        if probe['seats']==2:chosen[str(probe['root'])]=probe
    phases=[]
    def add(name,surface):
        # BenchSurfaceQa chooses exact contact coordinates from the live provider.
        phases.append(dict(name=name,x=0,y=100,z=0,yaw=0,pitch=5,
            dimension=surface.get('probe',{}).get('dimension','minecraft:overworld'),
            mode='creative',settleTicks=80,requireTerrain=True,benchSurface=surface))
    # User requested a short logical close, not another complete camera matrix.
    probe=next(iter(chosen.values()))
    add('bench-native-surface-0-crawl',dict(probe=probe,pose='crawl'))
    add('bench-fresh-surface-5-crawl',dict(fixture=5,pose='crawl'))
    probes=[probe]
    light=json.loads((RUN/'prelight-targets-bench-v21.json').read_text(encoding='utf-8'))
    write(RUN/'bench-surface-v22-plan.json',dict(benchSurfaceProbes=probes,phases=phases,
        disableFogForVisualReview=True,holdOnFailure=True,prelightChunks=light['prelightChunks']))

if __name__=='__main__':main()
