"""Apply compiled repair classes to the byte-bound visual.4-rc3 game JAR."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from prepare_workspace import BASE, RUN, WORKSPACE, sha, write


def package(revision: int):
    baseline = next(BASE.glob('*.jar'))
    assert sha(baseline) == 'd45c4d59386f9539e38272eb7db5b5da2df48f49d66ffc1ef6b9caf171780f36'
    patch = RUN / 'build/libs/dw-archive-repair-patch-20261028.1.jar'
    assert patch.is_file(), patch
    with zipfile.ZipFile(patch) as source:
        changes = {n:source.read(n) for n in source.namelist()
                   if not n.endswith('/') and not n.startswith('META-INF/') and n != 'fabric.mod.json'}
    native=RUN/'native-overlay/manifest.json'
    if native.exists():
        manifest=json.loads(native.read_text(encoding='utf-8'))
        assert manifest['baselineSha256']==sha(baseline)
        for name,expected in manifest['sources'].items():
            assert sha(Path(__file__).resolve().parent/'src/main/resources'/name)==expected,'Stale native geometry: '+name
        for name,expected in manifest['entries'].items():
            asset=native.parent/name;assert sha(asset)==expected['sha256'];changes[name]=asset.read_bytes()
        assert any(n.endswith('NativeShutterWindows.class') for n in changes),'Native function classes are missing'
    else:
        assert not any(n.endswith('NativeShutterWindows.class') for n in changes),'Native function data must be compiled before packaging'
    assert any(n.endswith('VoidScreenMixin.class') for n in changes)
    assert any('refmap' in n for n in changes), 'Missing remapped injection targets'
    with zipfile.ZipFile(baseline) as old:
        if 'assets/bloodborne_dw/native_grid/visual_physics.json' in changes:
            layout=json.loads(changes['assets/bloodborne_dw/native_grid/visual_physics.json'])
            banks=(len(layout['representatives'])+127)//128
            for bank in range(banks):
                name=f'assets/bloodborne_dw/blockstates/native_physics_{bank}.json'
                if name not in old.namelist():
                    changes[name]=json.dumps({'variants':{f'part={part}':{'model':'bloodborne_dw:block/native_physics_marker'} for part in range(128)}},separators=(',',':')).encode()
                name=f'assets/bloodborne_dw/models/item/native_physics_{bank}.json'
                if name not in old.namelist():changes[name]=b'{"parent":"bloodborne_dw:block/native_physics_marker"}'
        metadata = json.loads(old.read('fabric.mod.json'))
        metadata['version'] += '-dwfix.' + str(revision)
        metadata['entrypoints']['main'].append('dev.dreamwalker.bloodbornedw.repair.CityRepair')
        metadata['mixins'].append('dw-archive-repair.mixins.json')
        changes['fabric.mod.json'] = json.dumps(metadata, ensure_ascii=False, indent=2).encode()
        for language in ['ru_ru', 'en_us']:
            name = f'assets/bloodborne_dw/lang/{language}.json'
            strings = json.loads(old.read(name)) if name in old.namelist() else {}
            strings['block.bloodborne_dw.source_standard_lantern']='Фонарь' if language == 'ru_ru' else 'Street lantern'
            strings['block.bloodborne_dw.city_darkness'] = 'Тьма — слой города' if language == 'ru_ru' else 'City darkness'
            changes[name] = json.dumps(strings, ensure_ascii=False).encode()
        output = RUN / 'candidates' / f'dreamwalker-bb-visual4-rc3-dwfix.{revision}.jar'
        output.parent.mkdir(exist_ok=True)
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as result:
            for name in old.namelist():
                if not name.endswith('/'):
                    result.writestr(name, changes.get(name, old.read(name)))
            for name, data in changes.items():
                if name not in old.namelist():
                    result.writestr(name, data)
        with zipfile.ZipFile(output) as result:
            unchanged = [n for n in old.namelist() if not n.endswith('/') and n not in changes]
            for name in unchanged:
                assert result.read(name) == old.read(name), name
            protected = [n for n in old.namelist() if n.endswith('.class') and
                         ('stutter/' in n or 'npc/' in n or 'NativeGridClient' in n)]
            for name in protected:
                assert result.read(name) == old.read(name), 'Protected runtime changed: ' + name
        receipt = dict(version=metadata['version'], jar=str(output), sha256=sha(output),
                       baselineSha256=sha(baseline), patchSha256=sha(patch),
                       changedOrAddedEntries=sorted(changes), unchangedEntries=len(unchanged),
                       protectedRuntimeIdentical=protected, gameplayTested=False)
        write(output.with_suffix('.receipt.json'), receipt)
        print(json.dumps({k:v for k,v in receipt.items() if k not in ['protectedRuntimeIdentical','changedOrAddedEntries']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--revision', type=int, required=True)
    package(parser.parse_args().revision)
