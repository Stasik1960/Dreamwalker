"""Create a separate gameplay candidate and independently verify every changed saved chunk.

Only native visual references, equivalent physical palette states and catalog
headers in affected chunks change. Earlier pristine header-only updates are harmless. Ownership, light caches, heightmaps and the darkness layer stay exact.
"""
import argparse,collections,copy,json,shutil,subprocess,sys
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,sha,write
from remove_inert_cells import block_table,entries
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile,compound,section_blocks,block_state_key,Tag,TAG_STRING,TAG_COMPOUND,TAG_LIST,TAG_LONG_ARRAY,TAG_INT_ARRAY,pack_palette_indices

DIMS={'overworld':'region','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}


def state(physics):return 'bloodborne_dw:native_physics_'+str(physics//128)+'[part='+str(physics%128)+']'


def tag(physics):return Tag(TAG_COMPOUND,{'Name':Tag(TAG_STRING,'bloodborne_dw:native_physics_'+str(physics//128)),'Properties':Tag(TAG_COMPOUND,{'part':Tag(TAG_STRING,str(physics%128))})})


def metadata(root):
    root=copy.deepcopy(root)
    if 'DreamwalkerVisuals' in root:
        fields=compound(root['DreamwalkerVisuals']);fields.pop('Catalog',None);fields.pop('Sections',None)
    for section in root['sections'].value:compound(section).pop('block_states',None)
    return root


def verify(before,after,allowed,old_physics,new_physics,header):
    assert metadata(before)==metadata(after),'Unrelated NBT or lighting changed'
    assert compound(after['DreamwalkerVisuals'])['Catalog'].value==header
    old_entries=entries(before);expected=old_entries.copy()
    for key,(old,new) in allowed.items():assert expected[key]==old;expected[key]=new
    assert entries(after)==expected,'Unexpected native reference change'
    old_sections={compound(s)['Y'].value:compound(s).get('block_states') for s in before['sections'].value}
    new_sections={compound(s)['Y'].value:compound(s).get('block_states') for s in after['sections'].value}
    assert old_sections.keys()==new_sections.keys();changed=set()
    for sy,old_tag in old_sections.items():
        if old_tag==new_sections[sy]:continue
        old_section=next(s for s in before['sections'].value if compound(s)['Y'].value==sy)
        new_section=next(s for s in after['sections'].value if compound(s)['Y'].value==sy)
        p1,i1=section_blocks(old_section);p2,i2=section_blocks(new_section)
        p1=[block_state_key(p) for p in p1];p2=[block_state_key(p) for p in p2]
        for i in range(4096):
            a,b=p1[i1[i]],p2[i2[i]]
            if (sy,i) in allowed:
                old,new=allowed[sy,i];assert a==state(old_physics[old]) and b==state(new_physics[new])
            if a!=b:assert (sy,i) in allowed;changed.add((sy,i))
    expected_changes={key for key,(old,new) in allowed.items() if old_physics[old]!=new_physics[new]}
    assert changed==expected_changes


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--label');args=parser.parse_args()
    manifest=json.loads((RUN/'native-overlay/manifest.json').read_text(encoding='utf-8'));header=manifest['catalogSha256']
    label=args.label or header[:12];assert label.replace('-','').isalnum()
    source=RUN/'world/bloodborne';output=RUN/('native-window-world-'+label)/'bloodborne';assert output.resolve().is_relative_to(WORKSPACE)
    prior=[]
    if output.exists():
        assert not (output.parent/'receipt.json').exists(),'Candidate already completed'
        if (output.parent/'progress.json').exists():prior=json.loads((output.parent/'progress.json').read_text(encoding='utf-8'))['regions']
        else:
            for file in source.rglob('*'):
                if file.is_file() and file.name!='session.lock':assert sha(file)==sha(output/file.relative_to(source))
        for row in prior:assert sha(source/row['path'])==row['before'] and sha(output/row['path'])==row['after']
    plan=json.loads((RUN/'task09-native-window-map-plan.json').read_text(encoding='utf-8'));assert plan['catalogSha256']==header
    scenes=json.loads((Path(__file__).resolve().parent/'data/native-window-scenes.json').read_text(encoding='utf-8'))['scenes']
    layout=json.loads((RUN/'native-overlay/assets/bloodborne_dw/native_grid/visual_physics.json').read_text(encoding='utf-8'));new_physics=layout['cellToPhysics']
    import zipfile
    from prepare_workspace import BASE
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:old_physics=json.loads(z.read('assets/bloodborne_dw/native_grid/visual_physics.json'))['cellToPhysics']
    grouped=collections.defaultdict(lambda:collections.defaultdict(dict))
    for cell in plan['cells']:
        x,y,z=cell['pos'];old=scenes[cell['scene']]['old'];assert cell['next']>=0
        grouped[cell['dimension']][x>>4,z>>4][y>>4,((y&15)<<8)|((z&15)<<4)|(x&15)]=old,cell['next']
    if not output.exists():shutil.copytree(source,output,ignore=shutil.ignore_patterns('session.lock'))
    receipts=prior.copy();processed={row['path'] for row in prior};chunks_done=sum(row['chunks'] for row in prior)
    changed_cells=changed_states=0
    for cell in plan['cells']:
        x,y,z=cell['pos'];relative=DIMS[cell['dimension']]+f'/r.{x>>9}.{z>>9}.mca'
        if relative in processed:
            changed_cells+=1;changed_states+=old_physics[scenes[cell['scene']]['old']]!=new_physics[cell['next']]

    for dimension,directory in DIMS.items():
        for original_path in sorted((source/directory).glob('r.*.*.mca')):
            if directory+'/'+original_path.name in processed:continue
            rx,rz=map(int,original_path.stem.split('.')[1:])
            if not any(cx>>5==rx and cz>>5==rz for cx,cz in grouped[dimension]):continue
            subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)
            path=output/directory/original_path.name;region=RegionFile.open(original_path);allowed_chunks={};changed=False
            for chunk in list(region.chunks()):
                nbt=chunk.nbt();root=compound(nbt.root)
                if 'DreamwalkerVisuals' not in root:continue
                cx,cz=root['xPos'].value,root['zPos'].value;allowed=grouped[dimension].get((cx,cz),{})
                if not allowed:continue
                before=copy.deepcopy(root)
                for section in root['sections'].value:
                    fields=compound(section);sy=fields['Y'].value;selected={i:v for (y,i),v in allowed.items() if y==sy}
                    if not selected:continue
                    palette,indices=section_blocks(section);names=[block_state_key(p) for p in palette]
                    for index,(old,new) in selected.items():
                        assert names[indices[index]]==state(old_physics[old]),'Candidate changed since native preflight'
                        target=state(new_physics[new])
                        if target not in names:names.append(target);palette.append(tag(new_physics[new]))
                        changed_states+=names[indices[index]]!=target;indices[index]=names.index(target)
                    fields['block_states']=Tag(TAG_COMPOUND,{'palette':Tag(TAG_LIST,palette,TAG_COMPOUND),'data':Tag(TAG_LONG_ARRAY,pack_palette_indices(indices,len(palette)))})
                visuals=compound(root['DreamwalkerVisuals']);visuals['Catalog']=Tag(TAG_STRING,header)
                seen=set()
                for section in visuals['Sections'].value:
                    fields=compound(section);sy=fields['Y'].value;values=[]
                    for encoded in fields['Entries'].value:
                        key=sy,encoded&4095
                        if key in allowed:
                            old,new=allowed[key];assert (encoded&0xffffffff)>>12==old;encoded=(new<<12)|(encoded&4095);seen.add(key)
                        values.append(encoded)
                    fields['Entries']=Tag(TAG_INT_ARRAY,values)
                assert seen==allowed.keys();verify(before,root,allowed,old_physics,new_physics,header)
                region.set_chunk(chunk.x,chunk.z,nbt,timestamp=chunk.timestamp);allowed_chunks[chunk.x,chunk.z]=allowed;changed=True;changed_cells+=len(allowed);chunks_done+=1
            if not changed:continue
            region.save(path);saved=RegionFile.open(path);original=RegionFile.open(original_path)
            for chunk in original.chunks():
                other=saved.get_chunk(chunk.x,chunk.z)
                if (chunk.x,chunk.z) in allowed_chunks:verify(compound(chunk.nbt().root),compound(other.nbt().root),allowed_chunks[chunk.x,chunk.z],old_physics,new_physics,header)
                else:assert chunk.compressed_payload==other.compressed_payload and chunk.timestamp==other.timestamp
            receipts.append(dict(path=directory+'/'+path.name,before=sha(original_path),after=sha(path),chunks=len(allowed_chunks)))
            write(output.parent/'progress.json',dict(status='PREPARING',regions=receipts,cells=changed_cells))
    assert changed_cells==len(plan['cells'])==6855
    result=dict(status='SAVED_REGION_SCOPE_PASS_GAMEPLAY_PENDING',world=str(output),catalogSha256=header,windows=len(plan['windows']),cells=changed_cells,physicalPaletteChanges=changed_states,nativeChunks=chunks_done,regions=receipts,blockEntitiesAdded=0,lightingAndHeightmapsUnchanged=True,originalCandidateModified=False)
    write(output.parent/'receipt.json',result);print(json.dumps({k:v for k,v in result.items() if k!='regions'},indent=2))


if __name__=='__main__':main()
