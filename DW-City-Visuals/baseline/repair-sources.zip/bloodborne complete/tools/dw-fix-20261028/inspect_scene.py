from collections import Counter
import hashlib
from pathlib import Path
from PIL import Image, ImageDraw
from prepare_workspace import RUN
from map_reader import MapReader
import argparse

parser=argparse.ArgumentParser()
parser.add_argument('--ys',type=int,nargs=4,default=[0,16,27,48])
parser.add_argument('--output',default='scene01-slices.png')
args=parser.parse_args()

reader=MapReader(RUN/'world/bloodborne')
xs,zs=(-190,10),(-1000,-780)
scale=3
out=Image.new('RGB',((xs[1]-xs[0]+1)*scale*2,(zs[1]-zs[0]+1)*scale*2+70),'white')
draw=ImageDraw.Draw(out)
for panel,y in enumerate(args.ys):
    counts=Counter()
    for z in range(zs[0],zs[1]+1):
        for x in range(xs[0],xs[1]+1):
            state=reader.state(x,y,z)
            name=state.split('[')[0]
            counts[name]+=1
            if name.endswith(':air'): color=(15,20,27)
            elif name=='minecraft:stone':color=(240,50,50)
            else:color=tuple(70+(v%180) for v in hashlib.sha256(name.encode()).digest()[:3])
            px=(panel%2)*(xs[1]-xs[0]+1)*scale+(x-xs[0])*scale
            pz=(panel//2)*(zs[1]-zs[0]+1)*scale+(z-zs[0])*scale+35
            draw.rectangle((px,pz,px+scale-1,pz+scale-1),fill=color)
    ox=(panel%2)*(xs[1]-xs[0]+1)*scale
    oz=(panel//2)*(zs[1]-zs[0]+1)*scale+35
    px=ox+(-109-xs[0])*scale;pz=oz+(-891-zs[0])*scale
    draw.line((px-8,pz,px+8,pz),fill='white',width=2)
    draw.line((px,pz-8,px,pz+8),fill='white',width=2)
    draw.text((ox+8,oz-25),f'Y={y}; X={xs}, Z={zs}; white=(-109,-891)',fill='black')
    print('Y',y,'top',counts.most_common(15),flush=True)
print('Building coordinate',reader.state(-109,27,-891),'visual',reader.visual(-109,27,-891))
out.save(RUN/args.output)
