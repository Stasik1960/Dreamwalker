"""Instantiate normal-game placement templates with new immutable owner identities."""
import copy,math,uuid
from world_editor import *
TASK_NAMESPACE=uuid.UUID('f05bf129-533d-4c69-9c96-9ebd1744eb24')

def identity(kind,dimension,pos):
    value=uuid.uuid5(TASK_NAMESPACE,kind+'/'+dimension+'/'+','.join(map(str,pos))).int
    return [((value>>shift)&0xffffffff)-((1<<32) if ((value>>shift)&0x80000000) else 0) for shift in [96,64,32,0]]

def instantiate(template,root,dimension,*,cut=0,rotation=0):
    assert cut in [0,2] and rotation in [0,2];source_root=next(c for c in template['cells'] if c['offset']==[0,0,0]);root_be=compound(decode_nbt(bytes.fromhex(source_root['nbt'])).root);kind=compound(root_be['resident'])['id'].value
    uid=identity(kind,dimension,[root[0],root[1]-cut,root[2]]);owner=copy.deepcopy(root_be['resident']);compound(owner)['root']=Tag(TAG_INT_ARRAY,list(root));compound(owner)['uuid']=Tag(TAG_INT_ARRAY,uid);result=[]
    for c in template['cells']:
        if c['offset'][1]<cut:continue
        offset=list(c['offset']);offset[1]-=cut
        if rotation==2:offset=[-offset[2],offset[1],offset[0]]
        pos=[root[i]+offset[i] for i in range(3)];be=compound(decode_nbt(bytes.fromhex(c['nbt'])).root);assert 'NativeGridBase' not in be
        for k,v in zip('xyz',pos):be[k]=Tag(TAG_INT,v)
        envelope=decode_nbt(be['OwnerDataV1'].value);rows=compound(envelope.root)['owners'].value;assert len(rows)==1
        for entry in rows:
            row=compound(entry);assert compound(row['owner'])['uuid'].value==template['uuid'];row['owner']=copy.deepcopy(owner)
            if rotation==2:
                compound(compound(row['rootData'])['properties'])['rotation']=Tag(TAG_STRING,'2')
                for key in ['collision','selection']:
                    for box in row[key].value:
                        a,b,c0,d,e,f=[v.value for v in box.value];box.value[:]=[Tag(TAG_DOUBLE,v) for v in [1-f,b,a,1-c0,e,d]]
            if cut:
                props=compound(compound(row['rootData'])['properties']);props['variant']=Tag(TAG_STRING,'3');props['art_bank']=Tag(TAG_STRING,'2')
        be['OwnerDataV1']=Tag(TAG_BYTE_ARRAY,encode_nbt(envelope));be.pop('resident',None)
        if offset==[0,0,0]:be['resident']=copy.deepcopy(owner);be['payload']=copy.deepcopy(root_be['payload'])
        state=c['state'] if not cut else ('bloodborne_dw:source_street_lamp_post[art_bank=2,open=false,profile=base,rotation=0,variant=3]' if offset==[0,0,0] else 'bloodborne_dw:composite_cell')
        if rotation==2:state=state.replace('rotation=0','rotation=2')
        result.append(dict(pos=pos,state=state,entity=be))
    assert len(result)==len(template['cells'])-cut
    return result

def install_empty(editor,cells):
    for row in cells:
        p=row['pos'];assert editor.state(*p) in ['minecraft:air','minecraft:cave_air','minecraft:void_air'],(p,editor.state(*p));assert editor.entity(*p) is None and editor.visual(*p) is None,(p,'Occupied metadata')
    for row in cells:editor.set_state(row['pos'],row['state']);editor.set_entity(row['pos'],row['entity'])

def shifted_lamp_template(template,dy):
    result=copy.deepcopy(template);assert len(result['cells'])==1
    c=result['cells'][0];be=compound(decode_nbt(bytes.fromhex(c['nbt'])).root);payload=be['payload'];fields=compound(payload);assert 'SourceShift' not in fields
    fields['SourceShift']=Tag(TAG_LIST,[Tag(TAG_DOUBLE,v) for v in [0.,dy,0.]],TAG_DOUBLE)
    envelope=decode_nbt(be['OwnerDataV1'].value)
    for raw in compound(envelope.root)['owners'].value:
        row=compound(raw);compound(row['rootData'])['payload']=Tag(TAG_BYTE_ARRAY,encode_nbt(NbtFile('',payload)))
        for key in ['collision','selection']:
            for box in row[key].value:
                values=box.value;values[1].value+=dy;values[4].value=min(1,values[4].value+dy);assert 0<=values[1].value<values[4].value<=1
    be['OwnerDataV1']=Tag(TAG_BYTE_ARRAY,encode_nbt(envelope));c['nbt']=encode_nbt(NbtFile('',Tag(TAG_COMPOUND,be))).hex();return result
