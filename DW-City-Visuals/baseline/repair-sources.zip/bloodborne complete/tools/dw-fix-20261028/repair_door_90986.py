"""Task03: texture the source silhouette's exposed edges, without filling its arch opening."""
import copy
import io
import json
from pathlib import Path
import zipfile
import numpy as np
from PIL import Image

from prepare_workspace import BASE,RUN,write

SOURCE='assets/bloodborne_dw/models/remaining/source/minecraft/block/stairs/dark_prismarine_stairs_inner_right.json'
FRAME='assets/bloodborne_dw/models/remaining/final_followups/door_90986_frame.json'
LEAF='assets/bloodborne_dw/models/remaining/final_followups/door_90986_leaf.json'
DESCRIPTOR='bloodborne_dw/composite/source_stairs_dark_prismarine_stairs_inner_right.json'


def solid_caps(element):
    """The rectangular wooden panels use their existing decorative edge strips."""
    faces=element['faces'];front=faces['north'];u0,v0,u1,v1=front['uv']
    strips={'west':[u0,v0,u0+.125,v1], 'east':[u1-.125,v0,u1,v1],
            'up':[u0,v0,u1,v0+.125], 'down':[u0,v1-.125,u1,v1]}
    for direction,uv in strips.items():
        if direction not in faces:faces[direction]={'uv':uv,'texture':front['texture']}


def runs(values):
    start=None
    for i,on in enumerate([*values,False]):
        if on and start is None:start=i
        elif not on and start is not None:
            yield start,i
            start=None


def silhouette_edges(model,element,archive):
    """Extrude only opaque alpha-mask boundaries; preserve every hole in the stone arch."""
    face=element['faces']['north'];texture=face['texture']
    while texture.startswith('#'):texture=model['textures'][texture[1:]]
    ns,path=texture.split(':',1)
    image=Image.open(io.BytesIO(archive.read(f'assets/{ns}/textures/{path}.png'))).convert('RGBA')
    width,height=image.size;u0,v0,u1,v1=face['uv']
    assert u1!=u0 and v1!=v0,'Degenerate source UV rectangle'
    left,top,right,bottom=[round(x) for x in [min(u0,u1)*width/16,min(v0,v1)*height/16,max(u0,u1)*width/16,max(v0,v1)*height/16]]
    alpha=np.asarray(image)[top:bottom,left:right,3]>127
    h,w=alpha.shape
    x0,y0,z0=element['from'];x1,y1,z1=element['to']
    def x(u):return x1-(u*16/width-u0)/(u1-u0)*(x1-x0)
    def y(v):return y1-(v*16/height-v0)/(v1-v0)*(y1-y0)
    added=[]
    def emit(a,b,direction,uv):
        e={'from':a,'to':b,'faces':{direction:{'texture':face['texture'],'uv':uv}}}
        if 'rotation' in element:e['rotation']=copy.deepcopy(element['rotation'])
        added.append(e)
    # North-face U grows toward -X. Face normals therefore reverse at U edges.
    for u in range(w+1):
        for side in [-1,1]:
            opaque=alpha[:,u-1] if side==-1 and u>0 else alpha[:,u] if side==1 and u<w else np.zeros(h,bool)
            neighbor=alpha[:,u] if side==-1 and u<w else alpha[:,u-1] if side==1 and u>0 else np.zeros(h,bool)
            for a,b in runs(opaque & ~neighbor):
                pixel=left+u-1 if side==-1 else left+u
                uv=[(pixel+.1)*16/width,(top+a+.1)*16/height,(pixel+.9)*16/width,(top+b-.1)*16/height]
                yl,yh=sorted([y(top+a),y(top+b)])
                west=(side==-1)==(u1>u0)
                emit([x(left+u),yl,z0],[x(left+u),yh,z1],'west' if west else 'east',uv)
    for v in range(h+1):
        for side in [-1,1]:
            opaque=alpha[v-1,:] if side==-1 and v>0 else alpha[v,:] if side==1 and v<h else np.zeros(w,bool)
            neighbor=alpha[v,:] if side==-1 and v<h else alpha[v-1,:] if side==1 and v>0 else np.zeros(w,bool)
            for a,b in runs(opaque & ~neighbor):
                pixel=top+v-1 if side==-1 else top+v
                uv=[(left+a+.1)*16/width,(pixel+.1)*16/height,(left+b-.1)*16/width,(pixel+.9)*16/height]
                xl,xh=sorted([x(left+a),x(left+b)])
                down=(side==-1)==(v1>v0)
                emit([xl,y(top+v),z0],[xh,y(top+v),z1],'down' if down else 'up',uv)
    assert len(added)<=256,'Refusing an unbounded silhouette tessellation'
    return added


def remap_group(group,mapping):
    out=copy.deepcopy(group);children=[]
    for value in group.get('children',[]):
        if isinstance(value,int):
            if value in mapping:children.append(mapping[value])
        else:children.append(remap_group(value,mapping))
    out['children']=children
    return out


def main():
    output=Path(__file__).resolve().parent/'src/main/resources'
    changes={};receipt={}
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        for name,panel_ids,arch_ids,ornaments in [
                (SOURCE,[0],[8,9],{4,5,14}),
                (FRAME,[0,1],[9,10],{5,6,15})]:
            model=json.loads(archive.read(name));before=copy.deepcopy(model)
            for index in panel_ids:solid_caps(model['elements'][index])
            caps=[]
            for index in arch_ids:caps.extend(silhouette_edges(model,model['elements'][index],archive))
            mapping={old:new for new,old in enumerate(i for i in range(len(model['elements'])) if i not in ornaments)}
            model['elements']=[e for i,e in enumerate(model['elements']) if i not in ornaments]+caps
            if 'groups' in model:
                model['groups']=[remap_group(g,mapping) for g in model['groups']]
                model['groups'].append({'name':'DW arch edge caps','origin':[8,8,8],'color':0,
                                        'children':list(range(len(mapping),len(model['elements'])))})
            changes[name]=model
            receipt[name]=dict(originalElements=len(before['elements']),finalElements=len(model['elements']),
                silhouetteSideQuads=len(caps),removedOrnamentElements=sorted(ornaments))
        leaf=json.loads(archive.read(LEAF));assert len(leaf['elements'])==1
        element=leaf['elements'][0];assert element['from'][2]==2 and element['to'][2]==14
        element['to'][2]=4
        changes[LEAF]=leaf
        descriptor=json.loads(archive.read(DESCRIPTOR))
        # The final box is the swung leaf; its 12-unit X extent is the old Z thickness.
        for field in ['collision','selection']:
            box=descriptor['variants'][0]['poses']['open'][field][-1]
            assert abs(box['to'][0]-box['from'][0]-12)<1e-6
            box['from'][0]=box['to'][0]-2
        changes[DESCRIPTOR]=descriptor
    for name,document in changes.items():write(output/name,document)
    write(RUN/'task03-resource-repair.json',dict(status='DRAFT_REQUIRES_RENDER_AND_GAME_VALIDATION',
          models=receipt,openLeafThicknessBefore=12,openLeafThicknessAfter=2,
          closedLeafThicknessUnchanged=True,sourceTexturePixelsUnchanged=True,
          silhouetteHolesRetained=True,closedCollisionUnchanged=True))
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
