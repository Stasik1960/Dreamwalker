"""Independent persisted Anvil/shard cross-check for all canonical lamp and post owners."""
import collections,json
from map_reader import MapReader
from owner_shard_edit import *
from prepare_workspace import RUN,write

def main():
    world=RUN/'lamps-standard-stage2-v2/bloodborne';receipt=json.loads((world.parent/'migration-receipt.json').read_text(encoding='utf-8'));assert receipt['savedRegionGate']['status']=='PASS';index=json.loads((RUN/'task11-lantern-owner-preflight.json').read_text(encoding='utf-8'));deferred={k for c in index['cells'] if c['nativeBase']>=0 for k in c['targets']};actors=[]
    for k,o in index['owners'].items():
        if o['registryId']=='bloodborne_dw:source_lantern' and k not in deferred:actors.append(dict(dimension=o['dimension'],root=o['root'],kind='bloodborne_dw:source_standard_lantern',members=1))
    actors +=[dict(dimension=o['dimension'],root=o['root'],kind='bloodborne_dw:source_standard_lantern',members=1) for o in receipt['lamps']]
    actors +=[dict(dimension=o['dimension'],root=o['root'],kind='bloodborne_dw:source_street_lamp_post',members=o['cells']) for o in receipt['installedPosts']];assert len(actors)==1287
    readers={d:MapReader(world,p+'region') for d,p in PREFIX.items()};stores={d:Shards(world,d) for d in PREFIX};counts=collections.Counter();seen=set();unsupported=[]
    for actor in actors:
        d=actor['dimension'];root=actor['root'];reader=readers[d];store=stores[d];state=reader.state(*root);assert state.startswith(actor['kind']+'[');be=reader.entity(*root);owner=be['resident'];uid=key(owner);assert uid not in seen;seen.add(uid);assert compound(owner)['id'].value==actor['kind'] and compound(owner)['root'].value==root
        props=dict(v.split('=') for v in state.split('[',1)[1][:-1].split(','));n=store.get(root[0]>>4,root[2]>>4);ref=next(i for i,v in enumerate(n['ownerTable'].value) if key(v)==uid);membership=next(compound(v) for v in n['ownerMembership'].value if compound(v)['ownerRef'].value==ref);assert n['ownerTable'].value[ref]==owner;assert len(membership['members'].value)==actor['members']
        for raw in membership['members'].value:
            member=compound(raw);pos=tuple(root[i]+member['offset'].value[i] for i in range(3));rows=store.logical(pos);row=next(v for v in rows if key(v['owner'])==uid);entity=reader.entity(*pos);assert entity is not None;be_rows=compound(decode_nbt(entity['OwnerDataV1'].value).root)['owners'].value;actual=next(compound(v) for v in be_rows if key(compound(v)['owner'])==uid);assert actual==row
            shape=compound(n['shapeTable'].value[member['shapeRef'].value]);assert shape['collision']==row['collision'] and shape['selection']==row['selection'];properties={k:v.value for k,v in compound(compound(row['rootData'])['properties']).items()};assert properties==props,(root,properties,props);assert compound(row['rootData'])['id'].value==actor['kind'];assert row['owner']==owner
        counts[actor['kind']]+=1
    removed={k:o for k,o in index['owners'].items() if o['registryId']!='bloodborne_dw:source_lantern' or k in deferred};proof=json.loads((RUN/'task11-managed-shard-membership-proof.json').read_text(encoding='utf-8'));checked=0
    for k,o in removed.items():
        uid=tuple(o['uuid']);positions={tuple(c['pos']) for c in index['cells'] if k in c['targets']};positions.update(tuple(c['pos']) for c in proof['foreignCarrierBindings'] if c['owner']==k);store=stores[o['dimension']]
        for pos in positions:assert all(key(r['owner'])!=uid for r in store.logical(pos));checked+=1
        root=o['root'];n=store.get(root[0]>>4,root[2]>>4);assert not any(key(n['ownerTable'].value[compound(v)['ownerRef'].value])==uid for v in n['ownerMembership'].value)
    result=dict(status='PERSISTED_ANVIL_SHARD_MEMBERSHIP_AND_PROPERTY_GATE_PASS',actors=len(actors),byType=dict(counts),retiredOwnersGone=len(removed),retiredMemberBindingsChecked=checked,allNewAndExistingCanonicalRootPropertiesExactlyMatch=True,unrelatedLayerGeometryPreserved=True);write(world.parent/'owner-persistence-verification.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':main()
