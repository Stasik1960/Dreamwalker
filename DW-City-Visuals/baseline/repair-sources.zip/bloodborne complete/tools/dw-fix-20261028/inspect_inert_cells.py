"""Read-only task13 inventory. No air-like cell is removed by this program."""
import collections
import hashlib
import json
from pathlib import Path
import sys
import zipfile
from prepare_workspace import BASE,RUN,write
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile,compound,section_blocks,block_state_key


def main():
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        raw=archive.read('assets/bloodborne_dw/native_grid/catalog.json');catalog=json.loads(raw)
        physics=json.loads(archive.read('assets/bloodborne_dw/native_grid/visual_physics.json'))['cellToPhysics']
        repaired={r['mesh'] for r in json.loads(archive.read('assets/bloodborne_dw/native_grid/visual-repairs.json'))['groups']}
    members={m['cell'] for o in catalog['wholeObjects'] for m in o['cells']}
    alternatives={c['alt'] for c in catalog['cells'] if c.get('alt',-1)>=0}
    empty=set()
    for i,c in enumerate(catalog['cells']):
        if i in members or i in alternatives or c.get('alt',-1)>=0 or c.get('baseState') is not None:continue
        if c['mesh'] in repaired or catalog['meshes'][c['mesh']]['quadCount']!=0:continue
        if c.get('fluid') is not None or c.get('localFunction') is not None:continue
        if any(catalog['shapes'][c[k]] for k in ['collision','culling','climbing']):continue
        optics=catalog['optics'][c['optics']]
        if optics!=catalog['optics'][0]:continue
        empty.add(i)
    dimensions={};skips=collections.Counter();catalog_headers=set()
    for directory in ['region','dimensions/bloodborne_dw/bloodborne_old/region']:
        chunks=[];count=0
        for path in sorted((RUN/'world/bloodborne'/directory).glob('r.*.*.mca')):
            region=RegionFile.open(path)
            for chunk in region.chunks():
                root=compound(chunk.nbt().root);table=root.get('DreamwalkerVisuals')
                if table is None:continue
                fields=compound(table);catalog_headers.add(str(fields['Catalog'].value))
                if set(fields)-{'Catalog','Sections','Schema','ForcedWater'}:
                    skips['unknownVisualMetadata']+=1;continue
                if any(k.startswith('Dreamwalker') and k!='DreamwalkerVisuals' for k in root):
                    skips['unknownOwnerMetadata']+=1;continue
                protected=set()
                for key in ['block_entities','block_ticks','fluid_ticks']:
                    for tag in root[key].value if key in root else []:
                        t=compound(tag)
                        if all(k in t for k in 'xyz'):protected.add(tuple(t[k].value for k in 'xyz'))
                water={v & 0xffffffffffffffff for v in fields['ForcedWater'].value} if 'ForcedWater' in fields else set()
                cx,cz=root['xPos'].value,root['zPos'].value
                sections={compound(s)['Y'].value:s for s in root['sections'].value}
                selected=[]
                for row in fields['Sections'].value:
                    data=compound(row);sy=data['Y'].value;parsed=None
                    for packed in data['Entries'].value:
                        cell=(packed&0xffffffff)>>12;local=packed&4095
                        if cell not in empty:continue
                        x=cx*16+(local&15);y=sy*16+(local>>8);z=cz*16+((local>>4)&15)
                        wp=((x&0x3ffffff)<<38)|((z&0x3ffffff)<<12)|(y&4095)
                        if (x,y,z) in protected or wp in water:
                            skips['entityTickOrWater']+=1;continue
                        if parsed is None:
                            palette,indices=section_blocks(sections[sy]);parsed=([block_state_key(p) for p in palette],indices)
                        state=parsed[0][parsed[1][local]]
                        family,props=state.split('[',1) if '[' in state else (state,'')
                        expected=f'bloodborne_dw:native_physics_{physics[cell]//128}'
                        if family!=expected or f'part={physics[cell]%128}' not in props.split(']')[0].split(','):
                            skips['carrierMismatch']+=1;continue
                        selected.append([sy,local,cell])
                if selected:
                    chunks.append(dict(region=path.name,cx=cx,cz=cz,cells=selected));count+=len(selected)
        dimensions[directory]=dict(count=count,chunks=chunks)
    receipt=dict(status='READ_ONLY_CANDIDATES_REQUIRE_REMOVAL_AND_GAME_VALIDATION',catalogSha256=hashlib.sha256(raw).hexdigest(),
                 catalogHeaders=sorted(catalog_headers),eligibleCellTypes=sorted(empty),skipped=dict(skips),dimensions=dimensions)
    write(RUN/'task13-inert-census.json',receipt)
    print(json.dumps(dict(eligibleTypes=len(empty),catalogHeaders=sorted(catalog_headers),skipped=dict(skips),
                         dimensions={d:dict(cells=v['count'],chunks=len(v['chunks'])) for d,v in dimensions.items()}),indent=2))


if __name__=='__main__':main()
