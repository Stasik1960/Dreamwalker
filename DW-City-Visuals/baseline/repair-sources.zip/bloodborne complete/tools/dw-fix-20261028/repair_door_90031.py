"""Task05: close exposed swung-leaf edges while retaining front and back artwork."""
import json
from pathlib import Path
import zipfile
from prepare_workspace import BASE,RUN,write
from door_surfaces import rebuild


def main():
    output=Path(__file__).resolve().parent/'src/main/resources'
    changes={};receipt={}
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        descriptor=json.loads(archive.read('bloodborne_dw/composite/source_acacia_pressure_plate.json'))
        refs={p['model'] for v in descriptor['variants'] for p in v['poses'].get('open',{}).get('parts',[])}
        for ref in sorted(refs):
            name='assets/'+ref.replace(':','/models/',1)+'.json'
            assert '/v126/doors/90031/' in name
            model=json.loads(archive.read(name));receipt[name]=rebuild(model,{3.0:10,6.0:4},mirror_back=False)
            changes[name]=model
    assert len(changes)==6
    for name,model in changes.items():write(output/name,model)
    write(RUN/'task05-resource-repair.json',dict(status='DRAFT_REQUIRES_GAME_AND_PERFORMANCE_VALIDATION',
          models=receipt,frontAndBackArtUnchanged=True,closedModelsAndCollisionUnchanged=True))
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
