"""Retire only proven source-lamp quads; unrelated native bytes and physics remain intact."""
import collections,copy,hashlib,io,json,shutil,struct,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
from prepare_workspace import RUN,BASE,write
from compile_native_windows import canonical,DIRECTORY

def main():
    output=RUN/'native-overlay';source=RUN/'native-overlay-stage12-wall'
    if not source.exists():shutil.copytree(output,source)
    manifest=json.loads((source/'manifest.json').read_text(encoding='utf-8'));assert manifest['catalogSha256']=='62d4794366abe42689d73e06a5a5c55d84281d7ada40cf7af42082f690920677'
    catalog=json.loads((source/DIRECTORY/'catalog.json').read_text(encoding='utf-8'));original=copy.deepcopy(catalog);layout=json.loads((source/DIRECTORY/'visual_physics.json').read_text(encoding='utf-8'));raw=(source/DIRECTORY/'meshes.bin').read_bytes();meshes=[];cursor=8
    for m in catalog['meshes']:n=struct.unpack_from('>I',raw,cursor)[0];meshes.append(raw[cursor+4:cursor+4+n*139]);cursor+=4+n*139
    assert cursor==len(raw)
    retired=json.loads((RUN/'task11-native-lantern-preflight.json').read_text(encoding='utf-8'));positions={}
    for group in retired['groups']:
        assert group['matched']>=group['expected']*.95 and group['matched']>=6,'Source fingerprint coverage is insufficient'
        # Retire only byte-matched source faces; missing/occluded source faces are never invented here.
        for cell in group['cells']:
            key=('overworld' if group['dimension']==0 else 'bloodborne_old',*cell['pos']);row=positions.setdefault(key,dict(old=cell['visual'],remove=set()));assert row['old']==cell['visual'];row['remove'].update(cell['remove'])
    windows={(c['dimension'],*c['pos']) for c in json.loads((RUN/'task09-native-window-map-plan.json').read_text(encoding='utf-8'))['cells']};assert not windows.intersection(positions)
    bench=json.loads((Path(__file__).resolve().parent/'src/main/resources/bloodborne_dw/repair/native-benches.json').read_text(encoding='utf-8'));templates={t['id']:t for t in bench['templates']}
    for p in json.loads((RUN/'bench-plan.json').read_text(encoding='utf-8'))['benchProbes']:
        dim='overworld' if p['dimension']=='minecraft:overworld' else 'bloodborne_old';root=p['root']
        for dx,dy,dz,visual in templates[p['template']]['cells']:assert (dim,root[0]+dx,root[1]+dy,root[2]+dz) not in positions
    rank={'solid':0,'cutout_mipped':1,'cutout':2,'translucent':3};effective={};archive=zipfile.ZipFile(next(BASE.glob('*.jar')))
    def layer(mid):
        if mid not in effective:
            m=catalog['materials'][mid];value=m['layer']
            if value=='translucent':
                ns,path=m['sprite'].split(':');image=np.asarray(Image.open(io.BytesIO(archive.read('assets/'+ns+'/textures/'+path+'.png'))).convert('RGBA'))[:,:,3]
                if not np.any((image!=0)&(image!=255)):value='cutout'
            effective[mid]=value
        return effective[mid]
    semantics=lambda c:{k:v for k,v in c.items() if k not in ['key','mesh','displayName']}
    mapping={};bounds={};cleared=0;retained_quads=removed_quads=0;scenes={};cells=[]
    for pos,row in sorted(positions.items()):
        old=row['old'];key=old,tuple(sorted(row['remove']))
        if key not in mapping:
            base=original['cells'][old];blob=meshes[base['mesh']];quads=[blob[i:i+139] for i in range(0,len(blob),139)];keep=[q for i,q in enumerate(quads) if i not in row['remove']];removed_quads+=len(row['remove']);retained_quads+=len(keep)
            if not keep:
                assert base.get('baseState') is None and base.get('localFunction') is None and base.get('fluid') is None and base.get('alt',-1)<0 and base['optics']==0 and base['climbing']==0
                mapping[key]=-1;cleared+=1
            else:
                data=b''.join(keep);cell=copy.deepcopy(base);cell['mesh']=len(catalog['meshes']);catalog['meshes'].append(dict(quadCount=len(keep)));meshes.append(data);cell.pop('key');cell['key']=hashlib.sha256(('dwfix-native-lamp-retirement/'+canonical(cell)).encode()).hexdigest();index=len(catalog['cells']);catalog['cells'].append(cell)
                layers=[layer(struct.unpack_from('>I',q)[0]) for q in keep];render_layer=max(layers,key=rank.get);ambient=all(q[10]&2 for q in keep);same=semantics(cell)
                physical=next((i for i,r in enumerate(layout['representatives']) if semantics(catalog['cells'][r])==same and layout['physicsLayers'][i]==render_layer and layout['physicsAmbient'][i]==ambient),None)
                if physical is None:physical=len(layout['representatives']);layout['representatives'].append(index);layout['physicsLayers'].append(render_layer);layout['physicsAmbient'].append(ambient)
                layout['cellToPhysics'].append(physical);mapping[key]=index;assert semantics(cell)==semantics(base)
                if cell['outline']==0:
                    xyz=np.array([struct.unpack_from('>3f',q,11+32*v) for q in keep for v in range(4)]);lo=xyz.min(axis=0);hi=xyz.max(axis=0)
                    for axis in range(3):
                        if hi[axis]-lo[axis]<1e-6:lo[axis]=max(0,lo[axis]-1/1024);hi[axis]=min(1,hi[axis]+1/1024)
                    bounds[index]=[*map(float,lo),*map(float,hi)]
            sid=hashlib.sha256(repr(key).encode()).hexdigest()[:20];scenes[sid]=dict(old=old,remove=list(key[1]),next=mapping[key])
        sid=hashlib.sha256(repr(key).encode()).hexdigest()[:20];cells.append(dict(dimension=pos[0],pos=pos[1:],old=old,next=mapping[key],scene=sid))
    catalog_bytes=canonical(catalog).encode();header=hashlib.sha256(catalog_bytes).hexdigest();layout['catalogSha256']=header
    if manifest['catalogSha256'] not in layout['compatibleCatalogs']:layout['compatibleCatalogs'].append(manifest['catalogSha256'])
    repair=json.loads((source/DIRECTORY/'visual-repairs.json').read_text(encoding='utf-8'));repair['catalogSha256']=header;window=json.loads((source/'bloodborne_dw/repair/native-windows.json').read_text(encoding='utf-8'));window['catalogSha256']=header
    previous=(source/DIRECTORY/'selection-bounds.bin').read_bytes();length=struct.unpack_from('>H',previous,4)[0];assert length==64;at=6+length;count=struct.unpack_from('>I',previous,at)[0]
    bound_blob=previous[:4]+struct.pack('>H',64)+header.encode()+struct.pack('>I',count+len(bounds))+previous[at+4:]+b''.join(struct.pack('>i6f',i,*b) for i,b in bounds.items())
    generated={DIRECTORY+'catalog.json':catalog_bytes,DIRECTORY+'visual_physics.json':canonical(layout).encode(),DIRECTORY+'meshes.bin':struct.pack('>II',0x4e475131,len(meshes))+b''.join(struct.pack('>I',len(m)//139)+m for m in meshes),DIRECTORY+'visual-repairs.json':canonical(repair).encode(),DIRECTORY+'selection-bounds.bin':bound_blob,'bloodborne_dw/repair/native-windows.json':canonical(window).encode()}
    assert catalog['cells'][:len(original['cells'])]==original['cells'] and catalog['materials']==original['materials'];assert generated[DIRECTORY+'meshes.bin'][8:len(raw)]==raw[8:]
    for name,data in generated.items():p=output/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);manifest['entries'][name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
    manifest['catalogSha256']=header;manifest.setdefault('stages',{})['nativeLanternRemoval']=header;write(output/'manifest.json',manifest)
    report=dict(status='APPEND_ONLY_NATIVE_REMOVAL_PLAN_PASS_NO_MAP_WRITES',catalogSha256=header,objects=len(retired['groups']),cells=len(cells),uniqueScenes=len(mapping),clearedPureLampScenes=cleared,removedQuadsInUniqueScenes=removed_quads,unrelatedQuadBytesRetained=retained_quads,windowsAndBenchContactsUnchanged=True)
    write(RUN/'task11-native-lantern-removal-plan.json',dict(report=report,scenes=scenes,cells=cells));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
