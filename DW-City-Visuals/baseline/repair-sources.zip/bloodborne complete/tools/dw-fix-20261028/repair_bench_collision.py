"""Keep the walking plane on the plank; constrain decor collision to its actual elements."""
import copy,json,math,zipfile
from pathlib import Path
import numpy as np
from prepare_workspace import RUN,write
from native_model_baker import bake
from compile_native_bench_supports import overlaps
RESOURCE=Path(__file__).resolve().parent/'src/main/resources'

def plank_boxes(poly,top):
    lo=np.floor(poly.min(axis=0)*16+1e-6).astype(int);hi=np.ceil(poly.max(axis=0)*16-1e-6).astype(int);rows={}
    for z in range(lo[1],hi[1]):
        x=lo[0]
        while x<hi[0]:
            if not overlaps(poly,x/16,z/16):x+=1;continue
            start=x
            while x<hi[0] and overlaps(poly,x/16,z/16):x+=1
            rows.setdefault((start,x),[]).append(z)
    out=[]
    for (x,X),zs in sorted(rows.items()):
        start=last=zs[0]
        for z in zs[1:]+[999]:
            if z!=last+1:out.append(dict(from_=[int(x),round(top*16-2,8),int(start)],to=[int(X),round(top*16,8),int(last+1)]));start=z
            last=z
    return [{'from':v['from_'],'to':v['to']} for v in out]

def main():
    with zipfile.ZipFile(RUN/'candidates/dreamwalker-bb-visual4-rc3-dwfix.20.jar') as z:
        spec=json.loads(z.read('bloodborne_dw/composite/source_hold_bench.json'));old=copy.deepcopy(spec);counts=[]
        for variant,v in enumerate(spec['variants']):
            part=v['poses']['closed']['parts'][0];ns,path=part['model'].split(':',1);model=json.loads(z.read(f'assets/{ns}/models/{path}.json'));rotations=[]
            for rotation in range(8):
                quads=bake(model,offset=part['offset'],yaw=rotation,layer='cutout');plank=[q for q in quads if q.element==2 and q.normal[1]>.99];assert len(plank)==1
                p=plank[0].vertices[:,:3];top=float(p[:,1].mean());assert abs(top-1)<1e-6;boxes=plank_boxes(p[:,[0,2]],top)
                for ei,element in enumerate(model['elements'][5:],5):
                    if min(np.array(element['to'])-np.array(element['from']))<=1e-6:continue
                    points=np.concatenate([q.vertices[:,:3] for q in quads if q.element==ei]);a=points.min(axis=0)*16;b=points.max(axis=0)*16
                    boxes.append({'from':[round(float(x),8) for x in a],'to':[round(float(x),8) for x in b]})
                rotations.append(boxes)
            pose=v['poses']['closed'];pose['collision']=rotations[0];pose['simpleCollisionByRotation']=rotations;counts.append([len(x) for x in rotations])
        for a,b in zip(spec['variants'],old['variants']):
            aa=copy.deepcopy(a);bb=copy.deepcopy(b)
            for d in [aa,bb]:d['poses']['closed'].pop('collision');d['poses']['closed'].pop('simpleCollisionByRotation')
            assert aa==bb
        path=RESOURCE/'bloodborne_dw/repair/bench-surfaces.json';path.write_text(json.dumps({'variants':[v['poses']['closed']['simpleCollisionByRotation'] for v in spec['variants']]},separators=(',',':')),encoding='utf-8')
        obsolete=RESOURCE/'bloodborne_dw/composite/source_hold_bench.json'
        if obsolete.exists():obsolete.unlink()
        write(RUN/'bench-owned-collision-source-proof.json',dict(status='SOURCE_PLANK_AND_DECOR_COLLISION_DERIVED',plankTop=1,variants=len(spec['variants']),boxesPerRotation=counts,geometryTexturesAndSelectionUnchanged=True,originalDescriptorAndThreeBoxBudgetUnchanged=True));print(counts)

if __name__=='__main__':main()
