"""Inventory only the structural columns attached to the 56 retired paired lamps."""
import collections,json,zipfile
from map_reader import MapReader
from prepare_workspace import RUN,BASE,write
from world_io import compound

def main():
    static=json.loads((RUN/'task11-static-lantern-preflight.json').read_text(encoding='utf-8'));managed=json.loads((RUN/'task11-lantern-owner-preflight.json').read_text(encoding='utf-8'));anchors=[dict(dimension='overworld' if g['dimension']==0 else 'bloodborne_old',root=g['root']) for g in static['groups'] if g['pose']['registryId']=='bloodborne_dw:source_dead_fire_coral_block']
    anchors +=[dict(dimension=o['dimension'],root=o['root']) for o in managed['owners'].values() if o['registryId']=='bloodborne_dw:source_dead_fire_coral_block'];assert len(anchors)==56
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:catalog=json.loads(z.read('bloodborne_dw/static-architecture-v1274.json'))
    poses={p['key']:p for p in catalog['poses']};readers={dim:MapReader(RUN/'lamps-single-stage1/bloodborne',directory) for dim,directory in [('overworld','region'),('bloodborne_old','dimensions/bloodborne_dw/bloodborne_old/region')]};hist=collections.defaultdict(collections.Counter)
    for anchor in anchors:
        reader=readers[anchor['dimension']];rows=[]
        for dy in range(-7,5):
            pos=[anchor['root'][0],anchor['root'][1]+dy,anchor['root'][2]];state=reader.state(*pos);kind=state.split('[')[0];row=dict(dy=dy,pos=pos,state=state,native=reader.visual(*pos));ids=[kind]
            if kind.startswith('bloodborne_dw:static_architecture_'):
                props=dict(x.split('=') for x in state.split('[',1)[1][:-1].split(','));index=int(kind.rsplit('_',1)[1])*128+int(props['part']);row['recipe']=index;row['fragments']=[dict(pose=poses[f['pose']],origin=f['origin'],member=f['member']) for f in catalog['recipes'][index]['fragments']];ids=[f['pose']['registryId'] for f in row['fragments']]
            be=reader.entity(*pos)
            if be is not None and 'resident' in be:row['resident']=compound(be['resident'])['id'].value
            hist[dy].update(ids);rows.append(row)
        anchor['column']=rows
    write(RUN/'task11-red-post-columns.json',dict(anchors=anchors,histogram={str(k):dict(v) for k,v in hist.items()}));print(json.dumps({str(k):dict(v) for k,v in hist.items()},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
