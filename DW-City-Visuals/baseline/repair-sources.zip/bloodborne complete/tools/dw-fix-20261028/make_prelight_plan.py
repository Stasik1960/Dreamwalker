"""Select only existing full city chunks whose offline edits invalidated caches."""
import argparse,collections,json,subprocess
from pathlib import Path
from world_editor import *
from prepare_workspace import RUN,WORKSPACE,write

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--world',required=True);args=parser.parse_args();world=Path(args.world).resolve();assert world.is_relative_to(RUN.resolve());rows=[];counts={};headers=[]
    for dim,directory in [('minecraft:overworld','region'),('bloodborne_dw:bloodborne_old','dimensions/bloodborne_dw/bloodborne_old/region')]:
        count=0
        for path in sorted((world/directory).glob('r.*.*.mca')):
            subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)
            region=RegionFile.open(path)
            for chunk in region.chunks():
                root=compound(chunk.nbt().root);status=root.get('Status');assert status is not None
                if status.value not in ['minecraft:full','full']:continue
                heights=compound(root['Heightmaps']) if 'Heightmaps' in root else {};lit=root.get('isLightOn',Tag(TAG_BYTE,0)).value==1
                if lit and all(h in heights for h in ['WORLD_SURFACE','MOTION_BLOCKING']):continue
                rows.append(dict(dimension=dim,x=root['xPos'].value,z=root['zPos'].value));count+=1
            headers.append(str(path.relative_to(world)))
        counts[dim]=count
    result=dict(status='EXISTING_FULL_CHUNKS_ONLY',world=str(world),chunks=len(rows),byDimension=counts,prelightChunks=rows);write(RUN/'prelight-targets.json',result);print(json.dumps({k:v for k,v in result.items() if k!='prelightChunks'},indent=2))

if __name__=='__main__':main()
