"""Authoritative shard edits for the exact offline composite write set."""
import copy,gzip,hashlib
from pathlib import Path
from prefab_template import *
from fix_single_lamp_shards import read,key
PREFIX={'overworld':'','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/'}

def encoded(tag):return encode_nbt(NbtFile('',tag))
def flat(n,cell):
    rows=[]
    for ref in compound(cell)['refs'].value:
        o,d,s=ref.value;shape=compound(n['shapeTable'].value[s]);rows.append(dict(owner=n['ownerTable'].value[o],rootData=n['dataTable'].value[d],collision=shape['collision'],selection=shape['selection']))
    return rows

def chunk_long(cx,cz):
    value=(cx&0xffffffff)|((cz&0xffffffff)<<32);return value-(1<<64) if value>>63 else value

class Shards:
    def __init__(self,source,dimension):self.source=Path(source);self.dimension=dimension;self.cache={};self.before={};self.tables={};self.allowed=set()
    def relative(self,cx,cz):return PREFIX[self.dimension]+f'data/bloodborne_dw_owner_shards/owners-{cx}.{cz}.nbt'
    def get(self,cx,cz):
        k=cx,cz
        if k not in self.cache:
            path=self.source/self.relative(cx,cz)
            if path.exists():doc=read(path);self.before[k]=copy.deepcopy(compound(doc.root))
            else:
                doc=NbtFile('',Tag(TAG_COMPOUND,{'Schema':Tag(TAG_INT,1),'ChunkX':Tag(TAG_INT,cx),'ChunkZ':Tag(TAG_INT,cz),'Dictionary':Tag(TAG_BYTE,1),**{t:Tag(TAG_LIST,[],TAG_COMPOUND) for t in ['ownerTable','dataTable','shapeTable','cells','ownerMembership']}}));self.before[k]=None
            n=compound(doc.root);assert n['Schema'].value==1 and n['Dictionary'].value==1 and n['ChunkX'].value==cx and n['ChunkZ'].value==cz
            self.cache[k]=doc;self.tables[k]={name:{encoded(v):i for i,v in enumerate(n[name].value)} for name in ['ownerTable','dataTable','shapeTable']}
        return compound(self.cache[k].root)
    def append(self,k,table,value):
        n=self.get(*k);cache=self.tables[k][table];raw=encoded(value)
        if raw not in cache:cache[raw]=len(n[table].value);n[table].value.append(copy.deepcopy(value));n[table].list_type=TAG_COMPOUND
        return cache[raw]
    def set_cell(self,pos,rows):
        k=pos[0]>>4,pos[2]>>4;n=self.get(*k);old=next((v for v in n['cells'].value if tuple(compound(v)['pos'].value)==tuple(pos)),None)
        refs=[]
        for row in rows:
            if isinstance(row,Tag):row=compound(row)
            shape=Tag(TAG_COMPOUND,{'collision':row['collision'],'selection':row['selection']});refs.append(Tag(TAG_INT_ARRAY,[self.append(k,'ownerTable',row['owner']),self.append(k,'dataTable',row['rootData']),self.append(k,'shapeTable',shape)]))
        if not rows:
            if old is not None:n['cells'].value.remove(old)
        elif old is not None:compound(old)['refs']=Tag(TAG_LIST,refs,TAG_INT_ARRAY)
        else:n['cells'].value.append(Tag(TAG_COMPOUND,{'pos':Tag(TAG_INT_ARRAY,list(pos)),'refs':Tag(TAG_LIST,refs,TAG_INT_ARRAY)}))
        if n['cells'].value:n['cells'].list_type=TAG_COMPOUND
        self.allowed.add(tuple(pos))
    def logical(self,pos):
        n=self.get(pos[0]>>4,pos[2]>>4);cell=next((v for v in n['cells'].value if tuple(compound(v)['pos'].value)==tuple(pos)),None);return flat(n,cell) if cell is not None else []
    def prune(self,removed,positions):
        for pos in positions:
            rows=self.logical(pos);kept=[r for r in rows if key(r['owner']) not in removed]
            if len(kept)!=len(rows):self.set_cell(pos,kept)
        for k,doc in list(self.cache.items()):
            n=compound(doc.root);n['ownerMembership'].value[:]=[v for v in n['ownerMembership'].value if key(n['ownerTable'].value[compound(v)['ownerRef'].value]) not in removed]
    def mirror(self,editor,new_owners,removed):
        for pos in sorted(editor.be_changed):
            old=self.logical(pos);be=editor.entity(*pos);rows=compound(decode_nbt(be['OwnerDataV1'].value).root)['owners'].value if be is not None and 'OwnerDataV1' in be else [];after=[compound(v) for v in rows]
            if be is None:
                # Foreign carriers may legitimately keep guest layers exclusively in the ledger.
                after=old
            else:
                changed=False
                for row in old:
                    uid=key(row['owner'])
                    if uid in removed or row in after:continue
                    assert not any(key(r['owner'])==uid for r in after),('Conflicting foreign BE/ledger mirror',pos,uid)
                    assert not row['collision'].value,('New geometry overlaps a foreign physical layer',pos,uid)
                    # Passable grass/decals keep their exact existing layer in the new shared BE.
                    after.append(copy.deepcopy(row));changed=True
                if changed:
                    envelope=decode_nbt(be['OwnerDataV1'].value);compound(envelope.root)['owners']=Tag(TAG_LIST,[Tag(TAG_COMPOUND,r) for r in after],TAG_COMPOUND);be=copy.deepcopy(be);be['OwnerDataV1']=Tag(TAG_BYTE_ARRAY,encode_nbt(envelope));editor.set_entity(pos,be)
                for row in old:
                    if key(row['owner']) not in removed:assert row in after,('Unrelated authoritative contribution would be lost',pos,key(row['owner']))
            self.set_cell(pos,after)
        memberships={uid:{} for uid in new_owners}
        for pos in sorted(editor.be_changed):
            be=editor.entity(*pos)
            if be is None or 'OwnerDataV1' not in be:continue
            for raw in compound(decode_nbt(be['OwnerDataV1'].value).root)['owners'].value:
                row=compound(raw);uid=key(row['owner'])
                if uid in memberships:memberships[uid][tuple(pos)]=Tag(TAG_COMPOUND,{'collision':row['collision'],'selection':row['selection']})
        for uid,owner in new_owners.items():
            root=compound(owner)['root'].value;k=root[0]>>4,root[2]>>4;n=self.get(*k);assert tuple(root) in memberships[uid];ref=self.append(k,'ownerTable',owner);assert not any(key(n['ownerTable'].value[compound(v)['ownerRef'].value])==uid for v in n['ownerMembership'].value)
            rows=[]
            for pos,shape in sorted(memberships[uid].items()):rows.append(Tag(TAG_COMPOUND,{'offset':Tag(TAG_INT_ARRAY,[pos[i]-root[i] for i in range(3)]),'shapeRef':Tag(TAG_INT,self.append(k,'shapeTable',shape))}))
            n['ownerMembership'].list_type=TAG_COMPOUND
            n['ownerMembership'].value.append(Tag(TAG_COMPOUND,{'ownerRef':Tag(TAG_INT,ref),'members':Tag(TAG_LIST,rows,TAG_COMPOUND)}))
        return sum(len(v) for v in memberships.values())
    def prepare(self,removed,new_owners):
        edits=[]
        for k,doc in self.cache.items():
            n=compound(doc.root);before=self.before[k]
            if before==n or (before is None and not n['cells'].value and not n['ownerMembership'].value):continue
            if before is not None:
                old_cells={tuple(compound(v)['pos'].value):v for v in before['cells'].value};new_cells={tuple(compound(v)['pos'].value):v for v in n['cells'].value}
                for pos in old_cells.keys()|new_cells.keys():
                    if pos not in self.allowed:assert old_cells.get(pos)==new_cells.get(pos)
                    if pos in old_cells:
                        original=[r for r in flat(before,old_cells[pos]) if key(r['owner']) not in removed];actual=flat(n,new_cells[pos]) if pos in new_cells else []
                        for row in original:assert row in actual,('Foreign owner data changed',pos,key(row['owner']))
                for table in ['ownerTable','dataTable','shapeTable']:assert n[table].value[:len(before[table].value)]==before[table].value
                old_members=[v for v in before['ownerMembership'].value if key(before['ownerTable'].value[compound(v)['ownerRef'].value]) not in removed];actual_members=[v for v in n['ownerMembership'].value if key(n['ownerTable'].value[compound(v)['ownerRef'].value]) not in new_owners];assert old_members==actual_members
                other={'cells','ownerTable','dataTable','shapeTable','ownerMembership'};assert {a:b for a,b in n.items() if a not in other}=={a:b for a,b in before.items() if a not in other}
            edits.append((self.relative(*k),gzip.compress(encode_nbt(doc),mtime=0)))
        index_path=self.source/(PREFIX[self.dimension]+'data/bloodborne_dw_composite_owners.dat');index=read(index_path);data=compound(compound(index.root)['data']);assert data['OwnerShardSchema'].value==1;old=set(data['OwnerShardChunks'].value);known=old|{chunk_long(*k) for k,doc in self.cache.items() if self.before[k] is not None or compound(doc.root)['cells'].value or compound(doc.root)['ownerMembership'].value};data['OwnerShardChunks']=Tag(TAG_LONG_ARRAY,sorted(known));edits.append((PREFIX[self.dimension]+'data/bloodborne_dw_composite_owners.dat',gzip.compress(encode_nbt(index),mtime=0)))
        return edits
