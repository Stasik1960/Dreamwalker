"""Migrate the authoritative owner-shard mirror together with lamp BE identities.

Copy-on-write data-table entries preserve other owners sharing a root descriptor.
The runtime identity guards and its persisted schema remain unchanged.
"""
import copy,gzip,hashlib,json,shutil
from pathlib import Path
from prefab_template import *
from prepare_workspace import RUN,write,sha
OLD='bloodborne_dw:source_lantern';NEW='bloodborne_dw:source_standard_lantern'
DIRS={'overworld':'','bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/'}

def key(owner):return tuple(compound(owner)['uuid'].value)
def read(path):return decode_nbt(gzip.decompress(path.read_bytes()))
def raw_entries(n):
    out={};owners=n['ownerTable'].value;datas=n['dataTable'].value;shapes=n['shapeTable'].value
    for raw in n['cells'].value:
        row=compound(raw);out[tuple(row['pos'].value)]=[dict(owner=copy.deepcopy(owners[r.value[0]]),rootData=copy.deepcopy(datas[r.value[1]]),shape=copy.deepcopy(shapes[r.value[2]])) for r in row['refs'].value]
    return out

def main():
    source=RUN/'lamps-single-stage1-v2/bloodborne';target=RUN/'lamps-single-stage1-fixed-v2/bloodborne';assert not target.exists();index=json.loads((RUN/'task11-lantern-owner-preflight.json').read_text(encoding='utf-8'));deferred={k for c in index['cells'] if c['nativeBase']>=0 for k in c['targets']};selected={tuple(o['uuid']) for k,o in index['owners'].items() if o['registryId']==OLD and k not in deferred};assert len(selected)==559
    files=set();expected_members={}
    for k,o in index['owners'].items():
        if tuple(o['uuid']) not in selected:continue
        root=o['root'];files.add((o['dimension'],root[0]>>4,root[2]>>4));expected_members[tuple(o['uuid'])]=set()
    for c in index['cells']:
        for k in c['targets']:
            owner=index['owners'][k];uid=tuple(owner['uuid'])
            if uid not in selected:continue
            expected_members[uid].add(tuple(c['pos']));p=c['pos'];files.add((c['dimension'],p[0]>>4,p[2]>>4))
    edits=[];seen=set();members={};all_entries=0
    for dim,cx,cz in sorted(files):
        relative=DIRS[dim]+f'data/bloodborne_dw_owner_shards/owners-{cx}.{cz}.nbt';path=source/relative;doc=read(path);n=compound(doc.root);assert n['Dictionary'].value==1;before=copy.deepcopy(n);before_entries=raw_entries(before);selected_refs=set()
        for i,owner in enumerate(n['ownerTable'].value):
            uid=key(owner)
            if uid in selected:
                assert compound(owner)['id'].value==OLD;compound(owner)['id']=Tag(TAG_STRING,NEW);selected_refs.add(i);seen.add(uid)
        assert selected_refs,'Expected shard has no selected owner';data_remap={}
        for raw in n['cells'].value:
            row=compound(raw)
            for ref in row['refs'].value:
                own,data,shape=ref.value
                if own not in selected_refs:continue
                if data not in data_remap:
                    value=copy.deepcopy(n['dataTable'].value[data]);fields=compound(value);assert fields['id'].value==OLD;fields['id']=Tag(TAG_STRING,NEW);compound(fields['properties'])['variant']=Tag(TAG_STRING,'0');compound(fields['properties']).pop('art_bank',None);data_remap[data]=len(n['dataTable'].value);n['dataTable'].value.append(value)
                ref.value[1]=data_remap[data];all_entries+=1
        for raw in n['ownerMembership'].value:
            row=compound(raw);ref=row['ownerRef'].value
            if ref not in selected_refs:continue
            owner=compound(n['ownerTable'].value[ref]);uid=tuple(owner['uuid'].value);root=owner['root'].value;assert uid not in members
            members[uid]={tuple(root[i]+compound(m)['offset'].value[i] for i in range(3)) for m in row['members'].value}
        after_entries=raw_entries(n);assert before_entries.keys()==after_entries.keys()
        for pos,rows in before_entries.items():
            expected=copy.deepcopy(rows)
            for row in expected:
                if key(row['owner']) in selected:
                    compound(row['owner'])['id']=Tag(TAG_STRING,NEW);compound(row['rootData'])['id']=Tag(TAG_STRING,NEW);compound(compound(row['rootData'])['properties'])['variant']=Tag(TAG_STRING,'0');compound(compound(row['rootData'])['properties']).pop('art_bank',None)
            assert after_entries[pos]==expected
        assert before['shapeTable']==n['shapeTable'] and before['ownerMembership']==n['ownerMembership']
        edits.append((relative,gzip.compress(encode_nbt(doc),mtime=0),sha(path)))
    assert seen==selected and members==expected_members,(len(seen),len(members),len(expected_members));assert all_entries==559
    shutil.copytree(source,target,ignore=shutil.ignore_patterns('session.lock'));receipts=[]
    for relative,data,before_sha in edits:
        p=target/relative;p.write_bytes(data);assert read(p).root==decode_nbt(gzip.decompress(data)).root;receipts.append(dict(path=relative,before=before_sha,after=sha(p)))
    report=dict(status='AUTHORITATIVE_OWNER_MIRROR_SCOPE_PASS_GAMEPLAY_PENDING',world=str(target),renamedOwners=len(seen),renamedContributions=all_entries,changedShards=len(edits),savedMembershipsExactlyMatchBlockEntities=True,foreignLogicalContributionsUnchanged=True,allShapeTablesAndMembershipsUnchanged=True,regionsByteIdenticalToStage1=True,shards=receipts)
    write(target.parent/'receipt.json',report);print(json.dumps({k:v for k,v in report.items() if k!='shards'},indent=2))

if __name__=='__main__':main()
