"""Bind .22 to the accepted .20 resources and retain every previous runtime class."""
import json,struct,zipfile
from prepare_workspace import RUN,sha,write

def main():
    old=RUN/'candidates/dreamwalker-bb-visual4-rc3-dwfix.20.jar'
    new=RUN/'candidates/dreamwalker-bb-visual4-rc3-dwfix.22.jar'
    recorded=json.loads((RUN/'v22-byte-bound-change.json').read_text(encoding='utf-8'))
    expected={'assets/bloodborne_dw/native_grid/'+n for n in ['catalog.json','selection-bounds.bin','visual-repairs.json','visual_physics.json']}
    expected|={'bloodborne_dw/repair/native-benches.json','bloodborne_dw/repair/native-windows.json','dw-archive-repair.mixins.json','fabric.mod.json'}
    assert set(recorded['changedEntries'])==expected and not recorded['removedEntries']
    assert set(recorded['addedEntries'])=={'assets/bloodborne_dw/blockstates/native_physics_204.json','assets/bloodborne_dw/models/item/native_physics_204.json','bloodborne_dw/repair/bench-surfaces.json','dev/dreamwalker/bloodbornedw/composite/DwBenchSurfaces$Key.class','dev/dreamwalker/bloodbornedw/composite/DwBenchSurfaces.class','dev/dreamwalker/bloodbornedw/repair/mixin/BenchSurfaceFootprintMixin.class'}
    assert recorded['fromSha256']==sha(old) and recorded['toSha256']==sha(new)
    with zipfile.ZipFile(old) as a,zipfile.ZipFile(new) as b:
        read=lambda z,p:json.loads(z.read(p))
        directory='assets/bloodborne_dw/native_grid/'
        ac=read(a,directory+'catalog.json');bc=read(b,directory+'catalog.json')
        for name in ac:
            assert (bc[name][:len(ac[name])]==ac[name]) if isinstance(ac[name],list) else bc[name]==ac[name]
        for filename in [directory+'visual-repairs.json','bloodborne_dw/repair/native-windows.json']:
            x=read(a,filename);y=read(b,filename);x.pop('catalogSha256');y.pop('catalogSha256');assert x==y
        x=read(a,directory+'visual_physics.json');y=read(b,directory+'visual_physics.json')
        for name in ['cellToPhysics','representatives','physicsLayers','physicsAmbient']:
            assert y[name][:len(x[name])]==x[name]
        assert x['wholeBanks']==y['wholeBanks'] and x['catalogSha256'] in y['compatibleCatalogs']
        x=read(a,'bloodborne_dw/repair/native-benches.json');y=read(b,'bloodborne_dw/repair/native-benches.json')
        for before,after in zip(x['templates'],y['templates']):
            assert before.keys()==after.keys()
            for field in before:
                if field in ['cells','triggers']:
                    assert len(before[field])==len(after[field])
                    for u,v in zip(before[field],after[field]):
                        assert u[:3]==v[:3] and u[4:]==v[4:]
                        left={k:value for k,value in ac['cells'][u[3]].items() if k not in ['collision','key']}
                        right={k:value for k,value in bc['cells'][v[3]].items() if k not in ['collision','key']}
                        assert left==right
                else:assert before[field]==after[field]
        assert len(x['templates'])==len(y['templates'])==42
        before=a.read(directory+'selection-bounds.bin');after=b.read(directory+'selection-bounds.bin')
        ao=6+struct.unpack_from('>H',before,4)[0];bo=6+struct.unpack_from('>H',after,4)[0];count=struct.unpack_from('>I',before,ao)[0]
        assert len(before)==ao+4+count*28 and before[ao+4:]==after[bo+4:bo+4+count*28]
        for name in a.namelist():
            if name.endswith('.class') or name.endswith('.png'):
                assert a.read(name)==b.read(name),name
        assert a.read('bloodborne_dw/composite/source_hold_bench.json')==b.read('bloodborne_dw/composite/source_hold_bench.json')
    recorded.update(status='BENCH_SURFACE_ONLY_CHANGE_SCOPE_PASS',candidateSha256=sha(new),referenceSha256=sha(old),allExistingRuntimeClassesAndPngByteIdentical=True,allOldCatalogAndPhysicsPrefixesIdentical=True,windowRecipesAndOtherVisualRepairsUnchanged=True,benchAimAndGeometryUnchanged=True,originalBenchDescriptorUnchanged=True)
    write(RUN/'v22-byte-bound-change.json',recorded)
    print(recorded['status'])

if __name__=='__main__':main()
