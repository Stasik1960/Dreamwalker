"""Compare retained mixed-cell post feet against the canonical model before reuse."""
import collections,json,struct,zipfile
from discover_native_lanterns import sig
from native_model_baker import bake,cell_quads
from prepare_workspace import RUN,BASE,write
D='assets/bloodborne_dw/native_grid/'

def main():
    c=json.loads((RUN/'native-overlay'/D/'catalog.json').read_text(encoding='utf-8'));raw=(RUN/'native-overlay'/D/'meshes.bin').read_bytes();meshes=[];cursor=8;materials=c['materials'];by_sprite={m['sprite']:i for i,m in enumerate(materials)}
    for m in c['meshes']:
        n=struct.unpack_from('>I',raw,cursor)[0];meshes.append(raw[cursor+4:cursor+4+n*139]);cursor+=4+n*139
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        def model(id):
            ns,path=id.split(':');d=json.loads(z.read('assets/'+ns+'/models/'+path+'.json'))
            if 'parent' in d:
                b=model(d['parent']);textures=b.get('textures',{}).copy();textures.update(d.get('textures',{}));b.update(d);b['textures']=textures;d=b
            return d
        spec=json.loads(z.read('bloodborne_dw/composite/source_street_lamp_post.json'));parts=spec['variants'][0]['poses']['closed']['parts'];expected={}
        for i in [0,1]:expected[i]=cell_quads(bake(model(parts[i]['model']),offset=[0,0,0],yaw=0,layer='cutout'),lambda sprite,layer:by_sprite[sprite])
    results=[]
    for a in json.loads((RUN/'task11-red-post-columns.json').read_text(encoding='utf-8'))['anchors']:
        for row in a['column']:
            if row['dy'] not in [-5,-4] or row['native'] is None:continue
            blob=meshes[c['cells'][row['native']]['mesh']];actual={sig(blob[at:at+139],materials) for at in range(0,len(blob),139)};wanted=[sig(q,materials) for q in expected[row['dy']+5].get((0,0,0),[])];results.append(dict(dimension=a['dimension'],pos=row['pos'],visual=row['native'],matched=sum(q in actual for q in wanted),expected=len(wanted),canonicalPartUnchanged=all(q in actual for q in wanted)))
    write(RUN/'task11-native-post-base-proof.json',dict(cells=results));print(json.dumps(results,indent=2))

if __name__=='__main__':main()
