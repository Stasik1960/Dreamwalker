"""Finite static recipe removal closures preserve every unrelated component exactly."""
import collections,json,zipfile
from prepare_workspace import BASE,RUN,write

def fragment_key(f):return f['pose'],tuple(f['origin']),f['member']

def main():
    source=json.loads((RUN/'task11-static-lantern-preflight.json').read_text(encoding='utf-8'));cells={};objects=[]
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:catalog=json.loads(z.read('bloodborne_dw/static-architecture-v1274.json'))
    recipes=catalog['recipes']
    for g in source['groups']:
        pose=g['pose'];root=g['root'];bounds=pose['reviewedVisualBounds'];centre=[root[i]+(bounds[0][i]+bounds[1][i])/2 for i in range(3)];kind=pose['registryId'];post=kind=='bloodborne_dw:source_dead_fire_coral_block'
        objects.append(dict(dimension='overworld' if g['dimension']==0 else 'bloodborne_old',root=root,registryId=kind,post=post,desiredLamp=[round(centre[i]-[.5,.875,.5][i]) for i in range(3)],centre=centre))
        for entry in g['cells']:
            key=g['dimension'],*entry['pos'];old=entry['recipe'];f=recipes[old]['fragments'][entry['fragment']];row=cells.setdefault(key,dict(old=old,remove=set()));assert row['old']==old;row['remove'].add(fragment_key(f))
    result=[]
    for key,row in sorted(cells.items()):
        index=row['old'];before=recipes[index]['fragments'];remaining=[f for f in before if fragment_key(f) not in row['remove']]
        for target in sorted(row['remove']):
            assert index>=0
            current=recipes[index];at=next(i for i,f in enumerate(current['fragments']) if fragment_key(f)==target);index=current['remove'][at]
        assert ([] if index<0 else recipes[index]['fragments'])==remaining
        result.append(dict(dimension='overworld' if key[0]==0 else 'bloodborne_old',pos=key[1:],old=row['old'],next=index))
    report=dict(status='EXACT_FINITE_REMOVAL_CLOSURES_PASS_NO_MAP_WRITES',objects=len(objects),cells=len(result),postReplacements=sum(o['post'] for o in objects),singleReplacements=sum(not o['post'] for o in objects),mixedCellsRetained=sum(c['next']>=0 for c in result))
    write(RUN/'task11-static-removal-plan.json',dict(report=report,cells=result,objects=objects));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
