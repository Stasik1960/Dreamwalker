"""Find remaining owned/vanilla lanterns by their exact saved palette ids."""
import json,subprocess,sys
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile,compound,section_blocks,block_state_key

def main():
    world=RUN/'native-window-world-8e38b14da7b5-r1/bloodborne';kinds=set(json.loads((RUN/'task11-static-lantern-preflight.json').read_text(encoding='utf-8'))['types'])|{'bloodborne_dw:source_soul_lantern','minecraft:lantern','minecraft:soul_lantern'};found=[]
    for dim,directory in [('overworld','region'),('bloodborne_old','dimensions/bloodborne_dw/bloodborne_old/region')]:
        for path in sorted((world/directory).glob('r.*.*.mca')):
            subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)
            rx,rz=map(int,path.stem.split('.')[1:])
            for chunk in RegionFile.open(path).chunks():
                root=compound(chunk.nbt().root)
                for section in root['sections'].value:
                    fields=compound(section);bs=fields.get('block_states')
                    if bs is None:continue
                    palette=compound(bs)['palette'].value;names=[compound(p)['Name'].value for p in palette];wanted={i for i,n in enumerate(names) if n in kinds}
                    if not wanted:continue
                    palette,indices=section_blocks(section);sy=fields['Y'].value
                    for local,i in enumerate(indices):
                        if i in wanted:found.append(dict(dimension=dim,pos=[rx*512+chunk.x*16+(local&15),sy*16+(local>>8),rz*512+chunk.z*16+((local>>4)&15)],state=block_state_key(palette[i])))
            write(RUN/'task11-managed-lantern-progress.json',dict(region=str(path),found=len(found)))
    write(RUN/'task11-managed-lantern-preflight.json',dict(status='EXACT_PALETTE_POSITIONS_NO_WRITES',lamps=found));print(json.dumps(dict(found=len(found),byType=dict(__import__('collections').Counter(p['state'].split('[')[0] for p in found))),indent=2))

if __name__=='__main__':main()
