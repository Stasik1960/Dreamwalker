"""Apply the preflighted inert-cell inventory to the candidate, with a region checkpoint."""
import collections
import copy
import json
from pathlib import Path
import shutil
import sys
from prepare_workspace import RUN,sha,write
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import (RegionFile,compound,section_blocks,block_state_key,Tag,TAG_STRING,TAG_COMPOUND,
                      TAG_LIST,TAG_LONG_ARRAY,TAG_INT_ARRAY,pack_palette_indices,unpack_palette_indices)


def block_table(root):
    return {compound(s)['Y'].value:([block_state_key(p) for p in data[0]],data[1])
            for s in root['sections'].value if (data:=section_blocks(s))}


def entries(root):
    return {(compound(s)['Y'].value,v&4095):(v&0xffffffff)>>12
            for s in compound(root['DreamwalkerVisuals'])['Sections'].value for v in compound(s)['Entries'].value}


def metadata(root):
    root=copy.deepcopy(root)
    for s in root['sections'].value:compound(s).pop('block_states',None)
    compound(root['DreamwalkerVisuals']).pop('Sections')
    if 'Heightmaps' in root:
        for key in ['WORLD_SURFACE','WORLD_SURFACE_WG']:compound(root['Heightmaps']).pop(key,None)
    return root


def verify(before,after,selected):
    assert metadata(before)==metadata(after),'Unrelated chunk NBT changed'
    old,new=block_table(before),block_table(after);changed=set()
    assert old.keys()==new.keys()
    for sy,(palette,indices) in old.items():
        p2,i2=new[sy]
        for i in range(4096):
            a,b=palette[indices[i]],p2[i2[i]]
            if a!=b:
                assert b=='minecraft:air' and (sy,i) in selected
                changed.add((sy,i))
    assert changed==selected,'Missing or extra block removal'
    assert entries(after)=={k:v for k,v in entries(before).items() if k not in selected}
    minimum=before['yPos'].value*16
    columns={(i&15,(i>>4)&15) for sy,i in selected}
    for key,tag in compound(before['Heightmaps']).items():
        if key not in ['WORLD_SURFACE','WORLD_SURFACE_WG']:continue
        heights=unpack_palette_indices(tag.value,512,256)
        actual=unpack_palette_indices(compound(after['Heightmaps'])[key].value,512,256)
        for z in range(16):
            for x in range(16):
                index=z*16+x;expected=heights[index]
                if (x,z) in columns and ((expected+minimum-1)>>4,(((expected+minimum-1)&15)<<8)|(z<<4)|x) in selected:
                    expected=0
                    for sy in sorted(new,reverse=True):
                        p,i=new[sy]
                        found=next((sy*16+y-minimum+1 for y in range(15,-1,-1) if p[i[(y<<8)|(z<<4)|x]] not in
                                    ['minecraft:air','minecraft:cave_air','minecraft:void_air']),None)
                        if found is not None:expected=found;break
                assert actual[index]==expected,'Incorrect heightmap change'


def verify_region(original,saved,allowed):
    for chunk in original.chunks():
        other=saved.get_chunk(chunk.x,chunk.z)
        if (chunk.x,chunk.z) in allowed:
            verify(compound(chunk.nbt().root),compound(other.nbt().root),allowed[chunk.x,chunk.z])
        else:assert chunk.compressed_payload==other.compressed_payload and chunk.timestamp==other.timestamp


def main():
    report=RUN/'task13-inert-removal.json';assert not report.exists(),'Already applied'
    census=json.loads((RUN/'task13-inert-census.json').read_text(encoding='utf-8'))
    assert census['catalogHeaders']==[census['catalogSha256']]
    checkpoint=RUN/'checkpoints/pre-task13'
    checkpoint.mkdir(parents=True,exist_ok='--resume' in sys.argv)
    receipts=[];removed=0
    for directory,dimension in census['dimensions'].items():
        groups=collections.defaultdict(list)
        for c in dimension['chunks']:groups[c['region']].append(c)
        for name,chunks in groups.items():
            path=RUN/'world/bloodborne'/directory/name;backup=checkpoint/directory/name
            allowed={(c['cx']&31,c['cz']&31):{(sy,i) for sy,i,cell in c['cells']} for c in chunks}
            backup.parent.mkdir(parents=True,exist_ok=True)
            if backup.exists():
                assert '--resume' in sys.argv
                if sha(backup)!=sha(path):verify_region(RegionFile.open(backup),RegionFile.open(path),allowed)
            else:shutil.copy2(path,backup)
            region=RegionFile.open(backup)
            for c in chunks:
                chunk=region.get_chunk(c['cx']&31,c['cz']&31);nbt=chunk.nbt();root=compound(nbt.root);before=copy.deepcopy(root)
                selected={(sy,i) for sy,i,cell in c['cells']};by_section=collections.defaultdict(set)
                for sy,i,cell in c['cells']:
                    assert entries(before)[sy,i]==cell;by_section[sy].add(i)
                for section in root['sections'].value:
                    fields=compound(section);sy=fields['Y'].value
                    if sy not in by_section:continue
                    palette,indices=section_blocks(section)
                    air=next((i for i,p in enumerate(palette) if block_state_key(p)=='minecraft:air'),None)
                    if air is None:air=len(palette);palette.append(Tag(TAG_COMPOUND,{'Name':Tag(TAG_STRING,'minecraft:air')}))
                    for i in by_section[sy]:indices[i]=air
                    fields['block_states']=Tag(TAG_COMPOUND,{'palette':Tag(TAG_LIST,palette,TAG_COMPOUND),
                                      'data':Tag(TAG_LONG_ARRAY,pack_palette_indices(indices,len(palette)))})
                table=compound(root['DreamwalkerVisuals']);kept=[]
                for row in table['Sections'].value:
                    data=compound(row);sy=data['Y'].value
                    data['Entries']=Tag(TAG_INT_ARRAY,[v for v in data['Entries'].value if (sy,v&4095) not in selected])
                    if data['Entries'].value:kept.append(row)
                table['Sections'].value=kept
                blocks=block_table(root);minimum=root['yPos'].value*16
                for key,tag in compound(root['Heightmaps']).items():
                    if key not in ['WORLD_SURFACE','WORLD_SURFACE_WG']:continue
                    heights=unpack_palette_indices(tag.value,512,256)
                    for x,z in {(i&15,(i>>4)&15) for sy,i in selected}:
                        h=heights[z*16+x]+minimum-1
                        if (h>>4,((h&15)<<8)|(z<<4)|x) not in selected:continue
                        heights[z*16+x]=0
                        for sy in sorted(blocks,reverse=True):
                            p,indices=blocks[sy]
                            ys=[y for y in range(16) if p[indices[(y<<8)|(z<<4)|x]] not in ['minecraft:air','minecraft:cave_air','minecraft:void_air']]
                            if ys:heights[z*16+x]=sy*16+max(ys)-minimum+1;break
                    tag.value=pack_palette_indices(heights,512)
                verify(before,root,selected)
                region.set_chunk(c['cx']&31,c['cz']&31,nbt,timestamp=chunk.timestamp)
                removed+=len(selected)
            region.save(path)
            # Re-read the saved Anvil container independently of the mutated in-memory tree.
            verify_region(RegionFile.open(backup),RegionFile.open(path),allowed)
            receipts.append(dict(path=str(path.relative_to(RUN/'world/bloodborne')),before=sha(backup),after=sha(path)))
            write(checkpoint/'progress.json',dict(removed=removed,regions=receipts))
    write(report,dict(status='OFFLINE_SEMANTIC_GATE_PASS_GAMEPLAY_PENDING',removed=removed,regions=receipts,
                      checkpoint=str(checkpoint),entitiesRemoved=0,collisionLightFluidChanges=0))
    print(json.dumps(dict(removed=removed,regions=len(receipts),offlineSemanticGate='PASS'),indent=2))


if __name__=='__main__':main()
