"""Compare each recorded visit; keep summaries separate from acceptance gates."""
import argparse
import collections
import json
import statistics
from pathlib import Path
from prepare_workspace import RUN, sha, write

BASELINE_SHA = 'd45c4d59386f9539e38272eb7db5b5da2df48f49d66ffc1ef6b9caf171780f36'


def load(label):
    assert label.replace('-', '').isalnum()
    folder = RUN / 'runs' / label
    plan, report, receipt = [json.loads(p.read_text(encoding='utf-8')) for p in
        [folder/'plan.json', folder/'client/evidence/qa.json', folder/'receipt.json']]
    assert report['status'] == 'PASS' and report['saved'] and receipt['exitCode'] == 0
    assert plan['maxFps'] == 260 and plan['renderDistance'] == 12 and plan['heapGb'] == 8
    assert len(report['phases']) == len(plan['phases']) == 12
    for row, planned in zip(report['phases'], plan['phases']):
        assert row['name'] == planned['name']
        assert row['terrainComplete'] and row['allViewChunksDelivered'] and row['windowFocused']
        assert row['configuredMaxFps'] == 260 and row['steadyFrames']['frames'] >= 1800
        if 'simulationDistance' in plan:
            assert row['configuredSimulationDistance'] == plan['simulationDistance']
        assert abs((row['actualYaw']-row['yaw']+180) % 360-180) < .1
        assert abs(row['actualPitch']-row['pitch']) < .1
    return plan, report, receipt


def compare(baseline, candidate):
    a, ar, ac = load(baseline)
    b, br, bc = load(candidate)
    assert a['phases'] == b['phases'] and ac['qaSha256'] == bc['qaSha256']
    assert ac['candidateSha256'] == BASELINE_SHA
    assert all(a.get(k) == b.get(k) for k in ['maxFps', 'renderDistance', 'heapGb', 'fixedTime', 'simulationDistance'])
    visits = []
    for index, (old, new) in enumerate(zip(ar['phases'], br['phases'])):
        assert old['actualPosition'] == new['actualPosition']
        so, sn = old['steadyFrames'], new['steadyFrames']
        checks = {
            'meanFpsWithinTenPercent': sn['meanFps'] >= so['meanFps']*.9,
            'steadyP99WithinTenPercent': sn['p99Ms'] <= so['p99Ms']*1.1,
            'noNewSteadyStallAbove250ms': sn['maximumMs'] <= max(250, so['maximumMs']*1.1),
        }
        travel = None
        if index != 0:
            lo, ln = old['loadingFrames'], new['loadingFrames']
            checks.update({
                'travelReadyAndSettleWithinTenPercent': ln['readyAndSettleSeconds'] <= lo['readyAndSettleSeconds']*1.1,
                'travelP99WithinTenPercent': ln['p99Ms'] <= lo['p99Ms']*1.1,
                'noNewTravelStallAbove250ms': ln['maximumMs'] <= max(250, lo['maximumMs']*1.1),
            })
            travel = dict(baseline=lo, candidate=ln,
                readyAndSettleChangePercent=(ln['readyAndSettleSeconds']/lo['readyAndSettleSeconds']-1)*100)
        visits.append(dict(phase=old['name'], camera=old['name'].rsplit('-visit', 1)[0],
            fpsChangePercent=(sn['meanFps']/so['meanFps']-1)*100,
            steady=dict(baseline=so, candidate=sn), travel=travel,
            checks=checks, violations=[k for k, passed in checks.items() if not passed]))
    keys = set().union(*(v['checks'] for v in visits))
    gates = {k: all(v['checks'].get(k, True) for v in visits) for k in sorted(keys)}
    groups = collections.defaultdict(list)
    for visit in visits:
        groups[visit['camera']].append(visit)
    summaries = []
    for camera, rows in groups.items():
        assert len(rows) == 2
        summaries.append(dict(camera=camera, informationalOnly=True,
            baselineMeanFps=1000/statistics.mean(r['steady']['baseline']['meanMs'] for r in rows),
            candidateMeanFps=1000/statistics.mean(r['steady']['candidate']['meanMs'] for r in rows),
            violatingVisits=[r['phase'] for r in rows if r['violations']]))
    return dict(schemaVersion=2, status='PASS' if all(gates.values()) else 'REVIEW_REQUIRED',
        baseline=baseline, candidate=candidate, baselineSha256=ac['candidateSha256'],
        candidateSha256=bc['candidateSha256'], qaSha256=ac['qaSha256'], gates=gates,
        baselineWorld=str(Path(ac['world']).resolve()), candidateWorld=str(Path(bc['world']).resolve()),
        visits=visits, cameraSummaries=summaries,
        evidence={label: {name: sha(RUN/'runs'/label/name) for name in
            ['plan.json', 'receipt.json', 'client/evidence/qa.json']} for label in [baseline, candidate]},
        conditions=dict(renderDistance=12, maximumFpsSetting=260, heapGb=8,
            simulationDistanceSetting=a.get('simulationDistance'),
            fullRegisteredClientPack=True, sameRouteAndTwoVisits=True,
            firstWorldPreparationExcludedFromTravelGates=True,
            readinessMetric='Time to terrain/chunk readiness including configured 160 settle ticks; not disk I/O time.',
            acceptance='Each visit: user 10% limit for mean FPS and ready time; p99 and >250ms stalls are conservative smoothness review gates.'),
        initialWorldPreparation=dict(baseline=ar['phases'][0]['loadingFrames'],
            candidate=br['phases'][0]['loadingFrames'], includedInTenPercentTravelGates=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('baseline')
    parser.add_argument('candidate')
    parser.add_argument('--output', type=Path, default=RUN/'performance-comparison.json')
    args = parser.parse_args()
    assert args.output.resolve().is_relative_to(RUN.resolve())
    result = compare(args.baseline, args.candidate)
    write(args.output, result)
    print(json.dumps({k: result[k] for k in ['status', 'baseline', 'candidate', 'gates']}, indent=2))
    print('Report:', args.output)


def accepted_performance(expected, world):
    """Keep the raw diagnostic failure and the scoped user acceptance as separate records."""
    import math
    path = RUN/'performance-acceptance.json'
    if not path.is_file():
        return None
    accepted = json.loads(path.read_text(encoding='utf-8'))
    assert accepted['status'] == 'ACCEPTED_WITH_NOTES'
    assert accepted['candidateSha256'] == expected and Path(accepted['acceptedWorld']).resolve() == world.resolve()
    raw_path = RUN/'performance-comparison.json'
    assert sha(raw_path) == accepted['rawComparisonSha256']
    raw = json.loads(raw_path.read_text(encoding='utf-8'))
    assert raw['candidateSha256'] == expected
    assert all(raw['gates'][key] for key in ['meanFpsWithinTenPercent',
        'noNewSteadyStallAbove250ms','noNewTravelStallAbove250ms'])
    for visit in raw['visits']:
        if visit['travel'] and not visit['checks']['travelReadyAndSettleWithinTenPercent']:
            assert visit['phase'] == 'perf-old-city-visit2'
            assert visit['travel']['readyAndSettleChangePercent'] <= 11.2
            assert accepted['userAcceptedLoadingException']['phase'] == visit['phase']
    if Path(raw['candidateWorld']).resolve() != world.resolve():
        heightmap_path = world.parent/'heightmap-import-receipt.json'
        assert sha(heightmap_path) == accepted['cacheForwardReceiptSha256']
        cache = json.loads(heightmap_path.read_text(encoding='utf-8'))
        assert cache['status'] == 'PERSISTED_HEIGHTMAP_ONLY_GATE_PASS'
        assert cache['candidateSha256'] == expected and cache['sourceRun'] == raw['candidate']
        assert Path(cache['inputWorld']).resolve() == Path(raw['candidateWorld']).resolve()
        assert Path(cache['outputWorld']).resolve() == world.resolve()
        assert cache['allOtherChunkFieldsAndUntouchedCompressedPayloadsIdentical']
        plan = json.loads((RUN/'runs'/raw['candidate']/'plan.json').read_text(encoding='utf-8'))
        margin = plan['renderDistance']+2
        for chunk in cache['importedChunks']:
            assert all(chunk['dimension'] != phase['dimension'] or
                abs(chunk['x']-math.floor(phase['x']/16)) > margin or
                abs(chunk['z']-math.floor(phase['z']/16)) > margin for phase in plan['phases'])
    return accepted


if __name__ == '__main__':
    main()
