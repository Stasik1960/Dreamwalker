"""Repair sided glass and exposed open-door edges without moving the hinges."""
import copy
import json
from pathlib import Path
import zipfile
from prepare_workspace import BASE,RUN,write
from door_surfaces import rebuild,mirrored
from repair_door_90986 import silhouette_edges


def texture(model,face):
    value=face['texture']
    while value.startswith('#'):value=model['textures'][value[1:]]
    return value


def glass_back(model):
    count=0
    for e in model['elements']:
        face=e.get('faces',{}).get('north')
        if face and texture(model,face).endswith('/window_3') and abs(e['from'][2]-7)<1e-6:
            assert set(e['faces'])=={'north'} and e['from'][2]==e['to'][2]
            e['faces']={'south':mirrored(face)};count+=1
    return count


def ornament_backs(model,archive,with_caps):
    added=[]
    for e in list(model['elements']):
        face=e.get('faces',{}).get('north')
        if not face or texture(model,face).endswith('/window_3') or e['from'][2]!=e['to'][2]:continue
        if round(e['from'][2],6) not in {.75,1.75,2.75}:continue
        back=copy.deepcopy(e);back['from'][2]+=.25;back['to'][2]+=.25
        back['faces']={'south':mirrored(face)};added.append(back)
        if with_caps:
            volume=copy.deepcopy(e);volume['to'][2]+=.25
            added.extend(silhouette_edges(model,volume,archive))
    model['elements'].extend(added)
    return len(added)


def main():
    output=Path(__file__).resolve().parent/'src/main/resources';receipt={};changes={}
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as archive:
        for number,registry,depths in [(93152,'source_birch_grille_door',{.75:.25,1.:4.,1.75:.25,2.75:.25,5.:2.,6.25:.75,7.:.25}),
                                       (93153,'source_dark_arch_door',{5.:4.})]:
            descriptor=json.loads(archive.read('bloodborne_dw/composite/'+registry+'.json'))
            refs={p['model'] for p in descriptor['variants'][0]['poses']['open']['parts']}
            for ref in sorted(refs):
                name='assets/'+ref.replace(':','/models/',1)+'.json';model=json.loads(archive.read(name))
                if not any('north' in e.get('faces',{}) for e in model['elements']):continue
                stat={}
                if number==93152:
                    stat['correctedGlassBacks']=glass_back(model)
                    stat['newOrnamentBacks']=ornament_backs(model,archive,False)
                stat.update(rebuild(model,depths,mirror_back=False))
                changes[name]=model;receipt[name]=stat
        name='assets/bloodborne_dw/models/remaining/source/minecraft/block/bir_door_2.json'
        model=json.loads(archive.read(name));stat={'correctedGlassBacks':glass_back(model)}
        assert stat['correctedGlassBacks']==1
        stat['ornamentBackAndSideFaces']=ornament_backs(model,archive,True)
        changes[name]=model;receipt[name]=stat
    for name,model in changes.items():write(output/name,model)
    write(RUN/'task06-07-resource-repair.json',dict(status='DRAFT_REQUIRES_GAME_AND_PERFORMANCE_VALIDATION',
          models=receipt,hingesAndCollisionUnchanged=True,originalTexturePixelsUnchanged=True))
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
