"""Apply the reviewed exterior trim to the release candidate only; retain all ownership NBT."""
import collections
import copy
import json
from pathlib import Path
import shutil
import sys
from prepare_workspace import RUN,sha,write
from remove_inert_cells import block_table
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import (RegionFile,compound,section_blocks,block_state_key,Tag,TAG_STRING,TAG_COMPOUND,
                      TAG_LIST,TAG_LONG_ARRAY,pack_palette_indices,invalidate_chunk_lighting)


def metadata(root):
    root=copy.deepcopy(root);invalidate_chunk_lighting(root);root.pop('Heightmaps',None)
    for section in root['sections'].value:compound(section).pop('block_states',None)
    return root


def verify(before,after,allowed):
    assert metadata(before)==metadata(after),'Changed unrelated NBT, visuals or ownership'
    assert compound(after['Heightmaps'])=={},'Heightmaps must be regenerated with Minecraft predicates'
    old,new=block_table(before),block_table(after);changed=set()
    assert old.keys()==new.keys()
    for sy,(palette,indices) in old.items():
        p2,i2=new[sy]
        for i in range(4096):
            if palette[indices[i]]!=p2[i2[i]]:
                assert (sy,i) in allowed and p2[i2[i]]=='minecraft:air'
                changed.add((sy,i))
    assert changed==allowed


def main():
    report=RUN/'task01-trim-applied.json';assert not report.exists()
    plan=json.loads((RUN/'task01-trim-plan-final.json').read_text(encoding='utf-8'));groups=collections.defaultdict(lambda:collections.defaultdict(list))
    for x,y,z,state in plan['cells']:
        assert state!='bloodborne_dw:city_darkness'
        groups[x>>9,z>>9][x>>4,z>>4].append((x,y,z,state))
    checkpoint=RUN/'checkpoints/pre-task01';checkpoint.mkdir(parents=True,exist_ok=False)
    receipts=[];total=0
    for (rx,rz),chunks in sorted(groups.items()):
        path=RUN/'world/bloodborne/region'/f'r.{rx}.{rz}.mca';backup=checkpoint/path.name;shutil.copy2(path,backup)
        region=RegionFile.open(path);allowed_chunks={}
        for (cx,cz),cells in chunks.items():
            chunk=region.get_chunk(cx&31,cz&31);nbt=chunk.nbt();root=compound(nbt.root);before=copy.deepcopy(root)
            by_section=collections.defaultdict(dict)
            for x,y,z,state in cells:by_section[y>>4][((y&15)<<8)|((z&15)<<4)|(x&15)]=state
            allowed={(sy,i) for sy,values in by_section.items() for i in values};allowed_chunks[cx&31,cz&31]=allowed
            for section in root['sections'].value:
                fields=compound(section);sy=fields['Y'].value
                if sy not in by_section:continue
                palette,indices=section_blocks(section);names=[block_state_key(p) for p in palette]
                air=next((i for i,name in enumerate(names) if name=='minecraft:air'),None)
                if air is None:air=len(palette);palette.append(Tag(TAG_COMPOUND,{'Name':Tag(TAG_STRING,'minecraft:air')}))
                for index,state in by_section[sy].items():
                    assert names[indices[index]]==state,'Input map changed after trim preflight'
                    indices[index]=air
                fields['block_states']=Tag(TAG_COMPOUND,{'palette':Tag(TAG_LIST,palette,TAG_COMPOUND),
                                   'data':Tag(TAG_LONG_ARRAY,pack_palette_indices(indices,len(palette)))})
            invalidate_chunk_lighting(root)
            root['Heightmaps']=Tag(TAG_COMPOUND,{})
            verify(before,root,allowed);region.set_chunk(cx&31,cz&31,nbt,timestamp=chunk.timestamp);total+=len(cells)
        region.save(path);original=RegionFile.open(backup);saved=RegionFile.open(path)
        for chunk in original.chunks():
            other=saved.get_chunk(chunk.x,chunk.z)
            if (chunk.x,chunk.z) in allowed_chunks:verify(compound(chunk.nbt().root),compound(other.nbt().root),allowed_chunks[chunk.x,chunk.z])
            else:assert chunk.compressed_payload==other.compressed_payload and chunk.timestamp==other.timestamp
        receipts.append(dict(region=path.name,before=sha(backup),after=sha(path),chunks=len(chunks)))
        write(checkpoint/'progress.json',dict(total=total,regions=receipts))
    assert total==len(plan['cells'])==24419
    write(report,dict(status='OFFLINE_SCOPE_GATE_PASS_FINAL_GAMEPLAY_AND_RELIGHT_PENDING',removed=total,
          regions=receipts,checkpoint=str(checkpoint),entitiesChanged=0,nativeVisualsChanged=0,cityDarknessChanged=0))
    print(json.dumps(dict(removed=total,regions=len(receipts),scopeGate='PASS',heightmaps='REGENERATE_IN_GAME'),indent=2))


if __name__=='__main__':main()
