"""Append proven missing native source faces, preserving all original indices and behavior."""
import copy,hashlib,json,shutil,struct
import numpy as np
from prepare_workspace import RUN,sha,write
from compile_native_windows import canonical,DIRECTORY

def main():
    output=RUN/'native-overlay';source=RUN/'native-overlay-stage09'
    if not source.exists():shutil.copytree(output,source)
    manifest=json.loads((source/'manifest.json').read_text(encoding='utf-8'));assert manifest['catalogSha256']=='8e38b14da7b53cf2363cfb98dd5fdb3881783945134e15d8d8b74eba57a26981'
    original_bytes=(source/DIRECTORY/'catalog.json').read_bytes();catalog=json.loads(original_bytes);original=copy.deepcopy(catalog);layout=json.loads((source/DIRECTORY/'visual_physics.json').read_text(encoding='utf-8'));old_layout=copy.deepcopy(layout)
    raw=(source/DIRECTORY/'meshes.bin').read_bytes();meshes=[];cursor=8
    for m in catalog['meshes']:n=struct.unpack_from('>I',raw,cursor)[0];meshes.append(raw[cursor+4:cursor+4+n*139]);cursor+=4+n*139
    assert cursor==len(raw);plan=json.loads((RUN/'task12-wall-restoration-plan.json').read_text(encoding='utf-8'))
    windows={ (c['dimension'],*c['pos']) for c in json.loads((RUN/'task09-native-window-map-plan.json').read_text(encoding='utf-8'))['cells'] }
    benches=json.loads((RUN/'task08-native-bench-coverage.json').read_text(encoding='utf-8'))
    assert not windows.intersection((c['dimension'],*c['pos']) for c in plan['cells']),'Window composition must be regenerated if affected'
    def empty(cell):return not any(cell[k] for k in ['collision','outline','culling','climbing','optics']) and cell.get('fluid') is None and cell.get('localFunction') is None and cell.get('alt',-1)<0 and cell.get('baseState') is None
    empty_id=next(i for i,c in enumerate(catalog['cells']) if empty(c) and catalog['meshes'][c['mesh']]['quadCount']==0 and layout['cellToPhysics'][i]>=0)
    semantics=lambda cell:{k:v for k,v in cell.items() if k not in ['key','mesh','displayName']}
    bounds={};mapping={};rank={'solid':0,'cutout_mipped':1,'cutout':2,'translucent':3}
    for sid,scene in plan['scenes'].items():
        old=scene['old'];base=original['cells'][empty_id if old is None else old];cell=copy.deepcopy(base);old_blob=b'' if old is None else meshes[base['mesh']];extra=bytes.fromhex(scene['quads']);blob=old_blob+extra
        cell['mesh']=len(catalog['meshes']);catalog['meshes'].append(dict(quadCount=len(blob)//139));meshes.append(blob)
        cell.pop('key');cell['displayName']='Каменная облицовка';cell['key']=hashlib.sha256(('dwfix-wall-source-v1/'+canonical(cell)).encode()).hexdigest();index=len(catalog['cells']);catalog['cells'].append(cell)
        layers=[catalog['materials'][struct.unpack_from('>I',blob,i)[0]]['layer'] for i in range(0,len(blob),139)];layer=max(layers,key=rank.get);ambient=all(blob[i+10]&2 for i in range(0,len(blob),139));same=semantics(cell)
        physical=next((i for i,r in enumerate(layout['representatives']) if semantics(catalog['cells'][r])==same and layout['physicsLayers'][i]==layer and layout['physicsAmbient'][i]==ambient),None)
        if physical is None:physical=len(layout['representatives']);layout['representatives'].append(index);layout['physicsLayers'].append(layer);layout['physicsAmbient'].append(ambient)
        layout['cellToPhysics'].append(physical);mapping[sid]=index
        if cell['outline']==0:
            xyz=np.array([struct.unpack_from('>3f',blob,q+11+32*v) for q in range(0,len(blob),139) for v in range(4)]);lo=xyz.min(axis=0);hi=xyz.max(axis=0)
            for axis in range(3):
                if hi[axis]-lo[axis]<1e-6:lo[axis]=max(0,lo[axis]-1/1024);hi[axis]=min(1,hi[axis]+1/1024)
            bounds[index]=[*map(float,lo),*map(float,hi)]
        assert semantics(cell)==semantics(base) and blob.startswith(old_blob)
    catalog_bytes=canonical(catalog).encode();header=hashlib.sha256(catalog_bytes).hexdigest();layout['catalogSha256']=header
    compat=layout.setdefault('compatibleCatalogs',[])
    if manifest['catalogSha256'] not in compat:compat.append(manifest['catalogSha256'])
    repair=json.loads((source/DIRECTORY/'visual-repairs.json').read_text(encoding='utf-8'));repair['catalogSha256']=header
    window_data=json.loads((source/'bloodborne_dw/repair/native-windows.json').read_text(encoding='utf-8'));window_data['catalogSha256']=header
    old_bounds=(source/DIRECTORY/'selection-bounds.bin').read_bytes();length=struct.unpack_from('>H',old_bounds,4)[0];assert length==64;at=6+length;count=struct.unpack_from('>I',old_bounds,at)[0];assert len(old_bounds)==at+4+count*28
    new_bounds=old_bounds[:4]+struct.pack('>H',64)+header.encode()+struct.pack('>I',count+len(bounds))+old_bounds[at+4:]+b''.join(struct.pack('>i6f',i,*b) for i,b in bounds.items())
    generated={DIRECTORY+'catalog.json':catalog_bytes,DIRECTORY+'visual_physics.json':canonical(layout).encode(),DIRECTORY+'meshes.bin':struct.pack('>II',0x4e475131,len(meshes))+b''.join(struct.pack('>I',len(m)//139)+m for m in meshes),DIRECTORY+'visual-repairs.json':canonical(repair).encode(),DIRECTORY+'selection-bounds.bin':new_bounds,'bloodborne_dw/repair/native-windows.json':canonical(window_data).encode()}
    assert catalog['cells'][:len(original['cells'])]==original['cells'];assert catalog['materials']==original['materials'];assert generated[DIRECTORY+'meshes.bin'][8:8+len(raw)-8]==raw[8:]
    for name,data in generated.items():p=output/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    manifest['catalogSha256']=header;manifest['stages']=dict(windows=hashlib.sha256(original_bytes).hexdigest(),wallSourceRestoration=header)
    for name,data in generated.items():manifest['entries'][name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
    write(output/'manifest.json',manifest)
    cells=[{**row,'next':mapping[row['scene']]} for row in plan['cells']];write(RUN/'task12-wall-native-map-plan.json',dict(sourceCatalogSha256=hashlib.sha256(original_bytes).hexdigest(),catalogSha256=header,cells=cells))
    receipt=dict(status='APPEND_ONLY_DATA_PASS_MAP_GAMEPLAY_PENDING',catalogSha256=header,addedCells=len(mapping),mapCells=len(cells),addedQuads=plan['report']['addedQuads'],originalCellsUnchanged=len(original['cells']),collisionOpticsAndBehaviourUnchanged=True,windowFootprintUnchanged=True,blockEntitiesAdded=0)
    write(RUN/'task12-native-wall-data.json',receipt);print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
