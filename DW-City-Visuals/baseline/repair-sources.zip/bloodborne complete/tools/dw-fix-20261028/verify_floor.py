"""Semantic before/after gate: only authorized floor cells may change block identity."""
import copy
import json

from prepare_workspace import BASE,RUN,sha,write
from darkness_floor import footprint,STATE,Y
from map_reader import *

LIGHT={'BlockLight','SkyLight','starlight.blocklight_state','starlight.skylight_state'}


def main():
    source=BASE/'world/bloodborne'
    target=RUN/'world/bloodborne'
    census=json.loads((RUN/'census.json').read_text(encoding='utf-8'))
    changes=0;chunks=0
    for directory,city in census.items():
        selected=footprint(city['hull'])
        for path in sorted((source/directory).glob('*.mca')):
            old=RegionFile.open(path);new=RegionFile.open(target/path.relative_to(source))
            for before in old.chunks():
                after=new.get_chunk(before.x,before.z)
                assert after is not None
                if before.compressed_payload==after.compressed_payload:continue
                a=compound(before.nbt().root);b=compound(after.nbt().root)
                cx,cz=a['xPos'].value,a['zPos'].value
                assert (cx,cz) in selected
                positions={((Y&15)<<8)|((z&15)<<4)|(x&15) for x,z in selected[cx,cz]}
                for key in (set(a)|set(b))-{'sections','Heightmaps','isLightOn','starlight.light_version'}:
                    assert a.get(key)==b.get(key),(directory,cx,cz,key)
                sections_a={compound(s)['Y'].value:s for s in a['sections'].value}
                sections_b={compound(s)['Y'].value:s for s in b['sections'].value}
                for sy in set(sections_a)|set(sections_b):
                    sa=sections_a.get(sy);sb=sections_b.get(sy)
                    if sy!=Y>>4:
                        af=compound(sa) if sa else {};bf=compound(sb) if sb else {}
                        for key in (set(af)|set(bf))-LIGHT:
                            assert af.get(key)==bf.get(key),(directory,cx,cz,sy,key)
                        continue
                    pa,ia=section_blocks(sa) if sa else ([Tag(TAG_COMPOUND,{'Name':Tag(8,'minecraft:air')})],[0]*4096)
                    pb,ib=section_blocks(sb)
                    keys_a=[block_state_key(p) for p in pa];keys_b=[block_state_key(p) for p in pb]
                    for local in range(4096):
                        aa,bb=keys_a[ia[local]],keys_b[ib[local]]
                        if local in positions:
                            assert bb==STATE
                            changes+=aa!=bb
                        else:
                            assert aa==bb,(directory,cx,cz,sy,local,aa,bb)
                chunks+=1
    assert changes==747136 and chunks==3086,(changes,chunks)
    manifest=json.loads((RUN/'baseline-map-manifest.json').read_text(encoding='utf-8'))
    unchanged=0
    for name,record in manifest.items():
        if name.startswith(('region/','dimensions/bloodborne_dw/bloodborne_old/region/')) and name.endswith('.mca'):continue
        assert sha(target/name)==record['sha256'],name
        assert sha(source/name)==record['sha256'],'Original changed: '+name
        unchanged+=1
    write(RUN/'floor-verification.json',dict(status='PASS',changedBlocks=changes,changedChunks=chunks,
          onlyBlockYChanged=Y,zeroNewBlockEntities=True,unrelatedFilesIdentical=unchanged,
          ownersVisualsAndOtherBlocksPreserved=True,gameplayVerification='PENDING'))
    print('PASS floor: 747136 authorized cells; all other block identities and owner/visual data preserved',flush=True)


if __name__=='__main__':main()
