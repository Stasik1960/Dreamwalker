"""Exact vectorized 1.20.1 palette decoding, retaining the reference decoder's bounds checks."""
import math,numpy as np
from map_reader import MapReader
from world_io import compound,block_state_key,palette_bits

COUNT=4096
INDEX=np.arange(COUNT,dtype=np.uint64)

def section_data(section):
    if section is None or 'block_states' not in compound(section):return ['minecraft:air'],np.zeros(COUNT,dtype=np.uint16)
    data=compound(compound(section)['block_states']);names=[block_state_key(v) for v in data['palette'].value];assert names
    longs=data['data'].value if 'data' in data else []
    if len(names)==1 and not longs:return names,np.zeros(COUNT,dtype=np.uint16)
    bits=palette_bits(len(names));per=64//bits;assert len(longs)==math.ceil(COUNT/per)
    words=np.asarray(longs,dtype=np.int64).view(np.uint64);indices=((words[INDEX//per]>>((INDEX%per)*bits))&((1<<bits)-1)).astype(np.uint16)
    assert int(indices.max())<len(names);return names,indices

def differences(a,b):
    sa={compound(s)['Y'].value:s for s in a['sections'].value};sb={compound(s)['Y'].value:s for s in b['sections'].value}
    for y in sorted(sa.keys()|sb.keys()):
        aa,bb=sa.get(y),sb.get(y);ra=compound(aa).get('block_states') if aa else None;rb=compound(bb).get('block_states') if bb else None
        if ra==rb:continue
        pa,ia=section_data(aa);pb,ib=section_data(bb);ids={name:i for i,name in enumerate(sorted(set(pa)|set(pb)))};ca=np.asarray([ids[n] for n in pa],dtype=np.uint32)[ia];cb=np.asarray([ids[n] for n in pb],dtype=np.uint32)[ib]
        for index in np.flatnonzero(ca!=cb):
            i=int(index);yield y,i,pa[int(ia[i])],pb[int(ib[i])]

def same_blocks(a,b):return next(differences(a,b),None) is None
