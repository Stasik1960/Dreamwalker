"""Rename the 560 equal-physics single lamps into the interactive custom standard.

UUIDs, root positions, per-cell geometry, payload and foreign contributions stay exact.
Other lantern families are a separate migration stage.
"""
import collections,copy,json,shutil,sys
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write,sha
from index_lantern_owners import owner_key
from remove_inert_cells import entries,block_table
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from world_io import *
OLD='bloodborne_dw:source_lantern';NEW='bloodborne_dw:source_standard_lantern'

def invalidate(root):
    root.pop('isLightOn',None);root.pop('starlight.light_version',None)
    for section in root['sections'].value:
        fields=compound(section)
        for key in ['BlockLight','SkyLight','starlight.blocklight_state','starlight.skylight_state']:fields.pop(key,None)

def rename_owner(be,targets):
    result=copy.deepcopy(be);data=decode_nbt(result['OwnerDataV1'].value);changed=False
    for raw in compound(data.root)['owners'].value:
        row=compound(raw)
        if owner_key(row['owner']) not in targets:continue
        assert compound(row['owner'])['id'].value==OLD and compound(row['rootData'])['id'].value==OLD
        compound(row['owner'])['id']=Tag(TAG_STRING,NEW);compound(row['rootData'])['id']=Tag(TAG_STRING,NEW);compound(compound(row['rootData'])['properties'])['variant']=Tag(TAG_STRING,'0');compound(compound(row['rootData'])['properties']).pop('art_bank',None);changed=True
    assert changed;result['OwnerDataV1']=Tag(TAG_BYTE_ARRAY,encode_nbt(data))
    if 'resident' in result and owner_key(result['resident']) in targets:compound(result['resident'])['id']=Tag(TAG_STRING,NEW)
    return result

def main():
    source=RUN/'wall-world-62d4794366ab/bloodborne';output=RUN/'lamps-single-stage1-v2/bloodborne';assert output.resolve().is_relative_to(WORKSPACE)
    data=json.loads((RUN/'task11-lantern-owner-preflight.json').read_text(encoding='utf-8'));deferred={key for row in data['cells'] if row['nativeBase']>=0 for key in row['targets']};owners={k:v for k,v in data['owners'].items() if v['registryId']==OLD and k not in deferred};assert len(owners)==559 and all(v['residentPresent'] for v in owners.values());targets=set(owners)
    groups=collections.defaultdict(list)
    for row in data['cells']:
        if not targets.intersection(row['targets']):continue
        x,y,z=row['pos'];directory='region' if row['dimension']=='overworld' else 'dimensions/bloodborne_dw/bloodborne_old/region';groups[directory+f'/r.{x>>9}.{z>>9}.mca'].append(row)
    assert not (output.parent/'receipt.json').exists(),'Migration already completed'
    if not output.exists():shutil.copytree(source,output,ignore=shutil.ignore_patterns('session.lock'))
    receipts=[];roots_done=cells_done=chunks_done=0
    for relative,rows in sorted(groups.items()):
        region=RegionFile.open(source/relative);by_chunk=collections.defaultdict(list)
        for row in rows:by_chunk[(row['pos'][0]>>4)&31,(row['pos'][2]>>4)&31].append(row)
        expected={}
        for ck,changes in by_chunk.items():
            chunk=region.get_chunk(*ck);nbt=chunk.nbt();root=compound(nbt.root);before=copy.deepcopy(root);by_pos={tuple(r['pos']):r for r in changes};allowed_roots=set()
            for i,raw in enumerate(root['block_entities'].value):
                be=compound(raw);pos=tuple(be[k].value for k in 'xyz')
                if pos not in by_pos:continue
                assert sha_bytes(be['OwnerDataV1'].value)==by_pos[pos]['packedSha256'];after=rename_owner(be,targets);root['block_entities'].value[i]=Tag(TAG_COMPOUND,after);cells_done+=1
                if 'resident' in be and owner_key(be['resident']) in targets:allowed_roots.add(pos);roots_done+=1
            for section in root['sections'].value:
                fields=compound(section);sy=fields['Y'].value;positions=[p for p in allowed_roots if p[1]>>4==sy]
                if not positions:continue
                palette,indices=section_blocks(section);names=[block_state_key(p) for p in palette]
                for x,y,z in positions:
                    local=((y&15)<<8)|((z&15)<<4)|(x&15);old=compound(palette[indices[local]]);assert old['Name'].value==OLD;replacement=copy.deepcopy(old);replacement['Name']=Tag(TAG_STRING,NEW);compound(replacement['Properties'])['variant']=Tag(TAG_STRING,'0');compound(replacement['Properties']).pop('art_bank',None);key=block_state_key(Tag(TAG_COMPOUND,replacement))
                    if key not in names:names.append(key);palette.append(Tag(TAG_COMPOUND,replacement))
                    indices[local]=names.index(key)
                fields['block_states']=Tag(TAG_COMPOUND,{'palette':Tag(TAG_LIST,palette,TAG_COMPOUND),'data':Tag(TAG_LONG_ARRAY,pack_palette_indices(indices,len(palette)))})
            # The only non-owner changes are the explicit root type/variant and stale light caches.
            assert (entries(root) if 'DreamwalkerVisuals' in root else {})==(entries(before) if 'DreamwalkerVisuals' in before else {})
            root_expected=copy.deepcopy(before)
            for i,raw in enumerate(root_expected['block_entities'].value):
                be=compound(raw);pos=tuple(be[k].value for k in 'xyz')
                if pos in by_pos:root_expected['block_entities'].value[i]=Tag(TAG_COMPOUND,rename_owner(be,targets))
            for sec in root_expected['sections'].value:compound(sec).pop('block_states',None)
            comparison=copy.deepcopy(root)
            for sec in comparison['sections'].value:compound(sec).pop('block_states',None)
            assert comparison==root_expected
            aa,bb=block_table(before),block_table(root);observed=set()
            for sy,(pa,ia) in aa.items():
                pb,ib=bb[sy]
                for local in range(4096):
                    if pa[ia[local]]!=pb[ib[local]]:
                        x=before['xPos'].value*16+(local&15);y=sy*16+(local>>8);z=before['zPos'].value*16+((local>>4)&15);assert (x,y,z) in allowed_roots and pb[ib[local]].startswith(NEW+'[');observed.add((x,y,z))
            assert observed==allowed_roots
            invalidate(root);expected[ck]=copy.deepcopy(root);region.set_chunk(*ck,nbt,timestamp=chunk.timestamp);chunks_done+=1
        region.save(output/relative);saved=RegionFile.open(output/relative);original=RegionFile.open(source/relative)
        for chunk in original.chunks():
            ck=chunk.x,chunk.z;other=saved.get_chunk(*ck)
            if ck in expected:assert compound(other.nbt().root)==expected[ck]
            else:assert chunk.compressed_payload==other.compressed_payload and chunk.timestamp==other.timestamp
        receipts.append(dict(path=relative,before=sha(source/relative),after=sha(output/relative)));write(output.parent/'progress.json',dict(regions=len(receipts),roots=roots_done,cells=cells_done))
    assert roots_done==559;result=dict(status='SAVED_OWNER_AND_BLOCK_SCOPE_PASS_GAMEPLAY_PENDING',world=str(output),roots=roots_done,cells=cells_done,chunks=chunks_done,regions=receipts,uuidsAndPayloadAndGeometryUnchanged=True,foreignContributionsUnchanged=True,nativeMetadataUnchanged=True,lightCachesInvalidated=True,originalWorldModified=False);write(output.parent/'receipt.json',result);print(json.dumps({k:v for k,v in result.items() if k!='regions'},indent=2))

def sha_bytes(value):return __import__('hashlib').sha256(value).hexdigest()

if __name__=='__main__':main()
