"""The custom mod lantern, preserving its original animated flame and frame exactly."""
import copy,json,zipfile
from pathlib import Path
from prepare_workspace import BASE,RUN,write

def main():
    resource=Path(__file__).resolve().parent/'src/main/resources'
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as z:
        old=json.loads(z.read('bloodborne_dw/composite/source_lantern.json'));spec=copy.deepcopy(old);spec['id']='bloodborne_dw:source_standard_lantern';spec['displayName']='Фонарь';spec['openable']=True
        variant=copy.deepcopy(old['variants'][0]);fitted=json.loads(z.read('bloodborne_dw/imported-collision-v125.json'));fitted0=fitted['shapes'][fitted['objects']['bloodborne_dw:source_lantern'][0]['closedBase']][0];variant['poses']['closed']['collision']=copy.deepcopy(fitted0['collision']);variant['poses']['closed']['simpleCollisionByRotation']=[copy.deepcopy(r['collision']) for r in fitted['shapes'][fitted['objects']['bloodborne_dw:source_lantern'][0]['closedBase']]];off=copy.deepcopy(variant['poses']['closed']);off['parts']=[dict(model='bloodborne_dw:interactions/mod_lantern_empty',offset=[0,13,0])];variant['poses']['open']=off;spec['variants']=[variant]
        write(resource/'bloodborne_dw/composite/source_standard_lantern.json',spec)
        catalogue=json.loads(z.read('bloodborne_dw/remaining-catalogue.json'));before=copy.deepcopy(catalogue['objects'])
        catalogue['objects'].append(dict(path='source_standard_lantern',collisionPolicy='authored-exact',displayName='Фонарь',variants=[dict(variant=0,name='Фонарь',sourceModels=['minecraft:block/lantern'])]))
        assert catalogue['objects'][:-1]==before
        write(resource/'bloodborne_dw/remaining-catalogue.json',catalogue)
        for folder in ['models/item','blockstates']:
            source='assets/bloodborne_dw/'+folder+'/source_lantern.json';write(resource/('assets/bloodborne_dw/'+folder+'/source_standard_lantern.json'),json.loads(z.read(source)))
        model_path='assets/bloodborne_dw/models/remaining/source/minecraft/block/lantern.json';original=json.loads(z.read(model_path));empty=copy.deepcopy(original);removed=[]
        for index,e in enumerate(original['elements']):
            if any(f.get('texture')=='#1' for f in e.get('faces',{}).values()):removed.append(index)
        empty['elements']=[e for i,e in enumerate(empty['elements']) if i not in removed]
        assert removed==[4,5,10,11];assert all(all(f.get('texture')!='#1' for f in e['faces'].values()) for e in empty['elements'])
        write(resource/'assets/bloodborne_dw/models/interactions/mod_lantern_empty.json',empty)
        assert variant['poses']['closed']['parts']==old['variants'][0]['poses']['closed']['parts']
        assert variant['poses']['closed']['collision']==fitted0['collision']
        write(RUN/'task11-lantern-models.json',dict(status='CUSTOM_MOD_LANTERN_PREPARED_GAMEPLAY_PENDING',canonicalId=spec['id'],source='source_lantern variant0 / remaining/source/minecraft/block/lantern',litGeometryAndAnimatedTexturesUnchanged=True,removedFireElements=removed,emptyFrameElements=len(empty['elements']),pngBytesChanged=False,userClarification='Custom mod lantern, not the Minecraft lantern'))
    print('Custom mod lantern retained; only its four fire planes disappear when off')

if __name__=='__main__':main()
