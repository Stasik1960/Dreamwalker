"""Append corrected native shutter states without changing original indices or collision data.

Each affected cell retains its unrelated quad bytes. Finite combinations preserve
neighbouring shutters when their silhouettes share a cell. Runtime data is relative.
"""
import collections,copy,hashlib,io,itertools,json,math,struct,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
from native_model_baker import bake,cell_quads
from prepare_workspace import BASE,RUN,sha,write

TOOLS=Path(__file__).resolve().parent
RESOURCE=TOOLS/'src/main/resources'
DIRECTORY='assets/bloodborne_dw/native_grid/'


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)


def main():
    baseline=next(BASE.glob('*.jar'));pre=json.loads((RUN/'task09-native-window-preflight.json').read_text(encoding='utf-8'))
    archive=zipfile.ZipFile(baseline);original_catalog=archive.read(DIRECTORY+'catalog.json');catalog=json.loads(original_catalog)
    original=copy.deepcopy(catalog);layout=json.loads(archive.read(DIRECTORY+'visual_physics.json'));old_layout=copy.deepcopy(layout)
    raw=archive.read(DIRECTORY+'meshes.bin');old_count=len(catalog['meshes']);offsets=[];cursor=8
    for mesh in catalog['meshes']:
        count=struct.unpack_from('>I',raw,cursor)[0];assert count==mesh['quadCount'];offsets.append((cursor+4,count));cursor+=4+count*139
    assert cursor==len(raw)
    def mesh_raw(mid):start,count=offsets[mid];return [raw[start+139*i:start+139*(i+1)] for i in range(count)]
    material_ids={canonical(m):i for i,m in enumerate(catalog['materials'])};effective={};sources={}
    def resource(path):
        p=RESOURCE/path
        if p.is_file():sources[path]=sha(p);return p.read_bytes()
        return archive.read(path)
    def material(sprite,layer):
        value=dict(sprite=sprite,layer=layer);key=canonical(value)
        if key not in material_ids:material_ids[key]=len(catalog['materials']);catalog['materials'].append(value)
        return material_ids[key]
    def effective_layer(index):
        if index not in effective:
            m=catalog['materials'][index];layer=m['layer']
            if layer=='translucent':
                ns,path=m['sprite'].split(':',1);image=Image.open(io.BytesIO(resource('assets/'+ns+'/textures/'+path+'.png'))).convert('RGBA');alpha=np.asarray(image)[:,:,3]
                if not np.any((alpha!=0)&(alpha!=255)):layer='cutout'
            effective[index]=layer
        return effective[index]
    spec=json.loads(resource('bloodborne_dw/composite/source_shutter_window.json'));geometry={}
    for rotation in [0,2,4,6]:
        geometry[rotation]={}
        for mode,name in [(0,'closed'),(1,'open')]:
            quads=[]
            for part in spec['variants'][1]['poses'][name]['parts']:
                ns,path=part['model'].split(':',1);model=json.loads(resource('assets/'+ns+'/models/'+path+'.json'))
                quads+=bake(model,offset=part.get('offset',[0,0,0]),yaw=rotation,layer='cutout',sprite_layers={'bloodborne_dw:block/interactions/shutter_glass':'translucent'})
            geometry[rotation][mode]=cell_quads(quads,material)
    scene_by_position={};windows=[]
    for window in pre['windows']:
        root=tuple(round(x) for x in window['root']);assert all(abs(a-b)<1e-4 for a,b in zip(root,window['root']))
        rotation=window['rotation'];known={tuple(c['pos']):c for c in window['cells']}
        footprint=set(geometry[rotation][0])|set(geometry[rotation][1]);assert len(footprint)<=32
        assert all(tuple(root[i]+p[i] for i in range(3)) in known for p in footprint),'New geometry leaves the retained component footprint'
        windows.append(dict(dimension=window['dimension'],root=root,rotation=rotation))
        for offset in footprint:
            pos=tuple(root[i]+offset[i] for i in range(3));row=known[pos];key=(window['dimension'],*pos)
            assert not row['hasBlockEntity']
            scene=scene_by_position.setdefault(key,dict(old=row['visual'],components=[]));assert scene['old']==row['visual']
            scene['components'].append(dict(root=[-v for v in offset],rotation=rotation,remove=[i for i,e in enumerate(row['matched']) if e is not None]))
    scenes={};positions=[]
    for pos,value in sorted(scene_by_position.items()):
        value['components'].sort(key=lambda c:(c['root'],c['rotation']))
        key=hashlib.sha256(canonical(value).encode()).hexdigest()[:20]
        assert key not in scenes or scenes[key]==value;scenes[key]=value;positions.append(dict(dimension=pos[0],pos=pos[1:],scene=key))
    write(TOOLS/'data/native-window-scenes.json',dict(schemaVersion=1,baselineSha256=sha(baseline),catalogSha256=hashlib.sha256(original_catalog).hexdigest(),scenes=scenes))
    mesh_ids={};added_meshes=[]
    for mid,(start,count) in enumerate(offsets):mesh_ids.setdefault(hashlib.sha256(raw[start:start+139*count]).hexdigest(),mid)
    def append_mesh(quads):
        blob=b''.join(quads);digest=hashlib.sha256(blob).hexdigest()
        if digest not in mesh_ids:
            mesh_ids[digest]=len(catalog['meshes']);catalog['meshes'].append(dict(quadCount=len(quads)));added_meshes.append(struct.pack('>I',len(quads))+blob)
        return mesh_ids[digest]
    cell_ids={canonical({k:v for k,v in c.items() if k!='key'}):i for i,c in enumerate(catalog['cells'])}
    override_physics={};new_bounds={};rank={'solid':0,'cutout_mipped':1,'cutout':2,'translucent':3}
    def empty_semantics(cell):
        base=cell.get('baseState');base_air=base is None or base.get('registryId')=='minecraft:air'
        optics=catalog['optics'][cell['optics']]
        return base_air and not any(catalog['shapes'][cell[k]] for k in ['collision','culling','climbing']) and optics['opacity']==0 and optics['luminance']==0 and cell.get('fluid') is None and cell.get('localFunction') is None and cell.get('alt',-1)<0
    def append_cell(old,quads,has_window):
        base=original['cells'][old]
        if not quads and empty_semantics(base):return -1
        cell=copy.deepcopy(base);cell.pop('key');cell['mesh']=append_mesh(quads)
        if has_window:cell['displayName']='Узкое окно со ставнями'
        if cell.get('baseState',{} ) and cell['baseState'].get('registryId')=='minecraft:air':cell['baseState']=None
        signature=canonical(cell)
        if signature in cell_ids:return cell_ids[signature]
        index=len(catalog['cells']);cell_ids[signature]=index;cell['key']=hashlib.sha256(('dwfix-native-window-v1/'+signature).encode()).hexdigest();catalog['cells'].append(cell)
        base_physics=old_layout['cellToPhysics'][old];assert base_physics>=0
        layers=[effective_layer(struct.unpack_from('>I',q)[0]) for q in quads];layer=max(layers,key=rank.get) if layers else old_layout['physicsLayers'][base_physics]
        ambient=bool(quads) and all(q[10]&2 for q in quads)
        if layer==old_layout['physicsLayers'][base_physics] and ambient==old_layout['physicsAmbient'][base_physics]:physics=base_physics
        else:
            key=base_physics,layer,ambient
            if key not in override_physics:
                override_physics[key]=len(layout['representatives']);layout['representatives'].append(index);layout['physicsLayers'].append(layer);layout['physicsAmbient'].append(ambient)
            physics=override_physics[key]
        layout['cellToPhysics'].append(physics)
        if cell['outline']==0 and quads:
            vertices=np.array([struct.unpack_from('>3f',q,11+i*32) for q in quads for i in range(4)])
            lo=np.maximum(0,vertices.min(axis=0));hi=np.minimum(1,vertices.max(axis=0))
            for axis in range(3):
                if hi[axis]-lo[axis]<1e-6:lo[axis]=max(0,lo[axis]-1/1024);hi[axis]=min(1,hi[axis]+1/1024)
            assert np.all(lo<hi);new_bounds[index]=[*map(float,lo),*map(float,hi)]
        return index
    transitions={};seeds=set();modes={};initial={};scene_receipts=[]
    def put(table,key,value):
        assert key not in table or table[key]==value,('Ambiguous native window state',key,table.get(key),value)
        table[key]=value
    anchors={k:(0,1,0) for k in geometry}
    for sid,scene in sorted(scenes.items()):
        old=scene['old'];components=scene['components'];assert len(components)<=4
        removed=set()
        for c in components:
            assert not removed.intersection(c['remove']),'Shared source face claimed twice';removed.update(c['remove'])
        base=[q for i,q in enumerate(mesh_raw(original['cells'][old]['mesh'])) if i not in removed]
        ids=[];window_counts=[]
        for mask in range(1<<len(components)):
            quads=base.copy();counts=[]
            for i,c in enumerate(components):
                offset=tuple(-v for v in c['root']);part=geometry[c['rotation']][(mask>>i)&1].get(offset,[]);counts.append(len(part));quads+=part
            ids.append(append_cell(old,quads,any(counts)));window_counts.append(counts)
        initial[sid]=ids[-1]
        for mask,index in enumerate(ids):
            for i,c in enumerate(components):
                root=tuple(c['root']);rotation=c['rotation'];mode=(mask>>i)&1
                put(transitions,(index,*root,rotation,mode),ids[mask^(1<<i)])
                if index>=0 and window_counts[mask][i]:seeds.add((index,*root,rotation))
                if tuple(-v for v in root)==anchors[rotation]:
                    assert index>=0;put(modes,(index,*root,rotation),mode)
        for i,c in enumerate(components):
            root=tuple(c['root']);rotation=c['rotation'];put(transitions,(old,*root,rotation,1),ids[((1<<len(components))-1)^(1<<i)])
            if c['remove']:seeds.add((old,*root,rotation))
            if tuple(-v for v in root)==anchors[rotation]:put(modes,(old,*root,rotation),1)
        scene_receipts.append(dict(scene=sid,components=len(components),variants=len(set(ids)),old=old,initial=ids[-1]))
    assert len(catalog['cells'])<1<<19
    for field in ['materials','meshes','cells','shapes','optics','wholeObjects']:assert catalog[field][:len(original[field])]==original[field]
    for field in ['cellToPhysics','representatives','physicsLayers','physicsAmbient']:assert layout[field][:len(old_layout[field])]==old_layout[field]
    output=RUN/'native-overlay';output.mkdir(exist_ok=True)
    data=json.dumps(catalog,ensure_ascii=False,separators=(',',':')).encode();catalog_sha=hashlib.sha256(data).hexdigest();layout['catalogSha256']=catalog_sha
    layout['compatibleCatalogs']=sorted(set(layout.get('compatibleCatalogs',[])+[old_layout['catalogSha256']]))
    files={DIRECTORY+'catalog.json':data,DIRECTORY+'visual_physics.json':json.dumps(layout,separators=(',',':')).encode(),DIRECTORY+'meshes.bin':struct.pack('>II',0x4e475131,len(catalog['meshes']))+raw[8:]+b''.join(added_meshes)}
    repairs=json.loads(archive.read(DIRECTORY+'visual-repairs.json'));repairs['catalogSha256']=catalog_sha;files[DIRECTORY+'visual-repairs.json']=json.dumps(repairs,separators=(',',':')).encode()
    bounds=archive.read(DIRECTORY+'selection-bounds.bin');utf_len=struct.unpack_from('>H',bounds,4)[0];start=6+utf_len;count=struct.unpack_from('>I',bounds,start)[0];old_rows=bounds[start+4:];assert len(old_rows)==count*28
    files[DIRECTORY+'selection-bounds.bin']=struct.pack('>IH',0x4e475331,64)+catalog_sha.encode()+struct.pack('>I',count+len(new_bounds))+old_rows+b''.join(struct.pack('>I6f',i,*b) for i,b in sorted(new_bounds.items()))
    profiles=[]
    from discover_native_windows import rotation as rotate,PIVOT
    for k in geometry:
        centre=(np.array([.5,23/16,6/16])-PIVOT)@rotate(-45*k).T+PIVOT
        profiles.append(dict(rotation=k,anchor=anchors[k],centre=centre.tolist(),cells=[list(p) for p in sorted(set(geometry[k][0])|set(geometry[k][1]))]))
    functions=dict(schemaVersion=1,catalogSha256=catalog_sha,profiles=profiles,seeds=[list(x) for x in sorted(seeds)],modes=[[*key,value] for key,value in sorted(modes.items())],transitions=[[*key,value] for key,value in sorted(transitions.items())])
    files['bloodborne_dw/repair/native-windows.json']=json.dumps(functions,separators=(',',':')).encode()
    entries={}
    for name,blob in files.items():
        path=output/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(blob);entries[name]=dict(sha256=sha(path),bytes=len(blob))
    write(output/'manifest.json',dict(schemaVersion=1,baselineSha256=sha(baseline),catalogSha256=catalog_sha,sources=sources,entries=entries))
    write(RUN/'task09-native-window-map-plan.json',dict(catalogSha256=catalog_sha,windows=windows,cells=[dict(**p,next=initial[p['scene']]) for p in positions]))
    receipt=dict(status='COMPILED_NOT_GAME_TESTED',originalCells=len(original['cells']),cells=len(catalog['cells']),addedMeshes=len(added_meshes),addedPhysics=len(layout['representatives'])-len(old_layout['representatives']),catalogSha256=catalog_sha,scenes=len(scenes),sceneComponents=dict(collections.Counter(len(s['components']) for s in scenes.values())),windows=len(windows),cellsInMap=len(positions),seeds=len(seeds),modes=len(modes),transitions=len(transitions),prefixRecordsAndMeshPayloadUnchanged=True,blockEntitiesAdded=0,sceneReceipts=scene_receipts)
    write(RUN/'task09-native-window-compile.json',receipt);print(json.dumps({k:v for k,v in receipt.items() if k!='sceneReceipts'},indent=2))


if __name__=='__main__':main()
