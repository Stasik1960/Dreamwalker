"""Remove only the runtime-proven selection ghost whose root was already replaced by water."""
import copy,json,shutil,subprocess
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write
from world_editor import *
from owner_shard_edit import Shards,key
from lantern_owner_edit import remove_owners,physical_state,owner_key
from migrate_lanterns_stage2 import semantic_gate


def guard():subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)

def main():
    guard();audit=json.loads((RUN/'prelight-block-change-audit.json').read_text(encoding='utf-8'));assert audit['checkedChunks']==3058 and len(audit['changes'])==1;change=audit['changes'][0];assert change['directory']=='region' and change['pos']==[-38,7,-1107];source=Path(audit['sourceWorld']);target=RUN/'lamps-standard-stage4-v18/bloodborne';assert not target.exists()
    editor=Editor(source);pos=tuple(change['pos']);be=editor.entity(*pos);assert editor.state(*pos)==change['before'] and be and 'resident' not in be and 'NativeGridBase' in be and not compound(be['payload']);scene=be['NativeGridBase'].value
    layout=json.loads((RUN/'native-overlay/assets/bloodborne_dw/native_grid/visual_physics.json').read_text(encoding='utf-8'));assert physical_state(layout,scene)==change['after'];rows=[compound(v) for v in compound(decode_nbt(be['OwnerDataV1'].value).root)['owners'].value];assert len(rows)==1 and not rows[0]['collision'].value;owner=rows[0]['owner'];uid=key(owner);root=compound(owner)['root'].value;assert root==[-38,7,-1106] and editor.entity(*root) is None and editor.state(*root)=='minecraft:water[level=8]'
    store=Shards(source,'overworld');n=store.get(root[0]>>4,root[2]>>4);ref=next(i for i,v in enumerate(n['ownerTable'].value) if key(v)==uid);membership=next(compound(v) for v in n['ownerMembership'].value if compound(v)['ownerRef'].value==ref);positions={tuple(root[i]+compound(v)['offset'].value[i] for i in range(3)) for v in membership['members'].value};assert positions=={(-38,6,-1107),(-38,6,-1106),pos,tuple(root)},positions
    for cell in positions:
        for row in store.logical(cell):
            if key(row['owner'])==uid:assert not row['collision'].value
    result=remove_owners(editor,[p for p in positions if editor.entity(*p) is not None],{owner_key(owner)},layout,layout['catalogSha256']);assert result==dict(cells=2,contributions=2);assert editor.state(*pos)==change['after'] and editor.entity(*pos) is None and editor.visual(*pos)==scene;assert editor.state(*root)=='minecraft:water[level=8]'
    removed={uid};store.prune(removed,positions);store.mirror(editor,{},removed);edits=store.prepare(removed,{});semantic=semantic_gate(editor);guard();shutil.copytree(source,target,ignore=shutil.ignore_patterns('session.lock'));editor.save(target)
    for relative,raw in edits:file=target/relative;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
    reopened=MapReader(target);assert reopened.state(*pos)==change['after'] and reopened.visual(*pos)==scene and reopened.entity(*pos) is None and reopened.state(*root)=='minecraft:water[level=8]';after_store=Shards(target,'overworld');assert all(not any(key(v['owner'])==uid for v in after_store.logical(cell)) for cell in positions)
    saved=after_store.get(root[0]>>4,root[2]>>4);assert not any(key(saved['ownerTable'].value[compound(v)['ownerRef'].value])==uid for v in saved['ownerMembership'].value)
    # The native scene index, and thus all of its mesh/physics/optics tables, is unchanged.
    proof=dict(status='DEAD_SELECTION_OWNER_REMOVED_NATIVE_BACKGROUND_EXACT',pos=list(pos),missingRoot=root,missingRootState='minecraft:water[level=8]',nativeSceneRetained=scene,removedCollisionBoxes=0,removedOwners=1,removedBlockEntityContributions=2,removedLedgerContributions=4,sourceNativeMeshPhysicsAndOpticsUnchanged=True,semanticGate=semantic)
    base=json.loads((source.parent/'migration-receipt.json').read_text(encoding='utf-8'));base['deadSelectionOwnerCleanup']=proof;write(target.parent/'migration-receipt.json',base);write(RUN/'task13-dead-wrapper-proof.json',proof)
    targets=json.loads((RUN/'prelight-targets.json').read_text(encoding='utf-8'));targets['world']=str(target);write(RUN/'prelight-targets-stage4.json',targets);print(json.dumps(proof,indent=2))

if __name__=='__main__':main()
