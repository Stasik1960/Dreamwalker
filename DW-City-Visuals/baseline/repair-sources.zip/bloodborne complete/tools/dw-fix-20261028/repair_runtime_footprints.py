"""Replace only saved owner shape rows with exact worldless-runtime results; membership must stay identical."""
import argparse,copy,json,shutil,subprocess,collections
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write,sha
from world_editor import *
from owner_shard_edit import Shards,key
from migrate_lanterns_stage2 import DIRS,invalidate_caches,semantic_gate

def guard():subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)

def shape(values):return Tag(TAG_LIST,[Tag(TAG_LIST,[Tag(TAG_DOUBLE,float(v)) for v in box],TAG_DOUBLE) for box in values],TAG_LIST if values else TAG_END)

def main():
    p=argparse.ArgumentParser();p.add_argument('export');p.add_argument('--output',type=Path);args=p.parse_args();guard();folder=RUN/'exports'/args.export;receipt=json.loads((folder/'receipt.json').read_text(encoding='utf-8'));assert receipt['status']=='PASS';request=json.loads((folder/'request.json').read_text(encoding='utf-8'));source=Path(request['world']);data=json.loads((folder/'footprints.json').read_text(encoding='utf-8'));assert sha(folder/'footprints.json')==receipt['outputSha256'];assert request['candidateSha256']==receipt['candidateSha256'];results={r['key']:r for r in data['actors']};assert len(results)==len(request['actors'])==1287
    editors={d:Editor(source,path) for d,path in DIRS.items()};stores={d:Shards(source,d) for d in DIRS};changed={d:{} for d in DIRS};positions={d:set() for d in DIRS};conflicts=[];audited=0;changed_rows=0
    for actor in request['actors']:
        dim=actor['dimension'];root=actor['root'];uid=tuple(actor['uuid']);editor=editors[dim];store=stores[dim];expected=results[actor['key']];assert expected['closed']==expected['open'],'Off/on must retain the exact same physical footprint'
        n=store.get(root[0]>>4,root[2]>>4);ref=next(i for i,v in enumerate(n['ownerTable'].value) if key(v)==uid);membership=next(compound(v) for v in n['ownerMembership'].value if compound(v)['ownerRef'].value==ref);old={tuple(root[i]+compound(v)['offset'].value[i] for i in range(3)) for v in membership['members'].value};wanted={tuple(root[i]+c['offset'][i] for i in range(3)):c for c in expected['closed']}
        if old!=wanted.keys():conflicts.append(dict(key=actor['key'],reason='membership_change_requires_separate_review',old=sorted(old),new=sorted(wanted)));continue
        owner=editor.entity(*root)['resident'];assert key(owner)==uid;changes=[]
        for pos,cell in wanted.items():
            be=editor.entity(*pos);assert be is not None and 'OwnerDataV1' in be;envelope=decode_nbt(be['OwnerDataV1'].value);rows=compound(envelope.root)['owners'].value;row=next(compound(v) for v in rows if key(compound(v)['owner'])==uid);assert row==next(v for v in store.logical(pos) if key(v['owner'])==uid)
            exact={name:shape(cell[name]) for name in ['collision','selection']}
            if any(row[name]!=exact[name] for name in exact):changes.append((pos,exact));changed_rows+=1
        audited+=1
        if not changes:continue
        changed[dim][uid]=copy.deepcopy(owner);positions[dim].update(old)
        for pos,cell in wanted.items():
            be=copy.deepcopy(editor.entity(*pos));envelope=decode_nbt(be['OwnerDataV1'].value);row=next(compound(v) for v in compound(envelope.root)['owners'].value if key(compound(v)['owner'])==uid)
            for name in ['collision','selection']:row[name]=shape(cell[name])
            be['OwnerDataV1']=Tag(TAG_BYTE_ARRAY,encode_nbt(envelope));editor.set_entity(pos,be)
    report=dict(status='REJECTED_MEMBERSHIP_DIFFERENCE' if conflicts else 'EXACT_RUNTIME_SHAPE_PLAN_PASS',actors=audited,changedActors={d:len(v) for d,v in changed.items()},changedRows=changed_rows,conflicts=conflicts,blocksOrOwnerIdentitiesChanged=False,runtimeCandidateSha256=receipt['candidateSha256'])
    write(RUN/f'runtime-shape-plan-{args.export}.json',report);print(json.dumps(report,indent=2)[:4500]);assert not conflicts,'No world may be written when occupied-cell membership differs'
    if not args.output:return
    target=args.output.resolve();assert target.is_relative_to(RUN.resolve()) and not target.exists();shard_edits={}
    for dim,editor in editors.items():
        store=stores[dim];removed=set(changed[dim]);store.prune(removed,positions[dim]);store.mirror(editor,changed[dim],removed);shard_edits[dim]=store.prepare(removed,changed[dim]);invalidate_caches(editor);semantic_gate(editor)
    guard();shutil.copytree(source,target,ignore=shutil.ignore_patterns('session.lock'))
    for editor in editors.values():editor.save(target)
    regions=[]
    for dim,editor in editors.items():
        for rx,rz in sorted({(cx>>5,cz>>5) for cx,cz in editor.before}):
            guard();relative=editor.directory+f'/r.{rx}.{rz}.mca';before=RegionFile.open(source/relative);after=RegionFile.open(target/relative)
            for old in before.chunks():
                new=after.get_chunk(old.x,old.z);k=(rx*32+old.x,rz*32+old.z)
                if k in editor.before:assert compound(new.nbt().root)==editor.chunks[k]
                else:assert old.compressed_payload==new.compressed_payload and old.timestamp==new.timestamp
            regions.append(relative)
    for edits in shard_edits.values():
        for relative,raw in edits:file=target/relative;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
    # Independently reopen and compare every saved owner with the runtime, not the in-memory edit buffer.
    saved_readers={d:MapReader(target,path) for d,path in DIRS.items()};saved_stores={d:Shards(target,d) for d in DIRS};verified=0
    for actor in request['actors']:
        dim=actor['dimension'];uid=tuple(actor['uuid']);root=actor['root'];store=saved_stores[dim];n=store.get(root[0]>>4,root[2]>>4);ref=next(i for i,v in enumerate(n['ownerTable'].value) if key(v)==uid);membership=next(compound(v) for v in n['ownerMembership'].value if compound(v)['ownerRef'].value==ref);cells=results[actor['key']]['closed'];assert len(membership['members'].value)==len(cells)
        for cell in cells:
            pos=tuple(root[i]+cell['offset'][i] for i in range(3));be=saved_readers[dim].entity(*pos);row=next(compound(v) for v in compound(decode_nbt(be['OwnerDataV1'].value).root)['owners'].value if key(compound(v)['owner'])==uid);assert row==next(v for v in store.logical(pos) if key(v['owner'])==uid)
            for name in ['collision','selection']:assert row[name]==shape(cell[name])
        verified+=1
    base=json.loads((source.parent/'migration-receipt.json').read_text(encoding='utf-8'));base['runtimeFootprintRepair']=dict(status='PERSISTED_EXACT_RUNTIME_SHAPES_PASS',verifiedActors=verified,changedActors=report['changedActors'],changedRows=changed_rows,candidateSha256=receipt['candidateSha256'],regions=regions);write(target.parent/'migration-receipt.json',base);print('PERSISTED RUNTIME SHAPES PASS',verified,'actors')

if __name__=='__main__':main()
