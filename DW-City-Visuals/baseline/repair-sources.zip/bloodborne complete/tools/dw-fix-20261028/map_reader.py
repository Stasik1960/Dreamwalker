"""Read-only targeted view of candidate Anvil blocks and their visual identities."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from world_io import RegionFile, Tag, TAG_LIST, TAG_COMPOUND, compound, section_blocks, block_state_key


class MapReader:
    def __init__(self, world, directory='region'):
        self.world = Path(world)
        self.directory = directory
        self.regions, self.chunks, self.sections = {}, {}, {}

    def chunk(self, x, z):
        key = (x>>4,z>>4)
        if key not in self.chunks:
            region_key = (x>>9,z>>9)
            if region_key not in self.regions:
                path = self.world / self.directory / f'r.{x>>9}.{z>>9}.mca'
                self.regions[region_key] = RegionFile.open(path) if path.exists() else None
            region = self.regions[region_key]
            chunk = region.get_chunk(key[0]&31,key[1]&31) if region else None
            self.chunks[key] = compound(chunk.nbt().root) if chunk else None
        return self.chunks[key]

    def section(self,x,y,z):
        key=x>>4,y>>4,z>>4
        if key not in self.sections:
            chunk=self.chunk(x,z)
            raw=next((s for s in chunk.get('sections',Tag(TAG_LIST,[],TAG_COMPOUND)).value
                      if compound(s)['Y'].value == y>>4),None) if chunk else None
            parsed=section_blocks(raw) if raw else None
            self.sections[key]=([block_state_key(p) for p in parsed[0]],parsed[1]) if parsed else (['minecraft:air'],[0]*4096)
        return self.sections[key]

    def state(self,x,y,z):
        palette,indices=self.section(x,y,z)
        return palette[indices[((y&15)<<8)|((z&15)<<4)|(x&15)]]

    def entity(self,x,y,z):
        root=self.chunk(x,z)
        if root:
            for entity in root.get('block_entities',Tag(TAG_LIST,[],TAG_COMPOUND)).value:
                be=compound(entity)
                if all(be.get(k,Tag(3,0)).value==v for k,v in zip('xyz',(x,y,z))):
                    return be
        return None

    def visual(self,x,y,z):
        root=self.chunk(x,z)
        table=root.get('DreamwalkerVisuals') if root else None
        local=((y&15)<<8)|((z&15)<<4)|(x&15)
        if table:
            for row in compound(table).get('Sections',Tag(TAG_LIST,[],TAG_COMPOUND)).value:
                fields=compound(row)
                if fields['Y'].value==y>>4:
                    for entry in fields['Entries'].value:
                        if entry&4095==local:
                            return (entry&0xffffffff)>>12
        return None
