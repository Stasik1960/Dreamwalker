"""Inventory every real block change in the disposable lighting run before accepting any cache."""
import collections,json,subprocess
from pathlib import Path
from prepare_workspace import RUN,WORKSPACE,write
from world_editor import RegionFile,compound
from fast_block_compare import differences

DIR={'minecraft:overworld':'region','bloodborne_dw:bloodborne_old':'dimensions/bloodborne_dw/bloodborne_old/region'}

def main():
    plan=json.loads((RUN/'prelight-targets.json').read_text(encoding='utf-8'));source=Path(plan['world']);saved=RUN/'runs/v18-lighting-final/client/saves/city';groups=collections.defaultdict(list)
    for row in plan['prelightChunks']:groups[DIR[row['dimension']],row['x']>>5,row['z']>>5].append((row['x'],row['z']))
    changes=[];checked=0
    for (directory,rx,rz),chunks in sorted(groups.items()):
        subprocess.run(['pwsh','-NoProfile','-File',r'C:\Users\vakir\.codex\dreamwalker\Assert-Workspace.ps1'],cwd=WORKSPACE,check=True,stdout=subprocess.DEVNULL)
        a=RegionFile.open(source/directory/f'r.{rx}.{rz}.mca');b=RegionFile.open(saved/directory/f'r.{rx}.{rz}.mca')
        for cx,cz in chunks:
            aa=compound(a.get_chunk(cx&31,cz&31).nbt().root);bb=compound(b.get_chunk(cx&31,cz&31).nbt().root)
            for sy,i,old,new in differences(aa,bb):changes.append(dict(directory=directory,pos=[cx*16+(i&15),sy*16+(i>>8),cz*16+((i>>4)&15)],before=old,after=new))
            checked+=1
        write(RUN/'prelight-block-audit-progress.json',dict(checkedChunks=checked,totalChunks=len(plan['prelightChunks']),changedCells=len(changes)))
    result=dict(status='ALL_TARGET_BLOCK_CHANGES_INVENTORIED',sourceWorld=str(source),savedWorld=str(saved),checkedChunks=checked,changes=changes);write(RUN/'prelight-block-change-audit.json',result);print('Audited',checked,'chunks;',len(changes),'changed cells')

if __name__=='__main__':main()
