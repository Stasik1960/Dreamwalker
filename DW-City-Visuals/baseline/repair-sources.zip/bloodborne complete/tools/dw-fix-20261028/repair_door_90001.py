"""Task02: remove the obsolete center-cell support requirement of the imported door."""
import copy
import json
from pathlib import Path
import zipfile

from prepare_workspace import BASE,RUN,write


def main():
    name='bloodborne_dw/composite/prototype_double_door.json'
    with zipfile.ZipFile(next(BASE.glob('*.jar'))) as source:
        before=json.loads(source.read(name))
    assert before['id']=='bloodborne_dw:prototype_double_door'
    assert before['support']['required'] is True
    after=copy.deepcopy(before)
    after['support']['required']=False
    # Imported doors have their floor alignment in the authored pose/payload.
    # A center-only support test ignores SourceShift and rejects the existing map roots.
    output=Path(__file__).resolve().parent/'src/main/resources'/name
    write(output,after)
    for key in set(before)-{'support'}:
        assert before[key]==after[key],key
    assert after['support']['offset']==before['support']['offset']
    scan=json.loads((RUN/'task02-scan.json').read_text(encoding='utf-8'))
    write(RUN/'task02-resource-repair.json',dict(status='BUILT_REQUIRES_GAME_TEST',
          resource=name,changedField='support.required',before=True,after=False,
          existingRootsByDimension={k:len(v) for k,v in scan.items()},
          geometryAndIdentityUnchanged=True,corePlacementAndInteractionChecksUnchanged=True))
    print('Task02: scoped support repair prepared for 57 main-city + 43 old-city doors')


if __name__=='__main__':main()
