package dev.dreamwalker.bloodbornedw.repair;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;

/** The city floor shares the darkness model without allocating composite block entities. */
public final class CityRepair implements ModInitializer {
    public static final Identifier DARKNESS_ID = new Identifier("bloodborne_dw", "city_darkness");
    public static Block DARKNESS;
    public static Block LANTERN;

    @Override public void onInitialize() {
        DARKNESS = Registry.register(Registries.BLOCK, DARKNESS_ID, new DarknessFloor());
        Registry.register(Registries.ITEM, DARKNESS_ID, new BlockItem(DARKNESS, new Item.Settings()));
        LANTERN=Registries.BLOCK.get(new Identifier("bloodborne_dw","source_standard_lantern"));
        if(!(LANTERN instanceof dev.dreamwalker.bloodbornedw.composite.CompositeRootBlock))throw new IllegalStateException("Custom standard lantern was not registered");
        dev.dreamwalker.bloodbornedw.composite.NativeShutterWindows.initialize();
    }

    private static final class DarknessFloor extends Block {
        DarknessFloor() {
            // noCollision() also clears opacity; collision is explicitly empty below.
            super(Settings.create().strength(-1, 3600000).dropsNothing()
                    .solidBlock((s,w,p) -> false).suffocates((s,w,p) -> false)
                    .blockVision((s,w,p) -> true)
                    .pistonBehavior(net.minecraft.block.piston.PistonBehavior.BLOCK));
        }
        @Override public VoxelShape getCollisionShape(BlockState state, BlockView world,
                BlockPos pos, ShapeContext context) { return VoxelShapes.empty(); }
        @Override public VoxelShape getOutlineShape(BlockState state, BlockView world,
                BlockPos pos, ShapeContext context) {
            return context instanceof net.minecraft.block.EntityShapeContext entity
                    && entity.getEntity() instanceof PlayerEntity player && !player.isCreative()
                    ? VoxelShapes.empty() : VoxelShapes.fullCube();
        }
        @Override public int getOpacity(BlockState state, BlockView world, BlockPos pos) { return 15; }
        @Override public VoxelShape getCullingShape(BlockState state, BlockView world, BlockPos pos) {
            return VoxelShapes.fullCube();
        }
        @Override public boolean isSideInvisible(BlockState state, BlockState neighbor,
                net.minecraft.util.math.Direction direction) {
            return neighbor.isOf(this) || super.isSideInvisible(state,neighbor,direction);
        }
        @Override public boolean canPathfindThrough(BlockState state, BlockView world,
                BlockPos pos, NavigationType type) { return true; }
    }
}
