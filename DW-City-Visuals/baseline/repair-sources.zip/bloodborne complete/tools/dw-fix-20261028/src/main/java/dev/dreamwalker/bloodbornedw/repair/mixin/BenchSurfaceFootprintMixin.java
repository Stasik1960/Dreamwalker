package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import dev.dreamwalker.bloodbornedw.runtime.ObjectGeometry.*;
import java.util.Map;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Only bench physics changes; original aim and the following optics pass remain intact. */
@Mixin(value=CompositeSourceShift.class,remap=false)
public abstract class BenchSurfaceFootprintMixin {
    @Inject(method="physicalFootprint",at=@At("RETURN"),cancellable=true,remap=false)
    private static void dwfix$benchSupport(CompositeSpec spec,BlockState state,NbtCompound payload,CallbackInfoReturnable<Map<Cell,Footprint>> cir){
        if(spec.id.toString().equals("bloodborne_dw:source_hold_bench"))cir.setReturnValue(DwBenchSurfaces.replace(state,payload,cir.getReturnValue()));
    }
}
