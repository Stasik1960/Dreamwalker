package dev.dreamwalker.bloodbornedw.composite;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.architecture.mount.VerticalMount;
import dev.dreamwalker.bloodbornedw.runtime.ObjectGeometry.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;

/** Plank and decor shapes derived from the two original bench meshes. */
public final class DwBenchSurfaces {
    private static final List<List<List<ImportedCollisionMath.Box>>> SHAPES=load();
    private record Key(BlockState state,double mount,CompositeSourceShift.Shift shift){}
    private static final Map<Key,Map<Cell,Footprint>> CACHE=new ConcurrentHashMap<>();
    private DwBenchSurfaces(){}
    private static List<List<List<ImportedCollisionMath.Box>>> load(){
        var stream=DwBenchSurfaces.class.getResourceAsStream("/bloodborne_dw/repair/bench-surfaces.json");
        if(stream==null)throw new IllegalStateException("Missing bench support shapes");
        try(var reader=new InputStreamReader(stream,StandardCharsets.UTF_8)){
            var variants=new ArrayList<List<List<ImportedCollisionMath.Box>>>();
            for(var variant:JsonParser.parseReader(reader).getAsJsonObject().getAsJsonArray("variants")){
                var rotations=new ArrayList<List<ImportedCollisionMath.Box>>();
                for(var rotation:variant.getAsJsonArray()){
                    var boxes=new ArrayList<ImportedCollisionMath.Box>();
                    for(var item:rotation.getAsJsonArray()){
                        var a=item.getAsJsonObject().getAsJsonArray("from");var b=item.getAsJsonObject().getAsJsonArray("to");
                        boxes.add(new ImportedCollisionMath.Box(a.get(0).getAsDouble()/16,a.get(1).getAsDouble()/16,a.get(2).getAsDouble()/16,b.get(0).getAsDouble()/16,b.get(1).getAsDouble()/16,b.get(2).getAsDouble()/16));
                    }
                    if(boxes.isEmpty()||boxes.size()>64)throw new IllegalStateException("Bench shape budget");
                    rotations.add(List.copyOf(boxes));
                }
                if(rotations.size()!=8)throw new IllegalStateException("Bench rotations");
                variants.add(List.copyOf(rotations));
            }
            if(variants.size()!=2)throw new IllegalStateException("Bench variants");
            return List.copyOf(variants);
        }catch(IOException e){throw new UncheckedIOException(e);}
    }
    public static Map<Cell,Footprint> replace(BlockState state,NbtCompound payload,Map<Cell,Footprint> original){
        int variant=CompositeSpec.poseVariant(state);if(variant<0||variant>=SHAPES.size())return original;
        var shift=CompositeSourceShift.world(state,payload);double mount=payload.getDouble("MountY")+payload.getDouble(VerticalMount.KEY);
        var key=new Key(state,mount,shift);var known=CACHE.get(key);if(known!=null)return known;
        var physical=new TreeMap<Cell,List<Box>>();
        for(var box:ImportedCollisionMath.transform(SHAPES.get(variant).get(state.get(CompositeRootBlock.ROTATION)),0,mount,false,shift.x(),shift.y(),shift.z())){
            for(int x=(int)Math.floor(box.x0()+1e-8);x<Math.ceil(box.x1()-1e-8);x++)for(int y=(int)Math.floor(box.y0()+1e-8);y<Math.ceil(box.y1()-1e-8);y++)for(int z=(int)Math.floor(box.z0()+1e-8);z<Math.ceil(box.z1()-1e-8);z++){
                double a=Math.max(0,box.x0()-x),b=Math.max(0,box.y0()-y),c=Math.max(0,box.z0()-z),d=Math.min(1,box.x1()-x),e=Math.min(1,box.y1()-y),f=Math.min(1,box.z1()-z);
                if(a<d&&b<e&&c<f)physical.computeIfAbsent(new Cell(x,y,z),unused->new ArrayList<>()).add(new Box(a,b,c,d,e,f));
            }
        }
        var cells=new TreeSet<Cell>(original.keySet());cells.addAll(physical.keySet());var result=new TreeMap<Cell,Footprint>();
        for(var cell:cells)result.put(cell,new Footprint(List.copyOf(physical.getOrDefault(cell,List.of())),original.containsKey(cell)?original.get(cell).selection():List.of()));
        var immutable=Collections.unmodifiableMap(result);if(CACHE.size()<512)CACHE.putIfAbsent(key,immutable);return immutable;
    }
}
