package dev.dreamwalker.bloodbornedw.repair.mixin;

import net.minecraft.client.MinecraftClient;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.world.GameMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Covers the complete frame, including hidden HUD and menus, while below the world. */
@Mixin(value = GameRenderer.class, priority = 100)
public abstract class VoidScreenMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void dreamwalker$voidScreen(float tickDelta, long startTime, boolean tick, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        var player = client.player;
        if (client.world == null || player == null || client.interactionManager == null || !player.isAlive()
                || !(client.interactionManager.getCurrentGameMode() == GameMode.SURVIVAL
                     || client.interactionManager.getCurrentGameMode() == GameMode.CREATIVE)
                || player.getY() >= client.world.getBottomY()) return;
        // The final color buffer also covers F1 and renderers which composite
        // their world after GUI quads. No projection/depth/blend state is involved.
        client.getFramebuffer().beginWrite(false);
        RenderSystem.disableScissor();
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.clearColor(0, 0, 0, 1);
        RenderSystem.clear(org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT, MinecraftClient.IS_SYSTEM_MAC);
    }
}
