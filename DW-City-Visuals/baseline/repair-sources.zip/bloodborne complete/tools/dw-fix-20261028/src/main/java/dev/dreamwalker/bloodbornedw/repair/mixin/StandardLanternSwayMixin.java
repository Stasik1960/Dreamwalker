package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.LanternMotion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LanternMotion.class)
public abstract class StandardLanternSwayMixin {
    @Inject(method="lantern",at=@At("HEAD"),cancellable=true,remap=false)
    private static void dwfix$customLampSway(String id,CallbackInfoReturnable<Boolean> cir){if(id.equals("bloodborne_dw:source_standard_lantern"))cir.setReturnValue(true);}
}
