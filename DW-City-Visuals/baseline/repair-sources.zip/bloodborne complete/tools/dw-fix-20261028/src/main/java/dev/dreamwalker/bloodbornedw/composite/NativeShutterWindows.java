package dev.dreamwalker.bloodbornedw.composite;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.architecture.InteractionReach;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.*;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.*;
import org.slf4j.LoggerFactory;

/** Finite native shutter transitions; no per-window entities, NBT additions or idle ticks. */
public final class NativeShutterWindows {
    private record Key(int visual,int x,int y,int z,int rotation){}
    private record Step(Key key,int mode){}
    private record Role(BlockPos rootOffset,int rotation){}
    private record Profile(BlockPos anchor,Vec3d centre,List<BlockPos> cells){}
    private record Data(Map<Integer,Profile> profiles,Map<Integer,List<Role>> seeds,Map<Key,Integer> modes,Map<Step,Integer> transitions){}
    private record Selected(BlockPos root,int rotation,int mode){}
    private record Change(BlockPos pos,int before,int after){}
    private static final class Holder {static final Data DATA=load();}
    private static final Map<UUID,Long> LAST_USE=new HashMap<>();
    private NativeShutterWindows(){}
    private static BlockPos position(JsonArray row,int offset){
        int x=row.get(offset).getAsInt(),y=row.get(offset+1).getAsInt(),z=row.get(offset+2).getAsInt();
        if(Math.abs(x)>8||Math.abs(y)>8||Math.abs(z)>8)throw new IllegalArgumentException("Native window relative bounds");return new BlockPos(x,y,z);
    }
    private static int visual(int value,boolean air){
        if(value<(air?-1:0)||value>=NativeGridCatalog.cells().size()||value>=0&&NativeVisualLayout.physics(value)<0)throw new IllegalArgumentException("Native window visual reference");return value;
    }
    private static int orientation(int value){if(value<0||value>7||value%2!=0)throw new IllegalArgumentException("Native shutter orientation");return value;}
    private static Key key(int visual,BlockPos rootOffset,int rotation){return new Key(visual,rootOffset.getX(),rootOffset.getY(),rootOffset.getZ(),rotation);}
    private static Key key(JsonArray row){return key(visual(row.get(0).getAsInt(),true),position(row,1),orientation(row.get(4).getAsInt()));}
    private static <K,V> void put(Map<K,V> values,K key,V value){V old=values.putIfAbsent(key,value);if(old!=null&&!old.equals(value))throw new IllegalArgumentException("Ambiguous native shutter transition");}
    private static Data load(){
        try(var in=NativeShutterWindows.class.getResourceAsStream("/bloodborne_dw/repair/native-windows.json")){
            if(in==null)throw new FileNotFoundException("Native shutter definitions");
            var document=JsonParser.parseReader(new InputStreamReader(in,StandardCharsets.UTF_8)).getAsJsonObject();
            if(document.get("schemaVersion").getAsInt()!=1||!document.get("catalogSha256").getAsString().equals(NativeVisualLayout.catalogSha()))throw new IllegalArgumentException("Native shutter catalog/schema");
            var profiles=new HashMap<Integer,Profile>();var seeds=new HashMap<Integer,List<Role>>();var modes=new HashMap<Key,Integer>();var transitions=new HashMap<Step,Integer>();
            for(var value:document.getAsJsonArray("profiles")){var row=value.getAsJsonObject();int rotation=orientation(row.get("rotation").getAsInt());var centre=row.getAsJsonArray("centre");
                var point=new Vec3d(centre.get(0).getAsDouble(),centre.get(1).getAsDouble(),centre.get(2).getAsDouble());if(!Double.isFinite(point.x+point.y+point.z)||point.lengthSquared()>64)throw new IllegalArgumentException("Native shutter centre");
                var cells=new ArrayList<BlockPos>();for(var cell:row.getAsJsonArray("cells"))cells.add(position(cell.getAsJsonArray(),0));
                if(cells.isEmpty()||cells.size()>32||new HashSet<>(cells).size()!=cells.size())throw new IllegalArgumentException("Native shutter cell budget");
                var profile=new Profile(position(row.getAsJsonArray("anchor"),0),point,List.copyOf(cells));if(!cells.contains(profile.anchor))throw new IllegalArgumentException("Native shutter anchor");put(profiles,rotation,profile);
            }
            if(document.getAsJsonArray("seeds").size()>100000||document.getAsJsonArray("modes").size()>100000||document.getAsJsonArray("transitions").size()>300000)throw new IllegalArgumentException("Native shutter table budget");
            for(var value:document.getAsJsonArray("seeds")){var row=value.getAsJsonArray();if(row.size()!=5)throw new IllegalArgumentException("Native shutter seed tuple");var key=key(row);visual(key.visual,false);seeds.computeIfAbsent(key.visual,k->new ArrayList<>()).add(new Role(new BlockPos(key.x,key.y,key.z),key.rotation));}
            for(var value:document.getAsJsonArray("modes")){var row=value.getAsJsonArray();if(row.size()!=6)throw new IllegalArgumentException("Native shutter mode tuple");int mode=row.get(5).getAsInt();if(mode<0||mode>1)throw new IllegalArgumentException("Native shutter mode");put(modes,key(row),mode);}
            for(var value:document.getAsJsonArray("transitions")){var row=value.getAsJsonArray();if(row.size()!=7)throw new IllegalArgumentException("Native shutter transition tuple");int mode=row.get(5).getAsInt();if(mode<0||mode>1)throw new IllegalArgumentException("Native shutter mode");put(transitions,new Step(key(row),mode),visual(row.get(6).getAsInt(),true));}
            seeds.replaceAll((k,v)->List.copyOf(new LinkedHashSet<>(v)));
            return new Data(Map.copyOf(profiles),Map.copyOf(seeds),Map.copyOf(modes),Map.copyOf(transitions));
        }catch(IOException|RuntimeException failure){throw new IllegalStateException("Cannot load native shutter definitions",failure);}
    }
    public static void initialize(){
        if(Holder.DATA.profiles.isEmpty())throw new IllegalStateException("Native shutter profiles are empty");
        UseBlockCallback.EVENT.register(NativeShutterWindows::use);
        ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->LAST_USE.remove(handler.player.getUuid()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server->LAST_USE.clear());
    }
    public static int state(World world,BlockPos root,int rotation){
        var profile=Holder.DATA.profiles.get(rotation);if(profile==null)return -1;var anchor=root.add(profile.anchor);
        if(!world.isChunkLoaded(anchor))return -1;
        return Holder.DATA.modes.getOrDefault(key(NativeVisuals.index(world,anchor),root.subtract(anchor),rotation),-1);
    }
    private static List<Change> plan(World world,BlockPos root,int rotation,int mode){
        var profile=Holder.DATA.profiles.get(rotation);if(profile==null||mode<0)return null;var changes=new ArrayList<Change>();
        for(var offset:profile.cells){var pos=root.add(offset);
            if(pos.getY()<world.getBottomY()||pos.getY()>=world.getTopY()||!world.isChunkLoaded(pos)||world.getBlockEntity(pos)!=null)return null;
            int before=NativeVisuals.index(world,pos);var block=world.getBlockState(pos);
            if(before<0&&!block.isAir()||before>=0&&!block.equals(NativeGridCatalog.state(before)))return null;
            if(NativeVisuals.data(world.getChunk(pos)).forcedWater(pos))return null;
            Integer after=Holder.DATA.transitions.get(new Step(key(before,root.subtract(pos),rotation),mode));if(after==null)return null;
            if(after<0&&before>=0){var cell=NativeGridCatalog.cell(before);if(!cell.collision().isEmpty()||!cell.culling().isEmpty()||!cell.climbing().isEmpty()||!cell.fluid().isEmpty()||cell.optics().opacity()!=0||cell.optics().luminance()!=0||!cell.localFunction().isEmpty())return null;}
            if(after!=before)changes.add(new Change(pos.toImmutable(),before,after));
        }
        return List.copyOf(changes);
    }
    public static boolean complete(World world,BlockPos root,int rotation){return plan(world,root,rotation,state(world,root,rotation))!=null;}
    private static Selected selected(World world,BlockHitResult hit){
        int visual=NativeVisuals.index(world,hit.getBlockPos());var roles=Holder.DATA.seeds.get(visual);if(roles==null)return null;
        Selected selected=null;double distance=Double.POSITIVE_INFINITY;
        for(var role:roles){var root=hit.getBlockPos().add(role.rootOffset);var profile=Holder.DATA.profiles.get(role.rotation);if(profile==null)continue;
            int mode=state(world,root,role.rotation);if(mode<0)continue;
            double current=profile.centre.add(root.getX(),root.getY(),root.getZ()).squaredDistanceTo(hit.getPos());
            if(current<distance){distance=current;selected=new Selected(root,role.rotation,mode);}
        }
        return selected;
    }
    private static void write(ServerWorld world,BlockPos pos,int index){
        if(index>=0){if(!NativeVisuals.write(world,pos,index,Block.NOTIFY_ALL))throw new IllegalStateException("Native shutter cell write rejected");}
        else{
            int before=NativeVisuals.index(world,pos);var state=world.getBlockState(pos);NativeVisuals.stage(world,pos,-1);
            try{world.setBlockState(pos,Blocks.AIR.getDefaultState(),Block.NOTIFY_ALL);if(!world.getBlockState(pos).isAir())throw new IllegalStateException("Native shutter air write rejected");NativeVisuals.publish(world,pos);}
            catch(RuntimeException failure){NativeVisuals.stage(world,pos,before);world.setBlockState(pos,state,Block.NOTIFY_ALL|Block.SKIP_DROPS);NativeVisuals.publish(world,pos);throw failure;}
        }
    }
    private static ActionResult use(PlayerEntity player,World world,Hand hand,BlockHitResult hit){
        if(hand!=Hand.MAIN_HAND||player.isSpectator()||player.isSneaking()||player.getMainHandStack().getItem() instanceof dev.dreamwalker.bloodbornedw.tool.BbToolItem)return ActionResult.PASS;
        double reach=InteractionReach.block(player);if(player.getEyePos().squaredDistanceTo(hit.getPos())>(reach+.01)*(reach+.01))return ActionResult.PASS;
        var selected=selected(world,hit);if(selected==null)return ActionResult.PASS;
        if(world.isClient)return ActionResult.SUCCESS;
        var server=(ServerWorld)world;long now=System.nanoTime();var previous=LAST_USE.get(player.getUuid());if(previous!=null&&now-previous<150000000L)return ActionResult.CONSUME;LAST_USE.put(player.getUuid(),now);
        var changes=plan(world,selected.root,selected.rotation,selected.mode);if(changes==null){player.sendMessage(net.minecraft.text.Text.literal("Окно заблокировано"),true);return ActionResult.FAIL;}
        var applied=new ArrayList<Change>();
        try{for(var change:changes){write(server,change.pos,change.after);applied.add(change);}}
        catch(RuntimeException failure){
            Collections.reverse(applied);for(var change:applied)try{write(server,change.pos,change.before);}catch(RuntimeException rollback){failure.addSuppressed(rollback);}
            LoggerFactory.getLogger("DreamwalkerCityRepair").error("Native shutter transaction failed at {}",selected.root,failure);return ActionResult.FAIL;
        }
        world.playSound(null,selected.root,selected.mode==0?SoundEvents.BLOCK_WOODEN_TRAPDOOR_OPEN:SoundEvents.BLOCK_WOODEN_TRAPDOOR_CLOSE,SoundCategory.BLOCKS,.8f,1f);
        return ActionResult.CONSUME;
    }
    public static ItemStack pick(BlockView world,BlockPos pos){
        if(!Holder.DATA.seeds.containsKey(NativeVisuals.index(world,pos)))return ItemStack.EMPTY;
        var block=Registries.BLOCK.get(new Identifier("bloodborne_dw:source_shutter_window"));
        if(!(block instanceof CompositeRootBlock))return ItemStack.EMPTY;
        var stack=new ItemStack(block.asItem());stack.getOrCreateSubNbt("BlockStateTag").putString("variant","1");return stack;
    }
}
