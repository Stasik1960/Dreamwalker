package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(NativePhysicsBlock.class)
public abstract class NativeWindowPickMixin {
    @Inject(method="getPickStack",at=@At("HEAD"),cancellable=true)
    private void dwfix$windowItem(BlockView world,BlockPos pos,BlockState state,CallbackInfoReturnable<ItemStack> cir){
        var stack=NativeShutterWindows.pick(world,pos);if(!stack.isEmpty())cir.setReturnValue(stack);
    }
}
