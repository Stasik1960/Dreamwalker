package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets="dev.dreamwalker.bloodbornedw.composite.CompositeSurfacePlacement",remap=false)
public abstract class SurfacePlacementMixin {
    @Inject(method="align",at=@At("RETURN"),cancellable=true,remap=false)
    private static void dwfix$benchSurface(CompositeSpec spec,BlockState state,NbtCompound payload,
            ItemPlacementContext context,CallbackInfoReturnable<Object> cir){
        cir.setReturnValue(DwSurfacePlacement.align(spec,context,cir.getReturnValue()));
    }
}
