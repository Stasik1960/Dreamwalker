package dev.dreamwalker.bloodbornedw.repair.mixin;

import com.google.gson.*;
import dev.dreamwalker.bloodbornedw.debug.UnifiedCreativeCatalogue;
import dev.dreamwalker.bloodbornedw.repair.CityRepair;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Old ids keep deserializing; the offered catalogue contains the standard lamp. */
@Mixin(UnifiedCreativeCatalogue.class)
public abstract class StandardLanternCatalogueMixin {
    private static final Set<String> RETIRED=load();
    private static Set<String> load(){
        try(var stream=StandardLanternCatalogueMixin.class.getResourceAsStream("/bloodborne_dw/repair/retired-lanterns.json")){
            var rows=JsonParser.parseReader(new InputStreamReader(Objects.requireNonNull(stream),StandardCharsets.UTF_8)).getAsJsonArray();var ids=new HashSet<String>();for(var row:rows)ids.add(row.getAsString());return Set.copyOf(ids);
        }catch(IOException error){throw new IllegalStateException("Lantern catalogue data",error);}
    }
    @Inject(method="canonicalItems",at=@At("RETURN"),cancellable=true,remap=false)
    private static void dwfix$standardItems(CallbackInfoReturnable<List<ItemStack>> cir){
        var result=new ArrayList<ItemStack>();
        for(var stack:cir.getReturnValue()){
            var id=Registries.ITEM.getId(stack.getItem()).toString();if(RETIRED.contains(id))continue;
            if(id.equals("bloodborne_dw:source_street_lamp_post")&&stack.getSubNbt("BlockStateTag")!=null){var variant=stack.getSubNbt("BlockStateTag").getString("variant");if(!variant.isEmpty()&&!variant.equals("0"))continue;}
            result.add(stack);
        }
        if(CityRepair.LANTERN!=null)result.add(new ItemStack(CityRepair.LANTERN));
        if(CityRepair.DARKNESS!=null)result.add(new ItemStack(CityRepair.DARKNESS));
        cir.setReturnValue(List.copyOf(result));
    }
}
