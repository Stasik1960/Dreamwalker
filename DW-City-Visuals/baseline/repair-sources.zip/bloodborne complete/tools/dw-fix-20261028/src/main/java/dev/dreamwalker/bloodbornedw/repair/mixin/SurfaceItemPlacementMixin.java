package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.item.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

@Mixin(CompositeItem.class)
public abstract class SurfaceItemPlacementMixin {
    @ModifyVariable(method="place",at=@At("HEAD"),argsOnly=true,ordinal=0)
    private ItemPlacementContext dwfix$benchContext(ItemPlacementContext context){
        return DwSurfacePlacement.context(((BlockItem)(Object)this).getBlock(),context);
    }
}
