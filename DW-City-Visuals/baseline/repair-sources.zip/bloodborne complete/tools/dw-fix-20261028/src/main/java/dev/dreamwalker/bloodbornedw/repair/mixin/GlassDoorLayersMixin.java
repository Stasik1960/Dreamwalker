package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

/** Retain the existing mesh/cache and route only this mixed-material door's frame to cutout. */
@Mixin(value=CompositeWorldMesh.class,remap=false)
public abstract class GlassDoorLayersMixin {
    @Redirect(method="render",at=@At(value="INVOKE",target="Lnet/minecraft/client/render/VertexConsumerProvider;getBuffer(Lnet/minecraft/client/render/RenderLayer;)Lnet/minecraft/client/render/VertexConsumer;",remap=true))
    private static VertexConsumer dw$glassLayers(VertexConsumerProvider consumers,RenderLayer layer,
            CompositeBlockEntity entity,CompositeRootBlock block,BlockState state,NbtCompound payload,
            MatrixStack matrices,VertexConsumerProvider originalConsumers,int overlay) {
        String id=block.spec.id.getPath();
        if(!id.equals("source_birch_grille_door")&&!id.equals("source_shutter_window")) return consumers.getBuffer(layer);
        var atlas=MinecraftClient.getInstance().getBakedModelManager().getAtlas(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE);
        var glass=atlas.getSprite(new Identifier("bloodborne_dw",id.equals("source_shutter_window")?"block/interactions/shutter_glass":"block/remaining/source/minecraft/block/addon/window_3"));
        return new MaterialConsumer(consumers,glass);
    }

    private static final class MaterialConsumer implements VertexConsumer {
        private final VertexConsumerProvider consumers;
        private final Sprite glass;
        private RenderLayer active;
        private VertexConsumer output;
        private double x,y,z;
        private int r=255,g=255,b=255,a=255,ou,ov,lu,lv;
        private float u,v,nx,ny,nz;
        MaterialConsumer(VertexConsumerProvider consumers,Sprite glass){this.consumers=consumers;this.glass=glass;}
        @Override public VertexConsumer vertex(double x,double y,double z){this.x=x;this.y=y;this.z=z;return this;}
        @Override public VertexConsumer color(int r,int g,int b,int a){this.r=r;this.g=g;this.b=b;this.a=a;return this;}
        @Override public VertexConsumer texture(float u,float v){this.u=u;this.v=v;return this;}
        @Override public VertexConsumer overlay(int u,int v){ou=u;ov=v;return this;}
        @Override public VertexConsumer light(int u,int v){lu=u;lv=v;return this;}
        @Override public VertexConsumer normal(float x,float y,float z){nx=x;ny=y;nz=z;return this;}
        @Override public void next(){
            boolean isGlass=u>=glass.getMinU()&&u<=glass.getMaxU()&&v>=glass.getMinV()&&v<=glass.getMaxV();
            var layer=isGlass?RenderLayer.getTranslucent():RenderLayer.getCutout();
            if(active!=layer){active=layer;output=consumers.getBuffer(layer);}
            output.vertex(x,y,z).color(r,g,b,a).texture(u,v).overlay(ou,ov).light(lu,lv).normal(nx,ny,nz).next();
        }
        @Override public void fixedColor(int r,int g,int b,int a){color(r,g,b,a);}
        @Override public void unfixColor(){}
    }
}
