package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.BenchSeatEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BenchSeatEntity.class)
public abstract class BenchSeatHeightMixin {
    @Inject(method="getMountedHeightOffset",at=@At("RETURN"),cancellable=true)
    private void dwfix$raisePassenger(CallbackInfoReturnable<Double> cir){cir.setReturnValue(cir.getReturnValueD()+.15);}
}
