package dev.dreamwalker.bloodbornedw.composite;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.world.World;

/** Relative retained geometry identities; no coordinate registry, saved data or idle ticks. */
public final class DwNativeBenches {
    public static final String PREFIX="native-bench/";
    private record Cell(BlockPos offset,int visual){}
    private record Contact(Vec3d offset,float yaw){}
    private record Layout(String id,List<Cell> surface,List<Cell> triggers,List<Contact> seats){}
    private record Candidate(Layout layout,BlockPos offset){}
    private record Data(Map<String,Layout> layouts,Map<Integer,List<Candidate>> index){}
    private static final class Holder {static final Data DATA=load();}
    private DwNativeBenches(){}
    private static List<Cell> cells(JsonArray rows,int maximum){
        if(rows.size()==0||rows.size()>maximum)throw new IllegalArgumentException("Bench cell count");
        var result=new ArrayList<Cell>();
        for(var value:rows){var row=value.getAsJsonArray();if(row.size()!=4)throw new IllegalArgumentException("Bench cell tuple");
            int x=row.get(0).getAsInt(),y=row.get(1).getAsInt(),z=row.get(2).getAsInt(),visual=row.get(3).getAsInt();
            if(Math.abs(x)>8||Math.abs(y)>8||Math.abs(z)>8||visual<0||visual>=NativeGridCatalog.cells().size())throw new IllegalArgumentException("Bench cell bounds");
            result.add(new Cell(new BlockPos(x,y,z),visual));}
        return List.copyOf(result);
    }
    private static Data load(){
        try(var input=DwNativeBenches.class.getResourceAsStream("/bloodborne_dw/repair/native-benches.json")){
            if(input==null)throw new IllegalArgumentException("Missing native bench definitions");
            var root=JsonParser.parseReader(new InputStreamReader(input,StandardCharsets.UTF_8)).getAsJsonObject();
            if(root.get("schemaVersion").getAsInt()!=1||!NativeVisualLayout.acceptsCatalog(root.get("catalogSha256").getAsString()))throw new IllegalArgumentException("Native bench catalog/schema mismatch");
            var layouts=new HashMap<String,Layout>();var index=new HashMap<Integer,List<Candidate>>();
            var rows=root.getAsJsonArray("templates");if(rows.size()>256)throw new IllegalArgumentException("Bench layout count");
            for(var value:rows){var row=value.getAsJsonObject();String id=row.get("id").getAsString();
                if(!id.matches("[0-9a-f]{16}"))throw new IllegalArgumentException("Bench identity");
                var seats=new ArrayList<Contact>();
                for(var item:row.getAsJsonArray("seats")){var seat=item.getAsJsonArray();if(seat.size()!=4)throw new IllegalArgumentException("Bench contact tuple");
                    double x=seat.get(0).getAsDouble(),y=seat.get(1).getAsDouble(),z=seat.get(2).getAsDouble();float yaw=seat.get(3).getAsFloat();
                    if(!Double.isFinite(x+y+z)||!Float.isFinite(yaw)||Math.abs(x)>8||Math.abs(y)>8||Math.abs(z)>8)throw new IllegalArgumentException("Bench contact bounds");
                    seats.add(new Contact(new Vec3d(x,y,z),yaw));}
                if(seats.size()<1||seats.size()>3)throw new IllegalArgumentException("Bench contact count");
                var layout=new Layout(id,cells(row.getAsJsonArray("cells"),64),cells(row.getAsJsonArray("triggers"),128),List.copyOf(seats));
                if(layouts.put(id,layout)!=null)throw new IllegalArgumentException("Duplicate bench layout");
                for(var cell:layout.triggers)index.computeIfAbsent(cell.visual,k->new ArrayList<>()).add(new Candidate(layout,cell.offset));
            }
            index.replaceAll((k,v)->List.copyOf(v));return new Data(Map.copyOf(layouts),Map.copyOf(index));
        }catch(IOException|RuntimeException e){throw new IllegalStateException("Cannot read native bench layouts",e);}
    }
    private static boolean matches(World world,BlockPos root,Layout layout){
        for(var cell:layout.surface){var pos=root.add(cell.offset);
            if(!world.isChunkLoaded(pos)||NativeVisuals.index(world,pos)!=cell.visual)return false;}
        return true;
    }
    public static List<BenchSeating.Target> targets(World world,BlockPos cell){
        if(!world.isChunkLoaded(cell))return List.of();
        var candidates=Holder.DATA.index.get(NativeVisuals.index(world,cell));if(candidates==null)return List.of();
        var found=new LinkedHashMap<String,BenchSeating.Target>();
        for(var candidate:candidates){var root=cell.subtract(candidate.offset);var layout=candidate.layout;
            if(!matches(world,root,layout))continue;
            String identity=PREFIX+layout.id,key=identity+"/"+root.asLong();
            if(found.containsKey(key))continue;
            var seats=new ArrayList<BenchSeating.Point>();
            for(var contact:layout.seats)seats.add(new BenchSeating.Point(contact.offset.add(root.getX(),root.getY(),root.getZ()),contact.yaw));
            found.put(key,new BenchSeating.Target(root,identity,seats));
        }
        return List.copyOf(found.values());
    }
    public static boolean valid(World world,BlockPos root,String identity){
        if(!identity.startsWith(PREFIX))return false;
        var layout=Holder.DATA.layouts.get(identity.substring(PREFIX.length()));
        return layout!=null&&matches(world,root,layout);
    }
}
