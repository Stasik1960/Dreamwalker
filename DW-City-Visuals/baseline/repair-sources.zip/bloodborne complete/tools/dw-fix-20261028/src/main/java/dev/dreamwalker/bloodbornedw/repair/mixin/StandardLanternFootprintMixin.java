package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import dev.dreamwalker.bloodbornedw.runtime.ObjectGeometry.*;
import java.util.Map;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** The canonical lamp uses its source's existing fitted physics and aim, including shifted mounts. */
@Mixin(value=CompositeSourceShift.class,remap=false)
public abstract class StandardLanternFootprintMixin {
    @Inject(method="footprint",at=@At("HEAD"),cancellable=true,remap=false)
    private static void dwfix$sourceLampFootprint(CompositeSpec spec,BlockState state,NbtCompound payload,CallbackInfoReturnable<Map<Cell,Footprint>> cir){
        if(!spec.id.toString().equals("bloodborne_dw:source_standard_lantern"))return;
        var source=(CompositeRootBlock)Registries.BLOCK.get(new Identifier("bloodborne_dw:source_lantern"));
        var reference=source.getDefaultState().with(CompositeRootBlock.VARIANT,0)
            .with(CompositeRootBlock.ROTATION,state.get(CompositeRootBlock.ROTATION))
            .with(CompositeRootBlock.OPEN,state.get(CompositeRootBlock.OPEN))
            .with(CompositeRootBlock.PROFILE,state.get(CompositeRootBlock.PROFILE));
        cir.setReturnValue(CompositeSourceShift.footprint(source.spec,reference,payload));
    }
}
