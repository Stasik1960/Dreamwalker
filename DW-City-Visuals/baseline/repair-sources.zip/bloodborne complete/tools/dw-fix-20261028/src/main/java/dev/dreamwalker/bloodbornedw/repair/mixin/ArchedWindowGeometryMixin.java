package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Frozen arched tops use the same complete source mesh as a freshly placed top. */
@Mixin(StaticArchitectureGeometry.class)
public abstract class ArchedWindowGeometryMixin {
    @Inject(method="visible",at=@At("HEAD"),cancellable=true,remap=false)
    private static void dwfix$completeTop(StaticArchitectureCatalog.Pose pose,int part,BlockRenderView world,BlockPos root,CallbackInfoReturnable<BakedModel> cir){
        if(pose.block().spec.id.toString().equals("bloodborne_dw:source_warped_trapdoor_open_2"))
            cir.setReturnValue(MinecraftClient.getInstance().getBakedModelManager().getModel(pose.parts().get(part).model()));
    }
}
