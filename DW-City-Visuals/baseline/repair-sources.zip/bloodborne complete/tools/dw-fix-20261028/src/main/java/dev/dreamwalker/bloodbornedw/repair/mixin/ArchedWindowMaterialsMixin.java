package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import java.util.function.Function;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.*;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keep the arched frame's alpha mask in cutout while its glazing remains translucent. */
@Mixin(value=StaticArchitectureClient.class,remap=false)
public abstract class ArchedWindowMaterialsMixin {
    @Inject(method="renderLayered",at=@At("HEAD"),cancellable=true,remap=false)
    private static void dwfix$archMaterials(BlockModelRenderer renderer,BlockRenderView world,BlockState state,BlockPos pos,MatrixStack matrices,Function<RenderLayer,VertexConsumer> factory,int overlay,CallbackInfo ci){
        if(!(state.getBlock() instanceof StaticArchitectureBlock))return;
        boolean arch=StaticArchitectureCatalog.recipe(state).fragments().stream().anyMatch(f->f.pose().block().spec.id.getPath().equals("source_warped_trapdoor_open_2"));
        if(!arch)return;
        StaticArchitectureClient.render(renderer,world,state,pos,matrices,new Materials(factory,StaticArchitectureClient.layer(state)),overlay);ci.cancel();
    }
    private static final class Materials implements VertexConsumer {
        private final Function<RenderLayer,VertexConsumer> factory;private final VertexConsumer fallback;private VertexConsumer frame,solid;
        Materials(Function<RenderLayer,VertexConsumer> factory,RenderLayer original){this.factory=factory;fallback=factory.apply(original);}
        @Override public void quad(MatrixStack.Entry matrix,BakedQuad quad,float[] brightness,float r,float g,float b,int[] lights,int overlay,boolean useColor){
            VertexConsumer target=fallback;
            if(quad.getSprite().getContents().getId().getPath().equals("block/remaining/source/minecraft/block/addon/spirelamp_0017"))target=frame==null?frame=factory.apply(RenderLayer.getCutout()):frame;
            else if(StaticArchitectureGeometry.opaqueQuad(quad))target=solid==null?solid=factory.apply(RenderLayer.getSolid()):solid;
            target.quad(matrix,quad,brightness,r,g,b,lights,overlay,useColor);
        }
        @Override public VertexConsumer vertex(double x,double y,double z){fallback.vertex(x,y,z);return this;}
        @Override public VertexConsumer color(int r,int g,int b,int a){fallback.color(r,g,b,a);return this;}
        @Override public VertexConsumer texture(float u,float v){fallback.texture(u,v);return this;}
        @Override public VertexConsumer overlay(int u,int v){fallback.overlay(u,v);return this;}
        @Override public VertexConsumer light(int u,int v){fallback.light(u,v);return this;}
        @Override public VertexConsumer normal(float x,float y,float z){fallback.normal(x,y,z);return this;}
        @Override public void next(){fallback.next();}
        @Override public void fixedColor(int r,int g,int b,int a){fallback.fixedColor(r,g,b,a);}
        @Override public void unfixColor(){fallback.unfixColor();}
    }
}
