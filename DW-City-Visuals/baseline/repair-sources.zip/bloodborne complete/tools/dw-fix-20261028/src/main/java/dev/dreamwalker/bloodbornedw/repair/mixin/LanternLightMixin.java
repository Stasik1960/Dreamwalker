package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import net.minecraft.block.AbstractBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ImportedSourceLightingV127.class)
public abstract class LanternLightMixin {
    @Inject(method="settings",at=@At("RETURN"),cancellable=true,remap=false)
    private static void dwfix$lampLight(CompositeSpec spec,AbstractBlock.Settings settings,CallbackInfoReturnable<AbstractBlock.Settings> cir){
        if(spec.id.toString().equals("bloodborne_dw:source_standard_lantern"))
            cir.setReturnValue(cir.getReturnValue().luminance(state->state.get(CompositeRootBlock.OPEN)?0:15));
    }
}
