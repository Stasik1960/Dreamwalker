package dev.dreamwalker.bloodbornedw.composite;

import dev.dreamwalker.bloodbornedw.architecture.NoCollidePlacement;
import dev.dreamwalker.bloodbornedw.architecture.mount.VerticalMount;
import net.minecraft.block.Block;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.nbt.*;
import net.minecraft.util.math.Direction;

/** Ordinary bench feet follow the clicked floor surface, including replaceable helper cells. */
public final class DwSurfacePlacement {
    private DwSurfacePlacement(){}
    private static boolean bench(CompositeSpec spec){return spec.id.getNamespace().equals("bloodborne_dw")&&spec.id.getPath().startsWith("source_hold_bench");}
    private static boolean window(CompositeSpec spec){return spec.id.toString().equals("bloodborne_dw:source_shutter_window");}
    private static boolean normal(CompositeSpec spec,ItemPlacementContext context){return (window(spec)||bench(spec)&&context.getSide()==Direction.UP)&&!NoCollidePlacement.armed(context.getPlayer());}
    public static ItemPlacementContext context(Block block,ItemPlacementContext context){
        if(!(block instanceof CompositeRootBlock root)||!normal(root.spec,context))return context;
        var anchor=NoCollidePlacement.surfaceAnchor(context);if(anchor.equals(context.getBlockPos()))return context;
        return new ItemPlacementContext(context){
            @Override public net.minecraft.util.math.BlockPos getBlockPos(){return anchor==null?super.getBlockPos():anchor;}
            @Override public boolean canPlace(){return getWorld().getBlockState(getBlockPos()).canReplace(this);}
        };
    }
    public static Object align(CompositeSpec spec,ItemPlacementContext context,Object result){
        if(!normal(spec,context))return result;
        var placed=(CompositeSurfacePlacement.Placement)result;var state=placed.state();
        var bounds=spec.variant(state).visible();
        java.util.List<CompositeSpec.Bounds> boxes=bounds==null?spec.pose(state).selection():java.util.List.of(bounds);
        if(boxes.isEmpty())return result;
        NbtCompound payload=placed.payload()==null?new NbtCompound():placed.payload().copy();
        var previous=CompositeSourceShift.local(payload);int yaw=state.get(CompositeRootBlock.ROTATION);
        var world=previous.rotate(yaw);var face=context.getSide();boolean positive=face.getDirection()==Direction.AxisDirection.POSITIVE;
        double boundary=positive?Double.POSITIVE_INFINITY:Double.NEGATIVE_INFINITY;
        double mount=payload.getDouble("MountY")+payload.getDouble(VerticalMount.KEY);
        for(var box:boxes)for(double x:new double[]{box.from().x(),box.to().x()})for(double y:new double[]{box.from().y(),box.to().y()})for(double z:new double[]{box.from().z(),box.to().z()}){
            var point=new CompositeSourceShift.Shift(x/16-.5,y/16,z/16-.5).rotate(yaw);
            double coordinate=switch(face.getAxis()){case X->.5+point.x()+world.x();case Y->point.y()+world.y()+mount;case Z->.5+point.z()+world.z();};
            boundary=positive?Math.min(boundary,coordinate):Math.max(boundary,coordinate);
        }
        var hit=context.getHitPos();var origin=context.getBlockPos();
        double target=switch(face.getAxis()){case X->hit.x-origin.getX();case Y->hit.y-origin.getY();case Z->hit.z-origin.getZ();};
        if(window(spec))target+=positive?1./1024:-1./1024;
        double delta=target-boundary;
        var change=new CompositeSourceShift.Shift(face.getAxis()==Direction.Axis.X?delta:0,face.getAxis()==Direction.Axis.Y?delta:0,face.getAxis()==Direction.Axis.Z?delta:0).rotate(-yaw);
        var shift=new NbtList();shift.add(NbtDouble.of(previous.x()+change.x()));shift.add(NbtDouble.of(previous.y()+change.y()));shift.add(NbtDouble.of(previous.z()+change.z()));payload.put("SourceShift",shift);
        return new CompositeSurfacePlacement.Placement(state,payload);
    }
}
