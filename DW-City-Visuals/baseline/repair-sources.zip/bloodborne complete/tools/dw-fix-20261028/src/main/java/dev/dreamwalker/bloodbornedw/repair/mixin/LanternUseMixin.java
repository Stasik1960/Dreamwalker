package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.util.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

/** Preserve contact sway; ordinary RMB reaches the lamp's normal owner toggle. */
@Mixin(LanternMotion.class)
public abstract class LanternUseMixin {
    @Redirect(method="initialize",at=@At(value="INVOKE",target="Lnet/fabricmc/fabric/api/event/Event;register(Ljava/lang/Object;)V",ordinal=0),remap=false)
    private static void dwfix$ordinaryLampUse(Event<UseBlockCallback> event,Object callback){
        var original=(UseBlockCallback)callback;
        event.register((player,world,hand,hit)->{
            if(hand==Hand.MAIN_HAND&&!player.isSneaking()&&player.getMainHandStack().isEmpty()){
                var owner=CompositeRuntime.target(world,hit.getBlockPos(),player);
                if(owner!=null&&owner.registryId().equals("bloodborne_dw:source_standard_lantern"))return ActionResult.PASS;
            }
            return original.interact(player,world,hand,hit);
        });
    }
}
