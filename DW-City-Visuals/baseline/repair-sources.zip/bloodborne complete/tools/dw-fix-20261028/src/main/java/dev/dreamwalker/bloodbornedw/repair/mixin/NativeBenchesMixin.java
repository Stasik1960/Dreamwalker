package dev.dreamwalker.bloodbornedw.repair.mixin;

import dev.dreamwalker.bloodbornedw.composite.*;
import java.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BenchSeating.class)
public abstract class NativeBenchesMixin {
    @Inject(method="targets",at=@At("RETURN"),cancellable=true,remap=false)
    private static void dwfix$targets(World world,BlockPos cell,CallbackInfoReturnable<List<BenchSeating.Target>> cir){
        var nativeTargets=DwNativeBenches.targets(world,cell);if(nativeTargets.isEmpty())return;
        var all=new ArrayList<>(cir.getReturnValue());all.addAll(nativeTargets);cir.setReturnValue(List.copyOf(all));
    }
    @Inject(method="valid",at=@At("HEAD"),cancellable=true,remap=false)
    private static void dwfix$valid(World world,BlockPos root,String identity,CallbackInfoReturnable<Boolean> cir){
        if(identity.startsWith(DwNativeBenches.PREFIX))cir.setReturnValue(DwNativeBenches.valid(world,root,identity));
    }
}
