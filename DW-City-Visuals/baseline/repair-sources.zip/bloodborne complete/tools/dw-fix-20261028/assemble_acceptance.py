"""Bind the completed functional checks and persisted lighting into one honest pre-shadow record."""
import argparse,json
from pathlib import Path
from prepare_workspace import RUN,write,sha
from compare_performance import accepted_performance

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))

def main():
    p=argparse.ArgumentParser();p.add_argument('--world',required=True,type=Path);p.add_argument('--candidate',required=True,type=Path);p.add_argument('--bench-run');args=p.parse_args();expected=sha(args.candidate);sources=[];reference=expected;floor_reference=expected
    if args.bench_run:
        forward=read(RUN/'v22-byte-bound-change.json');assert forward['status']=='BENCH_SURFACE_ONLY_CHANGE_SCOPE_PASS' and forward['candidateSha256']==expected
        assert forward['allExistingRuntimeClassesAndPngByteIdentical'] and forward['allOldCatalogAndPhysicsPrefixesIdentical'] and forward['windowRecipesAndOtherVisualRepairsUnchanged'];floor_reference=forward['referenceSha256']
        extra=RUN/'bench-scope-closure.json';closed=read(extra);assert closed['status']=='COMPLETED_AT_USER_REQUESTED_SCOPE' and closed['candidateSha256']==expected and closed['run']==args.bench_run and closed['clientCrawlViewsReviewed']>=1;assert sha(RUN/'runs'/args.bench_run/'client/evidence/qa.json')==closed['clientRecordSha256'];sources.append(dict(path=str(extra),sha256=sha(extra)))
        visual=read(RUN/'bench-surface-visual-review.json');assert visual['status']=='PASS' and visual['candidateSha256']==expected and visual['run']==args.bench_run
        contacts=read(RUN/'bench-server-contact-acceptance.json');assert contacts['candidateSha256']==expected and contacts['nativeBenches']==42 and contacts['freshBenches']==6 and contacts['everyBenchHasFreePlankContact']
        server_proof=RUN/'runs'/contacts['run']/'client/evidence/qa.json';assert sha(server_proof)==contacts['sourceQaSha256']
        support=read(RUN/'bench-support-scope.json');assert support['benches']==42 and support['mapCells']==248 and support['blockEntitiesAdded']==0 and support['originalCatalogPrefixUnchanged'] and support['foreignPhysicsRetained']
    if floor_reference!='fe8d8dacf288292c5a208e865c7c635d7b55b198475d0688f8c0bc63cd249385':
        forward=read(RUN/'v20-byte-bound-change.json');assert forward['candidateSha256']==floor_reference and forward['allOtherEntriesByteIdentical']
        assert set(forward['differentEntries'])=={'fabric.mod.json','dev/dreamwalker/bloodbornedw/repair/CityRepair$DarknessFloor.class','assets/bloodborne_dw/blockstates/city_darkness.json'};assert forward['addedEntries']==['assets/bloodborne_dw/models/block/city_darkness.json'];reference=forward['referenceSha256']
        extra=RUN/'runs/floor-final-v20/acceptance.json';assert read(extra)['status']=='PASS' and all(read(extra)['gates'].values());assert read(extra.parent/'receipt.json')['candidateSha256']==floor_reference;sources.append(dict(path=str(extra),sha256=sha(extra)))
    for label in ['scene01-reopen','gallery-glass-and-map','door90001-use-deferred','windows-benches-v8','v18-lighting-final']:
        path=RUN/f'runs/{label}/acceptance.json';d=read(path);assert d['status']=='PASS' and all(d['gates'].values());sources.append(dict(path=str(path),sha256=sha(path)))
    run=RUN/'runs/complete-map-v18';d=read(run/'client/evidence/qa.json');assert read(run/'receipt.json')['candidateSha256']==reference;assert len(d['canonicalLampCycles'])==11 and all(v['status']=='PASS' and v['ordinaryUseCycle'] for v in d['canonicalLampCycles']);assert d['nativeWallTests']['status']=='PASS' and d['archedModelTests']['status']=='PASS';names={v['name'] for v in d['phases']};assert all(f'frozen-arch-rotation-{r}' in names for r in [2,4,6]);assert 'frozen-archtop-sky-front' in names
    live=read(RUN/'runs/v18-lighting-final/client/evidence/qa.json');assert live['lanternTests']['originalSourcePhysicalFootprintAndVoxelShape'] and live['status']=='PASS';assert read(RUN/'runs/v18-lighting-final/receipt.json')['candidateSha256']==reference
    migration=read(RUN/'lamps-standard-stage4-v18/migration-receipt.json');assert migration['runtimeFootprintRepair']['status']=='PERSISTED_EXACT_RUNTIME_SHAPES_PASS' and migration['runtimeFootprintRepair']['verifiedActors']==1287 and migration['runtimeFootprintRepair']['candidateSha256']==reference
    light=read(args.world.parent/'prelight-import-receipt.json');assert light['status']=='PERSISTED_LIGHTING_ONLY_GATE_PASS' and light['blocksOwnershipAndNativeGeometryUnchanged']
    if args.bench_run:
        assert light['chunks']==42
        base_light=read(RUN/'prelit-stage4-v18/prelight-import-receipt.json');assert base_light['status']=='PERSISTED_LIGHTING_ONLY_GATE_PASS' and base_light['chunks']==3058
        assert Path(support['sourceWorld']).resolve()==(RUN/'prelit-stage4-v18/bloodborne').resolve()
        assert Path(light['inputWorld']).resolve()==Path(support['outputWorld']).resolve()
        assert all(v['status']=='ALL_UNRELATED_BLOCKS_ENTITIES_NATIVE_ENTRIES_AND_CHUNK_DATA_IDENTICAL' for v in support['semanticGates'])
    else:assert light['chunks']==3058
    unchanged=read(RUN/'v18-unchanged-accepted-runtime.json');assert all(unchanged['entries'].values()) and unchanged['darknessFloor']['methodInstructionsIdentical']
    floor=read(RUN/'floor-verification.json');assert floor['status']=='PASS' and floor['changedBlocks']==747136 and floor['zeroNewBlockEntities']
    dead=read(RUN/'task13-dead-wrapper-proof.json');assert dead['allFourPersistedLedgerCellsAndRootMembershipChecked'] and dead['sourceNativeMeshPhysicsAndOpticsUnchanged']
    if light.get('heightmapCacheReceipt'):
        heightmap_path=args.world.parent/light['heightmapCacheReceipt'];heightmaps=read(heightmap_path)
        assert heightmaps['status']=='PERSISTED_HEIGHTMAP_ONLY_GATE_PASS' and heightmaps['candidateSha256']==expected
        assert Path(heightmaps['outputWorld']).resolve()==args.world.resolve() and heightmaps['allOtherChunkFieldsAndUntouchedCompressedPayloadsIdentical']
        assert sha(RUN/'runs'/heightmaps['sourceRun']/'client/evidence/qa.json')==heightmaps['sourceQaSha256']
        sources.append(dict(path=str(heightmap_path),sha256=sha(heightmap_path)))
    performance_ok=bool(accepted_performance(expected,args.world))
    result=dict(status='PRE_SHADOW_TASKS_ACCEPTED' if performance_ok else 'FUNCTIONAL_VISUAL_OWNERSHIP_AND_LIGHTING_GATES_PASS_PERFORMANCE_PENDING',candidateSha256=expected,world=str(args.world.resolve()),floorBlocks=747136,trimmedCells=24419,inertCellsRemoved=42891,nativeBenches=42,nativeShutterWindows=457,standardLanterns=1231,newPosts=56,runtimeOwnerFootprintsChecked=1287,normalLanternSourcePhysicsPreserved=True,ordinaryMapLanternCyclesPassed=11,archedWindowRotationsReviewed=[0,2,4,6],lightChunks=3058,evidence=sources,knownTestHarnessCorrection='An old raw-coordinate check ignored the established 1/16 VoxelShape quantization; the corrected source-to-source physical comparison passed in v18-lighting-final.',globalAngularShadowWorkStarted=False,performanceAccepted=performance_ok,githubModified=False)
    write(RUN/'pre-shadow-task-acceptance.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':main()
