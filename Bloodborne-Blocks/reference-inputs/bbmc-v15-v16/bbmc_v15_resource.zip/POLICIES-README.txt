[ POLICIES ]
Schematics / Maps
　Things I'm not okay with:

　　□ I DO NOT CONDONE Public access of Maps/Schematics due to downloading and stealing of the assets concern.
　　　To blatantly disregard the fact that World Stealing Programs exist would be arrogant.
　　□ I DO NOT CONDONE others to make money off of my gothic schematics, via reselling, using on publics servers with monetization incentives.
　　　I did not make the Maps/Schematics to be used commerically, this included but not limited to; Marketplace, Public Servers, Mods, & other forms of monetization methods.
　　□ I DO NOT CONDONE editing without making a clear difference and distinction from the original assets and taking credit without permission.
　　　I've worked hard to get to my skill level to where it's at within Gothic design in Minecraft. I can certainly tell you it wasn't from un-creatively editing others builds and taking credit from the original creators. Studying real life architecture terminology and gaining an understanding of Minecraft building tips/tricks grants a far better insight into the processes involved in creative creation.

　Things I am okay with:

　　◼ Private use of my schematics on worlds (not publicly open). 
　　　Mainly concerned with public access not preventing bad actors from joining and stealing/redistributing the content.
　　◼ Learning from and growing an understanding of gothic architecture via my Minecraft stylization of my builds is always welcomed.
　　　Knowledge is power and growing the gothic community within Minecraft has always been a passion of mine.
　　◼ Showcasing builds in projects via public social media, just make sure to give credit when applicable.
　　　@_Potomy_ and I may even like or share it 😉
　　◼ Reimagining them in a creative way that does not infringe on the original design.
　　　I take pride in coming up with my original designs and would love to see reimagining while not blatantly just copying the builds.

Bloodborne x Minecraft / Mods
　Things I'm not okay with:

　　□ I DO NOT CONDONE Public access of Maps/Schematics due to downloading and stealing of the assets concern:
　　　- To blatantly disregard the fact that World Stealing Programs exist would be arrogant. Also the mod is not made with public access in mind, it's solely designed for a single-player/co-op experience
　　□ I DO NOT CONDONE any form of monetization with the Mod inside and outside of Minecraft's Game Engine:
　　　- You wouldn't steal assets and republish them for sale of an official game, so why would anyone think it's alright to do with this mod?
　　□ I DO NOT CONDONE any editing or re-using my models, builds, sounds, animations, code, &  texture pack. Essentially all files included in the mod ARE NOT TO be reused in any manner not approved by me:
　　　- This mod and bloodborne map recreation has been my blood sweat and tears of over many years of my life. I've done this so all can experience and enjoy this once in a lifetime opportunity that my team and I have created. This has been done at the expense of many man hours, creative talent, and costly development. Please respect all the hard work that has been to made for this to be possible and my wishes to make an experience worth the Hunters Journey.
