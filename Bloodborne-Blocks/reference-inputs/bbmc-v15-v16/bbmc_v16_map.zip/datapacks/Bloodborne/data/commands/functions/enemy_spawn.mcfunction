execute run summon bloodborne:scourge_beast 329 30.5 -836

execute run summon bloodborne:huntsman_a 247 39.5 -905

execute run summon bloodborne:executioner 293 40.5 -906

execute run summon bloodborne:huntsman_c 276 61.5 -930

execute run summon bloodborne:huntsman_b 265 48.5 -968
execute run summon bloodborne:huntsman_a 268 48.5 -970
execute run summon bloodborne:huntsman_c 262 48.5 -970

execute run summon bloodborne:huntsman_a 268 48.5 -946
execute run summon bloodborne:huntsman_c 271 48.5 -948
execute run summon bloodborne:huntsman_b 268 48.5 -951

execute run summon bloodborne:huntsman_d 267 48.5 -1012
execute run summon bloodborne:huntsman_a 262 48.5 -1022
execute run summon bloodborne:huntsman_b 262 48.5 -1025

execute run summon bloodborne:huntsman_a 151 52.5 -1050
execute run summon bloodborne:huntsman_d 183 53.5 -1011
execute run summon bloodborne:rabid_dog 168 48.5 -1016
execute run summon bloodborne:huntsman_d 168 48.5 -1028
execute run summon bloodborne:huntsman_c 181 48.5 -1032
execute run summon bloodborne:huntsman_a 193 48.5 -1027
execute run summon bloodborne:huntsman_b 191 48.5 -1023
execute run summon bloodborne:huntsman_a 164 52.5 -1006
execute run summon bloodborne:huntsman_b 167 52.5 -1004

execute run summon bloodborne:brick_troll 133 48.5 -1028
execute run summon bloodborne:carrion_crow 58 48.5 -1030
execute run summon bloodborne:carrion_crow 56 48.5 -1031
execute run summon bloodborne:carrion_crow 56 48.5 -1029

execute run summon bloodborne:rabid_dog 90 57.5 -1079
execute run summon bloodborne:rabid_dog 92 57.5 -1097
execute run summon bloodborne:rabid_dog 126 60.5 -1080
execute run summon bloodborne:huntsman_d 124 60.5 -1080
execute run summon bloodborne:huntsman_a 124 60.5 -1082
execute run summon bloodborne:huntsman_b 118 57.5 -1080

execute run summon bloodborne:scourge_beast 146 75.5 -1030
execute run summon bloodborne:scourge_beast 137 74.5 -1032
execute run summon bloodborne:brick_troll 140 74.5 -938
execute run summon bloodborne:carrion_crow 141 74.5 -939
execute run summon bloodborne:carrion_crow 137 74.5 -938
execute run summon bloodborne:carrion_crow 140 74.5 -933

execute run summon bloodborne:huntsman_wheelchair 176 58 -990

execute run summon bloodborne:huntsman_a 209 62.5 -962

execute run summon bloodborne:brick_troll 143 47.5 -944
execute run summon bloodborne:brick_troll 126 47.5 -945

execute run summon bloodborne:rabid_dog 68 47.5 -992
execute run summon bloodborne:rabid_dog 52 42.5 -983
execute run summon bloodborne:rabid_dog 41 42.5 -959
execute run summon bloodborne:rabid_dog 4 42.5 -980
execute run summon bloodborne:rabid_dog 35 42.5 -991

execute run summon bloodborne:large_huntsman -62 25.5 -994
execute run summon bloodborne:huntsman_d -33 15.5 -1018
execute run summon bloodborne:large_huntsman -37 15.5 -1040
execute run summon bloodborne:large_huntsman -63 15.5 -1050
execute run summon bloodborne:large_huntsman -49 15.5 -1064
execute run summon bloodborne:huntsman_d -33 15.5 -1066
execute run summon bloodborne:small_rat -51 1.5 -1012
execute run summon bloodborne:small_rat -49 1.5 -1006
execute run summon bloodborne:small_rat -38 5.5 -1024
execute run summon bloodborne:small_rat -40 5.5 -1021
execute run summon bloodborne:small_rat -40 5.5 -1051
execute run summon bloodborne:small_rat -59 5.5 -1035
execute run summon bloodborne:small_rat -60 5.5 -1038
execute run summon bloodborne:giant_rat -50 1.5 -1004

execute run summon bloodborne:huntsman_d -115 15.5 -1092
execute run summon bloodborne:huntsman_d -91 15.5 -1095
execute run summon bloodborne:huntsman_d -84 15.5 -1097
execute run summon bloodborne:large_huntsman -114 15.5 -1071
execute run summon bloodborne:carrion_crow -27 15.5 -1107
execute run summon bloodborne:carrion_crow -11 15.5 -1105
execute run summon bloodborne:carrion_crow -2 15.5 -1106

execute run summon bloodborne:carrion_crow -13 35.5 -1053
execute run summon bloodborne:carrion_crow -12 35.5 -1051
execute run summon bloodborne:carrion_crow -8 35.5 -1054
execute run summon bloodborne:carrion_crow -5 35.5 -1050

execute run summon bloodborne:brick_troll 44 35.5 -1057

execute run summon bloodborne:rotted_corpse 31 -4.5 -1096
execute run summon bloodborne:rotted_corpse 24 -4.5 -1097
execute run summon bloodborne:rotted_corpse 27 -4 -1101
execute run summon bloodborne:rotted_corpse 33 -4.5 -1100
execute run summon bloodborne:rotted_corpse 27 -4.5 -1090
execute run summon bloodborne:rotted_corpse 22 -4.5 -1088
execute run summon bloodborne:rotted_corpse 35 -4.5 -1097

execute run summon bloodborne:rotted_corpse 25 -15.5 -1045
execute run summon bloodborne:rotted_corpse 20 -15.5 -1042
execute run summon bloodborne:rotted_corpse 23 -15.5 -1035
execute run summon bloodborne:carrion_crow 25 -8.5 -1028
execute run summon bloodborne:carrion_crow 19 -8.5 -1028
execute run summon bloodborne:carrion_crow 24 -8.5 -968
execute run summon bloodborne:carrion_crow 20 -8.5 -972
execute run summon bloodborne:rotted_corpse 38 -19.5 -999
execute run summon bloodborne:rotted_corpse 18 -19.5 -990
execute run summon bloodborne:rotted_corpse 17 -19.5 -995
execute run summon bloodborne:rotted_corpse 23 -19.5 -995
execute run summon bloodborne:maneater_boar 22 -20.5 -876

execute run summon bloodborne:huntsman_a 20 19.5 -886
execute run summon bloodborne:huntsman_b 23 19.5 -888
execute run summon bloodborne:huntsman_c 22 19.5 -890
execute run summon bloodborne:huntsman_b 20 19.5 -894
execute run summon bloodborne:brick_troll 21 27.5 -830
execute run summon bloodborne:huntsman_c 26 27.5 -833

execute run summon bloodborne:large_huntsman 30 33.5 -796
execute run summon bloodborne:large_huntsman 33 33.5 -794
execute run summon bloodborne:large_huntsman 56 19.5 -1091
execute run summon bloodborne:large_huntsman 109 33.5 -1120
execute run summon bloodborne:large_huntsman 164 33.5 -1084
execute run summon bloodborne:small_rat 138 17.5 -1105
execute run summon bloodborne:small_rat 127 17.5 -1103
execute run summon bloodborne:small_rat 102 17.5 -1111

execute run summon bloodborne:huntsman_a 311 60.5 -1072
execute run summon bloodborne:huntsman_b 314 60.5 -1072
execute run summon bloodborne:rabid_dog 313 60.5 -1068
execute run summon bloodborne:brick_troll 279.5 71 -1081
execute run summon bloodborne:huntsman_wheelchair 240 69 -1067
execute run summon bloodborne:huntsman_c 235 69.5 -1098
execute run summon bloodborne:huntsman_b 238 69.5 -1098

execute run summon bloodborne:carrion_crow 461 45.5 -871
execute run summon bloodborne:carrion_crow 458 47.5 -866
execute run summon bloodborne:carrion_crow 468 45.5 -861
execute run summon bloodborne:carrion_crow 471 47.5 -866