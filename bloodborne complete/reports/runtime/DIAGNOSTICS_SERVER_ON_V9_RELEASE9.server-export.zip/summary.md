# Dreamwalker diagnostics session

Session UUID: 2b2bb879-c590-478a-a45c-d4bbdd3fd7d4
Capture: STOPPED / NO ACTIVE RECORDING; reason: AUTO_DURATION_EXPIRED
Started: 2026-10-08T00:16:20.100946700Z; requested duration: 60 seconds
Observed duration: 60.014 seconds

Events: 8 observed, 8 retained, 0 dropped.
Distinct error keys: 0; repeated occurrences are counted in errors.json.
Object snapshots: 14 retained; full NBT is never captured.

Server ticks: 1201 observed; ticks over 50 ms: 0.
Tick mean / p95 / p99: 0.908 ms / 1.346 ms / 3.896 ms.
Mean/count cover observed ticks; p95/p99 use only the retained window. Tick intervals include Fabric END callbacks. Own hook timings can overlap; they are not unique process CPU cost.

Client telemetry: NOT_MEASURED_NO_CLIENT_BATCHES. Graphics settings and frame intervals are in client-batches.json and the separate local client ZIP with the same UUID.
GPU timing: NOT_MEASURED. CPU render submission and FPS do not determine a block's GPU time or exact load percentage.
All-mod / vanilla chunk / DataTracker / TCP traffic: NOT_MEASURED. Network counters include only instrumented custom-channel payload bytes.
JFR reports actual observed GC pauses when available; MXBean collection time is not an STW pause measurement. Client and integrated server may share one PID: do not add their heap/GC values.

Production version: 0.1.0-prototype.4; SHA256: ed43404d01b2b861a378bdb7dae6d57f36cccd6554461cfaeafbb8bccc82e1d8.
Minecraft/Java/Fabric/mod versions are in environment.json; detailed measurements, retention and unavailable data are in measurements.json. Normal placement refusals are events, not errors. This capture is not manual visual acceptance.
