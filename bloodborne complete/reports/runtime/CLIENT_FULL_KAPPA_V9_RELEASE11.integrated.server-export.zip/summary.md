# Dreamwalker diagnostics session

Session UUID: c9a23ab9-5ad7-4f74-aba1-265ba76c2679
Capture: STOPPED / NO ACTIVE RECORDING; reason: AUTO_DURATION_EXPIRED
Started: 2026-10-08T00:08:12.396696Z; requested duration: 60 seconds
Observed duration: 60.027 seconds

Events: 6 observed, 6 retained, 0 dropped.
Distinct error keys: 0; repeated occurrences are counted in errors.json.
Object snapshots: 1 retained; full NBT is never captured.

Server ticks: 1201 observed; ticks over 50 ms: 1.
Tick mean / p95 / p99: 4.281 ms / 7.674 ms / 17.616 ms.
Mean/count cover observed ticks; p95/p99 use only the retained window. Tick intervals include Fabric END callbacks. Own hook timings can overlap; they are not unique process CPU cost.

Client telemetry: BOUNDED_CLIENT_BATCHES_PRESENT. Graphics settings and frame intervals are in client-batches.json and the separate local client ZIP with the same UUID.
GPU timing: NOT_MEASURED. CPU render submission and FPS do not determine a block's GPU time or exact load percentage.
All-mod / vanilla chunk / DataTracker / TCP traffic: NOT_MEASURED. Network counters include only instrumented custom-channel payload bytes.
JFR reports actual observed GC pauses when available; MXBean collection time is not an STW pause measurement. Client and integrated server may share one PID: do not add their heap/GC values.

Production version: 0.1.0-prototype.4; SHA256: ed43404d01b2b861a378bdb7dae6d57f36cccd6554461cfaeafbb8bccc82e1d8.
Minecraft/Java/Fabric/mod versions are in environment.json; detailed measurements, retention and unavailable data are in measurements.json. Normal placement refusals are events, not errors. This capture is not manual visual acceptance.
