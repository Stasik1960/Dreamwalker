# Dreamwalker diagnostics session

Session UUID: 4f0ebbe5-6303-476e-a76c-a15d1788d5d3
Capture: STOPPED / NO ACTIVE RECORDING; reason: AUTO_DURATION_EXPIRED
Started: 2026-10-08T00:21:57.241125200Z; requested duration: 20 seconds
Observed duration: 20.019 seconds

Events: 6 observed, 6 retained, 0 dropped.
Distinct error keys: 0; repeated occurrences are counted in errors.json.
Object snapshots: 1 retained; full NBT is never captured.

Server ticks: 401 observed; ticks over 50 ms: 0.
Tick mean / p95 / p99: 2.284 ms / 6.425 ms / 11.869 ms.
Mean/count cover observed ticks; p95/p99 use only the retained window. Tick intervals include Fabric END callbacks. Own hook timings can overlap; they are not unique process CPU cost.

Client telemetry: BOUNDED_CLIENT_BATCHES_PRESENT. Graphics settings and frame intervals are in client-batches.json and the separate local client ZIP with the same UUID.
GPU timing: NOT_MEASURED. CPU render submission and FPS do not determine a block's GPU time or exact load percentage.
All-mod / vanilla chunk / DataTracker / TCP traffic: NOT_MEASURED. Network counters include only instrumented custom-channel payload bytes.
JFR reports actual observed GC pauses when available; MXBean collection time is not an STW pause measurement. Client and integrated server may share one PID: do not add their heap/GC values.

Production version: 0.1.0-prototype.4; SHA256: ed43404d01b2b861a378bdb7dae6d57f36cccd6554461cfaeafbb8bccc82e1d8.
Minecraft/Java/Fabric/mod versions are in environment.json; detailed measurements, retention and unavailable data are in measurements.json. Normal placement refusals are events, not errors. This capture is not manual visual acceptance.
