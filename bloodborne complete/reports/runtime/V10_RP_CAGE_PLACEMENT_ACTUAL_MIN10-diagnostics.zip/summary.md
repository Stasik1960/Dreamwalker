# Dreamwalker diagnostics session

Session UUID: a5baf4e4-9c2f-4295-bf82-175fb46bf174
Capture: STOPPED / NO ACTIVE RECORDING; reason: OPERATOR_STOP
Started: 2026-10-08T12:49:40.449389900Z; requested duration: 30 seconds
Observed duration: 0.801 seconds

Events: 3 observed, 3 retained, 0 dropped.
Distinct error keys: 0; repeated occurrences are counted in errors.json.
Object snapshots: 0 retained; full NBT is never captured.

Server ticks: 10 observed; ticks over 50 ms: 2.
Tick mean / p95 / p99: 38.193 ms / 66.010 ms / 66.010 ms.
Mean/count cover observed ticks; p95/p99 use only the retained window. Tick intervals include Fabric END callbacks. Own hook timings can overlap; they are not unique process CPU cost.

Client telemetry: NOT_MEASURED_NO_CLIENT_BATCHES. Graphics settings and frame intervals are in client-batches.json and the separate local client ZIP with the same UUID.
GPU timing: NOT_MEASURED. CPU render submission and FPS do not determine a block's GPU time or exact load percentage.
All-mod / vanilla chunk / DataTracker / TCP traffic: NOT_MEASURED. Network counters include only instrumented custom-channel payload bytes.
JFR reports actual observed GC pauses when available; MXBean collection time is not an STW pause measurement. Client and integrated server may share one PID: do not add their heap/GC values.

Production version: 0.1.0-prototype.5; SHA256: 2cf96fbe771bb44bba4e4e8f320ed65a8bc0a8ffe7a8149b07fbd9ec691592c1.
Minecraft/Java/Fabric/mod versions are in environment.json; detailed measurements, retention and unavailable data are in measurements.json. Normal placement refusals are events, not errors. This capture is not manual visual acceptance.
